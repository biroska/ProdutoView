package poc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class POC {

	private static final Logger logger = LoggerFactory.getLogger(POC.class);

	public static void main(String[] args) {
		
		System.out.println("POC.main()");
		
		String name = "lordofthejars";

		logger.info("Hello from Bar.");

		logger.debug("In bar my name is {}.", name);
		
		logger.error("com.lordofthejars.foo {}", "TESTE....");
		
	}

}
