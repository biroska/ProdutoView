package br.com.bvsistemas.dimof.business;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import br.com.bvsistemas.dimof.business.impl.TipoLogradouroBusinessImpl;
import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.dimof.persistence.dao.TipoLogradouroDAO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

public class TipoLogradouroBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private TipoLogradouroBusinessImpl tipoLogradouroService;

	/**
	 * Testa fluxo do servico listar
	 */
	public void testListar() {

		// Obtem o servi�o
		TipoLogradouroBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockTipoLogradouroDAO = mock(TipoLogradouroDAO.class);

		// Cria uma lista de objetos TipoLogradouroVO
		List<TipoLogradouroVO> lista = new ArrayList<TipoLogradouroVO>();
		
		// Cria um TipoLogradouroVO
		TipoLogradouroVO tipoLogradouro = 
			new TipoLogradouroVO(new IdentifierPK(1));
		tipoLogradouro.setNmTipoLogradouro("Avenida");
		lista.add(tipoLogradouro);

		// Especificacoes da mock para o metodo listar
		mockTipoLogradouroDAO.expects(once()).method("listar").
		withNoArguments().will(returnValue(lista));

		// Injetando a mock no servico
		service.setTipoLogradouroDAO(
				(TipoLogradouroDAO) mockTipoLogradouroDAO.proxy());

		// Executa o servico
		List<TipoLogradouroVO> pList = service.listar();

		assertFalse(pList.isEmpty());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	private TipoLogradouroBusinessImpl getService() {

		if (tipoLogradouroService == null) {
			tipoLogradouroService = new TipoLogradouroBusinessImpl();
		}

		return tipoLogradouroService;
	}
}
