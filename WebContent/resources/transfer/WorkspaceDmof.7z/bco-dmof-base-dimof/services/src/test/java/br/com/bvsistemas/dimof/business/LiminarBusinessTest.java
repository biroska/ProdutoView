package br.com.bvsistemas.dimof.business;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.jmock.core.Constraint;

import br.com.bvsistemas.dimof.business.impl.LiminarBusinessImpl;
import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoLiminarDAO;
import br.com.bvsistemas.dimof.persistence.dao.LiminarDAO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Classe de testes dos servi�os de Liminar.
 * 
 * @author cit.fmarques
 *
 */
public class LiminarBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private LiminarBusinessImpl liminarService;

	/**
	 * Testa fluxo do servico listar.
	 */
	public void testListarSucesso() {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockDao = mock(LiminarDAO.class);

		// Parametros do servico
		IdentifierPK pkPessoa = new IdentifierPK(1);
		String nuLiminar = null;
		BVDate dtInicio = null;
		BVDate dtFim = null;
		BooleanEnum apenasVigentes = null;
		
		// Constraints a ser validado
		Constraint params[] = new Constraint[5];
		params[0] = same(pkPessoa);
		params[1] = same(nuLiminar);
		params[2] = same(dtInicio);
		params[3] = same(dtFim);
		params[4] = same(apenasVigentes);

		// Lista de resultados
		List<LiminarVO> liminares = new ArrayList<LiminarVO>();
		
		// Cria um LiminarVO
		LiminarVO liminar = new LiminarVO(new IdentifierPK(1));
		liminar.setNuLiminar(new Long(1));
		liminar.setDtIniVigencia(new BVDate());
		liminares.add(liminar);

		// Especificacoes da mock para o metodo listar
		mockDao.expects(once()).method("listar").with(params).will(
				returnValue(liminares));

		// Injetando a mock no servico
		service.setLiminarDAO((LiminarDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<LiminarVO> pList = service.listar(pkPessoa, nuLiminar, 
					dtInicio, dtFim, apenasVigentes);
			assertFalse(pList.isEmpty());
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
			fail();
		}
	}

	/**
	 * Testa fluxo do servico listar sem retorno
	 */
	public void testListarSemRetorno() {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockDao = mock(LiminarDAO.class);

		// Parametros do servico
		IdentifierPK pkPessoa = new IdentifierPK(1);
		String nuLiminar = "1";
		BVDate dtInicio = new BVDate();
		BVDate dtFim = new BVDate();
		BooleanEnum apenasVigentes = BooleanEnum.SIM;
		
		// Constraints a ser validado
		Constraint params[] = new Constraint[5];
		params[0] = same(pkPessoa);
		params[1] = same(nuLiminar);
		params[2] = same(dtInicio);
		params[3] = same(dtFim);
		params[4] = same(apenasVigentes);

		// Especificacoes da mock para o metodo listar
		mockDao.expects(once()).method("listar").with(params).will(
				returnValue(null));

		// Injetando a mock no servico
		service.setLiminarDAO((LiminarDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<LiminarVO> pList = service.listar(pkPessoa, nuLiminar, 
					dtInicio, dtFim, apenasVigentes);
			assertTrue(pList == null);
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
			fail();
		}
	}

	/**
	 * Testa fluxo do servico listar com erro
	 */
	public void testListarCamposObrigatoriosNaoPreenchidos() {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockDao = mock(LiminarDAO.class);

		// Parametros do servico
		IdentifierPK pkPessoa = null;
		String nuLiminar = null;
		BVDate dtInicio = null;
		BVDate dtFim = null;
		BooleanEnum apenasVigentes = null;
		
		// Constraints a ser validado
		Constraint params[] = new Constraint[5];
		params[0] = same(pkPessoa);
		params[1] = same(nuLiminar);
		params[2] = same(dtInicio);
		params[3] = same(dtFim);
		params[4] = same(apenasVigentes);

		// Especificacoes da mock para o metodo listar
		mockDao.expects(never()).method("listar").with(params).will(
				returnValue(throwException(
						new CamposObrigatoriosNaoPreenchidosException())));
		// Injetando a mock no servico
		service.setLiminarDAO((LiminarDAO) mockDao.proxy());
		
		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<LiminarVO> pList = service.listar(pkPessoa, nuLiminar, 
					dtInicio, dtFim, apenasVigentes);
			fail();
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
		}
	}

	/**
	 * Testa fluxo do servico consultaLiminar sucesso
	 */
	public void testConsultarLiminarParametroNulo() throws ValidationException {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(LiminarDAO.class);         
		// Parametros do servico	  
		IdentifierPK pkLiminar = null;		
		Constraint params[] = new Constraint[1];
		params[0] = same(pkLiminar);
		// Especificacoes da mock para o metodo consultar
		mockDao.expects(never()).method("consultar").with(params).will(
				returnValue(throwException(
						new ValidationException())));
		// Injetando a mock no servico
		service.setLiminarDAO((LiminarDAO) mockDao.proxy());
		try {
			@SuppressWarnings("unused")
			// Executa o servico
			LiminarVO Liminar = service.consultarLiminar(pkLiminar);
			fail();
		} catch (ValidationException e) {

		}
	}
	/**
	 * Testa fluxo do servico consultaLiminar sucesso
	 */
	public void testConsultarLiminarSucesso() {
		// Obtem o servi�o
		LiminarBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(LiminarDAO.class);         
		// Parametros do servico
		Long pkLong = new Long(1);
		IdentifierPK pk = new IdentifierPK(pkLong);		
		Constraint params[] = new Constraint[1];	
		params[0] = same(pk);
		// Especificacoes da mock para o metodo consultar		
		mockDao.expects(once()).method("consultar").with(params);
		// Injetando a mock no servico
		service.setLiminarDAO((LiminarDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			LiminarVO pList = service.consultarLiminar(pk);

		} catch (ValidationException e) {
			fail();	
		}
	}	
	
	/**
	 * Testa fluxo do servico listarHisotrico.
	 */
	public void testListarHistoricoSucesso() {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(HistoricoLiminarDAO.class);
		// Parametros do servico
		IdentifierPK pkPessoa = new IdentifierPK(1);
		String nuLiminar = null;
		BVDate dtInicio = null;
		BVDate dtFim = null;

		// Constraints a ser validado
		Constraint params[] = new Constraint[4];
		params[0] = same(pkPessoa);
		params[1] = same(nuLiminar);
		params[2] = same(dtInicio);
		params[3] = same(dtFim);		

		// Lista de resultados
		List<HistoricoLiminarVO> historicos = new 
		ArrayList<HistoricoLiminarVO>();
		// Cria um LiminarVO
		LiminarVO liminar = new LiminarVO(new IdentifierPK(1));
		liminar.setNuLiminar(1);
		HistoricoLiminarVO historico = new HistoricoLiminarVO(
				new IdentifierPK(1));
		try{
			historico.setDtAlteracao(new BVDatetime ("30/10/2008","dd/MM/yyyy"));
		}catch (ParseException e) {	} 
		historico.setDsLogin("teste");
		historico.setLiminar(liminar);
		historico.setNuLiminar(liminar.getNuLiminar());
		historicos.add(historico);
		// Especificacoes da mock para o metodo listar
		mockDao.expects(once()).method("listar").with(params).will(
				returnValue(historicos));
		// Injetando a mock no servico
		service.setHistoricoLiminarDAO((HistoricoLiminarDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<HistoricoLiminarVO> pList = service.listarHistoricoLiminar(
					pkPessoa, nuLiminar, dtInicio, dtFim);
			assertFalse(pList.isEmpty());
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
			fail();
		}
	}

	/**
	 * Testa fluxo do servico listarHistorico sem retorno
	 */
	public void testListarHistoricoSemRetorno() {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(HistoricoLiminarDAO.class);
		// Parametros do servico
		IdentifierPK pkPessoa =null;
		String nuLiminar = "582";
		BVDate dtInicio = null;
		BVDate dtFim = null;	

		// Constraints a ser validado
		Constraint params[] = new Constraint[4];
		params[0] = same(pkPessoa);
		params[1] = same(nuLiminar);
		params[2] = same(dtInicio);
		params[3] = same(dtFim);

		// Especificacoes da mock para o metodo listar
		mockDao.expects(once()).method("listar").with(params).will(
				returnValue(null));
		// Injetando a mock no servico
		service.setHistoricoLiminarDAO((HistoricoLiminarDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<HistoricoLiminarVO> pList = service.listarHistoricoLiminar(
					pkPessoa, nuLiminar, dtInicio, dtFim);
			assertTrue(pList == null);
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
			fail();
		}
	}

	/**
	 * Testa fluxo do servico listar Historico com erro
	 */
	public void testListarHisotricoCamposObrigatoriosNaoPreenchidos() {

		// Obtem o servi�o
		LiminarBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(HistoricoLiminarDAO.class);
		// Parametros do servico
		IdentifierPK pkPessoa = null;
		String nuLiminar = null;
		BVDate dtInicio = null;
		BVDate dtFim = null;	

		// Constraints a ser validado
		Constraint params[] = new Constraint[5];
		params[0] = same(pkPessoa);
		params[1] = same(nuLiminar);
		params[2] = same(dtInicio);
		params[3] = same(dtFim);		

		// Especificacoes da mock para o metodo listar
		mockDao.expects(never()).method("listar").with(params).will(
				returnValue(throwException(
						new CamposObrigatoriosNaoPreenchidosException())));
		// Injetando a mock no servico
		service.setHistoricoLiminarDAO((HistoricoLiminarDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<HistoricoLiminarVO> pList = service.listarHistoricoLiminar(pkPessoa, 
					nuLiminar, dtInicio, dtFim);
			fail();
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
		}
	}
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Obtem o servi�o de liminar.
	 * @return
	 */
	private LiminarBusinessImpl getService() {
		if (liminarService == null) {
			liminarService = new LiminarBusinessImpl();
		}

		return liminarService;
	}	
	
}
