/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;

/**
 * Classe de teste para validar Transa��es de Estorno
 * 
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com.br">Edilson Almeida</a>
 *
 * @created 03/09/2012
 * 
 */
public class TransacaoEstornoDAOIntegrationTest extends AbstractJdbcDaoTest<TransacaoEstornoDAO> {

    /* (non-Javadoc)
     * @see br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDaoTest#getNomeDao()
     */
    @Override
    public String getNomeDao() {
	return TransacaoEstornoDAO.class.getName();
    }

    
    /**
     * Testa metodo listar do DAO
     */
    public void testListar() {
	Integer cdOrigem = 1;
	Integer cdTransacao = null;
	String raizCnpj = null;
	List<TransacaoEstornoVO> list = dao.listar(cdOrigem, cdTransacao, raizCnpj);
	assertFalse("Lista de tipos de transa��o n�o deveria estar vazia", list.isEmpty());
    }
}

