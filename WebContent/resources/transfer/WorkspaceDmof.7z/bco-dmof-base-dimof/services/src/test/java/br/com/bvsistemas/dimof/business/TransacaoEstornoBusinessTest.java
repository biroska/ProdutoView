/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.business;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import br.com.bvsistemas.dimof.business.impl.TransacaoEstornoBusinessImpl;
import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.TransacaoEstornoDAO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Classe de Teste para valida��o de Transa��o de Estorno
 *  
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com.br">Edilson Almeida</a>
 *
 * @created 03/09/2012
 * 
 */
public class TransacaoEstornoBusinessTest extends MockObjectTestCase {

    
    /**
     * Servi�o a ser testado
     */
    private TransacaoEstornoBusinessImpl transacaoEstornoService;
    
    
    /**
     * M�todo que valida a a��o de recuperar a lista de Transa��es de Estorno
     * 
     * @author talent.ealmeida
     * 
     * @throws ValidationException
     * 
     * @throws CamposObrigatoriosNaoPreenchidosException
     */
    public void testListar() throws ValidationException, CamposObrigatoriosNaoPreenchidosException{
	
	//Recupera o servi�o
	TransacaoEstornoBusinessImpl service = getService();
	
	//Cria o Mock
	Mock mockTransacaoEstornoDAO = mock(TransacaoEstornoDAO.class);
	
	// Cria uma lista de objetos TransacaoEstornoVO
	List<TransacaoEstornoVO> lista = new ArrayList<TransacaoEstornoVO>();
	
	// Cria um TransacaoEstornoVO
	TransacaoEstornoVO transacaoEstorno = new TransacaoEstornoVO(new IdentifierPK(1));	
	transacaoEstorno.setNmOrigem("Origem");
	lista.add(transacaoEstorno);

	// Especificacoes da mock para o metodo listar
	mockTransacaoEstornoDAO.expects(once()).method("listar").withAnyArguments().will(returnValue(lista));

	// Injetando a mock no servico
	service.setTransacaoEstornoDAO((TransacaoEstornoDAO) mockTransacaoEstornoDAO.proxy());

	// Executa o servico
	List<TransacaoEstornoVO> pList = service.listar(1, null, null);

	//Valida o resultado
	assertFalse(pList.isEmpty());
	
    }
    
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#tearDown()
     */
    @Override
    protected void tearDown() throws Exception {     
        super.tearDown();
    }
    
    /**
     * @author talent.ealmeida
     * @return
     */
    private TransacaoEstornoBusinessImpl getService(){
	
	if(transacaoEstornoService == null){
	    transacaoEstornoService = new TransacaoEstornoBusinessImpl();
	}
	return transacaoEstornoService;
    }
}

