/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;

/**
 * Testes de integra��o do DAO TipoLogradouro.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class TipoLogradouroDAOIntegrationTest extends AbstractJdbcDaoTest<TipoLogradouroDAO> {

	/**
	 * Testa metodo listar do DAO
	 */
	public void testListar() {
		List<TipoLogradouroVO> list = dao.listar();
		assertFalse("Lista de tipos de logradouros n�o deveria estar vazia", 
				list.isEmpty());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.sic.precos.persistence.dao.AbstractJdbcDaoTest#getNomeDao()
	 */
	public String getNomeDao() {
		return "tipoLogradouroDAO";
	}

}
