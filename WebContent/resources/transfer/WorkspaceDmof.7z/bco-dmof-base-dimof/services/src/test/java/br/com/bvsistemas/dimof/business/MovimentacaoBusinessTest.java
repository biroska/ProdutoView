package br.com.bvsistemas.dimof.business;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.jmock.core.Constraint;

import br.com.bvsistemas.dimof.business.impl.MovimentacaoBusinessImpl;
import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.MovimentacaoDAO;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;

public class MovimentacaoBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private MovimentacaoBusinessImpl movimentacaoService;
		
	/**
	 * Testa fluxo do servico listar.
	 */
	public void testListarMovimentacaoSucesso() {

		// Obtem o servi�o
		MovimentacaoBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(MovimentacaoDAO.class);
		// Parametros do servico
		IdentifierPK pkPessoa =new IdentifierPK();
		String ano = "2007";
		String semestre = "1";	

		// Constraints a ser validado
		Constraint params[] = new Constraint[3];		
		
		params[0] = same(semestre);	
		params[1] = same(ano);
		params[2] = same(pkPessoa);
		
		// Lista de resultados
		List<MovimentacaoVO> movimentacao= new 
		ArrayList<MovimentacaoVO>();
		// Cria um MOvimentacaoVO
		MovimentacaoVO movimentacaoVO = new MovimentacaoVO(new IdentifierPK(2));
		movimentacaoVO.setAno(2007);
		movimentacaoVO.setSemestre(1);
		movimentacaoVO.setCliente(new PessoaVO(new IdentifierPK(1)));
		movimentacaoVO.setVrCredMes1(new BVFloat("0"));
		movimentacaoVO.setVrDebMes1(new BVFloat("0"));
		movimentacaoVO.setVrCredMes2(new BVFloat("0"));
		movimentacaoVO.setVrDebMes2(new BVFloat("0"));
		movimentacaoVO.setVrCredMes3(new BVFloat("0"));
		movimentacaoVO.setVrDebMes3(new BVFloat("0"));
		movimentacaoVO.setVrCredMes4(new BVFloat("0"));
		movimentacaoVO.setVrDebMes4(new BVFloat("0"));
		movimentacaoVO.setVrCredMes5(new BVFloat("0"));
		movimentacaoVO.setVrDebMes5(new BVFloat("0"));
		movimentacaoVO.setVrCredMes6(new BVFloat("0"));
		movimentacaoVO.setVrDebMes6(new BVFloat("0"));	
		movimentacao.add(movimentacaoVO);
		movimentacao.add(movimentacaoVO);
		movimentacao.add(movimentacaoVO);		
		mockDao.expects(once()).method("listar").with(params).will(
				returnValue(movimentacao));
		// Injetando a mock no servico
		service.setMovimentacaoDAO((MovimentacaoDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<MovimentacaoVO> pList = service.listar(
					ano, semestre,pkPessoa);
			assertFalse(pList.isEmpty());
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
			
		}
	}

	/**
	 * Testa fluxo do servico listarMovimentacao sem retorno
	 */
	public void testListarMovimentacaoSemRetorno() {

		MovimentacaoBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(MovimentacaoDAO.class);
		// Parametros do servico
		IdentifierPK pkPessoa =new IdentifierPK();
		String ano = "2008";
		String semestre = "2";

		// Constraints a ser validado
		Constraint params[] = new Constraint[3];
		
		params[0] = same(ano);
		params[1] = same(semestre);
		params[2] = same(pkPessoa);
		// Especificacoes da mock para o metodo listar
		mockDao.expects(once()).method("listar").with(params).will(
				returnValue(null));

		// Injetando a mock no servico
		service.setMovimentacaoDAO((MovimentacaoDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<MovimentacaoVO> pList = service.listar(semestre,ano,pkPessoa);
			assertTrue(pList == null);
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
			fail();
		}
	
	}

	/**
	 * Testa fluxo do servico listar Movimentacao com erro
	 */
	public void testListarMovimentacaoCamposObrigatoriosNaoPreenchidos() {

		MovimentacaoBusinessImpl service = getService();
		// Cria mock para o dao
		Mock mockDao = mock(MovimentacaoDAO.class);
		// Parametros do servico
		IdentifierPK pkPessoa = null;
		String ano = null;
		String semestre = null;

		// Constraints a ser validado
		Constraint params[] = new Constraint[4];
		params[0] = same(pkPessoa);
		params[1] = same(ano);
		params[2] = same(semestre);

		// Especificacoes da mock para o metodo listar
		mockDao
				.expects(never())
				.method("listar")
				.with(params)
				.will(
						returnValue(throwException(
							new CamposObrigatoriosNaoPreenchidosException())));
		// Injetando a mock no servico
		service.setMovimentacaoDAO((MovimentacaoDAO) mockDao.proxy());

		try {
			@SuppressWarnings("unused")
			// Executa o servico
			List<MovimentacaoVO> pList = service
					.listar(semestre, ano, pkPessoa);
			fail();
		} catch (ValidationException e) {
			fail();
		} catch (CamposObrigatoriosNaoPreenchidosException e) {
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	private MovimentacaoBusinessImpl getService() {
		if (movimentacaoService == null) {
			movimentacaoService = new MovimentacaoBusinessImpl();
		}

		return movimentacaoService;
	}	

}
