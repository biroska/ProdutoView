package br.com.bvsistemas.dimof.persistence.dao;

import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

import br.com.bvsistemas.framework.logging.BVLogger;

/**
 * Classe base para testes de DAOs
 * 
 * @author <a href="mailto:cit.fuechi@bvsistemas.com.br">cit.fuechi</a>
 * 
 * @param <T>
 *            interface do DAO sob teste
 */
public abstract class AbstractJdbcDaoTest<T> extends
		AbstractTransactionalDataSourceSpringContextTests {

	protected BVLogger logger = BVLogger.getLogger(AbstractJdbcDaoTest.class);

	protected T dao;

	public AbstractJdbcDaoTest() {
		super();
	}

	public AbstractJdbcDaoTest(String name) {
		super(name);
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "classpath:/*-dao.xml" };
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void prepareTestInstance() throws Exception {
		super.prepareTestInstance();
		dao = (T) applicationContext.getBean(getNomeDao());
	}

	public abstract String getNomeDao();

}