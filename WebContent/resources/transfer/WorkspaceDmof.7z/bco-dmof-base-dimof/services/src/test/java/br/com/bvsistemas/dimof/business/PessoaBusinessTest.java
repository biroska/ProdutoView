package br.com.bvsistemas.dimof.business;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.jmock.core.Constraint;

import br.com.bvsistemas.dimof.business.impl.PessoaBusinessImpl;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.persistence.dao.PessoaDAO;
import br.com.bvsistemas.framework.exception.ValidationException;

public class PessoaBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private PessoaBusinessImpl pessoaService;

	/**
	 * Testa o servi�o listar pessoas com todos os parametros nulos
	 */
	public void testListarParametrosNulos() {

		// Obtem servi�o
		PessoaBusinessImpl service = getService();

		try {
			// Executa a pesquisa
			service.listar(null, null);
			fail("Deveria ter lancado uma exception");
		} catch (ValidationException e) {
		}

	}

	/**
	 * Testa fluxo completo do servico listar
	 */
	public void testListarSucesso() {

		// Obtem servi�o
		PessoaBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockPessoaDAO = mock(PessoaDAO.class);

		// Parametros do servico
		String nmPessoa = "junit Test";
		String nuCpfCnpj = null;

		// Constraints a ser validado
		Constraint params[] = new Constraint[2];
		params[0] = same(nmPessoa);
		params[1] = same(nuCpfCnpj);

		// Especificacoes da mock para o metodo listar
		mockPessoaDAO.expects(once()).method("listar").with(params).will(
				returnValue(new ArrayList<PessoaVO>()));

		// Injetando a mock no servico
		service.setPessoaDAO((PessoaDAO) mockPessoaDAO.proxy());

		// Executa o servico
		List<PessoaVO> pList = service.listar(nmPessoa, "");

		assertTrue("A lista de pessoas deveria estar vazia", pList.isEmpty());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	private PessoaBusinessImpl getService() {

		if (pessoaService == null) {
			pessoaService = new PessoaBusinessImpl();
		}

		return pessoaService;

	}
}
