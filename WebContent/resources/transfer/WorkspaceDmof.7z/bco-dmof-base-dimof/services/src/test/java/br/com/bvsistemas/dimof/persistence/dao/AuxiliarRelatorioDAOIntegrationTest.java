/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;

/**
 * Testes de integra��o do <code>AuxiliarRelatorioDAO</code>.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class AuxiliarRelatorioDAOIntegrationTest 
	extends AbstractJdbcDaoTest<AuxiliarRelatorioDAO> {

	/**
	 * Testa metodo consultarPorAnoPorSemestre do DAO
	 */
	public void testConsultarPorAnoPorSemestre() {

		// Par�metros da consulta
		Integer ano = new Integer(2007);
		Integer nuSemestre = new Integer(1);

		AuxiliarRelatorioVO result = dao.consultarPorAnoPorSemestre(
				ano, nuSemestre);

		assertNotNull(result);
	}

	/**
	 * Testa metodo alterarStatusProcessamento do DAO
	 */
	public void testAlterarStatusProcessamento() {

		IdentifierPK pk = new IdentifierPK(1);
		AuxiliarRelatorioVO vo = new AuxiliarRelatorioVO(pk);
		vo.setAno(2007);
		vo.setNuSemestre(1);
		vo.setTpProcessado(0);

		int registroAlterado = dao.alterarStatusProcessamento(vo);

	    assertTrue("Registro alterado: ", registroAlterado == 1);
	}

	/**
	 * Testa metodo incluir do DAO
	 */
	public void testIncluir() {

		IdentifierPK pk = new IdentifierPK(1);
		AuxiliarRelatorioVO vo = new AuxiliarRelatorioVO(pk);
		vo.setAno(2000);
		vo.setNuSemestre(1);
		vo.setTpProcessado(0);
		vo.setFlRetificadora(BooleanEnum.SIM);

		int registroIncluido = dao.incluir(vo);

	    assertTrue("Registro incluido: ", registroIncluido == 1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDaoTest#getNomeDao()
	 */
	public String getNomeDao() {
		return "auxiliarRelatorioDAO";
	}
}
