package br.com.bvsistemas.dimof.business;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import br.com.bvsistemas.dimof.business.impl.SecaoJudiciariaBusinessImpl;
import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.persistence.dao.SecaoJudiciariaDAO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

public class SecaoJudiciariaBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private SecaoJudiciariaBusinessImpl secaoJudiciariaService;

	/**
	 * Testa fluxo do servico listar
	 */
	public void testListar() {

		// Obtem o servi�o
		SecaoJudiciariaBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockDAO = mock(SecaoJudiciariaDAO.class);

		// Cria uma lista de objetos SecaoJudiciariaVO
		List<SecaoJudiciariaVO> lista = new ArrayList<SecaoJudiciariaVO>();
		
		// Cria um SecaoJudiciariaVO
		SecaoJudiciariaVO vo = new SecaoJudiciariaVO(new IdentifierPK(1));
		vo.setNmSecaoJudiciaria("Se��o Judici�ria de S�o Paulo");
		lista.add(vo);

		// Especificacoes da mock para o metodo listar
		mockDAO.expects(once()).method("listar").withNoArguments()
			.will(returnValue(lista));

		// Injetando a mock no servico
		service.setSecaoJudiciariaDAO((SecaoJudiciariaDAO) mockDAO.proxy());

		// Executa o servico
		List<SecaoJudiciariaVO> pList = service.listar();

		assertFalse(pList.isEmpty());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/*
	 * Obtem uma instancia singleton de SecaoJudiciariaBusinessImpl.
	 */
	private SecaoJudiciariaBusinessImpl getService() {

		if (secaoJudiciariaService == null) {
			secaoJudiciariaService = new SecaoJudiciariaBusinessImpl();
		}

		return secaoJudiciariaService;
	}
}
