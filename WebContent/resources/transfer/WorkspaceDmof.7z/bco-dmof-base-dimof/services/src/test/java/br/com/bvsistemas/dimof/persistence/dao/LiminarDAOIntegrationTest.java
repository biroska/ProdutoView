/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.text.ParseException;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;

/**
 * Testes de integra��o do DAO Liminar.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class LiminarDAOIntegrationTest extends AbstractJdbcDaoTest<LiminarDAO> {

	/**
	 * Testa metodo listar do DAO
	 */
	public void testListar() {
		
		IdentifierPK pkPessoa = null;
		String nuLiminar = null;
		BVDate dtInicio = null;
		BVDate dtFim = null;
		try {
			dtInicio = new BVDate("02/01/2008", "dd/MM/yyyy");
			dtFim = new BVDate("10/01/2008", "dd/MM/yyyy");
		} catch (ParseException e) {
		}
		BooleanEnum apenasVigentes = BooleanEnum.NAO;
		
		List<LiminarVO> list = dao.listar(pkPessoa, nuLiminar, dtInicio, 
				dtFim, apenasVigentes);

		assertFalse("Lista de liminares n�o deveria estar vazia ", 
				list.isEmpty());
	}
	
	/**
	 * Testa metodo consultar do DAO
	 */
	public void testConsulta() {
		
		Long cod = new Long(1);
		IdentifierPK pkLiminar = new IdentifierPK(cod);
		
		
		LiminarVO liminar = dao.consultar(pkLiminar);

		assertFalse("Liminar n�o deveria estar nulla ", 
				liminar==null);
	}
	
	/**
	 * Testa metodo atualizar do DAO
	 */
	public void testAtualizar() {
		
		Long cod = new Long(1);
		IdentifierPK pk = new IdentifierPK(cod);
		PessoaVO cliente = new PessoaVO(pk);
		BVDate data = null;
		BVDate dtFim = null;
		BooleanEnum retroativa = BooleanEnum.NAO;
		long numeroLong = 123;
		int numeroInt =321;
		try {
			data = new BVDate("02/01/2008", "dd/MM/yyyy");
			dtFim = new BVDate("10/01/2008", "dd/MM/yyyy");
		} catch (ParseException e) {
		}
		
		LiminarVO liminar = new LiminarVO(pk);
		liminar.setCliente(cliente);
		liminar.setDsLoginInclusao("Teste");
		liminar.setDtExpedicao(data);
		liminar.setDtFimVigencia(dtFim);
		liminar.setDtIniVigencia(data);
		liminar.setFlCassacaoRetroativa(retroativa);
		liminar.setNmSubsecaoJudiciaria("123");
		liminar.setNuLiminar(numeroLong);
		liminar.setNuSecaoJudiciaria(numeroInt);
		liminar.setNuVaraTramitacao(numeroInt);		
		
		
		int count = dao.atualizar(liminar);

		assertFalse("Liminar n�o deveria estar nulla ", 
				new Integer(count)==null);
	}
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.sic.precos.persistence.dao.AbstractJdbcDaoTest#getNomeDao()
	 */
	public String getNomeDao() {
		return "liminarDAO";
	}

}
