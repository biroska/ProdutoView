/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Testes de integra��o do DAO Parametro.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class ParametroDAOIntegrationTest extends AbstractJdbcDaoTest<ParametroDAO> {

	/**
	 * Testa metodo consultar do DAO
	 */
	public void testConsultar() {
		ParametroSistemaVO result = dao.consultar();
		assertNotNull(result);
	}

	/**
	 * Testa metodo alterar do DAO
	 */
	public void testAlterar() {
		ParametroSistemaVO parametro = 
			new ParametroSistemaVO(new IdentifierPK(1));
		
		PessoaVO declarante = getPessoaVOPorTipo("declarante");
		PessoaVO representanteLegal = getPessoaVOPorTipo("representanteLegal");
		PessoaVO respPreenchimento = getPessoaVOPorTipo("respPreenchimento");
		PessoaVO respAtendimentoRMF = getPessoaVOPorTipo("respAtendimentoRMF");
		
		TipoLogradouroVO tipoLogradouro = 
			new TipoLogradouroVO(new IdentifierPK(33));
		tipoLogradouro.setNmTipoLogradouro("Rua");
		
		parametro.setVrLimitePF(new BVFloat("10.50"));
		parametro.setVrLimitePJ(new BVFloat("25.75"));
		parametro.setDeclarante(declarante);
		parametro.setRepresentanteLegal(representanteLegal);
		parametro.setRespPreenchimento(respPreenchimento);
		parametro.setRespAtendimentoRMF(respAtendimentoRMF);
		parametro.setTpSituacaoEspecial("00");
		parametro.setDtEnvioSituacaoEspecial(null);
		parametro.setTipoLogradouroRespRMF(tipoLogradouro);
		parametro.setNmArquivo("ARQ-001");
		
		int parametroAlterado = dao.alterar(parametro);
	    
	    assertTrue("Registro alterado: ", parametroAlterado == 1);
	}
	
    private PessoaVO getPessoaVOPorTipo(final String tipo) {

		PessoaVO vo = null;

		if ("declarante".equals(tipo)) {
			final Long cdPessoa = new Long(7);
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = "Pessoa 01";
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		} else if ("representanteLegal".equals(tipo)) {
			final Long cdPessoa = new Long(8);
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = "Pessoa 02";
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		} else if ("respPreenchimento".equals(tipo)) {
			final Long cdPessoa = new Long(9);
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = "Pessoa 03";
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		} else if ("respAtendimentoRMF".equals(tipo)) {
			final Long cdPessoa = new Long(10);
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = "Pessoa 04";
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		}

		return vo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDaoTest#getNomeDao()
	 */
	public String getNomeDao() {
		return "parametroDAO";
	}

}
