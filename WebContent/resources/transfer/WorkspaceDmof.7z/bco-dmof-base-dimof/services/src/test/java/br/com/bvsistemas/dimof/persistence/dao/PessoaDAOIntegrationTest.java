/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Testes de integra��o do DAO Pessoa.
 * 
 * @author <a href="mailto:cmiranda@ciandt.com.br">Cristiano J. Miranda</a>
 * 
 */
public class PessoaDAOIntegrationTest extends AbstractJdbcDaoTest<PessoaDAO> {

	/**
	 * Testa metodo listar do DAO
	 */
	public void testListar() {

		List<PessoaVO> list = dao.listar(null, "03968045000576");
		// List<PessoaVO> list = dao.listar("banco vo", null);
		assertFalse("Lista de pessoas n�o deveria estar vazia", list.isEmpty());

	}
	
	/**
	 * Testa metodo listar do DAO
	 */
	public void testConsultaPelaChave() {
				
		final Long cdPessoa = new Long(7);
		IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
		PessoaVO pessoa = dao.consultaPelaChave(cdPessoaPK);
		
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.sic.precos.persistence.dao
	 *      .AbstractJdbcDaoTest#getNomeDao()
	 */
	public String getNomeDao() {
		return "pessoaDAO";
	}

}
