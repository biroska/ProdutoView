package br.com.bvsistemas.dimof.business;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.jmock.core.Constraint;

import br.com.bvsistemas.dimof.business.impl.ParametroSistemaBusinessImpl;
import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.dimof.exception.DataInvalidaSituacaoEspecialException;
import br.com.bvsistemas.dimof.persistence.dao.ParametroDAO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Testes dos servicos dos parametros do sistema.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 *
 */
public class ParametroSistemaBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private ParametroSistemaBusinessImpl parametroSistemaService;

	/**
	 * Testa fluxo do servico consultar
	 */
	public void testConsultar() {

		// Obtem o servi�o
		ParametroSistemaBusinessImpl service = getService();

		// Cria mock para o dao
		Mock mockDao = mock(ParametroDAO.class);

		// Cria um ParametroSistemaVO
		ParametroSistemaVO parametroSistema = 
			new ParametroSistemaVO(new IdentifierPK(1));
		parametroSistema.setVrLimitePF(new BVFloat("10.00"));
		parametroSistema.setVrLimitePJ(new BVFloat("15.00"));

		// Especificacoes da mock para o metodo consultar
		mockDao.expects(once()).method("consultar").withNoArguments()
			.will(returnValue(parametroSistema));

		// Injetando a mock no servico
		service.setParametroDAO((ParametroDAO) mockDao.proxy());

		// Executa o servico
		ParametroSistemaVO pParametroSistema = service.consultar();

		assertFalse(pParametroSistema == null);
	}
	
	/**
     * Testa fluxo do servico alterar com sucesso
	 * 
	 */		
	public void testAlterarSucesso() {

		// Obtem o servi�o
		ParametroSistemaBusinessImpl service = getService();

		BVDate dataEvento = new BVDate();
		IdentifierPK pk = new IdentifierPK(1);

		PessoaVO declarante = new PessoaVO(pk);
		PessoaVO representanteLegal = new PessoaVO(pk);
		PessoaVO respAtendimentoRMF = new PessoaVO(pk);
		PessoaVO respPreenchimento = new PessoaVO(pk);

		TipoLogradouroVO tipoLogradouro = 
			new TipoLogradouroVO(new IdentifierPK(30));

		ParametroSistemaVO parametroSistema = new ParametroSistemaVO(pk);
		parametroSistema.setTpSituacaoEspecial("01");
		parametroSistema.setDtEnvioSituacaoEspecial(dataEvento);
		parametroSistema.setVrLimitePF(new BVFloat("10.00"));
		parametroSistema.setVrLimitePJ(new BVFloat("15.00"));
		parametroSistema.setNmArquivo("TESTE");
		parametroSistema.setDeclarante(declarante);
		parametroSistema.setRepresentanteLegal(representanteLegal);
		parametroSistema.setRespAtendimentoRMF(respAtendimentoRMF);
		parametroSistema.setRespPreenchimento(respPreenchimento);
		parametroSistema.setTipoLogradouroRespRMF(tipoLogradouro);
		
		// Cria mock para o dao
		Mock mockDao = mock(ParametroDAO.class);

		// Constraints a ser validado
		Constraint params[] = new Constraint[1];
		params[0] = same(parametroSistema);

		mockDao.expects(exactly(1)).method("alterar").with(params)
			.will(returnValue(1));

		// Injetando a mock no servico
		service.setParametroDAO((ParametroDAO) mockDao.proxy());	

		try {
			@SuppressWarnings("unused")
			int qtdReg = service.alterar(parametroSistema);
		} catch (ValidationException e) {
			fail();
		} catch (DataInvalidaSituacaoEspecialException e) {
			fail();
		}
	}
	
	/**
     * Testa fluxo do servico alterar com erro
	 * 
	 */		
	public void testAlterarDataInvalidaSituacaoEspecial() {

		// Obtem o servi�o
		ParametroSistemaBusinessImpl service = getService();
		
		ParametroSistemaVO parametroSistema = 
			new ParametroSistemaVO(new IdentifierPK(1));
		parametroSistema.setTpSituacaoEspecial("01");
		parametroSistema.setDtEnvioSituacaoEspecial(null);
		
		// Cria mock para o dao
		Mock mockDao = mock(ParametroDAO.class);

		// Parametros do servico
		BVDate dtEnvioSituacaoEspecial = null;
		String tpSituacaoEspecial = null;

		// Constraints a ser validado
		Constraint params[] = new Constraint[2];
		params[0] = same(dtEnvioSituacaoEspecial);
		params[1] = same(tpSituacaoEspecial);

		mockDao.expects(never()).method("alterar").with(params)
			.will(throwException(new DataInvalidaSituacaoEspecialException()));

		// Injetando a mock no servico
		service.setParametroDAO((ParametroDAO) mockDao.proxy());	

		try {
			@SuppressWarnings("unused")
			int qtdReg = service.alterar(parametroSistema);
			fail();
		} catch (ValidationException e) {
			fail();
		} catch (DataInvalidaSituacaoEspecialException e) {
		}
	}
	
	/**
     * Testa fluxo do servico alterar com erro
	 * 
	 */		
	public void testAlterarWithNull() {

		// Obtem o servi�o
		ParametroSistemaBusinessImpl service = getService();
		
		ParametroSistemaVO parametroSistema = null;
		
		// Cria mock para o dao
		Mock mockDao = mock(ParametroDAO.class);

		// Parametros do servico
		BVFloat vrLimitePF = null;
		PessoaVO declarante = null;

		// Constraints a ser validado
		Constraint params[] = new Constraint[2];
		params[0] = same(vrLimitePF);
		params[1] = same(declarante);

		mockDao.expects(never()).method("alterar").with(params)
			.will(throwException(new ValidationException()));

		// Injetando a mock no servico
		service.setParametroDAO((ParametroDAO) mockDao.proxy());	

		try {
			@SuppressWarnings("unused")
			int qtdReg = service.alterar(parametroSistema);
			fail();
		} catch (ValidationException e) {
		} catch (DataInvalidaSituacaoEspecialException e) {
			fail();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	private ParametroSistemaBusinessImpl getService() {

		if (parametroSistemaService == null) {
			parametroSistemaService = new ParametroSistemaBusinessImpl();
		}

		return parametroSistemaService;
	}
}
