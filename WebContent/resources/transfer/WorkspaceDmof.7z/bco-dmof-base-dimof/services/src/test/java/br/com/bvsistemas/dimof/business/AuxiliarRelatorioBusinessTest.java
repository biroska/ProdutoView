package br.com.bvsistemas.dimof.business;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.jmock.core.Constraint;

import br.com.bvsistemas.dimof.business.impl.AuxiliarRelatorioBusinessImpl;
import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.dimof.persistence.dao.AuxiliarRelatorioDAO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Testes dos servicos de AuxiliarRelatorio.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class AuxiliarRelatorioBusinessTest extends MockObjectTestCase {

	// Servico a ser testado
	private AuxiliarRelatorioBusinessImpl service;

	/**
     * Testa fluxo do servico regerar com sucesso executando uma alteracao.
     * Comportamento esperado: Retorna 1 registro (alterado)
	 */		
	public void testRegerarSucesso1() {

		// Obtem o servi�o
		AuxiliarRelatorioBusinessImpl service = getService();

		IdentifierPK pk = new IdentifierPK(1);

		AuxiliarRelatorioVO auxiliarRelatorio = new AuxiliarRelatorioVO(pk);
		auxiliarRelatorio.setAno(2008);
		auxiliarRelatorio.setNuSemestre(1);
		auxiliarRelatorio.setFlRetificadora(BooleanEnum.NAO);
		auxiliarRelatorio.setTpProcessado(0);

		// Cria mock para o dao
		Mock mockDao = mock(AuxiliarRelatorioDAO.class);

		// Parametros do servico
		Integer ano = new Integer(2008);
		Integer nuSemestre = new Integer(1);
		
		// Constraints a ser validado
		Constraint paramsConsulta[] = new Constraint[2];
		paramsConsulta[0] = eq(ano);
		paramsConsulta[1] = eq(nuSemestre);

		mockDao.expects(once()).method("consultarPorAnoPorSemestre")
			.with(paramsConsulta).will(returnValue(auxiliarRelatorio));

		// Constraints a ser validado
		Constraint params[] = new Constraint[1];
		params[0] = same(auxiliarRelatorio);

		mockDao.expects(exactly(1)).method("alterarStatusProcessamento")
			.with(params).will(returnValue(1));

		// Injetando a mock no servico
		service.setAuxiliarRelatorioDAO((AuxiliarRelatorioDAO) mockDao.proxy());	

		try {
			@SuppressWarnings("unused")
			int retorno = service.regerar(auxiliarRelatorio);
			assertTrue(retorno == 1);
		} catch (ValidationException e) {
			fail();
		}
	}

	/**
     * Testa fluxo do servico regerar com erro.
	 * Comportamento esperado: ValidationException
	 */		
	public void testRegerarComErro() {

		// Obtem o servi�o
		AuxiliarRelatorioBusinessImpl service = getService();

		AuxiliarRelatorioVO auxiliarRelatorio = null;

		// Cria mock para o dao
		Mock mockDao = mock(AuxiliarRelatorioDAO.class);

		// Constraints a ser validado
		Constraint params[] = new Constraint[1];
		params[0] = same(auxiliarRelatorio);

		mockDao.expects(never()).method("alterarStatusProcessamento")
			.with(params).will(throwException(new ValidationException()));

		// Injetando a mock no servico
		service.setAuxiliarRelatorioDAO((AuxiliarRelatorioDAO) mockDao.proxy());	

		try {
			@SuppressWarnings("unused")
			int retorno = service.regerar(auxiliarRelatorio);
			fail();
		} catch (ValidationException e) {
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/*
	 * Recupera uma instancia do servico.
	 */
	private AuxiliarRelatorioBusinessImpl getService() {

		if (service == null) {
			service = new AuxiliarRelatorioBusinessImpl();
		}

		return service;
	}
}
