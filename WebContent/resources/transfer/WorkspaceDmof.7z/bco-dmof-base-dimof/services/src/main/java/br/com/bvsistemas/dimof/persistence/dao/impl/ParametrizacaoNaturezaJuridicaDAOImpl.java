package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.ParametrizacaoNaturezaJuridicaDAO;
import br.com.bvsistemas.dimof.persistence.dao.helper.GenericSingleColumnRowMapper;
import br.com.bvsistemas.framework.datatype.IdentifierDBKeyGenerator;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;


/**
 * Implementa��o de {@link ParametrizacaoNaturezaJuridicaDAO}
 * 
 * @spring.bean name="parametrizacaoNaturezaJuridicaDAO" lazy-init="true" scope="singleton"
 * 
 * @author rtomiyama
 * 
 */
public class ParametrizacaoNaturezaJuridicaDAOImpl  extends AbstractJdbcDao implements ParametrizacaoNaturezaJuridicaDAO {

	
	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(ParametrizacaoNaturezaJuridicaDAOImpl.class);
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	private RowMapper<ParametrizacaoNaturezaJuridicaVO> parametrizacaoNaturezaJuridicaRowMapper;
	
	
	/**
	 * Identificador do hist�rico.
	 */
	private IdentifierDBKeyGenerator parametrizacaoNaturezaJuridicaKeyGenerator;
	
	
	
	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public ParametrizacaoNaturezaJuridicaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}


	
	@SuppressWarnings("unchecked")
	@Override
	public String getNomeNaturezaJuridica(String cdNaturezaJuridica)
			throws PersistenceException {
    	String sqlCommand = this.getSqlCommand("getNomeNaturezaJuridica");
    	Map<String , Object> namedParameters = new HashMap<String, Object>();
    	namedParameters.put("cdNaturezaJuridica", cdNaturezaJuridica);
    	
    	StringBuffer sql = new StringBuffer(sqlCommand);
    	List<Object> lista = this.executeQuery(sql.toString(), namedParameters, new GenericSingleColumnRowMapper());
    	if(lista != null && lista.size() > 0) {
    		return (String) lista.get(0);	    	
    	}
    	
    	return "";
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ParametrizacaoNaturezaJuridicaVO> listarParametrizacoes(String cdNaturezaJuridica)
			throws PersistenceException {

		String sqlComando = this.getSqlCommand("listarParametrizacoes");
		StringBuffer sql = new StringBuffer(sqlComando);
		
		Map<String, Object> namedParameters = new HashMap<String, Object>(1);
		
		sql.append("\n WHERE CdNaturezaJuridica = :cdNaturezaJuridica");
		sql.append("\n ORDER BY DtInicioVigencia");
		namedParameters.put("cdNaturezaJuridica", cdNaturezaJuridica);
		
		
		final List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoes = this.executeQuery(
				sql.toString(), namedParameters, parametrizacaoNaturezaJuridicaRowMapper);

		return listaParametrizacoes;		
	}
	



	@Override
	public IdentifierPK inlcuir(ParametrizacaoNaturezaJuridicaVO parametrizacao)
			throws PersistenceException {
		IdentifierPK pk = parametrizacao.getPk();
		Long id = pk.getId();

		// Verificando a PrimaryKey	
		if (id == null) {
			id = parametrizacaoNaturezaJuridicaKeyGenerator.generate();
			pk.setId(id);
		}		 	 

		// Inserindo agendamento no banco de dados
		String sql = this.getSqlCommand("incluir");

		
		// Executa insert no banco
		int count = this.executeCommand(sql, parametrizacao);
		if (count != 1) {
			String errorMsg = "A parametrizacao  "
				+ "n�o foi inserida no banco de dados,  "
				+ "erro!";
			logger.workflow.warn(errorMsg);
			throw new PersistenceException(errorMsg);
		}

		//Retorna pk do objeto inserido
		return pk;
	}


	@Override
	public IdentifierPK atualizar(ParametrizacaoNaturezaJuridicaVO parametrizacao)
			throws PersistenceException {
		IdentifierPK pk = parametrizacao.getPk();

		// Inserindo agendamento no banco de dados
		String sql = this.getSqlCommand("atualizar");
		//StringBuffer sql = new StringBuffer(sqlComando);		
		
		//sql.append("\n AND DtInicioVigencia = :dataInicio");
		//namedParameters.put("dataInicio", dataInicio);

		
		// Executa insert no banco
		int count = this.executeCommand(sql, parametrizacao);
		
		if (count != 1) {
			String errorMsg = "A parametrizacao  "
				+ "n�o foi inserida no banco de dados,  "
				+ "erro!";
			logger.workflow.warn(errorMsg);
			throw new PersistenceException(errorMsg);
		}

		//Retorna pk do objeto inserido
		return pk;
	}
	
	
	
	 	/**
		 * Seta o parametrizacaoNaturezaJuridicaKeyGenerator, que ser� utilizado no m�todo incluir
		 * para obter o IdentifierPK.
		 * 
		 * @spring.property ref="parametrizacaoNaturezaJuridicaKeyGenerator"
		 * @param ParametrizacaoNaturezaJuridicaKeyGenerator
		 *            ParametrizacaoNaturezaJuridicaKeyGenerator para setar
		 */
		public void setParametrizacaoNaturezaJuridicaKeyGenerator(
				IdentifierDBKeyGenerator parametrizacaoNaturezaJuridicaKeyGenerator) {
			this.parametrizacaoNaturezaJuridicaKeyGenerator =parametrizacaoNaturezaJuridicaKeyGenerator;
		}
		

	/**
	 * M�todo para setar o RowMapper com informa��es de parametrizacao.
	 * 
	 * @spring.property ref="parametrizacaoNaturezaJuridicaRowMapper"
	 * @param parametrizacaoNaturezaJuridicaRowMapper
	 *            the parametrizacaoNaturezaJuridicaRowMapper a ser setado
	 */
	public void setParametrizacaoNaturezaJuridicaRowMapper(			
			RowMapper<ParametrizacaoNaturezaJuridicaVO> parametrizacaoNaturezaJuridicaRowMapper) {
		this.parametrizacaoNaturezaJuridicaRowMapper = parametrizacaoNaturezaJuridicaRowMapper;
	}

	

}
