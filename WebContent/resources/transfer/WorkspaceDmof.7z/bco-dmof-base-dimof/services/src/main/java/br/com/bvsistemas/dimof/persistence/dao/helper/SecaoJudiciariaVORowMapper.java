/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link SecaoJudiciariaVO}
 * 
 * @spring.bean name="secaoJudiciariaRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class SecaoJudiciariaVORowMapper implements 
	RowMapper<SecaoJudiciariaVO> {

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.simple.ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public SecaoJudiciariaVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final Long cdSecao = rs.getLong("CdSecao");
		IdentifierPK cdSecaoPK = new IdentifierPK(cdSecao);

		final String nmSecao = rs.getString("NmSecao");

		SecaoJudiciariaVO vo = new SecaoJudiciariaVO(cdSecaoPK);
		vo.setNmSecaoJudiciaria(nmSecao);

		return vo;
	}
}