/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.LiminarDAO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierDBKeyGenerator;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Implementa��o de {@link LiminarDAO}
 * 
 * @spring.bean name="liminarDAO" lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 * 
 */
public class LiminarDAOImpl extends AbstractJdbcDao implements LiminarDAO {

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(LiminarDAOImpl.class);

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public LiminarDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	RowMapper<LiminarVO> liminarRowMapper;
	
	
	/**
	 * Identificador do hist�rico.
	 */
	private IdentifierDBKeyGenerator liminarKeyGenerator;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#consultar(br.com.bvsistemas.framework.datatype.IdentifierPK)
	 */
	@SuppressWarnings("unchecked")
	
	
	public LiminarVO consultarPorNumeroCliente(Long numeroLiminar, 
			IdentifierPK pkPessoa) throws PersistenceException  {

		String sqlComando = this.getSqlCommand("consultarPorNumeroCliente");		
		StringBuffer sql = new StringBuffer(sqlComando);
		
		Map<String, Object> namedParameters = new HashMap<String, Object>(2);
		
		if(numeroLiminar != null) {
			sql.append("\n AND liminar.NuLiminar = :nuLiminar");
			namedParameters.put("nuLiminar", numeroLiminar.longValue());
		}
		if(pkPessoa != null){
			sql.append("\n AND pessoa.CdPessoa = :cdPessoa");
			namedParameters.put("cdPessoa", pkPessoa.getId());
		}
		

		final List<LiminarVO> liminares = this.executeQuery(sql.toString(), namedParameters,
				liminarRowMapper);

		if (liminares.size() != 1) {
			String errorMsg = "Liminar inexistente: pk[" + numeroLiminar
			+ "] Qdte = " + liminares.size();
			logger.workflow.warn(errorMsg);
			return null;
		} else{
			return liminares.get(0);
		}

		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#atualizar(br.com.bvsistemas.dimof.datatype.LiminarVO)
	 */
	public int atualizar(LiminarVO liminar) throws PersistenceException {
		String sql = this.getSqlCommand("atualizar");
        int count = this.executeCommand(sql, liminar);        
        //verifica o numero de registro alterados
        if (count == 0) {
            IdentifierPK pk =liminar.getPk();
            String errorMsg = "Serie Referencia inexistente: pk[" +
            	pk.getKeys() + "]";
            
            logger.workflow.warn(errorMsg);
            throw new PersistenceException(errorMsg);
           //verifica integridade dos dados 	
        } else if (count > 1) {
            IdentifierPK pk = liminar.getPk();
            
            String errorMsg = "Atualiza��o de serie referencia pela pk[" 
            	    + pk.getKeys() + "] afeta " + count + " registros. "
            	    + "Falha de integridade no banco de dados!";
            logger.workflow.warn(errorMsg);
            throw new PersistenceException(errorMsg);
        }      
        
        return count;
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#consultaPelaChave(br.com.bvsistemas.dimof.datatype.LiminarVO)
	 */
	public LiminarVO consultar(IdentifierPK pkLiminar) 
	throws PersistenceException{

		String sqlComando = this.getSqlCommand("consultaPelaChave");
		//monta string para select	
		
		StringBuffer sql = new StringBuffer(sqlComando);
		Map<String, Object> namedParameters = new HashMap<String, Object>(1);
		
		if (pkLiminar != null) {
			sql.append("\n AND liminar.CdLiminar = :cdLiminar");
			namedParameters.put("cdLiminar", pkLiminar.getId());
		}

		final List<LiminarVO> liminar = this.executeQuery(sql.toString(),
				namedParameters, liminarRowMapper);

		if(liminar==null || liminar.size() != 1){
			String errorMsg = (new StringBuilder("Serie Referencia inexistente:" +
			" pk[")).append(pkLiminar.getId())+"]";
			logger.workflow.warn(errorMsg);
		}   


		return liminar.get(0);

	}

	/* 
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#listar(br.com.bvsistemas.framework.datatype.IdentifierPK, 
	 *      java.lang.String, br.com.bvsistemas.framework.datatype.BVDate, br.com.bvsistemas.framework.datatype.BVDate, 
	 *      br.com.bvsistemas.framework.datatype.BolleanEnum)
	 */
	@SuppressWarnings("unchecked")
	public List<LiminarVO> listar(IdentifierPK pkPessoa, String nuLiminar,
			BVDate dtInicio, BVDate dtFim, BooleanEnum apenasVigentes)
			throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listar");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);

		// Filtros da pesquisa
		if (pkPessoa != null) {
			sql.append("\n AND pessoa.CdPessoa = :cdPessoa");
			namedParameters.put("cdPessoa", pkPessoa.getId());
		}

		if ((StringUtils.isNotBlank(nuLiminar)) 
				&& (StringUtils.isNumeric(nuLiminar))) {
			sql.append("\n AND liminar.NuLiminar = :nuLiminar");
			namedParameters.put("nuLiminar", new Long(nuLiminar));
		}

		if (apenasVigentes != null && BooleanEnum.SIM.innerValue().equals(
				apenasVigentes.innerValue())) {
			sql.append("\n AND liminar.DtFimVigencia IS NULL");
		} else {
			if ((dtInicio != null) && (dtFim != null)) {
				sql.append("\n AND (");
				sql.append("\n     (convert(date,liminar.DtInicioVigencia) >= :dtInicio AND");
				sql.append("\n        convert(date,liminar.DtFimVigencia) <= :dtFim");
				sql.append("\n     )");
				sql.append("\n  OR (liminar.DtFimVigencia IS NULL AND convert(date,liminar.DtInicioVigencia)");
				sql.append("\n        BETWEEN :dtInicio AND :dtFim");
				sql.append("\n     )");
				sql.append("\n )");
				namedParameters.put("dtInicio", dtInicio.getSqlValue());
				namedParameters.put("dtFim", dtFim.getSqlValue());
			}
		}

		// Ordena��o da consulta
		sql.append("\n ORDER BY UPPER(pessoa.NmPessoa)");

		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sql.toString());
		}

		final List<LiminarVO> listaLiminar = this.executeQuery(
				sql.toString(), namedParameters, liminarRowMapper);

		return listaLiminar;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#incluir(br.com.bvsistemas.dimof.datatype.LiminarVO)
	 */
	public IdentifierPK incluir(LiminarVO liminar) 
	throws PersistenceException {
		IdentifierPK pk = liminar.getPk();
		Long id = pk.getId();

		// Verificando a PrimaryKey	
		if (id == null) {
			id = liminarKeyGenerator.generate();
			pk.setId(id);
		}		 	 

		// Inserindo agendamento no banco de dados
		String sql = this.getSqlCommand("incluir");

		// Executa insert no banco
		int count = this.executeCommand(sql, liminar);
		if (count != 1) {
			String errorMsg = "A liminar  "
				+ "n�o foi inserido no banco de dados,  "
				+ "erro!";
			logger.workflow.warn(errorMsg);
			throw new PersistenceException(errorMsg);
		}

		//Retorna pk do objeto inserido
		return pk;
	}
	 
	 /**
		 * Seta o historicoLiminarKeyGenerator, que ser� utilizado no m�todo incluir
		 * para obter o IdentifierPK.
		 * 
		 * @spring.property ref="liminarKeyGenerator"
		 * @param LiminarKeyGenerator
		 *            LiminarKeyGenerator para setar
		 */
		public void setliminarKeyGenerator(
				IdentifierDBKeyGenerator liminarKeyGenerator) {
			this.liminarKeyGenerator =liminarKeyGenerator;
		}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="liminarRowMapper"
	 * @param liminarRowMapper
	 *            the liminarRowMapper a ser setado
	 */
	public void setLiminarRowMapper(
			RowMapper<LiminarVO> liminarRowMapper) {
		this.liminarRowMapper = liminarRowMapper;
	}
}
