/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.exception.DataInvalidaSituacaoEspecialException;
import br.com.bvsistemas.dimof.persistence.dao.ParametroDAO;
import br.com.bvsistemas.dimof.services.ParametroSistemaServices;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o do cadastro de parametros.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.ParametroSistemaBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class ParametroSistemaBusinessImpl extends AbstractBusiness implements 
	ParametroSistemaServices {

	// Constante para a situacao especial 00 - Nao se Aplica
	private static final String NAO_SE_APLICA = "00";

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(ParametroSistemaBusinessImpl.class);

	// DAO para acesso aos par�metros
	private ParametroDAO parametroDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo
	 *            O m�todo que ser� avaliado pelo timer
	 * @return Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo ParametroSistemaBusinessImpl." 
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.ParametroSistemaServices#consultar()
	 */
	@SuppressWarnings("unused")
	public ParametroSistemaVO consultar() {

		Timer timer = habilitarTimer("consultar");

		ParametroSistemaVO result = parametroDAO.consultar();

		desabilitarTimer(timer);

		return result;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.ParametroSistemaServices#alterar(br.com.bvsistemas.dimof.datatype.ParametroSistemaVO)
	 */
	@SuppressWarnings("unused")
	public int alterar(ParametroSistemaVO parametroSistema)
			throws ValidationException, DataInvalidaSituacaoEspecialException {
		
		Timer timer = habilitarTimer("alterar");

		// Verifica se o par�metro foi passado corretamente
		if (parametroSistema == null) {
			throw new ValidationException();
		}
		
		// Verifica se data do evento foi informada para a situacao
		// especial diferente de 00
		if (!NAO_SE_APLICA.equals(parametroSistema.getTpSituacaoEspecial()) 
				&& (parametroSistema.getDtEnvioSituacaoEspecial() == null)) {
			throw new DataInvalidaSituacaoEspecialException();
		}

        // Altera o par�metro
		int qtdeReg;
		qtdeReg = parametroDAO.alterar(parametroSistema);
		
		desabilitarTimer(timer);
		
		return qtdeReg;
	}

	/**
	 * @param parametroDAO
	 *            the parametroDAO to set
	 * @spring.property ref="parametroDAO"
	 */
	public void setParametroDAO(ParametroDAO parametroDAO) {
		this.parametroDAO = parametroDAO;
	}
}
