/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.Date;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

public interface MovimentacaoDAO {
	
	/**
	 * Busca Movimenta��o pelo filtro.
	 * 
	 * @param ano  ano da movimenta��o
	 * 
	 * @param semestre semestre da movimenta��o 
	 * 
	 * @param pessoa cliente movimenta��o
	 * 
	 * @return lista de com o valor da soma de creditos e debitos das 
	 * 				movimenta��es de acordo com  o filtro 
	 * 				Lista de objetos <code>MovimentacaoVO</code> 
	 * 			
	 * @throws PersistenceException Caso falhe alguma opera��o no banco de dados
	 */
	List<MovimentacaoVO> listar(String ano, String semestre,IdentifierPK pessoa) throws PersistenceException;
	
	/**
	 * Retorna a lista detalhada de movimentacoes de cambio para um cliente
	 *
	 * @throws PersistenceException
	 */
	public List<DetalheMovimentoCambioVO> detalharMovimentoCambio(Integer cdPessoa, Date dtInicio, Date dtFim) throws PersistenceException;
	
	/**
	 * Retorna a lista detalhada de movimentacoes de conta corrente para um cliente
	 * 
	 * @throws PersistenceException
	 */
	public List<DetalheMovimentoCCVO> detalharMovimentoContaCorrente(Integer cdPessoa, Date dtInicio, Date dtFim) throws PersistenceException;

}
