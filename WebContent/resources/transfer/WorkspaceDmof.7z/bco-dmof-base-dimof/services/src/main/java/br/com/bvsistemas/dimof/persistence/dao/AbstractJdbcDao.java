/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * Classe customizada de acesso a dados
 * 
 * @author cit.mcardoso
 * 
 */
public class AbstractJdbcDao extends
		br.com.bvsistemas.framework.persistence.dao.AbstractJdbcDao {

	/**
	 * Constante que indica atributo nulo na query
	 */
	private final String NULL_SQL_VALUE = "NULL";

	/**
	 * JdbcTemplate
	 */
	private JdbcTemplate jdbcTemplate;

	/**
	 * Construtor da classe pai
	 * 
	 * @param ds
	 * @throws PersistenceException
	 */
	public AbstractJdbcDao(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/**
	 * Altera os valores NULL por "NULL", este metodo � util quando os atributos
	 * nulo s�o tratados na propria query
	 * 
	 * @param params -
	 *            Array com todos os parametros da query
	 * 
	 * @return array otimizado
	 */
	public Object[] replaceNullValues(Object[] params) {

		if (params != null) {

			for (int i = 0; i < params.length; i++) {
				Object obj = params[i];
				if (obj == null)
					params[i] = NULL_SQL_VALUE;
			}

		}

		return params;

	}

	/**
	 * Obtem JdbcTemplate de acesso a dados
	 * 
	 * @return {@link JdbcTemplate}
	 */
	public JdbcTemplate getJdbcTemplate() {

		if (jdbcTemplate == null) {
			jdbcTemplate = new JdbcTemplate(getDataSource());
		}

		return jdbcTemplate;
	}

}
