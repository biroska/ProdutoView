/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.persistence.dao.SecaoJudiciariaDAO;
import br.com.bvsistemas.dimof.services.SecaoJudiciariaServices;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o do cadastro de secao judiciaria.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.SecaoJudiciariaBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class SecaoJudiciariaBusinessImpl extends AbstractBusiness implements 
	SecaoJudiciariaServices {

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(SecaoJudiciariaBusinessImpl.class);

	// DAO para acesso �s Secoes Judiciarias
	private SecaoJudiciariaDAO secaoJudiciariaDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo
	 *            O m�todo que ser� avaliado pelo timer
	 * @return Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo SecaoJudiciariaBusinessImpl." 
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	/**
	 * @param secaoJudiciariaDAO
	 *            the secaoJudiciariaDAO to set
	 * @spring.property ref="secaoJudiciariaDAO"
	 */
	public void setSecaoJudiciariaDAO(SecaoJudiciariaDAO secaoJudiciariaDAO) {
		this.secaoJudiciariaDAO = secaoJudiciariaDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.SecaoJudiciariaServices#listar()
	 */
	@SuppressWarnings("unused")
	public List<SecaoJudiciariaVO> listar() throws ValidationException {

		Timer timer = habilitarTimer("listar");

		List<SecaoJudiciariaVO> list = secaoJudiciariaDAO.listar();

		desabilitarTimer(timer);

		return list;
	}
}
