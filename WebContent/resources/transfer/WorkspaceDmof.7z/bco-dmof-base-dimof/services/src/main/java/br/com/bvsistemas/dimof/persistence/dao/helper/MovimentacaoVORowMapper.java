package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de Movimenta��o
 * 
 * @spring.bean name="movimentacaoRowMapper" lazy-init="true" scope="singleton"
 * 
 * @author palmeida
 * 
 */
public class MovimentacaoVORowMapper implements RowMapper<MovimentacaoVO> {
	
	/**
	 * Rowmapper para armazenar dados de pessoas.
	 */
	private RowMapper<PessoaVO> pessoaRowMapper;

	/**
	 * Mapeia o resultSet para o objeto movimentoVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public MovimentacaoVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		IdentifierPK cdMovimentacaoPK = new IdentifierPK(1);
		MovimentacaoVO vo = new MovimentacaoVO(cdMovimentacaoPK);

		final int semestre = rs.getInt("semestre");
		final int ano = rs.getInt("ano");

		final BVFloat vrDebMes1 = new BVFloat(rs.getString("vrDebMes1")!= null ? rs.getString("vrDebMes1") : "0");
		final BVFloat vrCredMes1 = new BVFloat(rs.getString("vrCredMes1")!= null ? rs.getString("vrCredMes1") : "0");
		final BVFloat vrDebMes2 = new BVFloat(rs.getString("vrDebMes2")!= null ? rs.getString("vrDebMes2") : "0");
		final BVFloat vrCredMes2 = new BVFloat(rs.getString("vrCredMes2")!= null ? rs.getString("vrCredMes2") : "0");
		final BVFloat vrDebMes3 = new BVFloat(rs.getString("vrDebMes3")!= null ? rs.getString("vrDebMes3") : "0");
		final BVFloat vrCredMes3 = new BVFloat(rs.getString("vrCredMes3")!= null ? rs.getString("vrCredMes3") : "0");
		final BVFloat vrDebMes4 = new BVFloat(rs.getString("vrDebMes4")!= null ? rs.getString("vrDebMes4") : "0");
		final BVFloat vrCredMes4 = new BVFloat(rs.getString("vrCredMes4")!= null ? rs.getString("vrCredMes4") : "0");
		final BVFloat vrDebMes5 = new BVFloat(rs.getString("vrDebMes5")!= null ? rs.getString("vrDebMes5") : "0");
		final BVFloat vrCredMes5 = new BVFloat(rs.getString("vrCredMes5")!= null ? rs.getString("vrCredMes5") : "0");
		final BVFloat vrDebMes6 = new BVFloat(rs.getString("vrDebMes6")!= null ? rs.getString("vrDebMes6") : "0");
		final BVFloat vrCredMes6 = new BVFloat(rs.getString("vrCredMes6")!= null ? rs.getString("vrCredMes6") : "0");

		final BVFloat vrCompCambMes1 = new BVFloat(rs.getString("vrCompCambMes1")!= null ? rs.getString("vrCompCambMes1") : "0");
		final BVFloat vrVendCambMes1 = new BVFloat(rs.getString("vrVendCambMes1")!= null ? rs.getString("vrVendCambMes1") : "0");
		final BVFloat vrTranCambMes1 = new BVFloat(rs.getString("vrTranCambMes1")!= null ? rs.getString("vrTranCambMes1") : "0");
		final BVFloat vrCompCambMes2 = new BVFloat(rs.getString("vrCompCambMes2")!= null ? rs.getString("vrCompCambMes2") : "0");
		final BVFloat vrVendCambMes2 = new BVFloat(rs.getString("vrVendCambMes2")!= null ? rs.getString("vrVendCambMes2") : "0");
		final BVFloat vrTranCambMes2 = new BVFloat(rs.getString("vrTranCambMes2")!= null ? rs.getString("vrTranCambMes2") : "0");
		final BVFloat vrCompCambMes3 = new BVFloat(rs.getString("vrCompCambMes3")!= null ? rs.getString("vrCompCambMes3") : "0");
		final BVFloat vrVendCambMes3 = new BVFloat(rs.getString("vrVendCambMes3")!= null ? rs.getString("vrVendCambMes3") : "0");
		final BVFloat vrTranCambMes3 = new BVFloat(rs.getString("vrTranCambMes3")!= null ? rs.getString("vrTranCambMes3") : "0");
		final BVFloat vrCompCambMes4 = new BVFloat(rs.getString("vrCompCambMes4")!= null ? rs.getString("vrCompCambMes4") : "0");
		final BVFloat vrVendCambMes4 = new BVFloat(rs.getString("vrVendCambMes4")!= null ? rs.getString("vrVendCambMes4") : "0");
		final BVFloat vrTranCambMes4 = new BVFloat(rs.getString("vrTranCambMes4")!= null ? rs.getString("vrTranCambMes4") : "0");
		final BVFloat vrCompCambMes5 = new BVFloat(rs.getString("vrCompCambMes5")!= null ? rs.getString("vrCompCambMes5") : "0");
		final BVFloat vrVendCambMes5 = new BVFloat(rs.getString("vrVendCambMes5")!= null ? rs.getString("vrVendCambMes5") : "0");
		final BVFloat vrTranCambMes5 = new BVFloat(rs.getString("vrTranCambMes5")!= null ? rs.getString("vrTranCambMes5") : "0");
		final BVFloat vrCompCambMes6 = new BVFloat(rs.getString("vrCompCambMes6")!= null ? rs.getString("vrCompCambMes6") : "0");
		final BVFloat vrVendCambMes6 = new BVFloat(rs.getString("vrVendCambMes6")!= null ? rs.getString("vrVendCambMes6") : "0");
		final BVFloat vrTranCambMes6 = new BVFloat(rs.getString("vrTranCambMes6")!= null ? rs.getString("vrTranCambMes6") : "0");
		
		if (pessoaRowMapper != null) {
			vo.setCliente(pessoaRowMapper.mapRow(rs, rowNum));
		}	

		vo.setPk(cdMovimentacaoPK);
		vo.setAno(ano);
		vo.setSemestre(semestre);
		vo.setVrCredMes1(vrCredMes1);
		vo.setVrDebMes1(vrDebMes1);
		vo.setVrCredMes2(vrCredMes2);
		vo.setVrDebMes2(vrDebMes2);
		vo.setVrCredMes3(vrCredMes3);
		vo.setVrDebMes3(vrDebMes3);
		vo.setVrCredMes4(vrCredMes4);
		vo.setVrDebMes4(vrDebMes4);
		vo.setVrCredMes5(vrCredMes5);
		vo.setVrDebMes5(vrDebMes5);
		vo.setVrCredMes6(vrCredMes6);
		vo.setVrDebMes6(vrDebMes6);
		
		vo.setVrCompCambMes1(vrCompCambMes1);
		vo.setVrVendCambMes1(vrVendCambMes1);
		vo.setVrTranCambMes1(vrTranCambMes1);
		vo.setVrCompCambMes2(vrCompCambMes2);
		vo.setVrVendCambMes2(vrVendCambMes2);
		vo.setVrTranCambMes2(vrTranCambMes2);
		vo.setVrCompCambMes3(vrCompCambMes3);
		vo.setVrVendCambMes3(vrVendCambMes3);
		vo.setVrTranCambMes3(vrTranCambMes3);
		vo.setVrCompCambMes4(vrCompCambMes4);
		vo.setVrVendCambMes4(vrVendCambMes4);
		vo.setVrTranCambMes4(vrTranCambMes4);
		vo.setVrCompCambMes5(vrCompCambMes5);
		vo.setVrVendCambMes5(vrVendCambMes5);
		vo.setVrTranCambMes5(vrTranCambMes5);
		vo.setVrCompCambMes6(vrCompCambMes6);
		vo.setVrVendCambMes6(vrVendCambMes6);
		vo.setVrTranCambMes6(vrTranCambMes6);

		
		return vo;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de pessoas.
	 * 
	 * @spring.property ref="pessoaRowMapper"
	 * @param pessoaRowMapper
	 *            pessoaRowMapper a ser setado
	 */
	public void setPessoaRowMapper(RowMapper<PessoaVO> pessoaRowMapper) {
		this.pessoaRowMapper = pessoaRowMapper;
	}

}
