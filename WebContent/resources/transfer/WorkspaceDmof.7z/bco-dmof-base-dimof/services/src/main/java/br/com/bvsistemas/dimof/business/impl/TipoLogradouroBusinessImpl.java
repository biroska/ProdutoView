/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.dimof.persistence.dao.TipoLogradouroDAO;
import br.com.bvsistemas.dimof.services.TipoLogradouroServices;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o do cadastro de tipos de logradouros.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.TipoLogradouroBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class TipoLogradouroBusinessImpl extends AbstractBusiness implements 
	TipoLogradouroServices {

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(TipoLogradouroBusinessImpl.class);

	// DAO para acesso aos tipos de logradouros
	private TipoLogradouroDAO tipoLogradouroDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo
	 *            O m�todo que ser� avaliado pelo timer
	 * @return Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo TipoLogradouroBusinessImpl." 
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}


	
	

	/**
	 * @param tipoLogradouroDAO
	 *            the tipoLogradouroDAO to set
	 * @spring.property ref="tipoLogradouroDAO"
	 */
	public void setTipoLogradouroDAO(TipoLogradouroDAO tipoLogradouroDAO) {
		this.tipoLogradouroDAO = tipoLogradouroDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.TipoLogradouroServices#listar()
	 */
	@SuppressWarnings("unused")
	public List<TipoLogradouroVO> listar() throws ValidationException {

		Timer timer = habilitarTimer("listar");

		List<TipoLogradouroVO> list = tipoLogradouroDAO.listar();

		desabilitarTimer(timer);

		return list;
	}
}
