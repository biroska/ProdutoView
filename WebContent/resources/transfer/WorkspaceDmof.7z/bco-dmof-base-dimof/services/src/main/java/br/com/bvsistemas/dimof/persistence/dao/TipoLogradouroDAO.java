/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO respons�vel pela manuten��o de dados de Tipo Logradouro.
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public interface TipoLogradouroDAO {

	/**
	 * Busca todos os tipos de logradouros do sistema.
	 * 
	 * @return Lista de objetos <code>TipoLogradouroVO</code>
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	List<TipoLogradouroVO> listar() throws PersistenceException;

}
