/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.ArrayList;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.exception.LiminarDuplicadaException;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoLiminarDAO;
import br.com.bvsistemas.dimof.persistence.dao.LiminarDAO;
import br.com.bvsistemas.dimof.services.LiminarServices;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.StringUtils;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o de cadastro de liminar.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.LiminarBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 */
public class LiminarBusinessImpl extends AbstractBusiness implements
		LiminarServices {

	// Constantes para nome do campo alterado
	private static final String CD_CLIENTE = "CLIENTE";
	private static final String NU_LIMINAR = "No. LIMINAR";
	private static final String NU_VARA_TRAMITACAO = "No. VARA TRAMITACAO";
	private static final String NU_SECAO = "No. SECAO JUDICIARIA";
	private static final String NM_SUBSECAO = "NOME SUBSECAO JUDICIARIA";
	private static final String DT_INI_VIGENCIA = "DATA INICIO VIGENCIA";
	private static final String DT_EXPEDICAO = "DATA EXPEDICAO";
	private static final String DT_FIM_VIGENCIA = "DATA FIM VIGENCIA";
	private static final String FL_CASSACAO_RETROATIVA = "CASSACAO RETROATIVA";

	// Constantes para mascara da data

	private static final String DD_MM_YYYY = "dd/MM/yyyy";

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(LiminarBusinessImpl.class);

	// DAO para acesso �s Liminares
	private LiminarDAO liminarDAO;

	// DAO para acesso ao hist�rico de liminar
	private HistoricoLiminarDAO historicoLiminarDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo -
	 *            O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
	   Timer timer = new Timer("Tempo do m�todo LiminarBusinessImpl." + metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer -
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	/**
	 * Gerar hist�rico de altera��es de liminar. Uma liminar alterada pode ter
	 * v�rios registros na tabela de hist�rico.
	 * 
	 * @param liminar
	 *            Liminar alterada
	 * @return Lista de historico para a liminar a ser atualizada
	 * 
	 * @exception ValidationException
	 */
	private List<HistoricoLiminarVO> gerarHistorico(LiminarVO liminar,
			String usuario) throws ValidationException {

		HistoricoLiminarVO historico;
		List<HistoricoLiminarVO> hisList = new ArrayList<HistoricoLiminarVO>();

		Timer timer = habilitarTimer("gerarHistorico");

		// Consultar os dados originais da liminar (sem as altera��es
		// do usu�rio)
		LiminarVO liminarOriginal = liminarDAO.consultar(liminar.getPk());
		// Verifica a integridade da liminar original
		if (liminarOriginal.getPk() == null
				|| liminarOriginal.getPk().getId() == null) {
			throw new ValidationException("Liminar nao encontrada na base");
		}
		// Compara campo a campo para verificar se houve altera��o
		// Compara o Id do cliente
		if (!liminar.getCliente().getPk().getId().equals(
				liminarOriginal.getCliente().getPk().getId())) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(CD_CLIENTE);
			historico.setDsDadoAntigo(liminarOriginal.getCliente()
					.getNmPessoa());
			historico.setDsDadoNovo(liminar.getCliente().getNmPessoa());
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);
		}

		// Compara o N�mero da liminar
		if (liminar.getNuLiminar() != liminarOriginal.getNuLiminar()) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(NU_LIMINAR);
			historico.setDsDadoAntigo(Long.toString(liminarOriginal
					.getNuLiminar()));
			historico.setDsDadoNovo(Long.toString(liminar.getNuLiminar()));
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);

		}

		// Compara data inicio vigencia
		if (liminar.getDtIniVigencia().compareTo(
				liminarOriginal.getDtIniVigencia()) != 0) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(DT_INI_VIGENCIA);
			historico.setDsDadoNovo(liminar.getDtIniVigencia().toString(
					DD_MM_YYYY));
			historico.setDsDadoAntigo(liminarOriginal.getDtIniVigencia()
					.toString(DD_MM_YYYY));
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);
		}

		// Compara data expedi��o
		if (liminar.getDtExpedicao()
				.compareTo(liminarOriginal.getDtExpedicao()) != 0) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(DT_EXPEDICAO);
			historico.setDsDadoNovo(liminar.getDtExpedicao().toString(
					DD_MM_YYYY));
			historico.setDsDadoAntigo(liminarOriginal.getDtExpedicao()
					.toString(DD_MM_YYYY));
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);
		}

		// Compara data fim vigencia
		if (!(liminar.getDtFimVigencia() == null && liminarOriginal
				.getDtFimVigencia() == null)) {
			if ((liminar.getDtFimVigencia() == null && liminarOriginal
					.getDtFimVigencia() != null)
					|| (liminar.getDtFimVigencia() != null && liminarOriginal
							.getDtFimVigencia() == null)) {
				historico = new HistoricoLiminarVO(new IdentifierPK());

				historico.setNuLiminar(liminarOriginal.getNuLiminar());

				historico.setNmCampo(DT_FIM_VIGENCIA);
				if (liminar.getDtFimVigencia() != null)
					historico.setDsDadoNovo(liminar.getDtFimVigencia()
							.toString(DD_MM_YYYY));
				else {
					historico.setDsDadoNovo("");
				}
				if (liminarOriginal.getDtFimVigencia() != null)
					historico.setDsDadoAntigo(liminarOriginal
							.getDtFimVigencia().toString(DD_MM_YYYY));
				else {
					historico.setDsDadoAntigo("");
				}
				historico.setLiminar(liminarOriginal);
				historico.setDsLogin(usuario);
				hisList.add(historico);
			} else if (liminar.getDtFimVigencia().compareTo(
					liminarOriginal.getDtFimVigencia()) != 0) {

				historico = new HistoricoLiminarVO(new IdentifierPK());
				historico.setNuLiminar(liminarOriginal.getNuLiminar());
				historico.setNmCampo(DT_FIM_VIGENCIA);
				historico.setDsDadoNovo(liminar.getDtFimVigencia().toString(
						DD_MM_YYYY));
				historico.setDsDadoAntigo(liminarOriginal.getDtFimVigencia()
						.toString(DD_MM_YYYY));
				historico.setLiminar(liminarOriginal);
				historico.setDsLogin(usuario);
				hisList.add(historico);
			}
		}
		// Compara flag cassa��o retroativa
		if (liminar.getFlCassacaoRetroativa().innerValue().compareTo(
				liminarOriginal.getFlCassacaoRetroativa().innerValue()) != 0) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(FL_CASSACAO_RETROATIVA);
			historico.setDsDadoNovo(liminar.getFlCassacaoRetroativa()
					.innerValue().toString());
			historico.setDsDadoAntigo(liminarOriginal.getFlCassacaoRetroativa()
					.innerValue().toString());
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);
		}

		// Compara n�mero da se��o
		if (liminar.getNuSecaoJudiciaria() != liminarOriginal
				.getNuSecaoJudiciaria()) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(NU_SECAO);
			historico.setDsDadoNovo(Integer.toString(liminar
					.getNuSecaoJudiciaria()));
			historico.setDsDadoAntigo(Integer.toString(liminarOriginal
					.getNuSecaoJudiciaria()));
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);
		}

		// Compara n�mero vara tramita��o
		if (liminar.getNuVaraTramitacao() != liminarOriginal
				.getNuVaraTramitacao()) {

			historico = new HistoricoLiminarVO(new IdentifierPK());
			historico.setNuLiminar(liminarOriginal.getNuLiminar());
			historico.setNmCampo(NU_VARA_TRAMITACAO);
			historico.setDsDadoNovo(Integer.toString(liminar
					.getNuVaraTramitacao()));
			historico.setDsDadoAntigo(Integer.toString(liminarOriginal
					.getNuVaraTramitacao()));
			historico.setLiminar(liminarOriginal);
			historico.setDsLogin(usuario);
			hisList.add(historico);
		}

		// Compara Nome da Subse��o
		if(!(liminar.getNmSubsecaoJudiciaria() == null && liminarOriginal
				.getNmSubsecaoJudiciaria() == null)) {
		if ((liminar.getNmSubsecaoJudiciaria() == null && liminarOriginal
				.getNmSubsecaoJudiciaria() != null) ||
			(liminar.getNmSubsecaoJudiciaria() != null && liminarOriginal
					.getNmSubsecaoJudiciaria() == null)){

				historico = new HistoricoLiminarVO(new IdentifierPK());
				historico.setNuLiminar(liminarOriginal.getNuLiminar());
				historico.setNmCampo(NM_SUBSECAO);
				if (liminar.getNmSubsecaoJudiciaria() != null)
					historico.setDsDadoNovo(liminar.getNmSubsecaoJudiciaria());
				else {
					historico.setDsDadoNovo("");
				}
				if (liminarOriginal.getNmSubsecaoJudiciaria() != null)
					historico.setDsDadoAntigo(liminarOriginal
							.getNmSubsecaoJudiciaria());
				else {
					historico.setDsDadoAntigo("");
				}
				historico.setLiminar(liminarOriginal);
				historico.setDsLogin(usuario);
				hisList.add(historico);

			} else if (!liminar.getNmSubsecaoJudiciaria().equalsIgnoreCase(
					liminarOriginal.getNmSubsecaoJudiciaria())) {

				historico = new HistoricoLiminarVO(new IdentifierPK());
				historico.setNuLiminar(liminarOriginal.getNuLiminar());
				historico.setNmCampo(NM_SUBSECAO);
				historico.setDsDadoNovo(liminar.getNmSubsecaoJudiciaria());
				historico.setDsDadoAntigo(liminarOriginal
						.getNmSubsecaoJudiciaria());
				historico.setLiminar(liminarOriginal);
				historico.setDsLogin(usuario);
				hisList.add(historico);
			}
		}

		desabilitarTimer(timer);

		return hisList;
	}

	/**
	 * @param liminarDAO
	 *            the liminarDAO to set
	 * 
	 * @spring.property ref="liminarDAO"
	 */
	public void setLiminarDAO(LiminarDAO liminarDAO) {
		this.liminarDAO = liminarDAO;
	}

	/**
	 * @param historicoLiminarDAO
	 *            the historicoLiminarDAO to set
	 * 
	 * @spring.property ref="historicoLiminarDAO"
	 */
	public void setHistoricoLiminarDAO(HistoricoLiminarDAO historicoLiminarDAO){
		this.historicoLiminarDAO = historicoLiminarDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.LiminarServices#atualizarLiminar(
	 * br.com.bvsistemas.dimof.datatype.LiminarVO)
	 */
	public int atualizarLiminar(LiminarVO liminar, String usuarioLogado)
			throws ValidationException, LiminarDuplicadaException {

		Timer timer = habilitarTimer("atualizarLiminar");

		if (liminar == null || liminar.getCliente() == null
				|| liminar.getDtExpedicao() == null
				|| liminar.getDtIniVigencia() == null
				|| new Long(liminar.getNuLiminar()) == null
				|| new Long(liminar.getNuSecaoJudiciaria()) == null
				|| new Long(liminar.getNuVaraTramitacao()) == null)
			throw new ValidationException("Liminar n�o infomada");

		LiminarVO liminarDuplicada = null;
		// recupera liminar com mesmo numero e cliente
		if (new Long(liminar.getNuLiminar()) != null
				&& liminar.getCliente() != null) {
			liminarDuplicada = liminarDAO.consultarPorNumeroCliente(new Long(
					liminar.getNuLiminar()), liminar.getCliente().getPk());
			// verifica se j� existe a liminar
			if (liminarDuplicada != null
					&& !liminarDuplicada.getPk().getId().equals(
							liminar.getPk().getId())) {
				throw new LiminarDuplicadaException();
			}
		}
		// Gera a lista de historico
		List<HistoricoLiminarVO> hisList = gerarHistorico(liminar,
				usuarioLogado);
		if (hisList.isEmpty()) {
			if (logger.workflow.isDebugEnabled()) {
				logger.workflow
						.debug("N�o foi encontrado nenhuma altera��o " +
								"na liminar: "
								+ liminar.getPk().getId());
			}
			return 0;
		} else {
			// Salva o historico de altera��o para a liminar
			historicoLiminarDAO.incluir(hisList);
		}
		desabilitarTimer(timer);
		// Atualiza a liminar em quest�o
		return liminarDAO.atualizar(liminar);
	}

	public LiminarVO consultaLiminarCliente(Long numLiminar,
			IdentifierPK pkPessoa) throws ValidationException {

		Timer timer = habilitarTimer("consultaLiminarCliente");

		LiminarVO liminar = liminarDAO.consultarPorNumeroCliente(numLiminar,
				pkPessoa);

		desabilitarTimer(timer);
		return liminar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.LiminarServices#
	 * consultarLiminar(br.com.bvsistemas.framework.datatype.IdentifierPK)
	 */
	public LiminarVO consultarLiminar(IdentifierPK pk)
			throws ValidationException {
		Timer timer = habilitarTimer("consultarLiminar");
		if (pk == null || pk.getId() == null) {
			throw new ValidationException();
		}
		LiminarVO liminar = null;
		liminar = liminarDAO.consultar(pk);
		desabilitarTimer(timer);
		return liminar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.LiminarServices#incluirLiminar(
	 * 	br.com.bvsistemas.dimof.datatype.LiminarVO)
	 */
	public int incluirLiminar(LiminarVO liminar) throws ValidationException,
			LiminarDuplicadaException {

		// habilita timer
		Timer timer = habilitarTimer("incluirLiminar");

		// Verifica se os atributos obrigatorios foram preenchidos
		if (liminar == null || liminar.getCliente() == null
				|| liminar.getDtExpedicao() == null
				|| liminar.getDtIniVigencia() == null
				|| new Long(liminar.getNuLiminar()) == null
				|| new Long(liminar.getNuSecaoJudiciaria()) == null
				|| new Long(liminar.getNuVaraTramitacao()) == null)
			throw new ValidationException("Liminar n�o infomada");

		LiminarVO liminarDuplicada = null;
		// recupera liminar com mesmo numero e cliente
		if (new Long(liminar.getNuLiminar()) != null
				&& liminar.getCliente() != null) {
			liminarDuplicada = liminarDAO.consultarPorNumeroCliente(new Long(
					liminar.getNuLiminar()), liminar.getCliente().getPk());
			// verifica se j� existe a liminar
			if (liminarDuplicada != null
					&& !liminarDuplicada.getPk().getId().equals(
							liminar.getPk().getId())) {
				throw new LiminarDuplicadaException();
			}
		}
		// realiza a inclus�o
		IdentifierPK pkLiminar = liminarDAO.incluir(liminar);
		// desabilita o timer
		desabilitarTimer(timer);

		return pkLiminar.getId().intValue();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.LiminarServices#listar(
	 *   	br.com.bvsistemas.framework.datatype.IdentifierPK,
	 *      java.lang.String, br.com.bvsistemas.framework.datatype.BVDate,
	 *      br.com.bvsistemas.framework.datatype.BVDate,
	 *      br.com.bvsistemas.framework.datatype.BooleanEnum)
	 */
	@SuppressWarnings("unused")
	public List<LiminarVO> listar(IdentifierPK pkPessoa, String nuLiminar,
			BVDate dtInicio, BVDate dtFim, BooleanEnum apenasVigentes)
			throws ValidationException,
			CamposObrigatoriosNaoPreenchidosException {

		Timer timer = habilitarTimer("listar");
		// Verifica preencgimento de campos obrigatorios
		if ((pkPessoa == null) && (nuLiminar == null) && (dtInicio == null)
				&& (dtFim == null) && (apenasVigentes == null)) {
			throw new CamposObrigatoriosNaoPreenchidosException();
		}
		// Verifica se o n�mero da liminar cont�m somente d�gitos
		if (nuLiminar != null && !StringUtils.isNumeric(nuLiminar)) {
			throw new ValidationException();
		}
		List<LiminarVO> list = liminarDAO.listar(pkPessoa, nuLiminar, dtInicio,
				dtFim, apenasVigentes);
		desabilitarTimer(timer);
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.LiminarServices#
	 *      listarHistoricoLiminar(br.com.bvsistemas.
	 *      framework.datatype.IdentifierPK,
	 *      java.lang.String, br.com.bvsistemas.framework.datatype.BVDate,
	 *      br.com.bvsistemas.framework.datatype.BVDate)
	 */
	public List<HistoricoLiminarVO> listarHistoricoLiminar(
			IdentifierPK pkCliente, String numLiminar, BVDate dtInicio,
			BVDate dtFim) throws ValidationException,
			CamposObrigatoriosNaoPreenchidosException {

		Timer timer = habilitarTimer("listarHistorico");
		// Verifica preencgimento de campos obrigatorios
		if ((pkCliente == null) && (numLiminar == null) && (dtInicio == null)
				&& (dtFim == null)) {
			throw new CamposObrigatoriosNaoPreenchidosException();
		}
		// Verifica se o n�mero da liminar cont�m somente d�gitos
		if (numLiminar != null && !StringUtils.isNumeric(numLiminar)) {
			throw new ValidationException();
		}
		List<HistoricoLiminarVO> list = historicoLiminarDAO.listar(pkCliente,
				numLiminar, dtInicio, dtFim);
		desabilitarTimer(timer);
		return list;

	}

}
