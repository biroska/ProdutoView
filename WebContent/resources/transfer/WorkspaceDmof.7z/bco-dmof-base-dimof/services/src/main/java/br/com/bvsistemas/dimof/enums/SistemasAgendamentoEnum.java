package br.com.bvsistemas.dimof.enums;

public enum SistemasAgendamentoEnum {

	CONTA_CORRENTE    	("1") ,
	CAMBIO            	("2") ,
	FUNDOS            	("3") , 
	RENDA_FIXA        	("4") ,
	CORRETORA         	("5") ,
	DERIVATIVOS       	("6");


	private SistemasAgendamentoEnum( String id ){
		this.id = id;
	}
	
	private String id;

	public String getId() {
		return id;
	}
}