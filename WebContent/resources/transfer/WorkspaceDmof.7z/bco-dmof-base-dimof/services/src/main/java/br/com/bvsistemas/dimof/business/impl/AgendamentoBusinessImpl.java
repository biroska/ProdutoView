/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ProcessamentoClienteVO;
import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoEmpresaVO;
import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoSistemaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.AgendamentoDAO;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoAgendamentoDAO;
import br.com.bvsistemas.dimof.persistence.dao.ProcessamentoClienteDAO;
import br.com.bvsistemas.dimof.persistence.dao.ResultadoProcessamentoEmpresaDAO;
import br.com.bvsistemas.dimof.persistence.dao.ResultadoProcessamentoSistemaDAO;
import br.com.bvsistemas.dimof.services.AgendamentoServices;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o de agendamentos.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.AgendamentoBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author Aimbere Galdino
 */
public class AgendamentoBusinessImpl extends AbstractBusiness implements
		AgendamentoServices {

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(AgendamentoBusinessImpl.class);

	// DAO para acesso aos agendamentos
	private AgendamentoDAO agendamentoDAO;
	
	private HistoricoAgendamentoDAO historicoAgendamentoDAO;
	
	private ResultadoProcessamentoSistemaDAO resultadoProcessamentoSistemaDAO;
	
	private ResultadoProcessamentoEmpresaDAO resultadoProcessamentoEmpresaDAO;
	
	private ProcessamentoClienteDAO processamentoClienteDAO;
	
	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo -
	 *            O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
	   Timer timer = new Timer("Tempo do m�todo LiminarBusinessImpl." + metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer -
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.AgendamentoServices#incluirAgendamento(
	 * 	br.com.bvsistemas.dimof.datatype.AgendamentoVO)
	 */
	public int incluirAgendamento(AgendamentoVO agendamento, List<PessoaVO> empresas, List<PessoaVO> clientes ) throws ValidationException{
		
		// habilita timer
		Timer timer = habilitarTimer("incluirAgendamento");
		
		agendamento.setFlAtivo( "S" );

		if ( validaCamposObrigatorios( agendamento )  ){
			agendamentoDAO.incluir( agendamento );
			
			if ( agendamento.getPk().getId() != null ){
				historicoAgendamentoDAO.incluir( new IdentifierPK( agendamento.getPk().getId() ) );
				
				List<ResultadoProcessamentoSistemaVO> resulList = montaResultadoProcessamentoSistema( agendamento );
				for ( ResultadoProcessamentoSistemaVO item : resulList) {
					resultadoProcessamentoEmpresaDAO.inserirParaEmpresas( convertTo( item ), empresas );
					resultadoProcessamentoSistemaDAO.inserirParaSistemasLegados( item );
				}
				processamentoClienteDAO.inserirParaTodosCLientes( montaProcessamentoCliente( agendamento ) , clientes );
			}
		}

		// desabilita o timer
		desabilitarTimer(timer);

		return -1;
	}
	
	private List<ResultadoProcessamentoSistemaVO> montaResultadoProcessamentoSistema( AgendamentoVO agendamento ){
		
		List<ResultadoProcessamentoSistemaVO> resulList = new ArrayList<ResultadoProcessamentoSistemaVO>();
		
		Long mesInicio = agendamento.getMesInicial().getPk().getId();
		Long mesFim = agendamento.getMesFinal().getPk().getId();
		
		for (long mes = mesInicio; mes <= mesFim; mes++) {
			
			ResultadoProcessamentoSistemaVO item = new ResultadoProcessamentoSistemaVO( new IdentifierPK() );
			
			item.setCdProcessamentoEscrituracao( Integer.valueOf( "" + agendamento.getPk().getId() ) );
			item.setQtRegistroProcessado( null );
			item.setQtRegistroErro( null );
			item.setDtResultadoProcessamento( new BVDate() );
			item.setMmProcessado( Integer.valueOf( ""+mes ) );
			item.setAaProcessado( agendamento.getAnoFinal() );
			
			resulList.add( item );
		}

		return resulList;
	}
	
	private ProcessamentoClienteVO montaProcessamentoCliente( AgendamentoVO agendamento ){
	
		if ( agendamento == null || agendamento.getPk().getId() == null ){
			return null;
		}
		
		IdentifierPK pkClienteVO = new IdentifierPK();
		
		return new ProcessamentoClienteVO( pkClienteVO, agendamento );
	}

	/**
	 * 
	 * Lista todos os agendamentos conforme filtro.
	 * 
	 * @param pkStatusProcessamento
	 *            Identificador do status do processamento (pk)
	 * @param nuMesInicial
	 *            Indice do mes de inicio
	 * @param anoInicial
	 *            Ano do inicio
	 * @param nuMesFinal
	 *            Indice do mes de final
	 * @param anoFinal
	 *            Ano do final
	 * 
	 * @return Lista de objetos <code>AgendamentoVO</code>
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	public List<AgendamentoVO> listar(String cdStatusProcessamento, String nuMesInicial,
			   						  String anoInicial, String nuMesFinal, String anoFinal )
			throws ValidationException, CamposObrigatoriosNaoPreenchidosException {

		Timer timer = habilitarTimer("AgendamentoBusinessImpl.listar");
		
//		Verifica os campos obrigatorios
		if ( StringUtils.isBlank( nuMesInicial ) ||
			 StringUtils.isBlank( anoInicial ) ||
			 StringUtils.isBlank( nuMesFinal ) ||
			 StringUtils.isBlank( anoFinal ) ) {
			
			throw new CamposObrigatoriosNaoPreenchidosException();
		}
		
		// Verifica o formato do campo
		if ( !StringUtils.isNumeric( nuMesInicial ) ||
			 !StringUtils.isNumeric( anoInicial ) ||
			 !StringUtils.isNumeric( nuMesFinal ) ||
			 !StringUtils.isNumeric( anoFinal ) ) {
			
			throw new ValidationException();
		}
		
		List<AgendamentoVO> listar = agendamentoDAO.listar(cdStatusProcessamento, nuMesInicial, anoInicial, nuMesFinal, anoFinal);
		
		desabilitarTimer(timer);
		
		return listar;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.AgendamentoServices#cancelar(java.lang.Long)
	 */
	public boolean cancelar(Long cdProcessamentoEscrituracao) throws PersistenceException {

		boolean executou = false;
		
		if ( cdProcessamentoEscrituracao != null && cdProcessamentoEscrituracao > 0 ){
			executou = agendamentoDAO.cancelar( cdProcessamentoEscrituracao );
			
			if ( executou ){
				executou = historicoAgendamentoDAO.incluir( new IdentifierPK( cdProcessamentoEscrituracao ) );
			}
		}
		
		return executou;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.AgendamentoBusiness#listarEmpresas(java.lang.Long)
	 */
	public List<PessoaVO> listarEmpresas( Long idAgendamento ) throws PersistenceException {

		List<PessoaVO> listarEmpresas = resultadoProcessamentoEmpresaDAO.listarEmpresas( idAgendamento );
		
		return listarEmpresas;
	}
	
	public List<PessoaVO> listarClientes( Long idAgendamento ) throws PersistenceException {
		List<PessoaVO> listarClientes = processamentoClienteDAO.listarClientes( idAgendamento );
		
		return listarClientes;
	}

	public List<ResultadoProcessamentoSistemaVO> listarSistemas( Long idAgendamento ) throws PersistenceException {
		List<ResultadoProcessamentoSistemaVO> listarPorAgendamento = resultadoProcessamentoSistemaDAO.listarSistemas(idAgendamento);
		
		return listarPorAgendamento;
	}
	
	public boolean validaCamposObrigatorios(AgendamentoVO agendamento) {
		
		boolean objValido = true;
		
		if ( agendamento.getStatusProcessamento().getPk().getId() == null ){
			objValido = false;
		}
		
		if ( agendamento.getMesInicial().getPk().getId() == null ){
			objValido = false;
		}
		
		if ( agendamento.getAnoInicial() < 1 ){
			objValido = false;
		}
		
		if ( agendamento.getMesFinal().getPk().getId() == null ){
			objValido = false;
		}
		
		if ( agendamento.getAnoFinal() < 1 ){
			objValido = false;
		}
		
		if ( !"S".equals( agendamento.getFlAtivo() ) && 
			 !"N".equals( agendamento.getFlAtivo() ) ) {
				
			objValido = false;
		}
		
		if ( StringUtils.isBlank( agendamento.getUsuario() ) ){
			objValido = false;
		}
		
		return objValido;
	}
	
	private ResultadoProcessamentoEmpresaVO convertTo( ResultadoProcessamentoSistemaVO procSis ){
		
		if ( procSis == null ){
			return null;
		}
		
		ResultadoProcessamentoEmpresaVO procEmpresa = new ResultadoProcessamentoEmpresaVO( new IdentifierPK() );
		procEmpresa.setCdProcessamentoEscrituracao( procSis.getCdProcessamentoEscrituracao() );
		procEmpresa.setAaProcessado( procSis.getAaProcessado() );
		procEmpresa.setDtResultadoProcessamento( procSis.getDtResultadoProcessamento() );
		procEmpresa.setMmProcessado( procSis.getMmProcessado() );
		procEmpresa.setQtRegistroErro( procSis.getQtRegistroErro() );
		procEmpresa.setQtRegistroProcessado( procSis.getQtRegistroProcessado() );
		
		return procEmpresa;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.AgendamentoServices#consultarAgendamento(IdentifierPK pk)
	 */	
	public AgendamentoVO consultarAgendamento(IdentifierPK pk)
			throws ValidationException {

		Timer timer = habilitarTimer("consultarAgendamento");
		if (pk == null || pk.getId() == null) {
			throw new ValidationException();
		}
		AgendamentoVO agendamento = null;
		agendamento = agendamentoDAO.consultarPorCodigoAgendamento(pk);
		desabilitarTimer(timer);
		return agendamento;
	}		
	
	
	/**
	 * @param agendamentoDAO
	 *            the agendamentoDAO to set
	 * 
	 * @spring.property ref="agendamentoDAO"
	 */
	public void setAgendamentoDAO(AgendamentoDAO agendamentoDAO) {
		this.agendamentoDAO = agendamentoDAO;
	}

	/**
	 * @param histAgendamentoDAO
	 *            the histAgendamentoDAO to set
	 * 
	 * @spring.property ref="historicoAgendamentoDAO"
	 */
	public void setHistoricoAgendamentoDAO(
			HistoricoAgendamentoDAO historicoAgendamentoDAO) {
		this.historicoAgendamentoDAO = historicoAgendamentoDAO;
	}
	
	/**
	 * @param resultadoProcessamentoSistemaDAO
	 *            the resultadoProcessamentoSistemaDAO to set
	 * 
	 * @spring.property ref="resultadoProcessamentoSistemaDAO"
	 */
	public void setResultadoProcessamentoSistemaDAO(
			ResultadoProcessamentoSistemaDAO resultadoProcessamentoSistemaDAO) {
		this.resultadoProcessamentoSistemaDAO = resultadoProcessamentoSistemaDAO;
	}
	
	/**
	 * @param resultadoProcessamentoEmpresaDAO
	 *            the resultadoProcessamentoEmpresaDAO to set
	 * 
	 * @spring.property ref="resultadoProcessamentoEmpresaDAO"
	 */
	public void setResultadoProcessamentoEmpresaDAO(
			ResultadoProcessamentoEmpresaDAO resultadoProcessamentoEmpresaDAO) {
		this.resultadoProcessamentoEmpresaDAO = resultadoProcessamentoEmpresaDAO;
	}
	
	/**
	 * @param processamentoClienteDAO
	 *            the processamentoClienteDAO to set
	 * 
	 * @spring.property ref="processamentoClienteDAO"
	 */
	public void setProcessamentoClienteDAO(
			ProcessamentoClienteDAO processamentoClienteDAO) {
		this.processamentoClienteDAO = processamentoClienteDAO;
	}
}