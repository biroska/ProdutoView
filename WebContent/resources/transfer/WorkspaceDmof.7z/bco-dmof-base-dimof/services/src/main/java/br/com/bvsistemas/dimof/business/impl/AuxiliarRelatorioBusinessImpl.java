/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.dimof.persistence.dao.AuxiliarRelatorioDAO;
import br.com.bvsistemas.dimof.services.AuxiliarRelatorioServices;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o de AuxiliarRelatorio.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.AuxiliarRelatorioBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class AuxiliarRelatorioBusinessImpl extends AbstractBusiness 
	implements AuxiliarRelatorioServices {

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(AuxiliarRelatorioBusinessImpl.class);

	// DAO para acesso aos par�metros
	private AuxiliarRelatorioDAO auxiliarRelatorioDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo
	 *            O m�todo que ser� avaliado pelo timer
	 * @return Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo AuxiliarRelatorioBusinessImpl." 
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.AuxiliarRelatorioServices#regerar()
	 */
	@SuppressWarnings("unused")
	public int regerar(final AuxiliarRelatorioVO auxiliarRelatorio) 
		throws ValidationException {

		Timer timer = habilitarTimer("atualizar");

		if (auxiliarRelatorio == null) {
			throw new ValidationException();
		}

		int retorno = 0;

		Integer ano = new Integer(auxiliarRelatorio.getAno());
		Integer nuSemestre = new Integer(auxiliarRelatorio.getNuSemestre());

		// Consulta um registro por ano e semestre
		AuxiliarRelatorioVO vo = auxiliarRelatorioDAO
			.consultarPorAnoPorSemestre(ano, nuSemestre);

		// Verifica se o registro existe
		if (vo != null) {
			// Atualiza o registro
			retorno = alterarStatusProcessamento(auxiliarRelatorio);
		} else {
			// Inclui o registro
			retorno = incluir(auxiliarRelatorio);
		}

		desabilitarTimer(timer);
		
		return retorno;
	}

	/*
	 * Inclui um novo registro de relatorio.
	 */
	private int incluir(final AuxiliarRelatorioVO auxiliarRelatorio) {

		return auxiliarRelatorioDAO.incluir(auxiliarRelatorio);
	}

	/*
	 * Altera o campo status de processamento do relatorio.
	 */
	private int alterarStatusProcessamento(
			final AuxiliarRelatorioVO auxiliarRelatorio) {

		return auxiliarRelatorioDAO.alterarStatusProcessamento(
				auxiliarRelatorio);
	}

	/**
	 * @param auxiliarRelatorioDAO
	 *            the auxiliarRelatorioDAO to set
	 * @spring.property ref="auxiliarRelatorioDAO"
	 */
	public void setAuxiliarRelatorioDAO(
			AuxiliarRelatorioDAO auxiliarRelatorioDAO) {
		this.auxiliarRelatorioDAO = auxiliarRelatorioDAO;
	}
}
