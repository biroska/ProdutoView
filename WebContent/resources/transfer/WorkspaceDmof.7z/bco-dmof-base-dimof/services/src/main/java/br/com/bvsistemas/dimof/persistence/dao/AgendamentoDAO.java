/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de Liminar.
 * 
 * @author ematsuda
 * 
 */
public interface AgendamentoDAO {

	/**
	 * Lista os agendamentos de acordo com os parametros
	 * 
	 * @param cdStatusProcessamento
	 *            Status do processamento do agendamento.
	 * @param nuMesInicial
	 *            mes inicial do periodo
	 * @param anoInicial
	 * 			  ano inicial do periodo
	 * @param nuMesFinal
	 *            mes final do periodo
	 * @param anoFinal
	 * 			  ano final do periodo                    
	 * @return Dados da liminar desejada
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	public List<AgendamentoVO> listar(String cdStatusProcessamento,
			  String nuMesInicial, String anoInicial, String nuMesFinal,
			  String anoFinal) throws PersistenceException;

	/**
	 * Cancela um agendamento
	 * 
	 * @param id do agendamento
	 * @return boolean
	 * @throws PersistenceException
	 */
	boolean cancelar( Long cdProcessamentoEscrituracao ) throws PersistenceException;
	
	/**
	 * Inclui um novo registro de liminar.
	 * 
	 * @param agendamento
	 *            registro Liminar
	 * @return Dados do agendamento desejado
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	IdentifierPK incluir(AgendamentoVO agendamento ) throws PersistenceException;
	
	/**
	 * Consulta dados de um agendamento pelo codigo do agendamento
	 * 
	 * @param pk
	 *            pk do agendamento.         
	 * @return Dados do agendamento
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	AgendamentoVO consultarPorCodigoAgendamento(IdentifierPK pk) throws PersistenceException;	

}