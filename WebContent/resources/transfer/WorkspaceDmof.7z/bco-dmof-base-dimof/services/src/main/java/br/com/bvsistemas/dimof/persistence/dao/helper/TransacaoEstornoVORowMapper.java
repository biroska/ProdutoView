package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de Detalhe de Movimento de conta corrente
 * 
 * @spring.bean name="transacaoEstornoVORowMapper" lazy-init="true" scope="singleton"
 * 
 * @author elias.yoshida
 * 
 */
public class TransacaoEstornoVORowMapper implements RowMapper<TransacaoEstornoVO> {

	/**
	 * Mapeia o resultSet para o objeto TransacaoEstornoVORowMapper.
	 */
	public TransacaoEstornoVO mapRow(ResultSet rs, int rowNum) throws SQLException {
	    	final Integer cdTransacaoEstorno = rs.getInt("cdAssocTransacaoEstorno");
		IdentifierPK pk = new IdentifierPK(cdTransacaoEstorno);
		
		TransacaoEstornoVO vo = new TransacaoEstornoVO(pk);
		final Integer cdOrigem = rs.getInt("cdOrigem");
		final Integer cdTransacao = rs.getInt("cdTransacao");
		final String raizCnpj = rs.getString("raizCnpj");
		final String flAtivo = rs.getString("flAtivo");
		
		vo.setPk(pk);
		vo.setCdOrigem(cdOrigem);
		vo.setCdTransacao(cdTransacao);
		vo.setRaizCnpj(raizCnpj);
		vo.setFlAtivo(flAtivo);
		

		return vo;
	}

}
