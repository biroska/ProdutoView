package br.com.bvsistemas.dimof.business.impl;

import java.util.Date;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoVO;
import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.MovimentacaoDAO;
import br.com.bvsistemas.dimof.persistence.dao.PessoaDAO;
import br.com.bvsistemas.dimof.services.MovimentacaoServices;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.StringUtils;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o das movimentacoes do cliente
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.MovimentacaoBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:palmeida@ciandt.com">Priscila Almeida</a>
 */
public class MovimentacaoBusinessImpl extends AbstractBusiness implements MovimentacaoServices {

	// DAO para acesso a movimentacao
	private MovimentacaoDAO movimentacaoDAO;
	
	// DAO para acesso a informacao a Pessoa
	private PessoaDAO pessoaDAO;

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
	.getLogger(LiminarBusinessImpl.class);
	
	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo -
	 *            O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo MovimentacaoBusinessImpl." 
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer -
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}
	
	/**
	 * Retorna os detalhes do movimento para o cliente selecionado
	 */
	@SuppressWarnings("deprecation")
	public DetalheMovimentoVO detalharMovimento(String semestre, String ano, Integer cdPessoa) {
		IdentifierPK clientePK = new IdentifierPK(cdPessoa);
		DetalheMovimentoVO detalheMovimentoVO = new DetalheMovimentoVO(clientePK);

		PessoaVO cliente;
		List<DetalheMovimentoCambioVO> listaDetalheMovCambio;
		List<DetalheMovimentoCCVO> listaDetalheMovCC;
		
		// TODO Elias: ver como obter o numero da conta corrente
		detalheMovimentoVO.setNuContaCorrente("");
		
		cliente = pessoaDAO.consultaPelaChave(clientePK);
		detalheMovimentoVO.setCliente(cliente);
		
		// faz a conversao para periodo de data
		int anoInt = new Integer(ano).intValue() - 1900;
		Date dtInicio;
		Date dtFim;
		
		if ("1".equals(semestre)) { // 1o semestre
			dtInicio = new Date(anoInt, 0, 1);
			dtFim    = new Date(anoInt, 5, 30);
		} else { // 2o semestre
			dtInicio = new Date(anoInt,  6,  1);
			dtFim    = new Date(anoInt, 11, 31);
		}

		listaDetalheMovCambio = movimentacaoDAO.detalharMovimentoCambio(cdPessoa, dtInicio, dtFim);
		listaDetalheMovCC = movimentacaoDAO.detalharMovimentoContaCorrente(cdPessoa, dtInicio, dtFim);
		
		detalheMovimentoVO.setListaMovCambio(listaDetalheMovCambio);
		detalheMovimentoVO.setListaMovContaCC(listaDetalheMovCC);
		
		return detalheMovimentoVO;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.MovimentacaoServices#listar(
	 * java.lang.String,
	 * java.lang.String,
	 *  br.com.bvsistemas.framework.datatype.IdentifierPK)
	 * 
	 */
	@SuppressWarnings("unused")
	public List<MovimentacaoVO> listar(String semestre, String ano, 
			IdentifierPK pkCliente) throws ValidationException,
			CamposObrigatoriosNaoPreenchidosException{
		
		Timer timer = habilitarTimer("listar");
		
		//valida campo Obrigatorio
		if(semestre == null ||	ano == null )
			throw new CamposObrigatoriosNaoPreenchidosException();
		//valida valor dos campos
		if(!StringUtils.isNumeric(semestre) ||!StringUtils.isNumeric(ano))
			throw new ValidationException("valor inv�lido");	
	
		List<MovimentacaoVO> listaMov = movimentacaoDAO.listar(ano, semestre, 
				pkCliente);
		
		desabilitarTimer(timer);
		
		return listaMov;
	}

	/**
	 * @param MovimentacaoDAO
	 *            the movimentacaoDAO to set
	 * 
	 * @spring.property ref="movimentacaoDAO"
	 */
	public void setMovimentacaoDAO(MovimentacaoDAO movimentacaoDAO) {
		this.movimentacaoDAO = movimentacaoDAO;
	}

	/**
	 * @param PessoaDAO
	 * @spring.property ref="pessoaDAO"
	 */
	public void setPessoaDAO(PessoaDAO pessoaDAO) {
		this.pessoaDAO = pessoaDAO;
	}
}
