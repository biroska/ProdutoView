
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.TransacaoEstornoDAO;
import br.com.bvsistemas.framework.datatype.IdentifierDBKeyGenerator;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link TransacaoEstornoDAO}
 * <br>
 * <br>Hist�rico
 * <br>
 * <br>#001 - 07/02/2013 - deal.echiang
 * <br>Migra��o Sybase 12 para 15
 * 
 * @spring.bean name="transacaoEstornoDAO" lazy-init="true" scope="singleton"
 * 
 * @author talent.ealmeida
 */
public class TransacaoEstornoDAOImpl extends AbstractJdbcDao implements
	TransacaoEstornoDAO {

    /**
     * Componente de logging.
     */
    private final BVLogger logger = BVLogger.getLogger(TransacaoEstornoDAOImpl.class);

    /**
     * Identificador do hist�rico.
     */
    private IdentifierDBKeyGenerator transacaoEstornoKeyGenerator;

    /**
     * 
     * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
     * @param ds
     * @throws PersistenceException
     */
    public TransacaoEstornoDAOImpl(DataSource ds) throws PersistenceException {
	super(ds);
    }

    /**
     * RowMapper de par�metros do sistema utilizado na consulta.
     */
    RowMapper<TransacaoEstornoVO> transacaoEstornoVORowMapper;

    /*
	// Vers�o anterior
    public List<TransacaoEstornoVO> listar(Integer cdOrigem,
    	    Integer cdTransacao, String raizCnpj) throws PersistenceException {

    	String sqlCommand = this.getSqlCommand("listar");
    	Map<String, Object> namedParameters = new HashMap<String, Object>();

    	StringBuffer sql = new StringBuffer(sqlCommand);

    	namedParameters.put("cdOrigem", cdOrigem);
    	namedParameters.put("cdTransacao", cdTransacao);
    	namedParameters.put("nuRaizCnpj", raizCnpj);

    	final List<TransacaoEstornoVO> listaTransacaoEstorno = this
    		.executeQuery(sql.toString(), namedParameters, transacaoEstornoVORowMapper);
    	return listaTransacaoEstorno;
     }
	//-->
    
    // #001
    /* (non-Javadoc)
     * @see br.com.bvsistemas.dimof.persistence.dao.TransacaoEstornoDAO#listar(java.lang.Integer, java.lang.Integer, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    public List<TransacaoEstornoVO> listar(Integer cdOrigem,
	    Integer cdTransacao, String nuRaizCnpj) throws PersistenceException {

    	String sql = this.getSqlCommand("listar");
    	String filtroCdOrigem = this.getSqlCommand("filtroCdOrigem");
    	String filtroCdTransacao = this.getSqlCommand("filtroCdTransacao");
    	String filtroNuRaizCnpj = this.getSqlCommand("filtroNuRaizCnpj");
	
    	Map<String, Object> namedParameters = new HashMap<String, Object>();
    	
    	StringBuffer buffer = new StringBuffer();
    	buffer.append(sql);
    	
    	if( cdOrigem != null ) {
    		buffer.append(" ");
    		buffer.append(filtroCdOrigem);
    		
    		namedParameters.put("cdOrigem", cdOrigem);
    	}    	
    	if( cdTransacao != null ) {
    		buffer.append(" ");
    		buffer.append(filtroCdTransacao);
    		
    		namedParameters.put("cdTransacao", cdTransacao);
    	}
    	if( nuRaizCnpj != null ) {
    		buffer.append(" ");
    		buffer.append(filtroNuRaizCnpj);
    		
    		namedParameters.put("nuRaizCnpj", nuRaizCnpj);
    	}
    	
    	String query = buffer.toString();    	

    	List<TransacaoEstornoVO> listaTransacaoEstorno = 
    		this.executeQuery(query, namedParameters, transacaoEstornoVORowMapper);
    	return listaTransacaoEstorno;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * br.com.bvsistemas.dimof.persistence.dao.TransacaoEstornoDAO#inserir(br
     * .com.bvsistemas.dimof.datatype.TransacaoEstornoVO)
     */
    public IdentifierPK inserir(TransacaoEstornoVO transacaoEstornoVO)
	    throws PersistenceException {
	IdentifierPK pk = transacaoEstornoVO.getPk();
	Long id = pk.getId();

	// Verificando a PrimaryKey
	if (id == null) {
	    id = transacaoEstornoKeyGenerator.generate();
	    pk.setId(id);
	} 

	// Inserindo agendamento no banco de dados
	String sql = this.getSqlCommand("inserir");

	// Executa insert no banco
	int count = this.executeCommand(sql, transacaoEstornoVO);
	if (count != 1) {
	    String errorMsg = "A transa��o de estorno "
		    + "n�o foi inserida no banco de dados,  " + "erro!";
	    logger.workflow.warn(errorMsg);
	    throw new PersistenceException(errorMsg);
	}

	// Retorna pk do objeto inserido
	return pk;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * br.com.bvsistemas.dimof.persistence.dao.TransacaoEstornoDAO#atualizar
     * (br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO)
     */
    public int atualizar(TransacaoEstornoVO transacaoEstornoVO)
	    throws PersistenceException {

    	String sqlCommand = this.getSqlCommand("atualizar");
    	Map<String, Object> namedParameters = new HashMap<String, Object>();
    
    	StringBuffer sql = new StringBuffer(sqlCommand);

    	namedParameters.put("pk.id", transacaoEstornoVO.getPk().getId());
    	namedParameters.put("flAtivo", transacaoEstornoVO.getFlAtivo());
    	namedParameters.put("DtAlteracao", transacaoEstornoVO.getDataAlteracao());
    	namedParameters.put("nuRaizCnpj", transacaoEstornoVO.getRaizCnpj());
    	namedParameters.put("cdTransacao", transacaoEstornoVO.getCdTransacao());
    	namedParameters.put("cdOrigem", transacaoEstornoVO.getCdOrigem());
    	final int linhasAfetadas = this.executeCommand(sql.toString(), namedParameters);
	
    	if (linhasAfetadas < 1 ) {
	    String errorMsg = "A transa��o de estorno "
		    + "n�o foi atualizada no banco de dados,  " + "erro!";
	    logger.workflow.warn(errorMsg);
	    throw new PersistenceException(errorMsg);
	}
	return linhasAfetadas;
    }
     
    /**
     * M�todo para setar o RowMapper com detalhe de movimento de conta corrente
     * 
     * @spring.property ref="transacaoEstornoVORowMapper"
     * @param transacaoEstornoVORowMapper
     *            the detalheMovimentoCCRowMapper a ser setado
     */
    public void setTransacaoEstornoVORowMapper(
	    RowMapper<TransacaoEstornoVO> transacaoEstornoVORowMapper) {
	this.transacaoEstornoVORowMapper = transacaoEstornoVORowMapper;
    }

    /**
     * Seta o transacaoEstornoKeyGenerator, que ser� utilizado no m�todo incluir
     * para obter o IdentifierPK.
     * 
     * @spring.property ref="transacaoEstornoKeyGenerator"
     * @param transacaoEstornoKeyGenerator
     *            transacaoEstornoKeyGenerator para setar
     **/
    public void setTransacaoEstornoKeyGenerator(
	    IdentifierDBKeyGenerator transacaoEstornoKeyGenerator) {
	this.transacaoEstornoKeyGenerator = transacaoEstornoKeyGenerator;
    }

}
