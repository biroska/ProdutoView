/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de Liminar.
 * 
 * @author ematsuda
 * 
 */
public interface LiminarDAO {

	/**
	 * Consulta dados de uma liminar para gera��o de auditoria.
	 * 
	 * @param pk
	 *            Identificador da liminar (pk)
	 * @return Dados da liminar desejada
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	LiminarVO consultar(IdentifierPK pk) throws PersistenceException;

	/**
	 * Consulta dados de uma liminar pelo cliente e liminar
	 * 
	 * @param numeroLiminar
	 *            numero da liminar.
	 * @param idCliente
	 *            id do Cliente             
	 * @return Dados da liminar desejada
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	LiminarVO consultarPorNumeroCliente(Long numeroLiminar,
			IdentifierPK pkPessoa) throws PersistenceException;

	/**
	 * Atualiza uma determinada liminar, tambem gera log para os atributos
	 * alterados
	 * 
	 * @param liminar
	 * @return
	 * @throws PersistenceException
	 */
	int atualizar(LiminarVO liminar) throws PersistenceException;

	/**
	 * Busca liminares pelo filtro.
	 * 
	 * @param pkPessoa
	 *            Identificador da pessoa (pk)
	 * @param nuLiminar
	 *            Numero da liminar
	 * @param dtInicio
	 *            Data de inicio da vigencia
	 * @param dtFim
	 *            Data de fim da vigencia
	 * @param apenasVigentes
	 *            Flag que indica apenas liminares vigentes
	 * 
	 * @return Lista de objetos <code>LiminarVO</code>
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	List<LiminarVO> listar(IdentifierPK pkPessoa, String nuLiminar,
			BVDate dtInicio, BVDate dtFim, BooleanEnum apenasVigentes)
			throws PersistenceException;

	/**
	 * Inclui um novo registro de liminar.
	 * 
	 * @param liminar
	 *            registro Liminar
	 * @return Dados da liminar desejada
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	IdentifierPK incluir(LiminarVO liminar) throws PersistenceException;

}
