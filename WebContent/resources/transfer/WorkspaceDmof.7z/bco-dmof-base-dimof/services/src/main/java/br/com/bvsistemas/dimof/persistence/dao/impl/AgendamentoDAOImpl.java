/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.AgendamentoDAO;
import br.com.bvsistemas.dimof.persistence.dao.LiminarDAO;
import br.com.bvsistemas.framework.datatype.IdentifierDBKeyGenerator;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Implementa��o de {@link LiminarDAO}
 * 
 * @spring.bean name="agendamentoDAO" lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 * 
 */
public class AgendamentoDAOImpl extends AbstractJdbcDao implements AgendamentoDAO {

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(AgendamentoDAOImpl.class);
	
	private final Long CD_STATUS_CANCELADO = 5L;

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public AgendamentoDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	private RowMapper<AgendamentoVO> agendamentoRowMapper;
	
	
	/**
	 * Identificador do hist�rico.
	 */
	private IdentifierDBKeyGenerator agendamentoKeyGenerator;
	
	/* 
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#listar(br.com.bvsistemas.framework.datatype.IdentifierPK, 
	 *      java.lang.String, br.com.bvsistemas.framework.datatype.BVDate, br.com.bvsistemas.framework.datatype.BVDate, 
	 *      br.com.bvsistemas.framework.datatype.BolleanEnum)
	 */
	@SuppressWarnings("unchecked")
	public List<AgendamentoVO> listar(String cdStatusProcessamento,
			  String nuMesInicial, String anoInicial, String nuMesFinal,
			  String anoFinal)
			throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listar");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		montaRestricoes(cdStatusProcessamento, nuMesInicial, anoInicial, nuMesFinal,
				  anoFinal, namedParameters, sql);
		
		sql.append("\n ORDER BY procEscrit.DtInclusao desc");
		
		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sql.toString());
		}

		final List<AgendamentoVO> listaAgendamento = this.executeQuery(
				sql.toString(), namedParameters, agendamentoRowMapper);

		return listaAgendamento;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AgendamentoDAO#cancelar(java.lang.Long)
	 */
	public boolean cancelar( Long cdProcessamentoEscrituracao ) throws PersistenceException {
		
		boolean executou = false;
		
		if ( cdProcessamentoEscrituracao != null && cdProcessamentoEscrituracao > 0 ){
			String sql = this.getSqlCommand("cancelar");
			
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("status", this.CD_STATUS_CANCELADO );
			parameters.put("cdAgendamento", cdProcessamentoEscrituracao );
			
			if (logger.workflow.isDebugEnabled()) {
				logger.workflow.debug("Comando SQL gerado em cancelar");
				logger.workflow.debug(sql.toString());
			}
			
			int executionResult = this.executeCommand(sql, parameters);
			
			if ( executionResult > 0 ){
				executou = true;
			}
		}
		return executou;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AgendamentoDAO#incluir(br.com.bvsistemas.dimof.datatype.AgendamentoVO)
	 */
	public IdentifierPK incluir(AgendamentoVO agendamento) throws PersistenceException {
		
		IdentifierPK pk = agendamento.getPk();
		Long id = pk.getId();

		// Verificando a PrimaryKey	
		if (id == null) {
			id = agendamentoKeyGenerator.generate();
			pk.setId(id);
		}

		// Inserindo agendamento no banco de dados
		String sql = this.getSqlCommand("inserir");
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("id", id );
		parameters.put("statusProcessamento", agendamento.getStatusProcessamento().getPk().getId() );
		parameters.put("mesInicial", agendamento.getMesInicial().getPk().getId() );
		parameters.put("anoInicial", agendamento.getAnoInicial() );
		parameters.put("mesFinal", agendamento.getMesFinal().getPk().getId() );
		parameters.put("anoFinal", agendamento.getAnoFinal() );
		parameters.put("dtProcessamento", agendamento.getDtProcessamento() );
		parameters.put("flAtivo", agendamento.getFlAtivo() );
		parameters.put("usuario", agendamento.getUsuario());

		// Executa insert no banco
		int count = this.executeCommand(sql, parameters);
		
		if (count != 1) {
			String errorMsg = "O agendamento  "
				+ "n�o foi inserido no banco de dados,  "
				+ "erro!";
			logger.workflow.warn(errorMsg);
			throw new PersistenceException(errorMsg);
		}

		//Retorna pk do objeto inserido
		return pk;
	}
	 
	private void montaRestricoes(String cdStatusProcessamento,
								 String nuMesInicial, String anoInicial, String nuMesFinal, String anoFinal,
							 	 Map<String, Object> namedParameters, StringBuffer sql) {
		
		sql.append("\n WHERE 1 = 1");
		
		if ( StringUtils.isNumeric( cdStatusProcessamento ) && Integer.valueOf( cdStatusProcessamento ) > 0 ){
			sql.append("\n AND procEscrit.CdStatusProcessamento = :cdStatusProcessamento");
			namedParameters.put("cdStatusProcessamento", Integer.valueOf( cdStatusProcessamento ) );
		}
		
		if ( StringUtils.isNumeric( anoInicial ) && StringUtils.isNumeric( anoFinal ) &&
			 StringUtils.isNumeric( nuMesInicial ) && StringUtils.isNumeric( nuMesFinal ) ){
			
			String betweenRestricao = " BETWEEN CONVERT(date, :dtInicial , 103) and CONVERT(date, :dtFinal , 103) ";
			
			sql.append("\n AND CONVERT(date, '01/' || CONVERT( VARCHAR(2), procEscrit.MmInicioPeriodoProcessamento, 356) " +
                       " ||'/'|| CONVERT( VARCHAR(4), procEscrit.AaInicioPeriodoProcessamento, 365 ) , 103) " +
                           betweenRestricao );
			
			sql.append("\n AND CONVERT(date, '01/' || CONVERT( VARCHAR(2), procEscrit.MmFimPeriodoProcessamento, 356) " +
                       " ||'/'|| CONVERT( VARCHAR(4), procEscrit.AaFimPeriodoProcessamento, 365 ) , 103) " +
                           betweenRestricao );
			
			namedParameters.put("dtInicial", "01/"+nuMesInicial+"/"+anoInicial );
			namedParameters.put("dtFinal", "01/"+nuMesFinal+"/"+anoFinal );
		}
	}
	

	@SuppressWarnings("unchecked")
	public AgendamentoVO consultarPorCodigoAgendamento(IdentifierPK pk)
			throws PersistenceException {
		String sqlComando = this.getSqlCommand("listar");
		StringBuffer sql = new StringBuffer(sqlComando);
		
		Map<String, Object> namedParameters = new HashMap<String, Object>(2);
		
		if(pk.getId() != null) {
			sql.append("\n WHERE procEscrit.CdProcessamentoEscrituracao = :codigoAgendamento");
			namedParameters.put("codigoAgendamento", pk.getId());
		}

		final List<AgendamentoVO> agendamento = this.executeQuery(sql.toString(), namedParameters,
				agendamentoRowMapper);

		if (agendamento.size() != 1) {
			String errorMsg = "Liminar inexistente: pk[" + pk.getId()
			+ "] Qdte = " + agendamento.size();
			logger.workflow.warn(errorMsg);
			return null;
		} else{
			return agendamento.get(0);
		}		
		
		
	}	 /**
	 * Seta o historicoAgendamentoKeyGenerator, que ser� utilizado no m�todo incluir
	 * para obter o IdentifierPK.
	 * 
	 * @spring.property ref="agendamentoKeyGenerator"
	 * @param AgendamentoKeyGenerator
	 *            AgendamentoKeyGenerator para setar
	 */
	public void setAgendamentoKeyGenerator(
			IdentifierDBKeyGenerator agendamentoKeyGenerator) {
		this.agendamentoKeyGenerator =agendamentoKeyGenerator;
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="agendamentoRowMapper"
	 * @param agendamentoRowMapper
	 *            the agendamentoRowMapper a ser setado
	 */
	public void setAgendamentoRowMapper(
			RowMapper<AgendamentoVO> agendamentoRowMapper) {
		this.agendamentoRowMapper = agendamentoRowMapper;
	}
}
