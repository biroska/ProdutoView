/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.TipoLogradouroDAO;
import br.com.bvsistemas.dimof.persistence.dao.helper.TipoLogradouroVORowMapper;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * Implementa��o de {@link TipoLogradouroDAO}
 * 
 * @spring.bean name="tipoLogradouroDAO" lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class TipoLogradouroDAOImpl extends AbstractJdbcDao implements TipoLogradouroDAO {

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public TipoLogradouroDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.TipoLogradouroDAO#listar()
	 */
	@SuppressWarnings("unchecked")
	public List<TipoLogradouroVO> listar() {

		// Obtem a query
		String sql = this.getSqlCommand("listar");

		// Executa a consulta
		List<TipoLogradouroVO> result = getJdbcTemplate().query(sql, 
				new TipoLogradouroVORowMapper());

		return result;
	}
}
