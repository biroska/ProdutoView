/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de HistoricoAgendamento.
 * 
 * @author Aimbere Galdino
 * 
 */
public interface HistoricoAgendamentoDAO {

	/**
	 * 
	 * Gera registro HistoricoAgendamento na tabela TbLogProcessamentoEscrituracao.
	 * 
	 * @param IdentifierPK
	 *            Agendamento o qual ser� gerado hist�rico
	 * 
	 * @return Transacao realizada com sucesso ou nao <code>boolean</code>
	 * 
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	public boolean incluir(IdentifierPK pk) throws PersistenceException;
}