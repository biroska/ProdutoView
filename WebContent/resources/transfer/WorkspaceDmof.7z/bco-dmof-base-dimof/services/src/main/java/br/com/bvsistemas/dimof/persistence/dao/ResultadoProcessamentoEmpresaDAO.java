/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoEmpresaVO;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de ResultadoProcessamentoSstma.
 * 
 * @author Aimbere Galdino
 * 
 */
public interface ResultadoProcessamentoEmpresaDAO {

	/**
	 * Inclui um novo registro de ResultadoProcessamentoSstma.
	 * 
	 * @param ResultadoProcessamentoSistemaVO
	 *            ResultadoProcessamentoSistemaVO
	 * @return Dados do ResultadoProcessamentoSistemaVO desejado
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	ResultadoProcessamentoEmpresaVO inserirParaEmpresas(ResultadoProcessamentoEmpresaVO obj, List<PessoaVO> empresas ) throws PersistenceException;

	/**
	 * Inclui um novo registro de ResultadoProcessamentoSstma.
	 * 
	 * @param idAgendamento
	 *            id do agendamento
	 * @return Lista de empresas List<PessoaVO>
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	List<PessoaVO> listarEmpresas( Long idAgendamento ) throws PersistenceException;

}