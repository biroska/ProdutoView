/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.OrigemTransacaoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoVO;
import br.com.bvsistemas.framework.exception.PersistenceException;

public interface OrigemTransacaoDAO {
	
	/** 
	 * M�todo que traz a lista de origem da movimenta��o da conta corrente
	 * 
	 */
	List<OrigemTransacaoVO> listarOrigem() throws PersistenceException;
	
	/** 
	 * M�todo que traz a lista de transacoes de conta corrente
	 * 
	 */
	List<TransacaoVO> listarTransacao() throws PersistenceException;

	/**
	 * M�todo respons�vel por obter o nome da Transa��o
	 * 
	 * @param cdTransacao o identificador da transa��o que deve retornar o nome
	 *  
	 * @author talent.ealmeida
	 * 
	 * @return String com o nome da Transa��o
	 *  
	 * @throws PersistenceException
	 */
	public String getNomeTransacao(Integer cdTransacao) throws PersistenceException;
	
	
	/**
	 * M�todo respons�vel por retornar o nome da Origem
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param cdOrigem o identificador da Orige que deve retornar o nome
	 * 
	 * @return String com o nome da Origem
	 * 
	 * @throws PersistenceException
	 */
	public String getNomeOrigem(Integer cdOrigem) throws PersistenceException;
	
}
