/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.HistoricoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link HistoricoNaturezaJuridicaVO}
 * 
 * @spring.bean name="historicoNaturezaJuridicaRowMapper" lazy-init="true"
 *              scope="singleton"
 * 
 * @author resource.bcastro
 * 
 */
public class HistoricoNaturezaJuridicaVORowMapper implements
		RowMapper<HistoricoNaturezaJuridicaVO> {

//	/**
//	 * Rowmapper para armazenar dados do historico da natureza juridica.
//	 */
//	private RowMapper<HistoricoNaturezaJuridicaVO> historicoNaturezaJuridicaRowMapper;

	/**
	 * Mapeia o resultSet para o objeto HistoricoNaturezaJuridicaVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public HistoricoNaturezaJuridicaVO mapRow(ResultSet rs, int rowNum)
			throws SQLException {

		HistoricoNaturezaJuridicaVO vo = new HistoricoNaturezaJuridicaVO(
				new IdentifierPK());
		NaturezaJuridicaVO nat = new NaturezaJuridicaVO(new IdentifierPK());

		
		nat.setCdNaturezaJuridica(rs.getString("CdNaturezaJuridica"));
		nat.setNmNaturezaJuridica(rs.getString("NmNaturezaJuridica"));
		nat.setFlEnviaInformacaoEFinanceira(rs
				.getString("FlEnviaInformacaoEFinanceira"));
		nat.setDtInicioVigencia(rs.getDate("DtInicioVigencia"));
		nat.setDtFimVigencia(rs.getDate("DtFimVigencia"));
		nat.setDsLogin(rs.getString("DsLogin"));
		nat.setFlAtivo(rs.getString("FlAtivo"));

		vo.setDtLogNaturezaJuridica(new BVDatetime(rs.getTimestamp("DtLogNaturezaJuridicaEscro")));
		vo.setCdNaturezaJuridicaEscrituracao(rs.getLong("CdNaturezaJuridicaEscrituracao"));

		
		if (nat.getDtInicioVigencia() != null){
			nat.setDtInicio(DataUtils.dateToStr(nat.getDtInicioVigencia(),
					"MMMM/yyyy"));
		}

		if (nat.getDtFimVigencia() != null){
			nat.setDtFim(DataUtils.dateToStr(nat.getDtFimVigencia(),
					"MMMM/yyyy"));
		}
		
		vo.setNaturezaJuridica(nat);

		return vo;
	}
//
//	/**
//	 * M�todo para setar o RowMapper com informa��es do Historico da Natureza
//	 * Juridica.
//	 * 
//	 * @spring.property ref="historicoNaturezaJuridicaRowMapper"
//	 * @param historicoNaturezaJuridicaRowMapper
//	 *            historicoNaturezaJuridicaRowMapper a ser setado
//	 */
//	public void setHistoricoNaturezaJuridicaRowMapper(
//			RowMapper<HistoricoNaturezaJuridicaVO> historicoNaturezaJuridicaRowMapper) {
//		this.historicoNaturezaJuridicaRowMapper = historicoNaturezaJuridicaRowMapper;
//	}

}