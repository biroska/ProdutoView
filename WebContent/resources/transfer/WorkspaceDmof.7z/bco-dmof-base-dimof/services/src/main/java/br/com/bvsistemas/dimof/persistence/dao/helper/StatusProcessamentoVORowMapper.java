/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.StatusProcessamentoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link StatusProcessamentoVO}
 * 
 * @spring.bean name="statusProcessamentoRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author Ambere Galdino
 * 
 */
@SuppressWarnings("unused")
public class StatusProcessamentoVORowMapper implements RowMapper<StatusProcessamentoVO> {

	
	/**
	 * Rowmapper para armazenar dados de Status de Processamento.
	 */
	private RowMapper<StatusProcessamentoVO> statusProcessamentoRowMapper;
	
	/**
	 * Mapeia o resultSet para o objeto StatusProcessamentoVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public StatusProcessamentoVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final Long cdStatusProcessamento = rs.getLong("CdStatusProcessamento");
		IdentifierPK cdStatusProcessamentoPK = new IdentifierPK(cdStatusProcessamento);

		final String dsStatusProcessamento = rs.getString("DsStatusProcessamento");

		StatusProcessamentoVO vo = new StatusProcessamentoVO( cdStatusProcessamentoPK );
		vo.setDsStatusProcessamento( dsStatusProcessamento );

		return vo;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de Status de processamento.
	 * 
	 * @spring.property ref="statusProcessamentoRowMapper"
	 * @param statusProcessamentoRowMapper
	 *            statusProcessamentoRowMapper a ser setado
	 */
	public void setStatusProcessamentoRowMapper(
			RowMapper<StatusProcessamentoVO> statusProcessamentoRowMapper) {
		this.statusProcessamentoRowMapper = statusProcessamentoRowMapper;
	}
}