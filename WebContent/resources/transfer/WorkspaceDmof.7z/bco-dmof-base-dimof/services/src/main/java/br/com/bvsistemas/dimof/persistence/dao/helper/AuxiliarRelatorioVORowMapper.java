/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link AuxiliarRelatorioVO}
 * 
 * @spring.bean name="auxiliarRelatorioRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class AuxiliarRelatorioVORowMapper implements RowMapper<AuxiliarRelatorioVO> {

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.simple.ParameterizedRowMapper#mapRow(
	 *      java.sql.ResultSet, int)
	 */
	public AuxiliarRelatorioVO mapRow(ResultSet rs, int rowNum) 
		throws SQLException {

		IdentifierPK pk = new IdentifierPK(1);
		AuxiliarRelatorioVO vo = new AuxiliarRelatorioVO(pk);

		vo.setAno(rs.getInt("AaRelatorio"));
		vo.setNuSemestre(rs.getInt("NuSemestreRelatorio"));

		if ("S".equals(rs.getString("FlRetificadora"))) {
			vo.setFlRetificadora(BooleanEnum.SIM);
		} else {
			vo.setFlRetificadora(BooleanEnum.NAO);
		}

		vo.setTpProcessado(rs.getInt("TpProcessado"));

		return vo;
	}
}