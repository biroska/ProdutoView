/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;


import java.util.List;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;


/**
 * DAO de Natureza Juridica.
 * 
 * @author Bianca Paulino
 * 
 */
public interface NaturezaJuridicaDAO {
	
	/**
	 * 
	 * Lista todos as naturezas juridicas conforme filtro.
	 * 
	 * @param vo objeto NaturezaJuridicaVO
	 * @return Lista de objetos <code>NaturezaJuridicaVO</code>
	 * 
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	List<NaturezaJuridicaVO> listar(NaturezaJuridicaVO vo )
			throws PersistenceException;
	
	
	/**
	 * 
	 * Importar as naturezas juridicas da base GLOBAL para DIMOF, caso n�o exista.
	 * @param dsLogin
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	void importarNaturezaJuridicaDIMOF(String dsLogin) throws PersistenceException;

	/**
	 * 
	 * Verifica se existem Naturezas Juridicas com um determinado status
	 * @param flag
	 * @exception ValidationException, PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	boolean existePorFlag( String flag ) throws PersistenceException, ValidationException;
}