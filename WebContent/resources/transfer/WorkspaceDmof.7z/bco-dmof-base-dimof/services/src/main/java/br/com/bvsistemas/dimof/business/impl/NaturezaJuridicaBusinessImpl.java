/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.ArrayList;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.persistence.dao.NaturezaJuridicaDAO;
import br.com.bvsistemas.dimof.services.NaturezaJuridicaServices;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o de natureza Juridica.
 * 
 * @spring.bean 
 *              name="br.com.bvsistemas.dimof.business.impl.NaturezaJuridicaBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author Bianca Paulino
 */
public class NaturezaJuridicaBusinessImpl extends AbstractBusiness implements
		NaturezaJuridicaServices {

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(NaturezaJuridicaBusinessImpl.class);

	private NaturezaJuridicaDAO naturezaJuridicaDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo
	 *            - O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo NaturezaJuridicaBusinessImpl."
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer
	 *            - Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	/**
	 * @param naturezaJuridicaDAO
	 *            the naturezaJuridicaDAO to set
	 * @spring.property ref="naturezaJuridicaDAO"
	 */
	public void setNaturezaJuridicaDAO(NaturezaJuridicaDAO naturezaJuridicaDAO) {
		this.naturezaJuridicaDAO = naturezaJuridicaDAO;
	}
	
	@Override
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<NaturezaJuridicaVO> listar(NaturezaJuridicaVO vo)
			throws ValidationException {

		List<NaturezaJuridicaVO> lista = new ArrayList<NaturezaJuridicaVO>();

			Timer timer = habilitarTimer("NaturezaJuridicaBusinessImpl.listar");

			// Verifica a necessidade de importar as naturezas juridicas do
			// GLOBAL para o DIMOF.
			//naturezaJuridicaDAO.importarNaturezaJuridicaDIMOF(vo.getDsLogin());

			// Lista as naturezas juridicas do DIMOF.
			lista = naturezaJuridicaDAO.listar(vo);

			desabilitarTimer(timer);

			return lista;
	}
	
	@Override
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.existePorFlag", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public boolean existePorFlag( String flag ) throws PersistenceException, ValidationException {
		
		return  naturezaJuridicaDAO.existePorFlag( flag );
	}


}
