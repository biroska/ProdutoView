/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.corporativo.global.generic.datatypes.TipoPessoaEnum;
import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link ParametroSistemaVO}
 * 
 * @spring.bean name="parametroSistemaVORowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class ParametroSistemaVORowMapper implements RowMapper<ParametroSistemaVO> {

	/**
	 * Rowmapper para armazenar dados de tipos de logradouro.
	 */
	private RowMapper<TipoLogradouroVO> tipoLogradouroRowMapper;

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.simple.ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public ParametroSistemaVO mapRow(ResultSet rs, int rowNum) 
		throws SQLException {

		final int cdParametro = rs.getInt("CdParametroSistema");
		IdentifierPK cdParametroPK = new IdentifierPK(cdParametro);
		ParametroSistemaVO vo = new ParametroSistemaVO(cdParametroPK);

		vo.setVrLimitePF(new BVFloat(rs.getString("VrLimitePf")));
		vo.setVrLimitePJ(new BVFloat(rs.getString("VrLimitePj")));

		PessoaVO declarante = getPessoaVOPorTipo(
				"declarante", rs, rowNum);
		PessoaVO representanteLegal = getPessoaVOPorTipo(
				"representanteLegal", rs, rowNum);
		PessoaVO respPreenchimento = getPessoaVOPorTipo(
				"respPreenchimento", rs, rowNum);
		PessoaVO respAtendimentoRMF = getPessoaVOPorTipo(
				"respAtendimentoRMF", rs, rowNum);

		vo.setDeclarante(declarante);
		vo.setRepresentanteLegal(representanteLegal);
		vo.setRespPreenchimento(respPreenchimento);
		vo.setRespAtendimentoRMF(respAtendimentoRMF);

		vo.setTpSituacaoEspecial(rs.getString("TpSituacaoEspecial"));

		if (rs.getDate("DtEnvioSituacaoEspecial") != null) {
			final BVDate dtEvento = new BVDate(
					rs.getDate("DtEnvioSituacaoEspecial"));
			vo.setDtEnvioSituacaoEspecial(dtEvento);
		}

		if (tipoLogradouroRowMapper != null) {
			vo.setTipoLogradouroRespRMF(
					tipoLogradouroRowMapper.mapRow(rs, rowNum));
		}

		vo.setNmArquivo(rs.getString("NmArquivo"));

		return vo;
	}

	/*
	 * Obt�m um VO de um determinado tipo de Pessoa.
	 * @return Objeto <code>PessoaVO</code>
	 */
    private PessoaVO getPessoaVOPorTipo(final String tipo, ResultSet rs, 
    		int rowNum) throws SQLException {

		PessoaVO vo = null;

		// Nomes das colunas
		String colCdPessoa = null;
		String colNuCpfCnpj = null;
		String colNmPessoa = null;
		String colTpPessoa = null;

		if ("declarante".equals(tipo)) {
			colCdPessoa = "CdPessoaDeclarante";
			colNuCpfCnpj = "NuCpfCnpjDeclarante";
			colNmPessoa = "NmPessoaDeclarante";
			colTpPessoa = "TpPessoaDeclarante";
			
		} else if ("representanteLegal".equals(tipo)) {
			colCdPessoa = "CdPessoaRepresentanteLegal";
			colNuCpfCnpj = "NuCpfCnpjRepresentanteLegal";
			colNmPessoa = "NmPessoaRepresentanteLegal";
			colTpPessoa = "TpPessoaRepresentanteLegal";
			
		} else if ("respPreenchimento".equals(tipo)) {
			colCdPessoa = "CdPessoaRespPreenchimento";
			colNuCpfCnpj = "NuCpfCnpjRespPreenchimento";
			colNmPessoa = "NmPessoaRespPreenchimento";
			colTpPessoa = "TpPessoaRespPreenchimento";
			
		} else if ("respAtendimentoRMF".equals(tipo)) {
			colCdPessoa = "CdPessoaRespAtendimentoRMF";
			colNuCpfCnpj = "NuCpfCnpjRespAtendimentoRMF";
			colNmPessoa = "NmPessoaRespAtendimentoRMF";
			colTpPessoa = "TpPessoaRespAtendimentoRMF";
		}

		final Long cdPessoa = rs.getLong(colCdPessoa);
		IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);

		final String nuCpfCnpj = rs.getString(colNuCpfCnpj);
		final String nmPessoa = rs.getString(colNmPessoa);

		vo = new PessoaVO(cdPessoaPK);
		vo.setNuCpfCnpj(nuCpfCnpj);
		vo.setNmPessoa(nmPessoa);

		if (rs.getString(colTpPessoa) != null) {
			if (TipoPessoaEnum.FISICA.innerValue().equals(
					rs.getString(colTpPessoa))) {
				vo.setTpPessoa(TipoPessoaEnum.FISICA);
			} else {
				vo.setTpPessoa(TipoPessoaEnum.JURIDICA);
			}
		}

		return vo;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de tipos de logradouro.
	 * 
	 * @spring.property ref="tipoLogradouroRowMapper"
	 * @param tipoLogradouroRowMapper
	 *            tipoLogradouroRowMapper a ser setado
	 */
	public void setTipoLogradouroRowMapper(
			RowMapper<TipoLogradouroVO> tipoLogradouroRowMapper) {
		this.tipoLogradouroRowMapper = tipoLogradouroRowMapper;
	}
}