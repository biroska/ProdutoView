/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.ParametrizacaoNaturezaJuridicaDAO;
import br.com.bvsistemas.dimof.services.ParametrizacaoNaturezaJuridicaServices;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;



/**
 * Implementa�ao dos servi�os de manuten��o de cadastro de parametriza��es.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.ParametrizacaoNaturezaJuridicaBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 */
public class ParametrizacaoNaturezaJuridicaBusinessImpl extends AbstractBusiness implements
		ParametrizacaoNaturezaJuridicaServices {
	
	
	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(ParametrizacaoNaturezaJuridicaBusinessImpl.class);

	// DAO para acesso �s Parametriza��es
	private ParametrizacaoNaturezaJuridicaDAO parametrizacaoNaturezaJuridicaDAO;
	
	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo -
	 *            O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
	   Timer timer = new Timer("Tempo do m�todo ParametrizacaoNaturezaJuridicaBusinessImpl." + metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer -
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}
	
	/**
	 * @param parametrizacaoNaturezaJuridicaDAO
	 *            the parametrizacaoNaturezaJuridicaDAO to set
	 * 
	 * @spring.property ref="parametrizacaoNaturezaJuridicaDAO"
	 */
	public void setParametrizacaoNaturezaJuridicaDAO(ParametrizacaoNaturezaJuridicaDAO parametrizacaoNaturezaJuridicaDAO) {
		this.parametrizacaoNaturezaJuridicaDAO = parametrizacaoNaturezaJuridicaDAO;
	}
	

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.ParametrizacaoNaturezaJuridicaBusinessImpl#listarParametrizacoes()
	 */
	public List<ParametrizacaoNaturezaJuridicaVO> listarParametrizacoes(
			String cdNaturezaJuridica) throws ValidationException,
			CamposObrigatoriosNaoPreenchidosException {

		//List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacaoJuridicaVO = null;
		
		Timer timer = habilitarTimer("ParametrizacaoNaturezaJuridicaBusinessImpl.listarParametrizacoes");
		
		desabilitarTimer(timer);
		
		List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoesVO = parametrizacaoNaturezaJuridicaDAO.listarParametrizacoes(cdNaturezaJuridica);
		
		return listaParametrizacoesVO;
	
	}


	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.ParametrizacaoNaturezaJuridicaBusinessImpl#salvarParametrizacao()
	 */
	public int incluirParametrizacao(ParametrizacaoNaturezaJuridicaVO parametrizacao)
			throws javax.xml.bind.ValidationException,
			CamposObrigatoriosNaoPreenchidosException {
		// habilita timer
		Timer timer = habilitarTimer("incluirParametrizacao");

		
		if (parametrizacao == null) {
			throw new ValidationException("Parametriza��o n�o infomada");
		}
		
		// Verifica se os atributos obrigatorios foram preenchidos
		if (parametrizacao.getFlEnviaInformacaoEFinanceira() == null
				|| parametrizacao.getFlEnviaInformacaoEFinanceira().equalsIgnoreCase("")) {
			throw new ValidationException("Parametriza��o E-Financeira n�o infomada");
		}
		
		if (parametrizacao.getDtInicioVigencia() == null) {
			throw new ValidationException("Parametriza��o In�cio de Vig�ncia n�o infomada");
		}
		
		// realiza a inclus�o
		IdentifierPK pkParametrizacao = parametrizacaoNaturezaJuridicaDAO.inlcuir(parametrizacao);
		// desabilita o timer
		desabilitarTimer(timer);

		return pkParametrizacao.getId().intValue();

	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.ParametrizacaoNaturezaJuridicaBusinessImpl#salvarParametrizacao()
	 */
	public int atualizarParametrizacao(ParametrizacaoNaturezaJuridicaVO parametrizacao)
			throws javax.xml.bind.ValidationException,
			CamposObrigatoriosNaoPreenchidosException {
		// habilita timer
		Timer timer = habilitarTimer("atualizarParametrizacao");

		if (parametrizacao == null) {
			throw new ValidationException("Parametriza��o n�o infomada");
		}
		
		// Verifica se os atributos obrigatorios foram preenchidos
		if (parametrizacao.getFlEnviaInformacaoEFinanceira() == null
				|| parametrizacao.getFlEnviaInformacaoEFinanceira().equalsIgnoreCase("")) {
			throw new ValidationException("Parametriza��o FlEnviaInformacaoEFinanceira n�o infomada");
		}
		
		if (parametrizacao.getDtInicioVigencia() == null) {
			throw new ValidationException("Parametriza��o In�cio de Vig�ncia n�o infomada");
		}
		
		// realiza a inclus�o
		IdentifierPK pkParametrizacaoNaturezaJuridica = parametrizacaoNaturezaJuridicaDAO.atualizar(parametrizacao);
		// desabilita o timer
		desabilitarTimer(timer);

		return pkParametrizacaoNaturezaJuridica.getId().intValue();

	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.ParametrizacaoNaturezaJuridicaBusinessImpl#getNomeNaturezaJuridica()
	 */
	public String getNomeNaturezaJuridica(
			String cdNaturezaJuridica)
			throws javax.xml.bind.ValidationException,
			CamposObrigatoriosNaoPreenchidosException {
		
		return parametrizacaoNaturezaJuridicaDAO.getNomeNaturezaJuridica(cdNaturezaJuridica);
	}
	

}
