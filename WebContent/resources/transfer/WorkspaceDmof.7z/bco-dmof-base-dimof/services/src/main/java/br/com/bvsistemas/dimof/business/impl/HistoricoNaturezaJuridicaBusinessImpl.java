/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.ArrayList;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.HistoricoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoNaturezaJuridicaDAO;
import br.com.bvsistemas.dimof.services.HistoricoNaturezaJuridicaServices;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa�ao dos servi�os de manuten��o de natureza Juridica.
 * 
 * @spring.bean 
 *              name="br.com.bvsistemas.dimof.business.impl.HistoricoNaturezaJuridicaBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author Bianca Paulino
 */
public class HistoricoNaturezaJuridicaBusinessImpl extends AbstractBusiness implements
		HistoricoNaturezaJuridicaServices {

	/**
	 * Logger de eventos do BV
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(NaturezaJuridicaBusinessImpl.class);

	private HistoricoNaturezaJuridicaDAO historicoNaturezaJuridicaDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o
	 * 
	 * @param metodo
	 *            - O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo NaturezaJuridicaBusinessImpl."
				+ metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o
	 * 
	 * @param timer
	 *            - Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	@Override
	@ESBServiceAnnotation(name = "Dimof.HistoricoNaturezaJuridica.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<HistoricoNaturezaJuridicaVO> listar(HistoricoNaturezaJuridicaVO vo)
			throws ValidationException {

		List<HistoricoNaturezaJuridicaVO> lista = new ArrayList<HistoricoNaturezaJuridicaVO>();

		
			Timer timer = habilitarTimer("HistoricoNaturezaJuridicaBusinessImpl.listar");

			// Lista as naturezas juridicas do DIMOF.
			lista = historicoNaturezaJuridicaDAO.listar(vo);

			desabilitarTimer(timer);

			return lista;

	}

	/**
	 * @param historicoNaturezaJuridicaDAO
	 *            the historicoNaturezaJuridicaDAO to set
	 * @spring.property ref="historicoNaturezaJuridicaDAO"
	 */

	public void setHistoricoNaturezaJuridicaDAO(HistoricoNaturezaJuridicaDAO historicoNaturezaJuridicaDAO) {
		this.historicoNaturezaJuridicaDAO = historicoNaturezaJuridicaDAO;
	}

}
