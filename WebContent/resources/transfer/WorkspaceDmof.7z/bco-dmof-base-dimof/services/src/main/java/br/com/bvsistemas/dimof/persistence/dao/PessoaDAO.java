/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de Pessoa
 * 
 * @author ematsuda
 * 
 */
public interface PessoaDAO {

	
	
	/**
	 * Lista pessoa pelo Nome ou CPF/CNPJ
	 * 
	 * @param nmPessoa Nome da pessoa
	 * @param nuCpjCnpj CPF/CNPJ da pessoa
	 * @return Lista de pessoas
	 */
	List<PessoaVO> listar(String nmPessoa, String nuCpfCnpj);
	
	
	/**
	 * busca pessoa pelo id.
	 * 
	 * @param pkPessoa
	 * 
	 * @return o registro de uma pessoa.
	 */
	PessoaVO consultaPelaChave(IdentifierPK  idPessoa);
	
	
	/**
	 * busca pessoa pelo id.
	 * 
	 * @return retorna lista de empresas.
	 */
	List<PessoaVO> listarEmpresasParaAgendamento() throws PersistenceException; 

}