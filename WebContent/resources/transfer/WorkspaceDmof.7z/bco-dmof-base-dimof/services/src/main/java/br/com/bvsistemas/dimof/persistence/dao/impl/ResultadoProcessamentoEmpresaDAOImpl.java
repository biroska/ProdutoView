/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoEmpresaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.ResultadoProcessamentoEmpresaDAO;
import br.com.bvsistemas.framework.datatype.IdentifierDBKeyGenerator;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link ResultadoProcessamentoEmpresaDAO}
 * 
 * @spring.bean name="resultadoProcessamentoEmpresaDAO" lazy-init="true" scope="singleton"
 * 
 * @author Aimbere Galdino
 * 
 */
public class ResultadoProcessamentoEmpresaDAOImpl extends AbstractJdbcDao implements ResultadoProcessamentoEmpresaDAO {

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public ResultadoProcessamentoEmpresaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	private RowMapper<PessoaVO> pessoaRowMapper;
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	private IdentifierDBKeyGenerator resultadoProcessamentoEmpresaKeyGenerator;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.ResultadoProcessamentoEmpresaDAOO#incluir(br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoEmpresaVO)
	 */
	public ResultadoProcessamentoEmpresaVO inserirParaEmpresas( ResultadoProcessamentoEmpresaVO obj, List<PessoaVO> empresas ) throws PersistenceException {
		
		Map<String, Object> parameters = null;
		
		IdentifierPK pk = null;
		Long id = null;
		
		if ( empresas == null ){
			return obj;
		}
		
		try {
			String sql = this.getSqlCommand("inserirParaEmpresas");
			
			for (PessoaVO empresa : empresas) {
				
				pk = new IdentifierPK();
				id = resultadoProcessamentoEmpresaKeyGenerator.generate();
				pk.setId(id);
			
				parameters = new HashMap<String, Object>();
				
				parameters.put("cdResultadoPrcsoEmpraBV", pk.getId() );
				
				parameters.put("cdPessoaEmpresaBV", empresa.getPk().getId() );
			
				parameters.put("cdProcessamentoEscrituracao", obj.getCdProcessamentoEscrituracao() );
			
				parameters.put("qtRegistroProcessado", obj.getQtRegistroProcessado() );
			
				parameters.put("qtRegistroErro", obj.getQtRegistroErro() );
			
				parameters.put("dtResultadoProcessamento", obj.getDtResultadoProcessamento() );
			
				parameters.put("mmProcessado", obj.getMmProcessado() );
			
				parameters.put("aaProcessado", obj.getAaProcessado() );
				
				// Executa insert no banco
				this.executeCommand(sql, parameters);
			}

		} catch ( Exception e){
			throw new PersistenceException( e.getMessage() );
		}
			
		//Retorna pk do objeto inserido
		return obj;
	}
	
	/* 
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.ResultadoProcessamentoEmpresaDAO#listar(br.com.bvsistemas.framework.datatype.IdentifierPK)
	 */
	@SuppressWarnings("unchecked")
	public List<PessoaVO> listarEmpresas( Long idAgendamento ) throws PersistenceException {
		
		List<PessoaVO> listaEmpresas = null;
		
		try {
			String sqlCommand = this.getSqlCommand("listarEmpresas");
			Map<String, Object> namedParameters = new HashMap<String, Object>();
			
			StringBuffer sql = new StringBuffer(sqlCommand);
			
			if ( idAgendamento != null ){
				sql.append(" \n WHERE procEmpresa.CdProcessamentoEscrituracao = :cdProcessamentoEscrituracao ");
				namedParameters.put("cdProcessamentoEscrituracao", idAgendamento );
			}
			
			sql.append("\n ORDER BY pe.nmPessoa ASC");
	
			listaEmpresas = this.executeQuery(
					sql.toString(), namedParameters, pessoaRowMapper );
			
		} catch ( Exception e ){
			throw new PersistenceException( e.getMessage() );
		}

		return listaEmpresas;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="pessoaRowMapper"
	 * @param pessoaRowMapper
	 *            the pessoaRowMapper a ser setado
	 */
	public void setPessoaRowMapper(
			RowMapper<PessoaVO> pessoaRowMapper) {
		this.pessoaRowMapper = pessoaRowMapper;
	}
	
	/**
	 * Seta o resultadoProcessamentoSistemaKeyGenerator, que ser� utilizado no m�todo incluir
	 * para obter o IdentifierPK.
	 * 
	 * @spring.property ref="resultadoProcessamentoEmpresaKeyGenerator"
	 * @param resultadoProcessamentoSistemaKeyGenerator
	 *            resultadoProcessamentoSistemaKeyGenerator para setar
	 */
	public void setResultadoProcessamentoEmpresaKeyGenerator(
			IdentifierDBKeyGenerator resultadoProcessamentoEmpresaKeyGenerator) {
		this.resultadoProcessamentoEmpresaKeyGenerator = resultadoProcessamentoEmpresaKeyGenerator;
	}
}