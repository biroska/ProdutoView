/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.SistemaVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link SistemaVO}
 * 
 * @spring.bean name="sistemaRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author Aimbere Galdino
 * 
 */
public class SistemaVORowMapper implements RowMapper<SistemaVO> {

	/**
	 * Mapeia o resultSet para o objeto SistemaVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public SistemaVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final Integer cdSistema = rs.getInt("CdSistema");
		final String  dsSistema = rs.getString("DsSistema");
//		final String  flAtivo = rs.getString("FlAtivo");
//		
//		BVDate dtInclusao = null;
//		if (rs.getDate("DtInclusao") != null) {
//			dtInclusao = new BVDate(rs.getDate("DtInclusao"));
//		}
//		
//		BVDate dtAlteracao = null;
//		if (rs.getDate("DtAlteracao") != null) {
//			dtAlteracao = new BVDate(rs.getDate("DtAlteracao"));
//		}
//		
//		final Integer cdPessoaFuncionario = rs.getInt("CdPessoaFuncionario");
//		final String  sgSistema = rs.getString("SgSistema");
		
		SistemaVO vo = new SistemaVO( new IdentifierPK( cdSistema ) );
		vo.setDsSistema( dsSistema );
//		vo.setFlAtivo( flAtivo );
//		vo.setDtInclusao( dtInclusao );
//		vo.setDtAlteracao( dtAlteracao );
//		vo.setCdPessoaFuncionario( cdPessoaFuncionario );
//		vo.setSgSistema( sgSistema );
		
		return vo;
	}
}