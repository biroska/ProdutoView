package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.OrigemTransacaoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.OrigemTransacaoDAO;
import br.com.bvsistemas.dimof.persistence.dao.helper.GenericSingleColumnRowMapper;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link OrigemTransacaoDAO}
 * 
 * @spring.bean name="origemTransacaoDAO" lazy-init="true" scope="singleton"
 * 
 * @author elias.yoshida
 * @created 24/08/2012 
 */
public class OrigemTransacaoDAOImpl extends AbstractJdbcDao implements OrigemTransacaoDAO {
	
	/**
	 * @spring.constructor-arg ref="DBITP"
	 * @param ds
	 * @throws PersistenceException
	 */
	public OrigemTransacaoDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	/**
	 * RowMapper de origem de transacao de movimentacao de conta corrente
	 */
	RowMapper<OrigemTransacaoVO> origemTransacaoVORowMapper;
	
	/**
	 * RowMapper da transacao de movimentacao de conta corrente
	 */
	RowMapper<TransacaoVO> transacaoVORowMapper;
	
	/**
	 * M�todo para setar o RowMapper com origem de transacao de movimentacao de conta corrente
	 * 
	 * @spring.property ref="origemTransacaoVORowMapper"
	 * @param origemTransacaoVORowMapper
	 *            the origemTransacaoVORowMapper a ser setado
	 */
	public void setOrigemTransacaoVORowMapper(RowMapper<OrigemTransacaoVO> origemTransacaoVORowMapper) {
		this.origemTransacaoVORowMapper =  origemTransacaoVORowMapper;
	}
	
	/**
	 * M�todo para setar o RowMapper com transacao de movimentacao de conta corrente
	 * 
	 * @spring.property ref="transacaoVORowMapper"
	 * @param transacaoVORowMapper
	 *            the transacaoVORowMapper a ser setado
	 */
	public void setTransacaoVORowMapper(RowMapper<TransacaoVO> transacaoVORowMapper) {
		this.transacaoVORowMapper =  transacaoVORowMapper;
	}
	
	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.persistence.dao.OrigemTransacaoDAO#listarOrigem()
	 */
	@SuppressWarnings("unchecked")
	public List<OrigemTransacaoVO> listarOrigem() throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listarOrigem");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		final List<OrigemTransacaoVO> listaOrigem = this.executeQuery(sql.toString(), namedParameters, origemTransacaoVORowMapper);
		return listaOrigem;
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.persistence.dao.OrigemTransacaoDAO#listarTransacao()
	 */
	@SuppressWarnings("unchecked")
	public List<TransacaoVO> listarTransacao() throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listarTransacao");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		final List<TransacaoVO> listaTransacao = this.executeQuery(sql.toString(), namedParameters, transacaoVORowMapper);
		return listaTransacao;
	}
		
	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.persistence.dao.OrigemTransacaoDAO#getNomeTransacao(java.lang.Integer)
	 */
	@SuppressWarnings("unchecked")
	public String getNomeTransacao(Integer cdTransacao) throws PersistenceException {
	    	
	    String sqlCommand = this.getSqlCommand("getNomeTransacao");
	    Map<String , Object> namedParameters = new HashMap<String, Object>();
	    namedParameters.put("cdTransacao", cdTransacao);
	    	
	    StringBuffer sql = new StringBuffer(sqlCommand);
	    List<Object> lista = this.executeQuery(sql.toString(), namedParameters, new GenericSingleColumnRowMapper());
	    
	    if(lista != null && lista.size() > 0)
		return (String)lista.get(0);
			    	
	    	
	    return "";	
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.persistence.dao.OrigemTransacaoDAO#getNomeOrigem(java.lang.Integer)
	 */
	@SuppressWarnings("unchecked")
	public String getNomeOrigem(Integer cdOrigem) throws PersistenceException {
	    
	    	String sqlCommand = this.getSqlCommand("getNomeOrigem");
	    	Map<String , Object> namedParameters = new HashMap<String, Object>();
	    	namedParameters.put("cdOrigem", cdOrigem);
	    	
	    	StringBuffer sql = new StringBuffer(sqlCommand);
		List<Object> lista = this.executeQuery(sql.toString(), namedParameters, new GenericSingleColumnRowMapper());
	    	if(lista != null && lista.size() > 0)
	    	return (String) lista.get(0);	    	
	    	
	    return "";
	}


	
	
	
}
