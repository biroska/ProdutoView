/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.HistoricoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoNaturezaJuridicaDAO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;



/**
 * Implementa��o de {@link HistoricoNaturezaJuridicaDAO}
 * 
 * @spring.bean name="historicoNaturezaJuridicaDAO" lazy-init="true" scope="singleton"
 * 
 * @author Bianca Paulino
 * 
 */

public class HistoricoNaturezaJuridicaDAOImpl extends AbstractJdbcDao implements HistoricoNaturezaJuridicaDAO{
	
	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(NaturezaJuridicaDAOImpl.class);

	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	private RowMapper<HistoricoNaturezaJuridicaVO> historicoNaturezaJuridicaRowMapper;


	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public HistoricoNaturezaJuridicaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	
	@Override
	public List<HistoricoNaturezaJuridicaVO> listar(
			HistoricoNaturezaJuridicaVO vo) throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listar");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		if (vo.getNaturezaJuridica() != null) {
			
			namedParameters.put("cdNaturezaJuridica", vo.getNaturezaJuridica().getCdNaturezaJuridica());
			namedParameters.put("flEnviaInformacaoEFinanceira", vo.getNaturezaJuridica().getFlEnviaInformacaoEFinanceira());
			namedParameters.put("nmNaturezaJuridica", vo.getNaturezaJuridica().getNmNaturezaJuridica());
		}
		
		
		if (vo.getDtLogInicio() != null && vo.getDtLogFim() != null) {
			sql.append("\n AND (");
			sql.append("\n      convert(date,log.DtLogNaturezaJuridicaEscro)") ;
			//sql.append("\n        BETWEEN Convert(date,:dtInicio) AND Convert(date,:dtFim)");
			sql.append("\n        <= Convert(date,:dtFim)");
			sql.append("\n     )");		
			namedParameters.put("dtInicio", vo.getDtLogInicio().getSqlValue().toString());
			namedParameters.put("dtFim",  vo.getDtLogFim().getSqlValue().toString());
		}
		
		
			
		// Ordena��o da consulta
		//	sql.append("\n ORDER BY log.DtLogNaturezaJuridicaEscro");
		sql.append("\n ORDER BY log.CdNaturezaJuridicaEscrituracao, log.DtLogNaturezaJuridicaEscro");
		
		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sqlCommand);
		}

		final List<HistoricoNaturezaJuridicaVO> listaHistoricoNaturezaJuridica = this.executeQuery(
				sql.toString(), namedParameters, historicoNaturezaJuridicaRowMapper);

		return listaHistoricoNaturezaJuridica;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es da natureza juridica.
	 * 
	 * @spring.property ref="historicoNaturezaJuridicaRowMapper"
	 * @param historicoNaturezaJuridicaRowMapper
	 *            the historicoNaturezaJuridicaRowMapper a ser setado
	 */
	public void setHistoricoNaturezaJuridicaRowMapper(
			RowMapper<HistoricoNaturezaJuridicaVO> historicoNaturezaJuridicaRowMapper) {
		this.historicoNaturezaJuridicaRowMapper = historicoNaturezaJuridicaRowMapper;
	}

}