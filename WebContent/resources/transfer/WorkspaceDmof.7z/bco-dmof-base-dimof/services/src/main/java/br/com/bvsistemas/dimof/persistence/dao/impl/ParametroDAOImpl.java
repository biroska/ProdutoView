/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.ParametroDAO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link ParametroDAO}
 * 
 * @spring.bean name="parametroDAO" lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class ParametroDAOImpl extends AbstractJdbcDao implements ParametroDAO {

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public ParametroDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	RowMapper<ParametroSistemaVO> parametroSistemaRowMapper;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.ParametroDAO#consultar()
	 */
	@SuppressWarnings("unchecked")
	public ParametroSistemaVO consultar() {

		// Obtem a query
		String sql = this.getSqlCommand("consultar");

		Map<String, Object> namedParameters = Collections.emptyMap();
		
		// Executa a consulta
		final List<ParametroSistemaVO> parametro = this.executeQuery(sql, 
				namedParameters, parametroSistemaRowMapper);

		return parametro.get(0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.ParametroDAO#alterar(
	 *      br.com.bvsistemas.dimof.datatype.ParametroSistemaVO)
	 */
	@SuppressWarnings("unchecked")
	public int alterar(ParametroSistemaVO parametro) throws PersistenceException {

		String sql = this.getSqlCommand("alterar");
		int result = this.executeCommand(sql, parametro);

		return result;
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es dos par�metros do sistema.
	 * 
	 * @spring.property ref="parametroSistemaVORowMapper"
	 * @param parametroSistemaVORowMapper
	 *            parametroSistemaVORowMapper a ser setado
	 */
	public void setParametroSistemaVORowMapper(
			RowMapper<ParametroSistemaVO> parametroSistemaRowMapper) {
		this.parametroSistemaRowMapper = parametroSistemaRowMapper;
	}
}
