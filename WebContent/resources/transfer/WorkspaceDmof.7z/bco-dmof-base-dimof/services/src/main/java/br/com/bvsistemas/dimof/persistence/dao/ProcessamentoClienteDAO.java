/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ProcessamentoClienteVO;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de ProcessamentoCliente.
 * 
 * @author Aimbere Galdino
 * 
 */
public interface ProcessamentoClienteDAO {

	/**
	 * Inclui um novo registro de ProcessamentoCliente.
	 * 
	 * @param ProcessamentoClienteVO
	 *            ProcessamentoClienteVO
	 * @return Dados do ProcessamentoClienteVO desejado
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	ProcessamentoClienteVO inserirParaTodosCLientes( ProcessamentoClienteVO obj, List<PessoaVO> clientes ) throws PersistenceException;
	
	/**
	 * Listar clientes do processamento.
	 * 
	 * @param Long idAgendamento
	 *            idAgendamento
	 * @return Lista de clientes do agendameno List<PessoaVO>
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	List<PessoaVO> listarClientes( Long idAgendamento ) throws PersistenceException;
}