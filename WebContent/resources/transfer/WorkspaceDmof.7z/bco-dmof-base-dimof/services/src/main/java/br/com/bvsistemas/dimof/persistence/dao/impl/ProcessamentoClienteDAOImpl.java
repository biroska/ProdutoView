/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ProcessamentoClienteVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.ProcessamentoClienteDAO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link ProcessamentoClienteDAO}
 * 
 * @spring.bean name="processamentoClienteDAO" lazy-init="true" scope="singleton"
 * 
 * @author Aimbere Galdino
 * 
 */
public class ProcessamentoClienteDAOImpl extends AbstractJdbcDao implements ProcessamentoClienteDAO {

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public ProcessamentoClienteDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	private RowMapper<PessoaVO> pessoaRowMapper;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AgendamentoDAO#incluir(br.com.bvsistemas.dimof.datatype.AgendamentoVO)
	 */
	public ProcessamentoClienteVO inserirParaTodosCLientes( ProcessamentoClienteVO obj, List<PessoaVO> clientes ) throws PersistenceException {
		
		if ( clientes == null ){
			return null;
		}
		
		try {
			String sql = this.getSqlCommand("inserir");
			
			Map<String, Object> parameters = null;
			
			for (PessoaVO cli : clientes) {
			
				parameters = new HashMap<String, Object>();
				
				parameters.put("cdProcessamentoEscrituracao", obj.getCdProcessamentoEscrituracao().getPk().getId() );
			
				parameters.put("cdCliente", cli.getPk().getId() );
			
				// Executa insert no banco
				this.executeCommand(sql, parameters);
			}

		} catch ( Exception e){
			throw new PersistenceException( e.getMessage() );
		}
			
		//Retorna pk do objeto inserido
		return obj;
	}
	
	/* 
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.ProcessamentoClienteDAO#listarClientes(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public List<PessoaVO> listarClientes( Long idAgendamento ) throws PersistenceException {
		
		List<PessoaVO> listaClientes = null;
		
		try {
			String sqlCommand = this.getSqlCommand("listarClientes");
			Map<String, Object> namedParameters = new HashMap<String, Object>();
			
			StringBuffer sql = new StringBuffer(sqlCommand);
			
			if ( idAgendamento != null ){
				sql.append(" \n WHERE cliente.CdProcessamentoEscrituracao = :cdProcessamentoEscrituracao ");
				namedParameters.put("cdProcessamentoEscrituracao", idAgendamento );
			}
			
			sql.append("\n ORDER BY pe.nmPessoa ASC");
	
			listaClientes = this.executeQuery( sql.toString(), namedParameters, pessoaRowMapper );
			
		} catch ( Exception e ){
			throw new PersistenceException( e.getMessage() );
		}

		return listaClientes;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="pessoaRowMapper"
	 * @param pessoaRowMapper
	 *            the pessoaRowMapper a ser setado
	 */
	public void setPessoaRowMapper(
			RowMapper<PessoaVO> pessoaRowMapper) {
		this.pessoaRowMapper = pessoaRowMapper;
	}
}