/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.enums.EmpresasAgendamentoEnum;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.PessoaDAO;
import br.com.bvsistemas.dimof.persistence.dao.helper.PessoaVORowMapper;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link PessoaDAO}
 * 
 * <br>#001 - 07/02/2013 - deal.echiang
 * <br>Migra��o Sybase 12 para 15
 * 
 * @spring.bean name="pessoaDAO" lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:cit.fuechi@bvsistemas.com.br">cit.fuechi</a>
 * 
 */
public class PessoaDAOImpl extends AbstractJdbcDao implements PessoaDAO {
	
	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(AgendamentoDAOImpl.class);

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public PessoaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	RowMapper<PessoaVO> pessoaRowMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.PessoaDAO#listar(java.lang.String,
	 *      java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<PessoaVO> listar(String nmPessoa, String nuCpfCnpj) {
		/*
		// Vers�o anterior
		// Obtem a query
		String sql = this.getSqlCommand("listar");

		// Seta os parametros da consulta
		Object[] params = replaceNullValues(new Object[] { nuCpfCnpj,
				nuCpfCnpj, nmPessoa, nmPessoa });

		// Executa a consulta
		List<PessoaVO> result = getJdbcTemplate().query(sql, params,
				new PessoaVORowMapper());
		*/
		
		// #001 - In�cio
		String sql = this.getSqlCommand("listar");
		String filtroNuCpfCnpj = this.getSqlCommand("filtroNuCpfCnpj");
		String filtroNmPessoa = this.getSqlCommand("filtroNmPessoa");
		String orderByNmPessoa = this.getSqlCommand("orderByNmPessoa");
		
		boolean temNmPessoa = false;
		boolean temNuCpfCnpj = false;		
		if( nmPessoa != null ) {
			temNmPessoa = true;
		}
		if( nuCpfCnpj != null ) {
			temNuCpfCnpj = true;
		}
		
		StringBuffer buffer = new StringBuffer();
		buffer.append(sql);
		if( temNuCpfCnpj || temNmPessoa ) {
			buffer.append(" where ");
			
			if( temNuCpfCnpj ) {
				buffer.append(filtroNuCpfCnpj);				
			}
			if( temNuCpfCnpj && temNmPessoa ) {
				buffer.append(" or ");
			}			
			if( temNmPessoa ) {
				buffer.append(filtroNmPessoa);
			}
		}
		buffer.append(" ");
		buffer.append(orderByNmPessoa);
		
		String query = buffer.toString();
		
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		if( temNuCpfCnpj ) {
			namedParameters.put("NuCpfCnpj", nuCpfCnpj);
		}
		if( temNmPessoa ) {
			namedParameters.put("NmPessoa", nmPessoa);
		}
		
		final List<PessoaVO> result = this.executeQuery(
				query, namedParameters, new PessoaVORowMapper());		
		// #001 - Fim

		return result;
	}
	
	@SuppressWarnings("unchecked")
	public PessoaVO consultaPelaChave(IdentifierPK idPessoa) {

		/*
		//Vers�o anterior
		// Obtem a query
		String sql = this.getSqlCommand("consultaPelaChave");

		// Seta os parametros da consulta
		Object[] params = replaceNullValues(new Object[] { idPessoa.getId(),idPessoa.getId() });

		// Executa a consulta
		List<PessoaVO> result = getJdbcTemplate().query(sql, params,
				new PessoaVORowMapper());
		*/

		String sql = this.getSqlCommand("consultaPelaChave");
		String filtroCdPessoa = this.getSqlCommand("filtroCdPessoa");
		String orderByNmPessoa = this.getSqlCommand("orderByNmPessoa");
		
		StringBuffer buffer = new StringBuffer();
		buffer.append(sql);
		if( idPessoa.getId() != null ) {
			buffer.append(" where ");
			buffer.append(filtroCdPessoa);						
		}
		else {
			buffer.append(orderByNmPessoa);
		}
		
		String query = buffer.toString();
		
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		if( idPessoa.getId() != null ) {
			namedParameters.put("CdPessoa", idPessoa.getId());
		}		
		
		final List<PessoaVO> result = this.executeQuery(
				query, namedParameters, new PessoaVORowMapper());		
		
		if ( result != null && !result.isEmpty() ){
			return result.get(0);
		}
		
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<PessoaVO> listarEmpresasParaAgendamento() throws PersistenceException{
		
		String sqlCommand = this.getSqlCommand("listarEmpresas");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		montaRestricoes( namedParameters, sql);
		
		sql.append("\n GROUP BY pes.nucpfcnpj ");
		sql.append("\n ORDER BY pes.nmPessoa ASC ");
		
		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sql.toString());
		}
		
		final List<PessoaVO> listaEmpresas = this.executeQuery(
				sql.toString(), namedParameters, pessoaRowMapper );
		
		return listaEmpresas;
	}
	
	private void montaRestricoes( Map<String, Object> namedParameters, StringBuffer sql ) {
		
		String restricao = " WHERE pes.NuCpfCnpj IN ( ";
		int count = 1;
		
		for (EmpresasAgendamentoEnum enumObj : EmpresasAgendamentoEnum.values() ) {
			
			restricao += ":"+count+",";
			namedParameters.put( ""+count, enumObj.getCnpj() );
			
			count ++;
		}
		
		restricao += "end";
		sql  = sql.append( restricao.replace(",end", ")" ) );
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="pessoaRowMapper"
	 * @param pessoaRowMapper
	 *            the pessoaRowMapper a ser setado
	 */
	public void setPessoaRowMapper(
			RowMapper<PessoaVO> pessoaRowMapper) {
		this.pessoaRowMapper = pessoaRowMapper;
	}
}