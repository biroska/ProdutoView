/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoSistemaVO;
import br.com.bvsistemas.dimof.datatype.SistemaVO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link ResultadoProcessamentoSistemaVORowMapper}
 * 
 * @spring.bean name="resultadoProcessamentoSistemaRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author Aimbere Galdino
 * 
 */
public class ResultadoProcessamentoSistemaVORowMapper implements RowMapper<ResultadoProcessamentoSistemaVO> {
	
	/**
	 * Rowmapper para armazenar dados de Status de Processamento.
	 */
	private RowMapper<SistemaVO> sistemaRowMapper;
	
	/**
	 * Mapeia o resultSet para o objeto SistemaVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public ResultadoProcessamentoSistemaVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final Integer cdProcessamentoEscrituracao = rs.getInt("CdProcessamentoEscrituracao");
		final Integer cdSistema = rs.getInt("CdSistema");
		final Integer qtRegistroProcessado = rs.getInt("QtRegistroProcessado");
		final Integer qtRegistroErro = rs.getInt("QtRegistroErro");
		
		BVDate dtResultadoProcessamento = null;
		if (rs.getDate("DtResultadoProcessamento") != null) {
			dtResultadoProcessamento = new BVDate(rs.getDate("DtResultadoProcessamento"));
		}
		
		final Integer mmProcessado = rs.getInt("MmProcessado");
		final Integer aaProcessado = rs.getInt("AaProcessado");
		
		ResultadoProcessamentoSistemaVO vo = new ResultadoProcessamentoSistemaVO( new IdentifierPK() );
		vo.setCdProcessamentoEscrituracao(cdProcessamentoEscrituracao);
		vo.setCdSistema(cdSistema);
		vo.setQtRegistroProcessado(qtRegistroProcessado);
		vo.setQtRegistroErro(qtRegistroErro);
		vo.setDtResultadoProcessamento(dtResultadoProcessamento);
		vo.setMmProcessado(mmProcessado);
		vo.setAaProcessado(aaProcessado);
		
		if ( sistemaRowMapper != null ) {			
			vo.setSistemaVO( sistemaRowMapper.mapRow(rs, rowNum) );
		}
		
		return vo;
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es do Sistema
	 * 
	 * @spring.property ref="sistemaRowMapper"
	 * @param sistemaRowMapper
	 *            sistemaRowMapper a ser setado
	 */
	public void setSistemaRowMapper(
			RowMapper<SistemaVO> sistemaRowMapper) {
		this.sistemaRowMapper = sistemaRowMapper;
	}
}