/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.business.impl;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.OrigemTransacaoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.persistence.dao.OrigemTransacaoDAO;
import br.com.bvsistemas.dimof.persistence.dao.TransacaoEstornoDAO;
import br.com.bvsistemas.dimof.services.TransacaoEstornoServices;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Implementa�ao dos servi�os de manuten��o das movimentacoes do cliente
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.TransacaoEstornoBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com">Edilson Almeida</a>
 */
public class TransacaoEstornoBusinessImpl extends AbstractBusiness implements TransacaoEstornoServices {

	/** 
	 * DAO para acesso a movimentacao
	 */
	private TransacaoEstornoDAO transacaoEstornoDAO;
	
	/**
	 * DAO para acesso a Origem da tranca��o 
	 */
	private OrigemTransacaoDAO origemTransacaoDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#listar(
	 * java.lang.String,
	 * java.lang.String,
	 *  br.com.bvsistemas.framework.datatype.IdentifierPK)
	 * 
	 */	
	public List<TransacaoEstornoVO> listar(Integer cdOrigem, Integer cdTransacao, String raizCnpj) throws ValidationException, CamposObrigatoriosNaoPreenchidosException{
		List<TransacaoEstornoVO> listaTransacaoEstorno = transacaoEstornoDAO.listar(cdOrigem, cdTransacao, raizCnpj);
	   return listaTransacaoEstorno;
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#listarOrigem()
	 */
	public List<OrigemTransacaoVO> listarOrigem()throws ValidationException, CamposObrigatoriosNaoPreenchidosException{

	    return  origemTransacaoDAO.listarOrigem();
	    
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#listarTransacao()
	 */
	public List<TransacaoVO> listarTransacao()throws ValidationException, CamposObrigatoriosNaoPreenchidosException{
	    
	    return  origemTransacaoDAO.listarTransacao();
	    
	}
	
	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#getNomeOrigem(java.lang.Integer)
	 */
	public String getNomeOrigem(Integer cdOrigem) throws ValidationException, CamposObrigatoriosNaoPreenchidosException {
	    	
	    return origemTransacaoDAO.getNomeOrigem(cdOrigem);
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#getNomeTransacao(java.lang.Integer)
	 */
	public String getNomeTransacao(Integer cdTransacao) throws ValidationException, CamposObrigatoriosNaoPreenchidosException {

	    return origemTransacaoDAO.getNomeTransacao(cdTransacao);
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#inserir(br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO)
	 */
	public IdentifierPK inserir(TransacaoEstornoVO transacaoEstornoVO) throws ValidationException, CamposObrigatoriosNaoPreenchidosException {
	    return this.transacaoEstornoDAO.inserir(transacaoEstornoVO);
	    
	}

	/* (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.services.TransacaoEstornoServices#alterar(br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO)
	 */
	public int alterar(TransacaoEstornoVO transacaoEstornoVO) throws ValidationException, CamposObrigatoriosNaoPreenchidosException {
	    if(transacaoEstornoVO.getPk().getId() == null)
		throw new CamposObrigatoriosNaoPreenchidosException();
	    
	    return transacaoEstornoDAO.atualizar(transacaoEstornoVO);
	}

	
	/**
	 * @param TransacaoEstornoDAO
	 *            the transacaoEstornoDAO to set
	 * 
	 * @spring.property ref="transacaoEstornoDAO"
	 */
	public void setTransacaoEstornoDAO(TransacaoEstornoDAO transacaoEstornoDAO) {
		this.transacaoEstornoDAO = transacaoEstornoDAO;
	}

	
	
	/**
	 * @param origemTransacaoDAO
	 * 		the origemTransacaoDAO to set
	 * 
	 * @spring.property ref="origemTransacaoDAO"
	 */
	public void setOrigemTransacaoDAO(OrigemTransacaoDAO origemTransacaoDAO) {
	    this.origemTransacaoDAO = origemTransacaoDAO;
	}
	
	
	
}
