/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.SecaoJudiciariaDAO;
import br.com.bvsistemas.dimof.persistence.dao.helper.SecaoJudiciariaVORowMapper;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * Implementa��o de {@link SecaoJudiciariaDAO}
 * 
 * @spring.bean name="secaoJudiciariaDAO" lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class SecaoJudiciariaDAOImpl extends AbstractJdbcDao 
	implements SecaoJudiciariaDAO {

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public SecaoJudiciariaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.SecaoJudiciariaDAO#listar()
	 */
	@SuppressWarnings("unchecked")
	public List<SecaoJudiciariaVO> listar() {

		// Obtem a query
		String sql = this.getSqlCommand("listar");

		// Executa a consulta
		List<SecaoJudiciariaVO> result = getJdbcTemplate().query(sql, 
				new SecaoJudiciariaVORowMapper());

		return result;
	}
}
