/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.SistemaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.SistemaDAO;
import br.com.bvsistemas.dimof.persistence.dao.TipoLogradouroDAO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link TipoLogradouroDAO}
 * 
 * @spring.bean name="sistemaDAO" lazy-init="true" scope="singleton"
 * 
 */
public class SistemaDAOImpl extends AbstractJdbcDao implements SistemaDAO {

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public SistemaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	RowMapper<SistemaVO> sistemaRowMapper;

	@SuppressWarnings("unchecked")
	public List<SistemaVO> listar() throws PersistenceException {

		// Obtem a query
		String sqlCommand = this.getSqlCommand("listar");
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		sql.append("\n ORDER BY sis.DsSistema asc");
		
		Map<String, Object> namedParameters = new HashMap<String, Object>();

		final List<SistemaVO> result = this.executeQuery(
				sql.toString(), namedParameters, sistemaRowMapper);

		return result;
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="sistemaRowMapper"
	 * @param sistemaRowMapper
	 *            the sistemaRowMapper a ser setado
	 */
	public void setSistemaRowMapper(
			RowMapper<SistemaVO> sistemaRowMapper) {
		this.sistemaRowMapper = sistemaRowMapper;
	}
}