/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * @author talent.ealmeida
 *
 */
public interface TransacaoEstornoDAO {
	
	
	/**
	 * M�todo respons�vel pela busca de Transa��es de Estorno pelo filtro
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param cdOrigem, o Identificador da Origem 
	 * 
	 * @param cdTransacao, o identificador da Transa��o
	 * 
	 * @param raizCnpj, o n�mero raiz doi cnpj
	 * 
	 * @return A lista com os registros encontrados que satisfa�am os crit�rios da busca
	 * 
	 * @throws PersistenceException
	 */
	List<TransacaoEstornoVO> listar(Integer cdOrigem, Integer cdTransacao, String raizCnpj) throws PersistenceException;
	
	
	

	/**
	 * M�todo Respons�vel por inserir uma nova Transa��o de Estorno
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param transacaoEstornoVO o Vo da Transa��o a ser Inserida
	 * 
	 * @return IdentifierPK, o identificador da Transa��o inserida
	 * 
	 * @throws PersistenceException
	 */
	public IdentifierPK inserir(TransacaoEstornoVO transacaoEstornoVO) throws PersistenceException;
	
	
	
	/**
	 * M�todo respons�vel pela atualiza��o de uma Transa��o de Estorno, usada para marcar uma transa��o como Inativa
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param transacaoEstornoVO
	 * 
	 * @return int, a quantidade de registros afetados
	 * 
	 * @throws PersistenceException
	 */
	public int atualizar(TransacaoEstornoVO transacaoEstornoVO) throws PersistenceException;
	
	}
