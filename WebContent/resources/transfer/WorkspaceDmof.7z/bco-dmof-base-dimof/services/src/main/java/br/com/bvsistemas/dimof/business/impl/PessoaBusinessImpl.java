/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */

package br.com.bvsistemas.dimof.business.impl;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.persistence.dao.PessoaDAO;
import br.com.bvsistemas.dimof.services.PessoaServices;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.business.AbstractBusiness;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.Timer;

/**
 * Implementa��o dos servi�os de busca de pessoa.
 * 
 * @spring.bean name="br.com.bvsistemas.dimof.business.impl.PessoaBusinessImpl"
 *              lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 * 
 */
public class PessoaBusinessImpl extends AbstractBusiness implements
		PessoaServices {

	/**
	 * Logger de eventos do BV.
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(PessoaBusinessImpl.class);

	// DAO para acesso as pessoas
	private PessoaDAO pessoaDAO;

	/**
	 * Habilita um timer para medi��o de performance de um servi�o.
	 * 
	 * @param metodo -
	 *            O m�todo que ser� avaliado pelo timer
	 * @return - Um timer para medi��o de performance do servi�o
	 */
	private Timer habilitarTimer(String metodo) {
		Timer timer = new Timer("Tempo do m�todo PessoaBusinessImpl." + metodo);
		timer.start();
		return timer;
	}

	/**
	 * Desabilita o timer de medi��o de performance de um servi�o.
	 * 
	 * @param timer -
	 *            Timer para medi��o de performance do servi�o
	 */
	private void desabilitarTimer(Timer timer) {
		timer.stop();
		if (logger.performance.isDebugEnabled()) {
			logger.performance.debug(timer);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.PessoaServices#listar()
	 */
	public List<PessoaVO> listar(String nmPessoa, String nuCpfCnpj)
			throws ValidationException {

		Timer timer = habilitarTimer("listar");

		// Verifica a integridade dos parametros
		if ((nmPessoa == null && nuCpfCnpj == null)
				|| (nmPessoa != null && nmPessoa.trim().length() > 0 
						&& nuCpfCnpj != null && nuCpfCnpj.trim().length() > 0)) {
			throw new ValidationException("Parametros invalidos");
		}

		if (nmPessoa == null || nmPessoa.trim().length() == 0) {
			nmPessoa = null;
		}

		if (nuCpfCnpj == null || nuCpfCnpj.trim().length() == 0) {
			nuCpfCnpj = null;
		}

		List<PessoaVO> pList = pessoaDAO.listar(nmPessoa, nuCpfCnpj);

		desabilitarTimer(timer);

		return pList;
	}
    
    /*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.PessoaServices#consultarPelaChave()
	 */
    
	public PessoaVO consultarPelaChave(IdentifierPK idPessoa) 
	                 throws ValidationException {
	
		Timer timer = habilitarTimer("consultarPelaChave");
		
		//Verifica integridade do parametro
		
		if(idPessoa == null || idPessoa.getId() == null){
			throw new ValidationException("Paramentros invalidos");
		}
		
		PessoaVO pessoa = pessoaDAO.consultaPelaChave(idPessoa);
		
		desabilitarTimer(timer);
		
		return pessoa;
		
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.services.PessoaServices#listarEmpresas()
	 */
	public List<PessoaVO> listarEmpresasParaAgendamento() throws PersistenceException{

		Timer timer = habilitarTimer("listarEmpresas");

		List<PessoaVO> listaEmpresas = pessoaDAO.listarEmpresasParaAgendamento();

		desabilitarTimer(timer);

		return listaEmpresas;
	}
	
	/**
	 * @param pessoaDAO
	 *            the pessoaDAO to set
	 * @spring.property ref="pessoaDAO"
	 */
	public void setPessoaDAO(PessoaDAO pessoaDAO) {
		this.pessoaDAO = pessoaDAO;
	}
}
