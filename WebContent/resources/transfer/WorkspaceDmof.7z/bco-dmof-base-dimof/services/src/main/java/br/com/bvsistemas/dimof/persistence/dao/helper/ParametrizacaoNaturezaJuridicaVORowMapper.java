/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.MesVO;
import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de Parametriza��es de Natureza Jur�dica.
 * 
 * @spring.bean name="parametrizacaoNaturezaJuridicaRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author rtomiyama
 * 
 */
public class ParametrizacaoNaturezaJuridicaVORowMapper implements RowMapper<ParametrizacaoNaturezaJuridicaVO> {

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger
			.getLogger(ParametrizacaoNaturezaJuridicaVORowMapper.class);
	
//	/**
//	 * Rowmapper para armazenar dados de pessoas.
//	 */
//	private RowMapper<PessoaVO> pessoaRowMapper;
//
//	/**
//	 * Rowmapper para armazenar dados de secoes judiciarias.
//	 */
//	private RowMapper<SecaoJudiciariaVO> secaoJudiciariaRowMapper;

	/**
	 * Mapeia o resultSet para o objeto ParametrizacaoNaturezaJuridicaVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public ParametrizacaoNaturezaJuridicaVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final int cdNaturezaJuridicaEscrituracao = rs.getInt("CdNaturezaJuridicaEscrituracao");
		IdentifierPK cdParametrizacaoNaturezaJuridicaPK = new IdentifierPK(cdNaturezaJuridicaEscrituracao);
		ParametrizacaoNaturezaJuridicaVO vo = new ParametrizacaoNaturezaJuridicaVO(cdParametrizacaoNaturezaJuridicaPK);
		
		
		//final String flEnviaInformacaoEFinanceira = rs.getString("FlEnviaInformacaoEFinanceira");

		BVDate dtIniVigencia = null;
		if (rs.getDate("DtInicioVigencia") != null) {
			dtIniVigencia = new BVDate(rs.getDate("DtInicioVigencia"));
		}
		BVDate dtFimVigencia = null;
		if (rs.getDate("DtFimVigencia") != null) {
			dtFimVigencia = new BVDate(rs.getDate("DtFimVigencia"));
		}
			
		
		BVDatetime dtInclusao = null;
		try {
			String dataInclusao = rs.getString("DtInclusao");
			dtInclusao = new BVDatetime(dataInclusao, "yyyy-MM-dd HH:mm:ss");
		} catch (ParseException e) {
			logger.workflow.error(e);
		}

		
		//if ("S".equals(rs.getString("FlEnviaInformacaoEFinanceira"))) {
		//	vo.setFlEnviaInformacaoEFinanceira("Sim");
		//} else {
		//	vo.setFlEnviaInformacaoEFinanceira("N�o");
		//}
		vo.setFlEnviaInformacaoEFinanceira(rs.getString("FlEnviaInformacaoEFinanceira"));
		
		vo.setPk(cdParametrizacaoNaturezaJuridicaPK);
		vo.setCdNaturezaJuridica(rs.getString("CdNaturezaJuridica"));
		vo.setDtInicioVigencia(dtIniVigencia);
		vo.setDtFimVigencia(dtFimVigencia);
		
		vo.setTxtInicioVigencia(formatarVigenciaMesAno(dtIniVigencia));
		vo.setTxtFimVigencia(formatarVigenciaMesAno(dtFimVigencia));

		vo.setDtInclusao(dtInclusao);
			
		return vo;
	}
	
	
	
	private String formatarVigenciaMesAno(BVDate dtVigencia) {
		String vigencia = "";
		List<MesVO> listaMeses;
		
		Calendar cal = Calendar.getInstance();

		if (dtVigencia != null) {
			cal.setTime(dtVigencia.getTime());
			int mes = cal.get(Calendar.MONTH);
			int ano = cal.get(Calendar.YEAR);
			
			listaMeses = new ArrayList<MesVO>();
			listaMeses.addAll( DataUtils.montaListaDeMeses() );
		
			vigencia = listaMeses.get(mes).getNomeMes().concat("/" + ano);
		}	
		return vigencia;
	}
	

}