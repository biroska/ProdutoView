/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
* RowMapper de HistoricoLiminar.
* 
* @spring.bean name="historicoLiminarRowMapper"
*              lazy-init="true"
*              scope="singleton" 
* 
* @author palmeida
* 
*/
public class HistoricoLiminarVORowMapper implements RowMapper<HistoricoLiminarVO> {
	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger
			.getLogger(HistoricoLiminarVORowMapper.class);
	
	/**
	 * Rowmapper para armazenar dados de pessoas.
	 */
	private RowMapper<LiminarVO> liminarRowMapper;

	/**
	 * Mapeia o resultSet para o objeto HistoricoLiminarVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public HistoricoLiminarVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		final int cdHistoricoLiminar = rs.getInt("CdLogLiminar");
		IdentifierPK cdHistoricoLiminarPK = new IdentifierPK(cdHistoricoLiminar);
		HistoricoLiminarVO vo = new HistoricoLiminarVO(cdHistoricoLiminarPK);

		final long nuLiminar = rs.getLong("NuLiminar");		
		final String dsLogin = rs.getString("DsLogin");
		final String nmCampo = rs.getString("NmCampo");
		final String dsDadoAntigo = rs.getString("DsDadoAntigo");
		final String dsDadoNovo = rs.getString("DsDadoNovo");
		
			
		BVDatetime dtAlteracao = null;
		try {
			String dataAlteracao = rs.getString("DtAlteracao");
			dtAlteracao = new BVDatetime(dataAlteracao, "yyyy-MM-dd HH:mm:ss");
		} catch (ParseException e) {
			logger.workflow.error(e);
		}

		if (liminarRowMapper != null)
	    	vo.setLiminar(liminarRowMapper.mapRow(rs, rowNum));
			
		
		vo.setPk(cdHistoricoLiminarPK);
		vo.setDtAlteracao(dtAlteracao);
		vo.setNuLiminar(nuLiminar);	
		vo.setDsLogin(dsLogin); 
		vo.setNmCampo(nmCampo);
		vo.setDsDadoAntigo(dsDadoAntigo);
		vo.setDsDadoNovo(dsDadoNovo);
			
		return vo;
		}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de pessoas.
	 * 
	 * @spring.property ref="liminarRowMapper"
	 * @param liminarRowMapper
	 *            liminarRowMapper a ser setado
	 */
	public void setLiminarRowMapper(RowMapper<LiminarVO> liminarRowMapper) {
		this.liminarRowMapper = liminarRowMapper;
	}
}
