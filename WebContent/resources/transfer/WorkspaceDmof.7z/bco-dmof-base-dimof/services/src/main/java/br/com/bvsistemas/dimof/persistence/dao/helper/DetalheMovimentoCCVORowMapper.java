package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de Detalhe de Movimento de conta corrente
 * 
 * @spring.bean name="detalheMovimentoCCRowMapper" lazy-init="true" scope="singleton"
 * 
 * @author elias.yoshida
 * 
 */
public class DetalheMovimentoCCVORowMapper implements RowMapper<DetalheMovimentoCCVO> {

	/**
	 * Mapeia o resultSet para o objeto DetalheMovimentoCCVO.
	 */
	public DetalheMovimentoCCVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		IdentifierPK pk = new IdentifierPK(1);
		DetalheMovimentoCCVO vo = new DetalheMovimentoCCVO(pk);
		
		final Date dtMovimento       = rs.getDate("DtMovimento");
		final BigDecimal vrOperacao  = rs.getBigDecimal("VrOperacao");
		final String tpDebitoCredito = rs.getString("TpDebitoCredito"); 
		final String nuCpfCnpjDebitado = rs.getString("NuCpfCnpjDebitado");
		final String nuCpfCnpjCreditado = rs.getString("NuCpfCnpjCreditado");
		final String nuContaCorrente = rs.getString("NuContaCorrente");
		
		vo.setPk(pk);
		vo.setDtMovimento(dtMovimento);
		vo.setVrOperacao(vrOperacao);
		vo.setTpDebitoCredito(tpDebitoCredito);
		vo.setNuCpfCnpjDebitado(nuCpfCnpjDebitado);
		vo.setNuCpfCnpjCreditado(nuCpfCnpjCreditado);
		vo.setNuContaCorrente(nuContaCorrente);

		return vo;
	}

}
