/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.NaturezaJuridicaDAO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link NaturezaJuridicaDAO}
 * 
 * @spring.bean name="naturezaJuridicaDAO" lazy-init="true" scope="singleton"
 * 
 * @author Bianca Paulino
 * 
 */
public class NaturezaJuridicaDAOImpl extends AbstractJdbcDao implements
		NaturezaJuridicaDAO {

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger
			.getLogger(NaturezaJuridicaDAOImpl.class);

	private final String NAO_DEFINIDO = "D";
	private final String SIM = "S";
	private final String NAO = "N";

	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	private RowMapper<NaturezaJuridicaVO> naturezaJuridicaRowMapper;

	/**listaNaturezaJuridicalistaNaturezaJuridica 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public NaturezaJuridicaDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/**
	 * M�todo para setar o RowMapper com informa��es da Natureza Juridica.
	 * 
	 * @spring.property ref="naturezaJuridicaRowMapper"
	 * @param naturezaJuridicaRowMapper
	 *            naturezaJuridicaRowMapper a ser setado
	 */
	public void setNaturezaJuridicaRowMapper(
			RowMapper<NaturezaJuridicaVO> naturezaJuridicaRowMapper) {
		this.naturezaJuridicaRowMapper = naturezaJuridicaRowMapper;
	}	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.bvsistemas.dimof.persistence.dao.NaturezaJuridicaDAO#listar(br
	 * .com.bvsistemas.dimof.datatype.NaturezaJuridicaVO)
	 */
	@Override
	public List<NaturezaJuridicaVO> listar(NaturezaJuridicaVO vo)
			throws PersistenceException {

		String sqlCommand = this.getSqlCommand("listar");
		Map<String, Object> namedParameters = new HashMap<String, Object>();

		StringBuffer sql = new StringBuffer(sqlCommand);

		namedParameters.put("cdNaturezaJuridica", vo.getCdNaturezaJuridica());
		namedParameters.put("nmNaturezaJuridica", vo.getNmNaturezaJuridica());

		if (NAO_DEFINIDO.equalsIgnoreCase(vo.getFlEnviaInformacaoEFinanceira())) {
			sql.append("\n AND (nat.FlEnviaInformacaoEFinanceira IS NULL  OR nat.FlEnviaInformacaoEFinanceira = 'D')");
		}

		else {
			sql.append("\n AND nat.FlEnviaInformacaoEFinanceira = isnull(:flEnviaInformacaoEFinanceira, nat.FlEnviaInformacaoEFinanceira)");
			namedParameters.put("flEnviaInformacaoEFinanceira",
					vo.getFlEnviaInformacaoEFinanceira());
		}

		// Ordena��o da consulta
		sql.append("\n ORDER BY glob.CdNaturezaJuridica, nat.dtiniciovigencia");

		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sqlCommand);
		}

		@SuppressWarnings("unchecked")
		final List<NaturezaJuridicaVO> listaNaturezaJuridica = this
				.executeQuery(sql.toString(), namedParameters,
						naturezaJuridicaRowMapper);

		return listaNaturezaJuridica;

	}

	@Override
	public void importarNaturezaJuridicaDIMOF(String dsLogin)
			throws PersistenceException {

		String sqlCommand = this.getSqlCommand("importarNaturezaJuridicaDIMOF");
		Map<String, Object> namedParameters = new HashMap<String, Object>();

		StringBuffer sql = new StringBuffer(sqlCommand);

		namedParameters.put("dsLogin", dsLogin);

		this.executeCommand(sql.toString(), namedParameters);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.bvsistemas.dimof.persistence.dao.NaturezaJuridicaDAO#existePorFlag
	 * (java.lang.String)
	 */
	@Override
	public boolean existePorFlag(String flag) throws PersistenceException,
			ValidationException {

		if (StringUtils.isBlank(flag)) {
			throw new ValidationException("Parametro nao informado");
		}

		if (!NAO_DEFINIDO.equals(flag) && !SIM.equals(flag)
				&& !NAO.equals(flag)) {
			throw new ValidationException(
					"Parametro invalido - Informe: S, N ou D");
		}

		String sqlCommand = this.getSqlCommand("existePorFlagEnviaInformacao");
		StringBuffer sql = new StringBuffer(sqlCommand);

		Long count = getJdbcTemplate().queryForLong(sql.toString(),
				new Object[] { flag });

		return (count > 0);

	}

	
	

}
