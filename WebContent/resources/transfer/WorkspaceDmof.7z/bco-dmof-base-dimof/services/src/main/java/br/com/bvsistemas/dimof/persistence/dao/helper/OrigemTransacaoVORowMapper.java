package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.OrigemTransacaoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper da Origem da Transacao da Movimencao de conta corrente
 * 
 * @spring.bean name="origemTransacaoVORowMapper" lazy-init="true" scope="singleton"
 * 
 * @author elias.yoshida
 * @created 24/08/2012 
 * 
 */
public class OrigemTransacaoVORowMapper implements RowMapper<OrigemTransacaoVO> {

	/**
	 * Mapeia o resultSet para o objeto OrigemTransacaoVORowMapper.
	 */
	public OrigemTransacaoVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		IdentifierPK pk = new IdentifierPK(rs.getInt("CdOrigem"));
		OrigemTransacaoVO vo = new OrigemTransacaoVO(pk);
		
		final String nmOrigem = rs.getString("NmOrigem"); 
		final String nmEmpresa = rs.getString("NmEmpresa");
		
		vo.setPk(pk);
		vo.setNmOrigem(nmOrigem);
		vo.setNmEmpresa(nmEmpresa);

		return vo;
	}

}
