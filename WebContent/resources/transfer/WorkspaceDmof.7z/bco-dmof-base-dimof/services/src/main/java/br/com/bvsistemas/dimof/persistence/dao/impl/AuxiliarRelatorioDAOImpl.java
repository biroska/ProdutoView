/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.AuxiliarRelatorioDAO;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Implementa��o de {@link AuxiliarRelatorioDAO}
 * 
 * @spring.bean name="auxiliarRelatorioDAO" lazy-init="true" scope="singleton"
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class AuxiliarRelatorioDAOImpl extends AbstractJdbcDao 
	implements AuxiliarRelatorioDAO {

	/**
	 * Construtor.
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds the DataSource
	 * @throws PersistenceException
	 */
	public AuxiliarRelatorioDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/**
	 * RowMapper de AuxiliarRelatorio.
	 */
	RowMapper<AuxiliarRelatorioVO> auxiliarRelatorioRowMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AuxiliarRelatorioDAO#alterarStatusProcessamento(
	 *      br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO)
	 */
	@SuppressWarnings("unchecked")
	public int alterarStatusProcessamento(AuxiliarRelatorioVO auxiliarRelatorio)
			throws PersistenceException {

		String sql = this.getSqlCommand("alterarStatusProcessamento");
		int result = this.executeCommand(sql, auxiliarRelatorio);

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AuxiliarRelatorioDAO#consultarPorAnoPorSemestre(int, int)
	 */
	@SuppressWarnings("unchecked")
	public AuxiliarRelatorioVO consultarPorAnoPorSemestre(final Integer ano,
			final Integer nuSemestre) throws PersistenceException {

		// Parametro(s) da operacao de inclusao
		Map<String, Object> namedParameters = new HashMap<String, Object>(2);
		namedParameters.put("ano", ano);
		namedParameters.put("nuSemestre", nuSemestre);

		// Obtem a query
		String sql = this.getSqlCommand("consultarPorAnoPorSemestre");

		// Executa a consulta
		final List<AuxiliarRelatorioVO> result = this.executeQuery(sql, 
				namedParameters, auxiliarRelatorioRowMapper);

		if ((result != null) && (result.size() > 0)) {
			return result.get(0);
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.AuxiliarRelatorioDAO#incluir(
	 *      br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO)
	 */
	@SuppressWarnings("unchecked")
	public int incluir(AuxiliarRelatorioVO auxiliarRelatorio)
			throws PersistenceException {

		String sql = this.getSqlCommand("incluir");
		int result = this.executeCommand(sql, auxiliarRelatorio);

		return result;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de AuxiliarRelatorio.
	 * 
	 * @spring.property ref="auxiliarRelatorioRowMapper"
	 * @param auxiliarRelatorioRowMapper
	 *            auxiliarRelatorioRowMapper a ser setado
	 */
	public void setAuxiliarRelatorioRowMapper(
			RowMapper<AuxiliarRelatorioVO> auxiliarRelatorioRowMapper) {
		this.auxiliarRelatorioRowMapper = auxiliarRelatorioRowMapper;
	}
}
