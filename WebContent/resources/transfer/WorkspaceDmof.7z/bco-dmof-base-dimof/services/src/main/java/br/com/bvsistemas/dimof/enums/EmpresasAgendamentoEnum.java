package br.com.bvsistemas.dimof.enums;

public enum EmpresasAgendamentoEnum {

	BANCO_VOTORANTIM		("59588111000103") ,
	VOTORANTIM_ASSET		("03384738000198") ,
	VOTORANTIM_CTVM			("01170892000131");

	private EmpresasAgendamentoEnum( String cnpj ){
		this.cnpj = cnpj;
	}
	
	private String cnpj;

	public String getCnpj() {
		return cnpj;
	}
}