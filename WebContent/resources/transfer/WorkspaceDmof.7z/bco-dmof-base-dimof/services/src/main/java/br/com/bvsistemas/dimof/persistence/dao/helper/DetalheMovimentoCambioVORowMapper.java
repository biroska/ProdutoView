package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de Detalhe de Movimento de cambio
 * 
 * @spring.bean name="detalheMovimentoCambioRowMapper" lazy-init="true" scope="singleton"
 * 
 * @author elias.yoshida
 * 
 */
public class DetalheMovimentoCambioVORowMapper implements RowMapper<DetalheMovimentoCambioVO> {

	/**
	 * Mapeia o resultSet para o objeto DetalheMovimentoCambioVO.
	 */
	public DetalheMovimentoCambioVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		IdentifierPK pk = new IdentifierPK(1);
		DetalheMovimentoCambioVO vo = new DetalheMovimentoCambioVO(pk);
		
		final Date dtMovimento      = rs.getDate("DtMovimento");
		final BigDecimal vrOperacao = rs.getBigDecimal("VrOperacao");
		final String tpOperacao     = rs.getString("TpOperacao"); 

		vo.setPk(pk);
		vo.setDtMovimento(dtMovimento);
		vo.setVrOperacao(vrOperacao);
		vo.setTpOperacao(tpOperacao);

		return vo;
	}

}
