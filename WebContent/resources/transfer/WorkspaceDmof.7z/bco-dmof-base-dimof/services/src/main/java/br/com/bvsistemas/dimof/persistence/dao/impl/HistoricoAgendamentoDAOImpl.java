/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoAgendamentoDAO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;

/**
 * Implementa��o de {@link HistoricoAgendamentoDAO}
 * 
 * @spring.bean name="historicoAgendamentoDAO" lazy-init="true" scope="singleton"
 * 
 * @author Aimbere Galdino
 * 
 */
public class HistoricoAgendamentoDAOImpl extends AbstractJdbcDao implements HistoricoAgendamentoDAO {

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(HistoricoAgendamentoDAOImpl.class);
	
	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceExceptions
	 */
	public HistoricoAgendamentoDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	@Override
	public boolean incluir( IdentifierPK pk ) throws PersistenceException {
		
		boolean executou = false;
		
		String sql = this.getSqlCommand("incluirByCdAgendamento");
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("cdAgendamento", pk.getId() );
		
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em incluir");
			logger.workflow.debug(sql.toString());
		}
		
		int executionResult = this.executeCommand(sql, parameters);
		
		if ( executionResult > 0 ){
			executou = true;
		}
		
		return executou;
	}
}