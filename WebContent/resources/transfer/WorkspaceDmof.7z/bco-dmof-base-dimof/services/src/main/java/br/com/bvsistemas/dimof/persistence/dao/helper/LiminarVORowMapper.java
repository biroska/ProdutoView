/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de liminar.
 * 
 * @spring.bean name="liminarRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author ematsuda
 * 
 */
public class LiminarVORowMapper implements RowMapper<LiminarVO> {

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger
			.getLogger(LiminarVORowMapper.class);
	
	/**
	 * Rowmapper para armazenar dados de pessoas.
	 */
	private RowMapper<PessoaVO> pessoaRowMapper;

	/**
	 * Rowmapper para armazenar dados de secoes judiciarias.
	 */
	private RowMapper<SecaoJudiciariaVO> secaoJudiciariaRowMapper;

	/**
	 * Mapeia o resultSet para o objeto LiminarVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public LiminarVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final int cdLiminar = rs.getInt("CdLiminar");
		IdentifierPK cdLiminarPK = new IdentifierPK(cdLiminar);
		LiminarVO vo = new LiminarVO(cdLiminarPK);

		final long nuLiminar = rs.getLong("NuLiminar");
		final int nuVaraTramitacao = rs.getInt("NuVaraTramitacao");
		final int nuSecaoJudiciaria = rs.getInt("NuSecaoJudiciaria");
		final String nmSubsecaoJudiciaria = rs.getString("NmSubsecaoJudiciaria");
		final String dsLogin = rs.getString("DsLogin");

		BVDate dtIniVigencia = null;
		if (rs.getDate("DtInicioVigencia") != null) {
			dtIniVigencia = new BVDate(rs.getDate("DtInicioVigencia"));
		}
		BVDate dtExpedicao = null;
		if (rs.getDate("DtExpedicao") != null) {
			dtExpedicao = new BVDate(rs.getDate("DtExpedicao"));
		}
		BVDate dtFimVigencia = null;
		if (rs.getDate("DtFimVigencia") != null) {
			dtFimVigencia = new BVDate(rs.getDate("DtFimVigencia"));
		}
		BVDatetime dtInformeFimVigencia = null;
		if (rs.getDate("DtInformeFimVigencia") != null) {
			dtInformeFimVigencia = new BVDatetime(
					rs.getDate("DtInformeFimVigencia"));
		}
		BVDate dtProcessamento = null;
		if (rs.getDate("DtProcessamento") != null) {
			dtProcessamento = new BVDate(rs.getDate("DtProcessamento"));
		}
		BVDatetime dtInclusao = null;
		try {
			String dataInclusao = rs.getString("DtInclusao");
			dtInclusao = new BVDatetime(dataInclusao, "yyyy-MM-dd HH:mm:ss");
		} catch (ParseException e) {
			logger.workflow.error(e);
		}

		if (pessoaRowMapper != null) {			
			vo.setCliente(pessoaRowMapper.mapRow(rs, rowNum));
		}

		if (secaoJudiciariaRowMapper != null) {
			vo.setSecaoJudiciaria(secaoJudiciariaRowMapper.mapRow(rs, rowNum));
		}
		
		if ("S".equals(rs.getString("FlCassacaoRetroativa"))) {
			vo.setFlCassacaoRetroativa(BooleanEnum.SIM);
		} else {
			vo.setFlCassacaoRetroativa(BooleanEnum.NAO);
		}
		
		vo.setPk(cdLiminarPK);
		vo.setNuLiminar(nuLiminar);
		vo.setNuVaraTramitacao(nuVaraTramitacao);
		vo.setNuSecaoJudiciaria(nuSecaoJudiciaria);
		vo.setNmSubsecaoJudiciaria(nmSubsecaoJudiciaria);
		vo.setDsLoginInclusao(dsLogin);
		vo.setDtIniVigencia(dtIniVigencia);
		vo.setDtExpedicao(dtExpedicao);
		vo.setDtFimVigencia(dtFimVigencia);
		vo.setDtProcessamento(dtProcessamento);
		vo.setDtInformeFimVigencia(dtInformeFimVigencia);
		vo.setDtInclusao(dtInclusao);
			
		return vo;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de pessoas.
	 * 
	 * @spring.property ref="pessoaRowMapper"
	 * @param pessoaRowMapper
	 *            pessoaRowMapper a ser setado
	 */
	public void setPessoaRowMapper(RowMapper<PessoaVO> pessoaRowMapper) {
		this.pessoaRowMapper = pessoaRowMapper;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de secoes judiciarias.
	 * 
	 * @spring.property ref="secaoJudiciariaRowMapper"
	 * @param secaoJudiciariaRowMapper
	 *            secaoJudiciariaRowMapper a ser setado
	 */
	public void setSecaoJudiciariaRowMapper(
			RowMapper<SecaoJudiciariaVO> secaoJudiciariaRowMapper) {
		this.secaoJudiciariaRowMapper = secaoJudiciariaRowMapper;
	}

}