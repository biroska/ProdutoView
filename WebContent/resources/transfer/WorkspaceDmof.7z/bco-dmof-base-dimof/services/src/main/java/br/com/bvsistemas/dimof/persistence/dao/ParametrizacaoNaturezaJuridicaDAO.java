package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

public interface ParametrizacaoNaturezaJuridicaDAO {

	
	/**
	 * M�todo respons�vel por retornar o nome da Natureza Juridica
	 * 
	 * @author resource.rtomiyama
	 * 
	 * @param cdNaturezaJuridica o identificador da Natureza Juridica que deve retornar o nome
	 * 
	 * @return String com o nome da Natureza Juridica
	 * 
	 * @throws PersistenceException
	 */
	public String getNomeNaturezaJuridica(String cdNaturezaJuridica) throws PersistenceException;
	
	/**
	 * Busca parametriza��es de uma natureza juridica.
	 * 
	 * @param cdNaturezaJuridica
	 *            C�digo da natureza juridica
	 * 
	 * @return Lista de objetos <code>ParametrizacaoNaturezaJuridicaVO</code>
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	List<ParametrizacaoNaturezaJuridicaVO> listarParametrizacoes(String cdNaturezaJuridica)
			throws PersistenceException;
	
	
	
	/**
	 * Salva parametrizacao de uma natureza juridica.
	 * 
	 * @param parametrizacao
	 *            dados da parametrizacao a ser salva
	 * @return Pk da parametrizacao salva
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	IdentifierPK inlcuir(ParametrizacaoNaturezaJuridicaVO parametrizacao)
			throws PersistenceException;		
	
	
	/**
	 * Salva parametrizacao de uma natureza juridica.
	 * 
	 * @param parametrizacao
	 *            dados da parametrizacao a ser salva
	 * @return Pk da parametrizacao salva
	 * @exception PersistenceException
	 *                caso falhe alguma opera��o no banco de dados
	 */
	IdentifierPK atualizar(ParametrizacaoNaturezaJuridicaVO parametrizacao)
			throws PersistenceException;		
	
}
