/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO respons�vel pela manuten��o de dados de Par�metro.
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public interface ParametroDAO {

	/**
	 * Consulta dados do (�nico) par�metro do sistema.
	 * 
	 * @return Objeto <code>ParametroSistemaVO</code>
	 * @exception PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	ParametroSistemaVO consultar() throws PersistenceException;

	/**
	 * Atualiza os dados do par�metro.
	 * 
	 * @param parametro
	 * 		      Objeto a ser alterado
	 * @return
	 * @throws PersistenceException
	 */
	int alterar(ParametroSistemaVO parametro) throws PersistenceException;

}
