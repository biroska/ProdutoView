/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.persistence.dao.HistoricoLiminarDAO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierDBKeyGenerator;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Implementa��o de {@link HistoricoLiminarDAO}
 * 
 * @spring.bean name="historicoLiminarDAO" lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 * 
 */
public class HistoricoLiminarDAOImpl extends AbstractJdbcDao implements
		HistoricoLiminarDAO {
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	RowMapper<HistoricoLiminarVO> historicoLiminarRowMapper;
	

	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger
			.getLogger(HistoricoLiminarDAOImpl.class);

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public HistoricoLiminarDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}

	/**
	 * Identificador do hist�rico.
	 */
	private IdentifierDBKeyGenerator historicoLiminarKeyGenerator;

	/**
	 * Inclui um hist�rico de altera��o.
	 * 
	 * @param historico
	 *            Historico a ser inserido
	 * @return IdentifierPK Id do hist�rico
	 * @throws PersistenceException
	 *             caso falhe alguma opera��o no banco de dados
	 */
	public IdentifierPK incluir(HistoricoLiminarVO historico)
			throws PersistenceException {
		// 1 - Verificando a PrimaryKey
		IdentifierPK pk = historico.getPk();
		Long id = pk.getId();
		if (id == null) {
			id = historicoLiminarKeyGenerator.generate();
			pk.setId(id);
		}

		// 2 - Inserindo registro no banco de dados
		String sql = this.getSqlCommand("incluir");

		// Executa insert na tabela
		int count = this.executeCommand(sql, historico);
		if (count != 1) {
			String errorMsg = "O hist�rico de altera��o de liminar "
					+ "n�o foi inserido no banco de dados, por�m o banco "
					+ "n�o retornou erro!";
			logger.workflow.warn(errorMsg);
			throw new PersistenceException(errorMsg);
		}

		return pk;
	}

	/**
	 * Seta o historicoLiminarKeyGenerator, que ser� utilizado no m�todo incluir
	 * para obter o IdentifierPK.
	 * 
	 * @spring.property ref="historicoLiminarKeyGenerator"
	 * @param historicoLiminarKeyGenerator
	 *            HistoricoLiminarKeyGenerator para setar
	 */
	public void setHistoricoLiminarKeyGenerator(
			IdentifierDBKeyGenerator historicoLiminarKeyGenerator) {
		this.historicoLiminarKeyGenerator = historicoLiminarKeyGenerator;
	}
	
	/* 
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.LiminarDAO#listar(br.com.bvsistemas.framework.datatype.IdentifierPK, 
	 *      java.lang.String, br.com.bvsistemas.framework.datatype.BVDate, br.com.bvsistemas.framework.datatype.BVDate, 
	 *      br.com.bvsistemas.framework.datatype.BolleanEnum)
	 */
	@SuppressWarnings("unchecked")
	public List<HistoricoLiminarVO> listar(IdentifierPK pkPessoa, String nuLiminar,
			BVDate dtInicio, BVDate dtFim)
			throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listar");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);

		// Filtros da pesquisa
		if (pkPessoa != null) {
			sql.append("\n AND pessoa.CdPessoa = :cdPessoa");
			namedParameters.put("cdPessoa", pkPessoa.getId());
		}

		if ((StringUtils.isNotBlank(nuLiminar)) 
				&& (StringUtils.isNumeric(nuLiminar))) {
			sql.append("\n AND liminar.NuLiminar = :nuLiminar");
			namedParameters.put("nuLiminar", new Long(nuLiminar));
		}

			if ((dtInicio != null) && (dtFim != null)) {
				sql.append("\n AND (");
				sql.append("\n     (convert(date,logL.DtAlteracao)") ;
				sql.append("\n        BETWEEN :dtInicio AND :dtFim)");
				sql.append("\n     )");		
				namedParameters.put("dtInicio", dtInicio.getSqlValue());
				namedParameters.put("dtFim", dtFim.getSqlValue());
			}
		

		// Ordena��o da consulta
		sql.append("\n ORDER BY logL.DtAlteracao");

		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sql.toString());
		}

		final List<HistoricoLiminarVO> listaLiminar = this.executeQuery(
				sql.toString(), namedParameters, historicoLiminarRowMapper);

		return listaLiminar;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.HistoricoLiminarDAO#incluir(java.util.List)
	 */
	public void incluir(List<HistoricoLiminarVO> historicoList)
			throws PersistenceException {

		for (Iterator<HistoricoLiminarVO> iterator = historicoList.iterator(); 
				iterator.hasNext();) {
			incluir(iterator.next());
		}

	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de liminares.
	 * 
	 * @spring.property ref="historicoLiminarRowMapper"
	 * @param historicoLiminarRowMapper
	 *            the historicoLiminarRowMapper a ser setado
	 */
	public void setHistoricoLiminarRowMapper(
			RowMapper<HistoricoLiminarVO> historicoLiminarRowMapper) {
		this.historicoLiminarRowMapper = historicoLiminarRowMapper;
	}
}
