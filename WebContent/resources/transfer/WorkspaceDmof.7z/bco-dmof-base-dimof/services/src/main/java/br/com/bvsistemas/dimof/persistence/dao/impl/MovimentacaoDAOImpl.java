package br.com.bvsistemas.dimof.persistence.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.persistence.dao.AbstractJdbcDao;
import br.com.bvsistemas.dimof.persistence.dao.MovimentacaoDAO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Implementa��o de {@link MovimentacaoDAO}
 * 
 * @spring.bean name="movimentacaoDAO" lazy-init="true" scope="singleton"
 * 
 * @author ematsuda
 */
public class MovimentacaoDAOImpl extends AbstractJdbcDao implements MovimentacaoDAO {
	
	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger.getLogger(LiminarDAOImpl.class);

	/**
	 * 
	 * @spring.constructor-arg ref="DBINFORMACAOFINANCEIRA"
	 * @param ds
	 * @throws PersistenceException
	 */
	public MovimentacaoDAOImpl(DataSource ds) throws PersistenceException {
		super(ds);
	}
	
	/**
	 * RowMapper de par�metros do sistema utilizado na consulta.
	 */
	RowMapper<MovimentacaoVO> movimentacaoRowMapper;
	
	/**
	 * RowMapper de detalhe de movimento de cambio
	 */
	RowMapper<DetalheMovimentoCambioVO> detalheMovimentoCambioRowMapper;
	/**
	 * RowMapper de detalhe de movimento de conta corrente
	 */
	RowMapper<DetalheMovimentoCCVO> detalheMovimentoCCRowMapper;
	
	/* 
	 * (non-Javadoc)
	 * 
	 * @see br.com.bvsistemas.dimof.persistence.dao.MovimentacaoDAO#listar(
	 * java.lang.String,java.lang.String,
	 * br.com.bvsistemas.framework.datatype.IdentifierPK 
	 *       )
	 */
	@SuppressWarnings("unchecked")
	public List<MovimentacaoVO> listar(String ano, String semestre,
			IdentifierPK pessoa) throws PersistenceException {
		
		String sqlCommand = this.getSqlCommand("listar");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);

		// Filtros da pesquisa
		if (pessoa != null && pessoa.getId() != null) {
			sql.append("\n AND pessoa.CdPessoa = :cdPessoa");
			namedParameters.put("cdPessoa", pessoa.getId());
		}

		if ((StringUtils.isNotBlank(ano)) 
				&& (StringUtils.isNumeric(ano))) {
			sql.append("\n AND year(movimento.DtMovimento) = :ano");
			namedParameters.put("ano", new Long(ano));
		}
		
		if ((StringUtils.isNotBlank(ano)) 
				&& (StringUtils.isNumeric(ano))) {
			sql.append("\n AND movimento.NuSemestre = :semestre");
			namedParameters.put("semestre", new Long(semestre));
		}

		// Ordena��o da consulta
		sql.append("\n group by movimento.CdPessoa ,"
         
       + "  year(movimento.DtMovimento) ,"
          +" pessoa.NuCpfCnpj,"
          +"  pessoa.NmPessoa,  "
          +"  pessoa.CdPessoa,  "
          +"  movimento.NuSemestre ,"
          +"   pessoa.TpPessoa");
         sql.append("\n ORDER BY UPPER(pessoa.NmPessoa)");



		// Debug
		if (logger.workflow.isDebugEnabled()) {
			logger.workflow.debug("Comando SQL gerado em listar");
			logger.workflow.debug(sql.toString());
		}

		final List<MovimentacaoVO> listaMovimentacao = this.executeQuery(
				sql.toString(), namedParameters, movimentacaoRowMapper);
		
		return listaMovimentacao;
	}
	
	/**
	 * Retorna a lista detalhada de movimentacoes de cambio para um cliente
	 * 
	 * @throws PersistenceException
	 */
	@SuppressWarnings("unchecked")
	public List<DetalheMovimentoCambioVO> detalharMovimentoCambio(Integer cdPessoa, Date dtInicio, Date dtFim) throws PersistenceException {
		String sqlCommand = this.getSqlCommand("detalharMovimentoCambio");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);
		
		namedParameters.put("cdPessoa", cdPessoa);
		namedParameters.put("dtInicioMovimento", dtInicio);
		namedParameters.put("dtFimMovimento", dtFim);
		
		final List<DetalheMovimentoCambioVO> listaMovimentoCambio = this.executeQuery(sql.toString(), namedParameters, detalheMovimentoCambioRowMapper);
		return listaMovimentoCambio;
	}

	/**
	 * Retorna a lista detalhada de movimentacoes de conta corrente para um cliente
	 * 
	 * @throws PersistenceException
	 */
	@SuppressWarnings("unchecked")
	public List<DetalheMovimentoCCVO> detalharMovimentoContaCorrente(Integer cdPessoa, Date dtInicio, Date dtFim) throws PersistenceException {
		String sqlCommand = this.getSqlCommand("detalharMovimentoContaCorrente");
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		
		StringBuffer sql = new StringBuffer(sqlCommand);

		namedParameters.put("cdPessoa", cdPessoa);
		namedParameters.put("dtInicioMovimento", dtInicio);
		namedParameters.put("dtFimMovimento", dtFim);
		
		final List<DetalheMovimentoCCVO> listaMovimentoCC = this.executeQuery(sql.toString(), namedParameters, detalheMovimentoCCRowMapper);
		return listaMovimentoCC;
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de movimentacao.
	 * 
	 * @spring.property ref="movimentacaoRowMapper"
	 * @param movimentacaoRowMapper
	 *            the movimentacaoRowMapper a ser setado
	 */
	public void setMovimentacaoRowMapper(
			RowMapper<MovimentacaoVO> movimentacaoRowMapper) {
		this.movimentacaoRowMapper =  movimentacaoRowMapper;
	}

	/**
	 * M�todo para setar o RowMapper com detalhe de movimento de cambio
	 * 
	 * @spring.property ref="detalheMovimentoCambioRowMapper"
	 * @param detalheMovimentoCambioRowMapper
	 *            the detalheMovimentoCambioRowMapper a ser setado
	 */
	public void setDetalheMovimentoCambioRowMapper(RowMapper<DetalheMovimentoCambioVO> detalheMovimentoCambioRowMapper) {
		this.detalheMovimentoCambioRowMapper =  detalheMovimentoCambioRowMapper;
	}
	
	/**
	 * M�todo para setar o RowMapper com detalhe de movimento de conta corrente
	 * 
	 * @spring.property ref="detalheMovimentoCCRowMapper"
	 * @param detalheMovimentoCCRowMapper
	 *            the detalheMovimentoCCRowMapper a ser setado
	 */
	public void setDetalheMovimentoCCRowMapper(RowMapper<DetalheMovimentoCCVO> detalheMovimentoCCRowMapper) {
		this.detalheMovimentoCCRowMapper =  detalheMovimentoCCRowMapper;
	}
	
}
