package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * Retorna o valor de uma �nica coluna
 *
 * @author talent.ealmeida
 * 
 * @spring.bean name="genericSingleColumnRowMapper" lazy-init="true" scope="singleton"
 * 
 * @created 29/08/2012
 */
public class GenericSingleColumnRowMapper implements RowMapper<Object> {

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.simple.ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		final String column = rs.getString(1);

		return column;
	}

}
