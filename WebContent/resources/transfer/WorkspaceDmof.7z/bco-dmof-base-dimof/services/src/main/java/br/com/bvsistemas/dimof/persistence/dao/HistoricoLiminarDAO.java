/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.PersistenceException;

/**
 * DAO de Historico de liminar.
 * 
 * @author ematsuda
 * 
 */
public interface HistoricoLiminarDAO {

	/**
	 * Inclui um hist�rico de altera��o.
	 * 
	 * @param historico
	 *            Historico a ser inserido
	 * @return IdentifierPK Id do hist�rico
	 * @throws PersistenceException
	 *             caso falhe alguma opera��o no banco de dados
	 */
	public IdentifierPK incluir(HistoricoLiminarVO historico)
			throws PersistenceException;

	/**
	 * Inclui uma lista de hist�rico de altera��o.
	 * 
	 * @param historicoList
	 *            Lista de Historico a ser inserido
	 * @throws PersistenceException
	 *             caso falhe alguma opera��o no banco de dados
	 */
	public void incluir(List<HistoricoLiminarVO> historicoList)
			throws PersistenceException;
	

	public List<HistoricoLiminarVO> listar(IdentifierPK pkPessoa, 
			String nuLiminar, BVDate dtInicio, BVDate dtFim)
			throws PersistenceException ;

}
