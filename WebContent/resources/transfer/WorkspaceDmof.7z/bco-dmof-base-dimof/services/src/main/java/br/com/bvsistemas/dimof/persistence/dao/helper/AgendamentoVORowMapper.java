/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.datatype.StatusProcessamentoVO;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de agendamento.
 * 
 * @spring.bean name="agendamentoRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author Aimbere Galdino
 * 
 */
@SuppressWarnings("unused")
public class AgendamentoVORowMapper implements RowMapper<AgendamentoVO> {
	
	/**
	 * <p>
	 * Componente de logging.
	 * </p>
	 */
	private final BVLogger logger = BVLogger
			.getLogger(AgendamentoVORowMapper.class);

	/**
	 * Rowmapper para armazenar dados de Status de Processamento.
	 */
	private RowMapper<StatusProcessamentoVO> statusProcessamentoRowMapper;
	

	/**
	 * Rowmapper para armazenar dados de Status de Processamento.
	 */
	private RowMapper<AgendamentoVO> agendamentoRowMapper;

	/**
	 * Mapeia o resultSet para o objeto AgendamentoVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public AgendamentoVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		final int cdAgendamento = rs.getInt("CdProcessamentoEscrituracao");
		IdentifierPK cdAgendamentoPK = new IdentifierPK( cdAgendamento );
		AgendamentoVO vo = new AgendamentoVO( cdAgendamentoPK );
		
		final int mesInicial = rs.getInt("MmInicioPeriodoProcessamento");
		
		final int anoInicial = rs.getInt("AaInicioPeriodoProcessamento");

		final int mesFinal = rs.getInt("MmFimPeriodoProcessamento");
		
		final int anoFinal = rs.getInt("AaFimPeriodoProcessamento");
		
		String usuario = null;
		if ( rs.getString("DsLogin") != null ) {			
			usuario = rs.getString("DsLogin");
		}

		if ( statusProcessamentoRowMapper != null ) {			
			vo.setStatusProcessamento( statusProcessamentoRowMapper.mapRow(rs, rowNum) );
		}
		
		Date dtAtualizacao = null;
		if ( rs.getTimestamp("DtAlteracao") != null ) {
			dtAtualizacao = rs.getTimestamp("DtAlteracao");
		}
		
		BVDate dtProcessamento = null;
		if ( rs.getDate("DtProcessamento") != null ) {
			dtProcessamento = new BVDate(rs.getDate("DtProcessamento"));
		}

		BVDate dtInclusao = null;
		if ( rs.getDate("DtInclusao") != null ) {
			dtInclusao = new BVDate(rs.getDate("DtInclusao"));
		}
		
		vo.setPk( cdAgendamentoPK );
		vo.setMesInicial( DataUtils.getMesVO( mesInicial ) );
		vo.setAnoInicial( anoInicial );
		vo.setMesFinal( DataUtils.getMesVO( mesFinal ) );
		vo.setAnoFinal( anoFinal );
		vo.setDtProcessamento( dtProcessamento );
		vo.setDtInclusao( dtInclusao );
		vo.setUsuario( usuario );
		vo.setDtAtualizacao( dtAtualizacao );
		
//		vo.setStatusProcessamento( ) ja setado nos ifs acima
//		vo.setMesInicial() ja setado nos ifs acima
//		vo.setMesFinal() ja setado nos ifs acima
			
		return vo;
	}

	/**
	 * M�todo para setar o RowMapper com informa��es de Status de agendamento.
	 * 
	 * @spring.property ref="agendamentoRowMapper"
	 * @param agendamentoRowMapper
	 *            agendamentoRowMapper a ser setado
	 */
	public void setAgendamentoRowMapper(
			RowMapper<AgendamentoVO> agendamentoRowMapper) {
		this.agendamentoRowMapper = agendamentoRowMapper;
	}
	
	/**
	 * M�todo para setar o RowMapper com informa��es de Status de processamento.
	 * 
	 * @spring.property ref="statusProcessamentoRowMapper"
	 * @param statusProcessamentoRowMapper
	 *            statusProcessamentoRowMapper a ser setado
	 */
	public void setStatusProcessamentoRowMapper(
			RowMapper<StatusProcessamentoVO> statusProcessamentoRowMapper) {
		this.statusProcessamentoRowMapper = statusProcessamentoRowMapper;
	}
}