/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper de {@link NaturezaJuridicaVO}
 * 
 * @spring.bean name="naturezaJuridicaRowMapper"
 *              lazy-init="true"
 *              scope="singleton" 
 * 
 * @author ematsuda
 * 
 */
public class NaturezaJuridicaVORowMapper implements RowMapper<NaturezaJuridicaVO> {

///**
//
// * Rowmapper para armazenar dados da natureza juridica.
//*/
//	
// RowMapper<NaturezaJuridicaVO> naturezaJuridicaRowMapper;
	
	
	/**
	 * Mapeia o resultSet para o objeto NaturezaJuridicaVO.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.jdbc.core.simple.
	 *      ParameterizedRowMapper#mapRow(java.sql.ResultSet, int)
	 */
	public NaturezaJuridicaVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		NaturezaJuridicaVO vo = new NaturezaJuridicaVO(new IdentifierPK());
		
		
		vo.setCdNaturezaJuridicaEscrituracao(rs.getLong("CdNaturezaJuridicaEscrituracao"));
		vo.setCdNaturezaJuridica(rs.getString("CdNaturezaJuridica"));
		vo.setNmNaturezaJuridica(rs.getString("NmNaturezaJuridica"));
		vo.setDsLogin(rs.getString("DsLogin"));
		vo.setDtInclusao(rs.getTimestamp("DtInclusao"));
		vo.setDtAlteracao(rs.getTimestamp("DtAlteracao"));
		vo.setDtFimVigencia(rs.getDate("DtFimVigencia"));
		vo.setDtInicioVigencia(rs.getDate("DtInicioVigencia"));
		vo.setFlAtivo(rs.getString("FlAtivo"));
		vo.setFlEnviaInformacaoEFinanceira(rs.getString("FlEnviaInformacaoEFinanceira"));
		
		if(vo.getDtInicioVigencia() != null){
			vo.setDtInicio(DataUtils.dateToStr(vo.getDtInicioVigencia() , "MMMM/yyyy"));
		}
		

		if(vo.getDtFimVigencia() != null){
			vo.setDtFim(DataUtils.dateToStr(vo.getDtFimVigencia() , "MMMM/yyyy"));
		}
		

		return vo;
	}
	
//	/**
//	 * M�todo para setar o RowMapper com informa��es da Natureza Juridica.
//	 * 
//	 * @spring.property ref="naturezaJuridicaRowMapper"
//	 * @param naturezaJuridicaRowMapper
//	 *            naturezaJuridicaRowMapper a ser setado
//	 */
//	public void setNaturezaJuridicaRowMapper(RowMapper<NaturezaJuridicaVO> naturezaJuridicaRowMapper) {
//		this.naturezaJuridicaRowMapper = naturezaJuridicaRowMapper;
//	}
}