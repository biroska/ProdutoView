package br.com.bvsistemas.dimof.persistence.dao.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.bvsistemas.dimof.datatype.TransacaoVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.persistence.dao.RowMapper;

/**
 * RowMapper da Transacao da Movimencao de conta corrente
 * 
 * @spring.bean name="transacaoVORowMapper" lazy-init="true" scope="singleton"
 * 
 * @author elias.yoshida
 * @created 24/08/2012 
 * 
 */
public class TransacaoVORowMapper implements RowMapper<TransacaoVO> {

	/**
	 * Mapeia o resultSet para o objeto TransacaoVORowMapper.
	 */
	public TransacaoVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		IdentifierPK pk = new IdentifierPK(rs.getInt("CdTransacao"));
		TransacaoVO vo = new TransacaoVO(pk);
		
		final String nmTransacao = rs.getString("NmTransacao"); 
		
		vo.setPk(pk);
		vo.setNmTransacao(nmTransacao);

		return vo;
	}

}
