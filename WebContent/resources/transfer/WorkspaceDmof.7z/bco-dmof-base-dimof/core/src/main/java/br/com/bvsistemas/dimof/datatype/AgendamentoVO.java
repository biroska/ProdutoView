/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import java.util.Date;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * Informa��es dos agendamentos.
 * 
 * @author Aimbere Galdino
 * @version 1.0
 * @created 25-fev-16 
 */
public class AgendamentoVO extends AbstractValueObject<IdentifierPK> {
	
	/**
	 * Serial
	 */
	private static final long serialVersionUID = -47020107923455837L;

	public AgendamentoVO( final IdentifierPK pk) {
		super(pk);
	}
	
	/**
	 * Mes inicial do agendamento.
	 */
	private MesVO mesInicial;
	
	private int anoInicial;
	
	/**
	 * Mes final do agendamento.
	 */
	private MesVO mesFinal;
	
	private int anoFinal;
	
	private String flAtivo;
	
	/**
	 * Usuario que criou o agendamento.
	 */
	private String usuario;
	
	/**
	 * Status do processamento.
	 */
	private StatusProcessamentoVO statusProcessamento;
	
	/**
	 * Data de atualiza��o do agendamento.
	 */
	private Date dtAtualizacao;
	
	/**
	 * Data de inclusao do agendamento.
	 */
	private BVDate dtInclusao;
	
	/**
	 * Data do processamento.
	 */
	private BVDate dtProcessamento;

	public MesVO getMesInicial() {
		return mesInicial;
	}

	public void setMesInicial(MesVO mesInicial) {
		this.mesInicial = mesInicial;
	}

	public int getAnoInicial() {
		return anoInicial;
	}

	public void setAnoInicial(int anoInicial) {
		this.anoInicial = anoInicial;
	}

	public MesVO getMesFinal() {
		return mesFinal;
	}

	public void setMesFinal(MesVO mesFinal) {
		this.mesFinal = mesFinal;
	}

	public int getAnoFinal() {
		return anoFinal;
	}

	public void setAnoFinal(int anoFinal) {
		this.anoFinal = anoFinal;
	}
	
	public String getFlAtivo() {
		return flAtivo;
	}

	public void setFlAtivo(String flAtivo) {
		this.flAtivo = flAtivo;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public StatusProcessamentoVO getStatusProcessamento() {
		return statusProcessamento;
	}

	public void setStatusProcessamento(StatusProcessamentoVO statusProcessamento) {
		this.statusProcessamento = statusProcessamento;
	}

	public BVDate getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(BVDate dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public Date getDtAtualizacao() {
		return extracted();
	}

	private Date extracted() {
		return dtAtualizacao;
	}

	public void setDtAtualizacao(Date dtAtualizacao) {
		extracted(dtAtualizacao);
	}

	private void extracted(Date dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}

	public BVDate getDtProcessamento() {
		return dtProcessamento;
	}

	public void setDtProcessamento(BVDate dtProcessamento) {
		this.dtProcessamento = dtProcessamento;
	}
}