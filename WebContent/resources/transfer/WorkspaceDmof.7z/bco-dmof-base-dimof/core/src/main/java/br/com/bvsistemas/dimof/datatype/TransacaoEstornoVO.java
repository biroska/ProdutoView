/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import java.util.Date;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Value Object referente as transa��es de estorno cadastradas
 * 
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com.br">Edilson Almeida</a>
 * 
 * @created  24/08/2012
 */
public class TransacaoEstornoVO extends AbstractValueObject<IdentifierPK> {


    /**
     * Serial
     */
    private static final long serialVersionUID = -1274912321953048928L;


    /**
     * Construtor da Classe
     * @param pk Identificador do log
     */
    public TransacaoEstornoVO(IdentifierPK pk) {
	super(pk);
    }    
    
    
    /** Identificador da Origem da Transa��o  */
    private Integer cdOrigem;
    
    /** Nome da Origem */
    private String nmOrigem;
    
    /** Nome da Transa��o */
    private String nmTransacao;
    
    /** Identificador da Transa��o */
    private Integer cdTransacao;
    
    /** Identificador do CNPJ destino */
    private String raizCnpj;
    
    /** Data de cadastro do registro */
    private Date dataInclusao;
    
    /** Data de altera��o do registro */
    private Date dataAlteracao;

    /** Flag que indica se ativo = S ou inativo = N */
    private String flAtivo;

    public Integer getCdOrigem() {
        return cdOrigem;
    }

    public void setCdOrigem(Integer cdOrigem) {
        this.cdOrigem = cdOrigem;
    }

    public String getNmOrigem() {
        return nmOrigem;
    }

    public void setNmOrigem(String nmOrigem) {
        this.nmOrigem = nmOrigem;
    }

    public String getNmTransacao() {
        return nmTransacao;
    }

    public void setNmTransacao(String nmTransacao) {
        this.nmTransacao = nmTransacao;
    }

    public Integer getCdTransacao() {
        return cdTransacao;
    }

    public void setCdTransacao(Integer cdTransacao) {
        this.cdTransacao = cdTransacao;
    }

    public String getRaizCnpj() {
        return raizCnpj;
    }

    public void setRaizCnpj(String raizCnpj) {
        this.raizCnpj = raizCnpj;
    }

    public Date getDataInclusao() {
        return dataInclusao;
    }

    public void setDataInclusao(Date dataInclusao) {
        this.dataInclusao = dataInclusao;
    }

    public Date getDataAlteracao() {
        return dataAlteracao;
    }

    public void setDataAlteracao(Date dataAlteracao) {
        this.dataAlteracao = dataAlteracao;
    }

    public String getFlAtivo() {
        return flAtivo;
    }

    public void setFlAtivo(String flAtivo) {
        this.flAtivo = flAtivo;
    }
    
}
