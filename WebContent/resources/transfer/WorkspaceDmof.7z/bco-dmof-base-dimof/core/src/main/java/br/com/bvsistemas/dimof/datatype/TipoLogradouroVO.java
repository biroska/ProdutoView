/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Tipo do logradouro de acordo com a tabela divulgada na Instru��o Normativa.
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008
 */
public class TipoLogradouroVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 3840683817266544529L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do tipo de logradouro.
	 */
	public TipoLogradouroVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Nome do tipo do logradouro. 
	 */
	private String nmTipoLogradouro;
		
	/**
	 * Retorna o nome do tipo de logradouro.
	 * 
	 * @return nmTipoLogradouro
	 */
	public String getNmTipoLogradouro() {
		return nmTipoLogradouro;
	}
	
	/**
	 * Seta o nome do tipo de logradouro.
	 * 
	 * @param nmTipoLogradouro Nome do tipo de logradouro
	 */
	public void setNmTipoLogradouro(String nmTipoLogradouro) {
		this.nmTipoLogradouro = nmTipoLogradouro;
	}
}
