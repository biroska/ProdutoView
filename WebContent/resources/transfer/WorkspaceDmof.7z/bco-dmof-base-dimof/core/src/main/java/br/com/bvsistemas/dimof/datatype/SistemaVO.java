/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Dados do sistema do Global
 * 
 * @author Aimbere Galdino
 * @version 1.0
 * @created 11-Mar-2016
 */
public class SistemaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial
	 */
	private static final long serialVersionUID = -1285838559507694293L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador da pessoa
	 */
	public SistemaVO(final IdentifierPK pk) {
		super(pk);
	}
	
	private String dsSistema;
	
	private String flAtivo;
	
	private BVDate dtInclusao;
	
	private BVDate dtAlteracao;
	
	private Integer cdPessoaFuncionario;
	
	private String sgSistema;

	public String getDsSistema() {
		return dsSistema;
	}

	public void setDsSistema(String dsSistema) {
		this.dsSistema = dsSistema;
	}

	public String getFlAtivo() {
		return flAtivo;
	}

	public void setFlAtivo(String flAtivo) {
		this.flAtivo = flAtivo;
	}

	public BVDate getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(BVDate dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public BVDate getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(BVDate dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Integer getCdPessoaFuncionario() {
		return cdPessoaFuncionario;
	}

	public void setCdPessoaFuncionario(Integer cdPessoaFuncionario) {
		this.cdPessoaFuncionario = cdPessoaFuncionario;
	}

	public String getSgSistema() {
		return sgSistema;
	}

	public void setSgSistema(String sgSistema) {
		this.sgSistema = sgSistema;
	}
}