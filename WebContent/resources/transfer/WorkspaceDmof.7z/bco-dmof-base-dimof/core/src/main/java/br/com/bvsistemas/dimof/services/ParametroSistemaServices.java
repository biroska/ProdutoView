/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.exception.DataInvalidaSituacaoEspecialException;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de Parametriza��o do sistema
 * 
 * @author ematsuda
 * @version 1.0
 * @created 09-Oct-2008
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface ParametroSistemaServices {

	/**
	 * Altera um parametro do sistema.
	 * 
	 * @param parametroSistema
	 *            Parametro a ser alterado
	 * @return Flag de persistencia da base
	 * @throws ValidationException
	 * @throws DataInvalidaSituacaoEspecialException
	 */
	@ESBServiceAnnotation(name = "Dimof.ParametroSistema.alterar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract int alterar(ParametroSistemaVO parametroSistema)
			throws ValidationException, DataInvalidaSituacaoEspecialException;

	/**
	 * Consulta um determinado parametro do sistema.
	 * 
	 * @return Parametro procurado
	 * @throws ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.ParametroSistema.consultar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract ParametroSistemaVO consultar()
			throws ValidationException;

}
