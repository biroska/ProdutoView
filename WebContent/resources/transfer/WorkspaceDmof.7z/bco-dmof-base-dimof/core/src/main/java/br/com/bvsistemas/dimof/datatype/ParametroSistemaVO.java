/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Par�metros necess�rios para a gera��o do arquivo texto Dimof.
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008 
 */
public class ParametroSistemaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 3840683817266544529L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public ParametroSistemaVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Valor do limite para pessoa f�sica.
	 */
	private BVFloat vrLimitePF;
	
	/**
	 * Valor do limite para pessoa jur�dica.
	 */
	private BVFloat vrLimitePJ;

	/**
	 * Declarante.
	 */
	private PessoaVO declarante;

	/**
	 * Representante legal.
	 */
	private PessoaVO representanteLegal;

	/**
	 * Respons�vel pelo preenchimento.
	 */
	private PessoaVO respPreenchimento;

	/**
	 * Respons�vel pelo atendimento da RMF.
	 */
	private PessoaVO respAtendimentoRMF;
	
	/**
	 * Tipo da situa��o especial.
	 */
	private String tpSituacaoEspecial;
	
	/**
	 * Data do evento quando h� situa��o especial.
	 */
	private BVDate dtEnvioSituacaoEspecial;
	
	/**
	 * Tipo de logradouro do respons�vel pela RMF.
	 */
	private TipoLogradouroVO tipoLogradouroRespRMF;
	
	/**
	 * Nome do arquivo.
	 */
	private String nmArquivo;

	/**
	 * Retorna o valor limite de pessoa f�sica.
	 * @return vrLimitePF
	 */
	public BVFloat getVrLimitePF() {
		return vrLimitePF;
	}

	/**
	 * Seta o valor limite de pessoa f�sica.
	 * 
	 * @param vrLimitePF Valor a ser setado
	 */
	public void setVrLimitePF(BVFloat vrLimitePF) {
		this.vrLimitePF = vrLimitePF;
	}

	/**
	 * Retorna o valor limite de pssoa jur�dica.
	 * 
	 * @return vrLimitePJ
	 */
	public BVFloat getVrLimitePJ() {
		return vrLimitePJ;
	}

	/**
	 * Seta o valor limite de pessoa jur�dica.
	 * 
	 * @param vrLimitePJ Valor a ser setado
	 */
	public void setVrLimitePJ(BVFloat vrLimitePJ) {
		this.vrLimitePJ = vrLimitePJ;
	}

	/**
	 * Retorna o declarante.
	 * 
	 * @return declarante
	 */
	public PessoaVO getDeclarante() {
		return declarante;
	}

	/**
	 * Seta o declarante.
	 * 
	 * @param declarante Declarante a ser setado
	 */
	public void setDeclarante(PessoaVO declarante) {
		this.declarante = declarante;
	}

	/**
	 * Retorna o representante legal.
	 * 
	 * @return representanteLegal
	 */
	public PessoaVO getRepresentanteLegal() {
		return representanteLegal;
	}

	/**
	 * Seta o representante legal.
	 * 
	 * @param representanteLegal Representante a ser setado
	 */
	public void setRepresentanteLegal(PessoaVO representanteLegal) {
		this.representanteLegal = representanteLegal;
	}

	/**
	 * Retorna o respons�vel pelo preenchimento.
	 * 
	 * @return respPreenchimento
	 */
	public PessoaVO getRespPreenchimento() {
		return respPreenchimento;
	}

	/**
	 * Seta o respons�vel pelo preenchimento.
	 * 
	 * @param respPreenchimento Respons�vel a ser setado
	 */
	public void setRespPreenchimento(PessoaVO respPreenchimento) {
		this.respPreenchimento = respPreenchimento;
	}

	/**
	 * Retorna o Respons�vel pelo atendimento da RMF.
	 * 
	 * @return respAtendimentoRMF
	 */
	public PessoaVO getRespAtendimentoRMF() {
		return respAtendimentoRMF;
	}

	/**
	 * Seta o respons�vel pelo atendimento da RMF.
	 * 
	 * @param respAtendimentoRMF Respons�vel a ser setado
	 */
	public void setRespAtendimentoRMF(PessoaVO respAtendimentoRMF) {
		this.respAtendimentoRMF = respAtendimentoRMF;
	}

	/**
	 * Retorna o tipo da situa��o especial.
	 * 
	 * @return tpSituacaoEspecial
	 */
	public String getTpSituacaoEspecial() {
		return tpSituacaoEspecial;
	}

	/**
	 * Seta o tipo da situa��o especial.
	 * 
	 * @param tpSituacaoEspecial Tipo a ser setado.
	 */
	public void setTpSituacaoEspecial(String tpSituacaoEspecial) {
		this.tpSituacaoEspecial = tpSituacaoEspecial;
	}

	/**
	 * Retorna a data do evento da situa��o especial.
	 * 
	 * @return dtEnvioSituacaoEspecial
	 */
	public BVDate getDtEnvioSituacaoEspecial() {
		return dtEnvioSituacaoEspecial;
	}

	/**
	 * Seta a data do evendo da situa��o especial.
	 *  
	 * @param dtEnvioSituacaoEspecial Data a ser setada
	 */
	public void setDtEnvioSituacaoEspecial(BVDate dtEnvioSituacaoEspecial) {
		this.dtEnvioSituacaoEspecial = dtEnvioSituacaoEspecial;
	}

	/**
	 * Retorna o tipo de logradouro do respons�vel pelo atendimento da RMF.
	 * 
	 * @return tipoLogradouroRespRMF
	 */
	public TipoLogradouroVO getTipoLogradouroRespRMF() {
		return tipoLogradouroRespRMF;
	}

	/**
	 * Seta o tipo de logradouro do respons�vel pelo atendimento da RMF.
	 * 
	 * @param tipoLogradouroVO Tipo de logradouro a ser setado
	 */
	public void setTipoLogradouroRespRMF(TipoLogradouroVO 
			tipoLogradouroRespRMF) {
		this.tipoLogradouroRespRMF = tipoLogradouroRespRMF;
	}

	/**
	 * Retorna o nome do arquivo a ser gerado.
	 * 
	 * @return nmArquivo
	 */
	public String getNmArquivo() {
		return nmArquivo;
	}

	/**
	 * Seta o nome do arquivo a ser gerado.
	 * 
	 * @param nmArquivo Nome a ser setado
	 */
	public void setNmArquivo(String nmArquivo) {
		this.nmArquivo = nmArquivo;
	}
	
}
