/* Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.exception;

import br.com.bvsistemas.framework.exception.BVBusinessException;

/**
 * Exce��o lan�ada caso j� exista a chave n�mero de liminar + cliente.
 * 
 * @author ematsuda
 * @version 1.0
 */
@SuppressWarnings("serial")
public class LiminarDuplicadaException extends BVBusinessException{

	public LiminarDuplicadaException() {

	}

	public void finalize() throws Throwable {

	}

}