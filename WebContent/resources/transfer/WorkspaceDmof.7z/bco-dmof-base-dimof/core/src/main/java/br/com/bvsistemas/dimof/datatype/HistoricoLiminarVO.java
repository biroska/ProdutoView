/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Hist�rico de altera��es das liminares.
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008 
 */
public class HistoricoLiminarVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 3840683817266544529L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public HistoricoLiminarVO(final IdentifierPK pk) {
		super(pk);
	}
	/**
	* Liminar a qual pertence o log.
	*/
	private LiminarVO  liminar;
	
	/**
	 * Data/hora da altera��o.
	 */
	private BVDatetime dtAlteracao;
	
	/**
	 * Usu�rio que realizou a altera��o.
	 */
	private String DsLogin;
	
	/**
	 * N�mero da liminar.
	 */
	private long nuLiminar;
	
	/**
	 * Campo altera��o.
	 */
	private String nmCampo;
	
	/**
	 * Dado antigo.
	 */
	private String dsDadoAntigo;
	
	/**
	 * Dado novo.
	 */
	private String dsDadoNovo;

	/**
	 * @return the dtAlteracao
	 */
	public BVDatetime getDtAlteracao() {
		return dtAlteracao;
	}

	/**
	 * @param dtAlteracao the dtAlteracao to set
	 */
	public void setDtAlteracao(BVDatetime dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	/**
	 * @return the dsLogin
	 */
	public String getDsLogin() {
		return DsLogin;
	}

	/**
	 * @param dsLogin the dsLogin to set
	 */
	public void setDsLogin(String dsLogin) {
		DsLogin = dsLogin;
	}

	/**
	 * @return the nuLiminar
	 */
	public long getNuLiminar() {
		return nuLiminar;
	}

	/**
	 * @param nuLiminar the nuLiminar to set
	 */
	public void setNuLiminar(long nuLiminar) {
		this.nuLiminar = nuLiminar;
	}

	/**
	 * @return the nmCampo
	 */
	public String getNmCampo() {
		return nmCampo;
	}

	/**
	 * @param nmCampo the nmCampo to set
	 */
	public void setNmCampo(String nmCampo) {
		this.nmCampo = nmCampo;
	}

	/**
	 * @return the dsDadoAntigo
	 */
	public String getDsDadoAntigo() {
		return dsDadoAntigo;
	}

	/**
	 * @param dsDadoAntigo the dsDadoAntigo to set
	 */
	public void setDsDadoAntigo(String dsDadoAntigo) {
		this.dsDadoAntigo = dsDadoAntigo;
	}

	/**
	 * @return the dsDadoNovo
	 */
	public String getDsDadoNovo() {
		return dsDadoNovo;
	}

	/**
	 * @param dsDadoNovo the dsDadoNovo to set
	 */
	public void setDsDadoNovo(String dsDadoNovo) {
		this.dsDadoNovo = dsDadoNovo;
	}

	public final LiminarVO getLiminar() {
		return liminar;
	}

	public final void setLiminar(LiminarVO liminar) {
		this.liminar = liminar;
	}
	
}
