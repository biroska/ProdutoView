/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services.auth.enums;

import br.com.bvsistemas.framework.datatype.BVEnum;

/**
 * @author cit.cmiranda
 * @version 1.0
 * @created 02-May-2008 11:09:05
 */
public enum DominioEnum implements BVEnum<String> {
	DIMOF("Dimof");

	private String innerValue;

	/**
	 * Construtor que recebe o valor String.
	 * 
	 * @param value
	 * 
	 */
	private DominioEnum(String value) {
		this.innerValue = value;
	}

	/**
	 * @see br.com.bvsistemas.framework.datatype.BVEnum#innerValue()
	 */
	public String innerValue() {
		return this.innerValue;
	}
}
