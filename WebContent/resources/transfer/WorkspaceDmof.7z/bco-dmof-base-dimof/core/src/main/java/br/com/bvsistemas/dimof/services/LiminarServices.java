/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.exception.LiminarDuplicadaException;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de manuten��o de cadastro de liminares.
 * 
 * @author ematsuda
 * @version 1.0
 * @created 09-Oct-2008
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface LiminarServices {

	/**
	 * Atualiza uma determinada liminar
	 * 
	 * @param liminar -
	 *            Liminar a ser atualizada
	 * @return flag de atualizacao da base
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Liminar.atualizar", transactionType = ESBTransactionTypeEnum.REQUIRED)
	public abstract int atualizarLiminar(LiminarVO liminar, String usuario)
			throws ValidationException, LiminarDuplicadaException;

	/**
	 * Inclui uma nova liminar
	 * 
	 * @param liminar
	 *            Liminar a ser criada
	 * @return flag de atualizacao da base
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Liminar.incluir", transactionType = ESBTransactionTypeEnum.REQUIRED)
	public abstract int incluirLiminar(LiminarVO liminar)
			throws ValidationException, LiminarDuplicadaException;

	/**
	 * 
	 * Lista todas as liminares conforme filtro.
	 * 
	 * @param pkPessoa
	 *            Identificador da pessoa (pk)
	 * @param nuLiminar
	 *            Numero da liminar
	 * @param dtInicio
	 *            Data de inicio da vigencia
	 * @param dtFim
	 *            Data de fim da vigencia
	 * @param apenasVigentes
	 *            Flag que indica apenas liminares vigentes
	 * 
	 * @return Lista de objetos <code>LiminarVO</code>
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.Liminar.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<LiminarVO> listar(IdentifierPK pkPessoa,
			String nuLiminar, BVDate dtInicio, BVDate dtFim,
			BooleanEnum apenasVigentes) throws ValidationException,
			CamposObrigatoriosNaoPreenchidosException;

	/**
	 * 
	 * Consulta uma determinada liminar pelo id
	 * 
	 * @param pk -
	 *            Identifier da liminar
	 * 
	 * @return uma determinada liminar
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Liminar.consultar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract LiminarVO consultarLiminar(IdentifierPK pk)
			throws ValidationException;

	/**  
	 * Consulta o hist�rico de liminar pelo id do cliente, n�mero da liminar
	 * ou per�odo de altera��o. 
	 * 
	 * @param pkCliente -
	 *            Identifier do cliente
	 * @param nuLiminar -
	 *            N�mero da Liminar
	 * @param dtInicio -
	 *            Per�odo inicial de altera��o
	 * @param dtFinal -
	 *            Per�odo final de altera��o
	 * @return Lista das altera��es realizadas
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.Liminar.listarHistorico", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<HistoricoLiminarVO> listarHistoricoLiminar(
		IdentifierPK pkCliente, String nuMLiminar, BVDate dtInicio, 
			BVDate dtFim) throws ValidationException,
				CamposObrigatoriosNaoPreenchidosException;

}
