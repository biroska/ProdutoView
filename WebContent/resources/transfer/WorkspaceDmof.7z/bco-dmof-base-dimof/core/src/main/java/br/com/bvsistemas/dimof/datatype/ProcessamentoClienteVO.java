/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * Informa��es dos resultados de Processamento do Sistema.
 * 
 * @author Aimbere Galdino
 * @version 1.0
 * @created 08-mar-16 
 */
public class ProcessamentoClienteVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial
	 */
	private static final long serialVersionUID = -1076587584024823159L;

	public ProcessamentoClienteVO( final IdentifierPK pk) {
		super(pk);
	}
	
	public ProcessamentoClienteVO(IdentifierPK pk,
			AgendamentoVO cdProcessamentoEscrituracao) {
		super(pk);
		this.cdProcessamentoEscrituracao = cdProcessamentoEscrituracao;
	}

	private AgendamentoVO cdProcessamentoEscrituracao;
	
	private PessoaVO cdCliente;

	public AgendamentoVO getCdProcessamentoEscrituracao() {
		return cdProcessamentoEscrituracao;
	}

	public void setCdProcessamentoEscrituracao(
			AgendamentoVO cdProcessamentoEscrituracao) {
		this.cdProcessamentoEscrituracao = cdProcessamentoEscrituracao;
	}

	public PessoaVO getCdCliente() {
		return cdCliente;
	}

	public void setCdCliente(PessoaVO cdCliente) {
		this.cdCliente = cdCliente;
	}
}