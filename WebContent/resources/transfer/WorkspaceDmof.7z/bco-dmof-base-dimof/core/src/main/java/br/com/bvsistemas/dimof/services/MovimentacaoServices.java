/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoVO;
import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de Movimenta��es
 * 
 * @author ematsuda
 * @version 1.0
 * @created 09-Oct-2008
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface MovimentacaoServices {

	/**
	 * 
	 * Lista Movimenta��es
	 * 
	 * @return lista de movimenta��es
	 * 
	 * @exception ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.Movimentacoes.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<MovimentacaoVO> listar(String semestre,
			String ano, IdentifierPK pkCliente) throws ValidationException,
			CamposObrigatoriosNaoPreenchidosException;
	
	/**
	 * Retorna os detalhes do movimento para o cliente selecionado
	 */
	@ESBServiceAnnotation(name = "Dimof.Movimentacoes.detalhar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public DetalheMovimentoVO detalharMovimento(String semestre, String ano, Integer cdPessoa);
	
}
