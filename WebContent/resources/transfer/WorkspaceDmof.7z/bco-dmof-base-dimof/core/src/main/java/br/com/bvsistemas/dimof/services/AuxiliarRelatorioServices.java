/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de manutencao de AuxiliarRelatorio.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface AuxiliarRelatorioServices {

	/**
	 * Atualiza um registro de relatorio. Caso o registro ainda nao exista, 
	 * inclui um novo registro.
	 * 
	 * @param auxiliarRelatorio
	 * 		      Objeto a ser atualizado
	 * @return Flag de persistencia da base
	 * @throws ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Demonstrativo.regerar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract int regerar(final AuxiliarRelatorioVO auxiliarRelatorio) 
		throws ValidationException;
}
