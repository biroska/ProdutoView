/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Se��es Judici�rias de acordo com a tabela divulgada na Instru��o Normativa.
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008
 */
public class SecaoJudiciariaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 3840683817266544529L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador da se��o judici�ria
	 */
	public SecaoJudiciariaVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Nome da se��o judici�ria. 
	 */
	private String nmSecaoJudiciaria;
		
	/**
	 * Retorna o nome da se��o judici�ria.
	 * 
	 * @return nmSecaoJudiciaria
	 */
	public String getNmSecaoJudiciaria() {
		return nmSecaoJudiciaria;
	}
	
	/**
	 * Seta o nome da se��o judici�ria.
	 * 
	 * @param nmSecaoJudiciaria Nome da se��o judici�ria
	 */
	public void setNmSecaoJudiciaria(String nmSecaoJudiciaria) {
		this.nmSecaoJudiciaria = nmSecaoJudiciaria;
	}
}
