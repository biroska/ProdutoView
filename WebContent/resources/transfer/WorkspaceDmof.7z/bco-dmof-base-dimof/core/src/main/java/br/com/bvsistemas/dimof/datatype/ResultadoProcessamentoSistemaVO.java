/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * Informa��es dos resultados de Processamento do Sistema.
 * 
 * @author Aimbere Galdino
 * @version 1.0
 * @created 08-mar-16 
 */
public class ResultadoProcessamentoSistemaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial
	 */
	private static final long serialVersionUID = 3017429454279350254L;

	public ResultadoProcessamentoSistemaVO( final IdentifierPK pk) {
		super(pk);
	}
	
	private Integer cdProcessamentoEscrituracao;
	
	private Integer cdSistema; // remover e retestar....
	private SistemaVO sistemaVO;
	
	private Integer qtRegistroProcessado;
	
	private Integer qtRegistroErro;
	
	private BVDate dtResultadoProcessamento;
	
	private Integer mmProcessado;
	
	private Integer aaProcessado;

	public Integer getCdProcessamentoEscrituracao() {
		return cdProcessamentoEscrituracao;
	}

	public void setCdProcessamentoEscrituracao(Integer cdProcessamentoEscrituracao) {
		this.cdProcessamentoEscrituracao = cdProcessamentoEscrituracao;
	}

	public Integer getCdSistema() {
		return cdSistema;
	}

	public void setCdSistema(Integer cdSistema) {
		this.cdSistema = cdSistema;
	}
	
	public SistemaVO getSistemaVO() {
		return sistemaVO;
	}

	public void setSistemaVO(SistemaVO sistemaVO) {
		this.sistemaVO = sistemaVO;
	}

	public Integer getQtRegistroProcessado() {
		return qtRegistroProcessado;
	}

	public void setQtRegistroProcessado(Integer qtRegistroProcessado) {
		this.qtRegistroProcessado = qtRegistroProcessado;
	}

	public Integer getQtRegistroErro() {
		return qtRegistroErro;
	}

	public void setQtRegistroErro(Integer qtRegistroErro) {
		this.qtRegistroErro = qtRegistroErro;
	}

	public BVDate getDtResultadoProcessamento() {
		return dtResultadoProcessamento;
	}

	public void setDtResultadoProcessamento(BVDate dtResultadoProcessamento) {
		this.dtResultadoProcessamento = dtResultadoProcessamento;
	}

	public Integer getMmProcessado() {
		return mmProcessado;
	}

	public void setMmProcessado(Integer mmProcessado) {
		this.mmProcessado = mmProcessado;
	}

	public Integer getAaProcessado() {
		return aaProcessado;
	}

	public void setAaProcessado(Integer aaProcessado) {
		this.aaProcessado = aaProcessado;
	}
}