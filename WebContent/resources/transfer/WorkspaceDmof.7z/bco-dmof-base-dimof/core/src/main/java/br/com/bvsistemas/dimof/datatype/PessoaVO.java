/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.corporativo.global.generic.datatypes.TipoPessoaEnum;
import br.com.bvsistemas.dimof.util.DimofUtils;
import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Dados em comun de pessoa (cliente/declarante/representante).
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008
 */
public class PessoaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7151309474371877106L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador da pessoa
	 */
	public PessoaVO(final IdentifierPK pk) {
		super(pk);
	}
	
	public PessoaVO(IdentifierPK pk, String nmPessoa, String nuCpfCnpj) {
		super(pk);
		this.nuCpfCnpj = nuCpfCnpj;
		this.nmPessoa = nmPessoa;
	}
	
	/** 
	 * Flag nao gerar agendamento.
	 */
	private String flRemover;

	/**
	 * Cpf/Cnpj da pessoa. 
	 */
	private String nuCpfCnpj;
		
	/**
	 * Nome da pessoa. 
	 */
	private String nmPessoa;
	
	/**
	 * Tipo da pessoa. 
	 */
	private TipoPessoaEnum tpPessoa;
	
	/**
	 * Retorna o  Cpf/Cnpj da pessoa.
	 * 
	 * @return nuCpfCnpj
	 */
	public String getNuCpfCnpj() {		
		return nuCpfCnpj;
	}
	
	/**
	 * Retorna o  Cpf/Cnpj da pessoa. Formatado
	 * 
	 * @return nuCpfCnpj
	 */
	public String getNuCpfCnpjFormatado() {
		if(nuCpfCnpj != null )
			return DimofUtils.formatarCpfCnpj(nuCpfCnpj);
		return nuCpfCnpj;
	}
	
	
	
	/**
	 * Seta o Cpf/Cnpj da pessoa.
	 * 
	 * @param nuCpfCnpj Cpf/Cnpj da pessoa
	 */
	public void setNuCpfCnpj(String nuCpfCnpj) {
		this.nuCpfCnpj = nuCpfCnpj;
	}

	/**
	 * Retorna o nome da pessoa.
	 * 
	 * @return nmPessoa
	 */
	public String getNmPessoa() {
		return nmPessoa;
	}

	/**
	 * Seta o nome da pessoa.
	 * 
	 * @param nmPessoa Nome da pessoa 
	 */
	public void setNmPessoa(String nmPessoa) {
		this.nmPessoa = nmPessoa;
	}

	/**
	 * Retorna o tipo da pessoa.
	 * 
	 * @return tipo (f�sica ou jur�dica)
	 */
	public TipoPessoaEnum getTpPessoa() {
		return tpPessoa;
	}

	/**
	 * Seta o tipo da pessoa (F�sica ou Jur�dica)
	 * 
	 * @param tipo Tipo da pessoa
	 */
	public void setTpPessoa(TipoPessoaEnum tpPessoa) {
		this.tpPessoa = tpPessoa;
	}

	public String getFlRemover() {
		return flRemover;
	}

	public void setFlRemover(String flRemover) {
		this.flRemover = flRemover;
	}
}
