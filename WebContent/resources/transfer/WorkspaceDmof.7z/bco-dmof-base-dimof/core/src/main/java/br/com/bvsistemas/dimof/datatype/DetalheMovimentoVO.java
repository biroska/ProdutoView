/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import java.util.List;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Value Object com detalhe de movimenta��es de d�bito e cr�dito em conta corrente 
 * e compra, venda e transferencia de cambio para um cliente.
 * 
 * @author elias.yoshida
 * @created 18-07-2012 
 */
public class DetalheMovimentoVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public DetalheMovimentoVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * VO do Cliente
	 */
	private PessoaVO cliente;
	
	/**
	 * Numero da conta corrente
	 */
	private String nuContaCorrente;


	/**
	 * Lista de detalhes de movimentacoes de cambio
	 */
	private List<DetalheMovimentoCambioVO> listaMovCambio;
	
	/**
	 * Lista de detalhes de movimentacoes de conta corrente
	 */
	private List<DetalheMovimentoCCVO> listaMovContaCC;

	
	public PessoaVO getCliente() {
		return cliente;
	}

	public void setCliente(PessoaVO cliente) {
		this.cliente = cliente;
	}

	public String getNuContaCorrente() {
		return nuContaCorrente;
	}

	public void setNuContaCorrente(String nuContaCorrente) {
		this.nuContaCorrente = nuContaCorrente;
	}

	public List<DetalheMovimentoCambioVO> getListaMovCambio() {
		return listaMovCambio;
	}

	public void setListaMovCambio(List<DetalheMovimentoCambioVO> listaMovCambio) {
		this.listaMovCambio = listaMovCambio;
	}

	public List<DetalheMovimentoCCVO> getListaMovContaCC() {
		return listaMovContaCC;
	}

	public void setListaMovContaCC(List<DetalheMovimentoCCVO> listaMovContaCC) {
		this.listaMovContaCC = listaMovContaCC;
	}

}
