package br.com.bvsistemas.dimof.datatype;

import java.util.Date;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * Informa��es dos agendamentos.
 * 
 * @author Bianca Paulino
 * @version 1.0
 * @created 26-fev-16 
 */
public class NaturezaJuridicaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7878814764438826868L;

	public NaturezaJuridicaVO( final IdentifierPK pk) {
		super(pk);
	}


	private Long cdNaturezaJuridicaEscrituracao;
	private String cdNaturezaJuridica;
	private String nmNaturezaJuridica;
	private String flEnviaInformacaoEFinanceira;
	private Date dtInicioVigencia;
	private Date dtFimVigencia;
	private String dsLogin;
	private String flAtivo;
	private Date dtInclusao;
	private Date dtAlteracao;
	private String dtInicio;
	private String dtFim;


	public Long getCdNaturezaJuridicaEscrituracao() {
		return cdNaturezaJuridicaEscrituracao;
	}
	public void setCdNaturezaJuridicaEscrituracao(
			Long cdNaturezaJuridicaEscrituracao) {
		this.cdNaturezaJuridicaEscrituracao = cdNaturezaJuridicaEscrituracao != null? cdNaturezaJuridicaEscrituracao: null;
	}
	public String getNmNaturezaJuridica() {
		return nmNaturezaJuridica;
	}
	public void setNmNaturezaJuridica(String nmNaturezaJuridica) {
		this.nmNaturezaJuridica = nmNaturezaJuridica;
	}
	public String getFlEnviaInformacaoEFinanceira() {
		return flEnviaInformacaoEFinanceira;
	}
	public void setFlEnviaInformacaoEFinanceira(String flEnviaInformacaoEFinanceira) {
		this.flEnviaInformacaoEFinanceira = flEnviaInformacaoEFinanceira;
	}
	public Date getDtInicioVigencia() {
		return dtInicioVigencia != null ? dtInicioVigencia : null;
	}
	public void setDtInicioVigencia(Date dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia != null ? dtInicioVigencia : null;
	}
	public Date getDtFimVigencia() {
		return dtFimVigencia != null ? dtFimVigencia : null;
	}
	public void setDtFimVigencia(Date dtFimVigencia) {
		this.dtFimVigencia = dtFimVigencia != null ? dtFimVigencia : null;
	}
	public String getDsLogin() {
		return dsLogin;
	}
	public void setDsLogin(String dsLogin) {
		this.dsLogin = dsLogin;
	}
	public String getFlAtivo() {
		return flAtivo;
	}
	public void setFlAtivo(String flAtivo) {
		this.flAtivo = flAtivo;
	}
	public Date getDtInclusao() {
		return dtInclusao != null ? dtInclusao : null;
	}
	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao != null ? dtInclusao : null;
	}
	public Date getDtAlteracao() {
		return dtAlteracao != null ?dtAlteracao : null;
	}
	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao != null ? dtAlteracao : null;
	}
	public String getDtInicio() {
		return dtInicio;
	}
	public void setDtInicio(String dtInicio) {
		this.dtInicio = dtInicio;
	}
	public String getDtFim() {
		return dtFim;
	}
	public void setDtFim(String dtFim) {
		this.dtFim = dtFim;
	}
	public String getCdNaturezaJuridica() {
		return cdNaturezaJuridica;
	}
	public void setCdNaturezaJuridica(String cdNaturezaJuridica) {
		this.cdNaturezaJuridica = cdNaturezaJuridica;
	}

}