package br.com.bvsistemas.dimof.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import br.com.bvsistemas.dimof.datatype.MesVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Classe util para manipulacao de datas
 *
 * @author Aimbere  Galdino</a>
 *
 * @created 26/02/2016
 * 
 */
public class DataUtils {

	private static Locale locale = new Locale("pt", "BR");
	
	private static final BVLogger logger = BVLogger.getLogger(DataUtils.class);
	
	public static List<MesVO> montaListaDeMeses(){
		
		SimpleDateFormat formatter = new SimpleDateFormat("MMMM", locale );
		
		List<MesVO> meses = new ArrayList<MesVO>();
		Calendar calendar = new GregorianCalendar();
		calendar.set( Calendar.DAY_OF_MONTH, 1 );
		
		calendar.set( Calendar.MONTH, Calendar.JANUARY );
		meses.add( new MesVO( new IdentifierPK( Calendar.JANUARY +1 ), formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.FEBRUARY );
		meses.add( new MesVO( new IdentifierPK( Calendar.FEBRUARY +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.MARCH );
		meses.add( new MesVO( new IdentifierPK( Calendar.MARCH +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.APRIL );
		meses.add( new MesVO( new IdentifierPK( Calendar.APRIL +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.MAY );
		meses.add( new MesVO( new IdentifierPK( Calendar.MAY +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.JUNE );
		meses.add( new MesVO( new IdentifierPK( Calendar.JUNE +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.JULY );
		meses.add( new MesVO( new IdentifierPK( Calendar.JULY +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.AUGUST );
		meses.add( new MesVO( new IdentifierPK( Calendar.AUGUST +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.SEPTEMBER );
		meses.add( new MesVO( new IdentifierPK( Calendar.SEPTEMBER +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.OCTOBER );
		meses.add( new MesVO( new IdentifierPK( Calendar.OCTOBER +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.NOVEMBER );
		meses.add( new MesVO( new IdentifierPK( Calendar.NOVEMBER +1 ) , formatter.format( calendar.getTime() ) ) );
		
		calendar.set( Calendar.MONTH, Calendar.DECEMBER );
		meses.add( new MesVO( new IdentifierPK( Calendar.DECEMBER +1 ) , formatter.format( calendar.getTime() ) ) );
		
		return meses;
	}

	/**
	 * Retorna o MesVO de acordo com o indice do mes informado.
	 * O indice segue o indice do banco de dados, 1 -> Janeiro
	 * 12 -> Dezembro
	 * 
	 * @param int indice do mes
	 * @return MesVO
	 */
	public static MesVO getMesVO( int index ){
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM", locale );
		
	    Calendar calendar = new GregorianCalendar();
	    calendar.set( Calendar.MONTH, index -1 );
	    
	    IdentifierPK identifierPK = new IdentifierPK( index );
	    
	    String format = sdf.format( calendar.getTime() );
	    
	    MesVO mesVO = new MesVO( identifierPK, format );
	    
	    return mesVO;
	}
	
	/**
	 * Converte uma data no formato String para um objeto Date.
	 * 
	 * @param String data, String pattern
	 * @return Date
	 * @throws ParseException
	 */
	public static Date strToDate(String data, String pattern) {
		
		if ( StringUtils.isBlank( pattern ) || StringUtils.isBlank( data ) ) {
			return null;
		}
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			return sdf.parse(data);
		} catch (ParseException e) {
			
			if ( logger.workflow.isInfoEnabled() ) {
				logger.workflow.info("Erro ao fazer a conversao: ", new ParseException( e.toString(), -1 )  );
			}
			return null;
		}
	}

	 /**
	 * Converte uma data no formato Date para um objeto String.
	 * 
	 * @param Date data, String pattern
	 * @return String data formatada segundo o pattern informado
	 * @throws ParseException
	 */
	public static String dateToStr(Date data, String pattern) {

		if (StringUtils.isBlank(pattern) || data == null) {
			return null;
		}

		SimpleDateFormat sdf = new SimpleDateFormat( pattern );
		
		return sdf.format(data);
	}
}
