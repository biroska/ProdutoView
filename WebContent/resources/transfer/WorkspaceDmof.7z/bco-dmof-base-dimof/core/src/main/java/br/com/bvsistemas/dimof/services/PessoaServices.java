/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de Pessoa.
 * 
 * @author ematsuda
 * @version 1.0
 * @created 09-Oct-2008
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface PessoaServices {

	/**
	 * 
	 * Lista Pessoas.
	 * 
	 * @param nmPessoa -
	 *            Nome parcial da pessoa procurada
	 * @param nuCpfCnpj -
	 *            Numero do Cpf/Cnpj da pessoa
	 * 
	 * @return lista de Pessoas
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Pessoa.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<PessoaVO> listar(String nmPessoa, String nuCpfCnpj)
			throws ValidationException;

	/**
	 * 
	 * Consulta Pessoas pelo id.
	 * 
	 * @param idPessoa -
	 *            Codigo da pessoa procurada
	 * 
	 * @return um registro de pessoa(PessoaVO)
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Pessoa.consultarPelaChave", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract PessoaVO consultarPelaChave(IdentifierPK idPessoa)
			throws ValidationException;

	/**
	 * 
	 * Consulta Empresas pelo id.
	 * 
	 * @param idPessoa -
	 *            Codigo da empresa procurada
	 * 
	 * @param nmPessoa -
	 *            Nome da empresa procurada
	 * 
	 * @param nuCpfCnpj -
	 *            nuCpfCnpj da empresa procurada
	 *                         
	 * @return um registro de pessoa(PessoaVO)
	 */
	@ESBServiceAnnotation(name = "Dimof.Pessoa.listarEmpresas", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<PessoaVO> listarEmpresasParaAgendamento() throws PersistenceException;

}