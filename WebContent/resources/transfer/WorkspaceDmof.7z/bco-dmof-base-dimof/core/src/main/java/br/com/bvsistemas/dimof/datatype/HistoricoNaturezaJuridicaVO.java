package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * Informa��es dos agendamentos.
 * 
 * @author Bianca Paulino
 * @version 1.0
 * @created 29-fev-16 
 */
public class HistoricoNaturezaJuridicaVO extends AbstractValueObject<IdentifierPK> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7897012767557616321L;


	public HistoricoNaturezaJuridicaVO( final IdentifierPK pk) {
		super(pk);
	}


	private BVDatetime dtLogNaturezaJuridica;
	private Long cdNaturezaJuridicaEscrituracao;
	private BVDate dtLogInicio;
	private BVDate dtLogFim;
	
	private NaturezaJuridicaVO naturezaJuridica;

	
	

	public Long getCdNaturezaJuridicaEscrituracao() {
		return cdNaturezaJuridicaEscrituracao;
	}


	public void setCdNaturezaJuridicaEscrituracao(
			Long cdNaturezaJuridicaEscrituracao) {
		this.cdNaturezaJuridicaEscrituracao = cdNaturezaJuridicaEscrituracao;
	}


	public NaturezaJuridicaVO getNaturezaJuridica() {
		return naturezaJuridica;
	}


	public void setNaturezaJuridica(NaturezaJuridicaVO naturezaJuridica) {
		this.naturezaJuridica = naturezaJuridica;
	}


	public BVDatetime getDtLogNaturezaJuridica() {
		return dtLogNaturezaJuridica != null ? dtLogNaturezaJuridica : null ;
	}


	public void setDtLogNaturezaJuridica(BVDatetime dtLogNaturezaJuridica) {
		this.dtLogNaturezaJuridica = dtLogNaturezaJuridica != null ? dtLogNaturezaJuridica : null;
	}


	public BVDate getDtLogInicio() {
		return dtLogInicio;
	}


	public void setDtLogInicio(BVDate dtLogInicio) {
		this.dtLogInicio = dtLogInicio;
	}


	public BVDate getDtLogFim() {
		return dtLogFim;
	}


	public void setDtLogFim(BVDate dtLogFim) {
		this.dtLogFim = dtLogFim;
	}

}