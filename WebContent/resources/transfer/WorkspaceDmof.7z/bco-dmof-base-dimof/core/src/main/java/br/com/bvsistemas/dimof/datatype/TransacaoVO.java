/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Value Object com a informa��o da transa��o
 * 
 * @author elias.yoshida
 * @created 24/08/2012 
 */
public class TransacaoVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public TransacaoVO(final IdentifierPK pk) {
		super(pk);
	}
	
	private String nmTransacao;
	

	public String getNmTransacao() {
		return nmTransacao;
	}

	public void setNmTransacao(String nmTransacao) {
		this.nmTransacao = nmTransacao;
	}
}
