/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoSistemaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de manuten��o de agendamentos.
 * 
 * @author Aimbere Galdino
 * @version 1.0
 * @created 26-Fev-2016
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface AgendamentoServices {

	/**
	 * Inclui uma nova liminar
	 * 
	 * @param AgendamentoVO
	 *            AgendamentoVO a ser criado
	 * @return flag de atualizacao da base
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.incluirAgendamento", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract int incluirAgendamento( AgendamentoVO agendamento, List<PessoaVO> empresas, List<PessoaVO> clientes ) throws ValidationException;
	
	/**
	 * Lista todos os agendamentos conforme filtro.
	 * 
	 * @param pkStatusProcessamento
	 *            Identificador do status do processamento (pk)
	 * @param nuMesInicial
	 *            Indice do mes de inicio
	 * @param anoInicial
	 *            Ano do inicio
	 * @param nuMesFinal
	 *            Indice do mes de final
	 * @param anoFinal
	 *            Ano do final
	 * 
	 * @return Lista de objetos <code>AgendamentoVO</code>
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<AgendamentoVO> listar(String cdStatusProcessamento, String nuMesInicial,
											   String anoInicial, String nuMesFinal, String anoFinal ) 
			throws ValidationException, CamposObrigatoriosNaoPreenchidosException;
	
	/**
	 * Cancela o Agendamento pelo pk informado..
	 * 
	 * @param cdProcessamentoEscrituracao
	 *            Identificador do agendamento (pk)
	 * @return Boolean <code>boolean</code>
	 * @throws PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.cancelar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract boolean cancelar( Long cdProcessamentoEscrituracao ) throws PersistenceException;

	/**
	 * Busca as empresas do agendamento.
	 * 
	 * @param idAgendamento
	 *            Identificador do agendamento (pk)
	 * @return Lista de Empresas <code>List<PessoaVO></code>
	 * @throws PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.listarEmpresas", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<PessoaVO> listarEmpresas( Long idAgendamento ) throws PersistenceException;
	
	/**
	 * Busca de clientes do agendamento.
	 * 
	 * @param idAgendamento
	 *            Identificador do agendamento (pk)
	 * @return Lista de clientes <code>List<PessoaVO></code>
	 * @throws PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.listarClientes", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<PessoaVO> listarClientes( Long idAgendamento ) throws PersistenceException;

	
	/**
	 * Busca de sistemas associados ao agendamento.
	 * 
	 * @param idAgendamento
	 *            Identificador do agendamento (pk)
	 * @return Lista de Sistemas <code>List<ResultadoProcessamentoSistemaVO></code>
	 * @throws PersistenceException
	 *                Caso falhe alguma opera��o no banco de dados
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.listarSistemas", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<ResultadoProcessamentoSistemaVO> listarSistemas( Long idAgendamento ) throws PersistenceException;


	/**
	 * 
	 * Consulta um determinado agendamento pelo id
	 * 
	 * @param pk -
	 *            Identifier do agendamento
	 * 
	 * @return um determinado agendamento
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.Agendamento.consultar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract AgendamentoVO consultarAgendamento(IdentifierPK pk)
			throws ValidationException;
	

}