package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * Informa��es dos agendamentos.
 * 
 * @author Bianca Paulino
 * @version 1.0
 * @created 29-fev-16 
 */
public class LogNaturezaJuridicaVO extends AbstractValueObject<IdentifierPK> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7897012767557616321L;

	private BVDatetime dtLogNaturezaJuridica;
	private long cdNaturezaJuridicaEscrituracao;
	private String cdNaturezaJuridica;
	private String nmNaturezaJuridica;
	private String dsLogin;
	private String nmCampoAlterado;
	private String vlAnterior;
	private String vlAtual;
	
		
	public LogNaturezaJuridicaVO( final IdentifierPK pk) {
		super(pk);
	}

	public BVDatetime getDtLogNaturezaJuridica() {
		return dtLogNaturezaJuridica != null ? dtLogNaturezaJuridica : null ;
	}


	public void setDtLogNaturezaJuridica(BVDatetime dtLogNaturezaJuridica) {
		this.dtLogNaturezaJuridica = dtLogNaturezaJuridica != null ? dtLogNaturezaJuridica : null;
	}

	
	
	public long getCdNaturezaJuridicaEscrituracao() {
		return cdNaturezaJuridicaEscrituracao;
	}

	public void setCdNaturezaJuridicaEscrituracao(long cdNaturezaJuridicaEscrituracao) {
		this.cdNaturezaJuridicaEscrituracao = cdNaturezaJuridicaEscrituracao;
	}

	public String getCdNaturezaJuridica() {
		return cdNaturezaJuridica;
	}

	public void setCdNaturezaJuridica(String cdNaturezaJuridica) {
		this.cdNaturezaJuridica = cdNaturezaJuridica;
	}

	public String getNmNaturezaJuridica() {
		return nmNaturezaJuridica;
	}

	public void setNmNaturezaJuridica(String nmNaturezaJuridica) {
		this.nmNaturezaJuridica = nmNaturezaJuridica;
	}

	public String getDsLogin() {
		return dsLogin;
	}

	public void setDsLogin(String dsLogin) {
		this.dsLogin = dsLogin;
	}

	public String getNmCampoAlterado() {
		return nmCampoAlterado;
	}

	public void setNmCampoAlterado(String nmCampoAlterado) {
		this.nmCampoAlterado = nmCampoAlterado;
	}

	public String getVlAnterior() {
		return vlAnterior;
	}

	public void setVlAnterior(String vlAnterior) {
		this.vlAnterior = vlAnterior;
	}

	public String getVlAtual() {
		return vlAtual;
	}

	public void setVlAtual(String vlAtual) {
		this.vlAtual = vlAtual;
	}

	

}