/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Status do processamento dos agendamentos
 * 
 * @author Aimbere Galdino
 * @version 1.0
 * @created 25-Fev-2016 
 */
public class StatusProcessamentoVO extends AbstractValueObject<IdentifierPK> {
	
	/**
	 * Serial.
	 */
	private static final long serialVersionUID = -6103105230145318343L;
	
	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do status
	 */
	public StatusProcessamentoVO(final IdentifierPK pk) {
		super(pk);
		
		if ( pk.getId() == 1L ){
			this.dsStatusProcessamento = "Agendado";
		} else
			if ( pk.getId() == 2L ){
				this.dsStatusProcessamento = "Gerado";
			} else
				if ( pk.getId() == 3L ){
					this.dsStatusProcessamento = "Gerado com restri��es";
				} else
					if ( pk.getId() == 4L ){
						this.dsStatusProcessamento = "Erro de processamento";
					} else {
						this.dsStatusProcessamento = "Cancelado";
					}
	}

	/**
	 * Descricao do status do processamento.
	 */
	private String dsStatusProcessamento;

	/**
	 * Retorna a descricao do status do processamento.
	 * 
	 * @return dsStatusProcessamento
	 */
	public String getDsStatusProcessamento() {
		return dsStatusProcessamento;
	}

	/**
	 * Seta a descricao do status do processamento.
	 * 
	 * @param dsStatusProcessamento descricao do status do processamento..
	 */
	public void setDsStatusProcessamento(String dsStatusProcessamento) {
		this.dsStatusProcessamento = dsStatusProcessamento;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((dsStatusProcessamento == null) ? 0 : dsStatusProcessamento
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (!super.equals(obj)){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		StatusProcessamentoVO other = (StatusProcessamentoVO) obj;
		if (dsStatusProcessamento == null) {
			if (other.dsStatusProcessamento != null){
				return false;
			}
		} else if (!dsStatusProcessamento.equals(other.dsStatusProcessamento)){
			return false;
		}
		return true;
	}
}	