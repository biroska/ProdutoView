/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Value Object com detalhe de movimenta��es de compra, venda e transferencia 
 * de cambio para um cliente.
 * 
 * @author elias.yoshida
 * @created 18-07-2012 
 */
public class DetalheMovimentoCambioVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public DetalheMovimentoCambioVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Data do movimento da operacao de cambio
	 */
	private Date dtMovimento;
	
	/**
	 * Valor da operacao de cambio
	 */
	private BigDecimal vrOperacao;
	
	/**
	 * Tipo de operacao de cambio: compra, venda ou transferencia
	 */
	private String tpOperacao;

	
	public Date getDtMovimento() {
		return dtMovimento;
	}

	public void setDtMovimento(Date dtMovimento) {
		this.dtMovimento = dtMovimento;
	}

	/**
	 * Retorna a data no formato dd/mm/aaaa
	 */
	public String getDtMovimentoFormatado() {
		if(dtMovimento != null){
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			return df.format(dtMovimento);
		}
		return "";
	}
	
	public BigDecimal getVrOperacao() {
		return vrOperacao;
	}

	public void setVrOperacao(BigDecimal vrOperacao) {
		this.vrOperacao = vrOperacao;
	}

	public String getTpOperacao() {
		return tpOperacao;
	}

	public void setTpOperacao(String tpOperacao) {
		this.tpOperacao = tpOperacao;
	}

}
