/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Value Object com movimenta��es a d�bito e a cr�dito dos clientes.
 * Acrescido compra, venda e transferencia de cambio
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008 
 */
public class MovimentacaoVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 3840683817266544529L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public MovimentacaoVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Semestre da movimenta��o (1 ou 2).
	 */
	private int semestre;
	
	/**
	 * Ano da movimenta��o (YYYY).
	 */
	private int ano;
	
	/**
	 * Cliente.
	 */
	private PessoaVO cliente;
	
	/**
	 * Valor a d�bito do m�s 1 
	 */
	private BVFloat vrDebMes1;

	/**
	 * Valor a cr�dito do m�s 1 
	 */
	private BVFloat vrCredMes1;

	/**
	 * Valor a d�bito do m�s 2 
	 */
	private BVFloat vrDebMes2;
	
	/**
	 * Valor a cr�dito do m�s 2
	 */
	private BVFloat vrCredMes2;
	
	/**
	 * Valor a d�bito do m�s 3 
	 */
	private BVFloat vrDebMes3;
	
	/**
	 * Valor a cr�dito do m�s 3 
	 */
	private BVFloat vrCredMes3;
	
	/**
	 * Valor a d�bito do m�s 4 
	 */
	private BVFloat vrDebMes4;

	/**
	 * Valor a cr�dito do m�s 4 
	 */
	private BVFloat vrCredMes4;

	/**
	 * Valor a d�bito do m�s 5 
	 */
	private BVFloat vrDebMes5;

	/**
	 * Valor a cr�dito do m�s 5
	 */
	private BVFloat vrCredMes5;

	/**
	 * Valor a d�bito do m�s 6 
	 */
	private BVFloat vrDebMes6;
	
	/**
	 * Valor a cr�dito do m�s 6 
	 */
	private BVFloat vrCredMes6;

	// Valor de compra de cambio do mes 1
	private BVFloat vrCompCambMes1;
	// Valor de venda de cambio do mes 1
	private BVFloat vrVendCambMes1;
	// Valor de transferencia de cambio do mes 1
	private BVFloat vrTranCambMes1;
	
	// Valor de compra / venda / transferencia de cambio do mes 2
	private BVFloat vrCompCambMes2;
	private BVFloat vrVendCambMes2;
	private BVFloat vrTranCambMes2;
	
	// Valor de compra / venda / transferencia de cambio do mes 3
	private BVFloat vrCompCambMes3;
	private BVFloat vrVendCambMes3;
	private BVFloat vrTranCambMes3;
	
	// Valor de compra / venda / transferencia de cambio do mes 4
	private BVFloat vrCompCambMes4;
	private BVFloat vrVendCambMes4;
	private BVFloat vrTranCambMes4;

	// Valor de compra / venda / transferencia de cambio do mes 5
	private BVFloat vrCompCambMes5;
	private BVFloat vrVendCambMes5;
	private BVFloat vrTranCambMes5;
	
	// Valor de compra / venda / transferencia de cambio do mes 6
	private BVFloat vrCompCambMes6;
	private BVFloat vrVendCambMes6;
	private BVFloat vrTranCambMes6;
	
	
	/**
	 * @return the semestre
	 */
	public int getSemestre() {
		return semestre;
	}

	/**
	 * @param semestre the semestre to set
	 */
	public void setSemestre(int semestre) {
		this.semestre = semestre;
	}

	/**
	 * @return the ano
	 */
	public int getAno() {
		return ano;
	}

	/**
	 * @param ano the ano to set
	 */
	public void setAno(int ano) {
		this.ano = ano;
	}

	/**
	 * @return the cliente
	 */
	public PessoaVO getCliente() {
		return cliente;
	}

	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(PessoaVO cliente) {
		this.cliente = cliente;
	}

	/**
	 * @return the vrDebMes1
	 */
	public BVFloat getVrDebMes1() {
		return vrDebMes1;
	}

	/**
	 * @return the vrDebMes1 wrapped
	 */
	public Double getVrDebMes1Wrapped() {
		 if (vrDebMes1 != null) {
			 try {
				 return Double.parseDouble(vrDebMes1.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrDebMes1 the vrDebMes1 to set
	 */
	public void setVrDebMes1(BVFloat vrDebMes1) {
		this.vrDebMes1 = vrDebMes1;
	}

	/**
	 * @return the vrCredMes1
	 */
	public BVFloat getVrCredMes1() {
		return vrCredMes1;
	}
	
	/**
	 * @return the vrCredMes1 wrapped
	 */
	public Double getVrCredMes1Wrapped() {
		 if (vrCredMes1 != null) {
			 try {
				 return Double.parseDouble(vrCredMes1.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrCredMes1 the vrCredMes1 to set
	 */
	public void setVrCredMes1(BVFloat vrCredMes1) {
		this.vrCredMes1 = vrCredMes1;
	}

	/**
	 * @return the vrDebMes2
	 */
	public BVFloat getVrDebMes2() {
		return vrDebMes2;
	}

	/**
	 * @return the vrDebMes2 wrapped
	 */
	public Double getVrDebMes2Wrapped() {
		 if (vrDebMes2 != null) {
			 try {
				 return Double.parseDouble(vrDebMes2.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrDebMes2 the vrDebMes2 to set
	 */
	public void setVrDebMes2(BVFloat vrDebMes2) {
		this.vrDebMes2 = vrDebMes2;
	}

	/**
	 * @return the vrCredMes2
	 */
	public BVFloat getVrCredMes2() {
		return vrCredMes2;
	}

	/**
	 * @return the vrCredMes2 wrapped
	 */
	public Double getVrCredMes2Wrapped() {
		 if (vrCredMes2 != null) {
			 try {
				 return Double.parseDouble(vrCredMes2.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrCredMes2 the vrCredMes2 to set
	 */
	public void setVrCredMes2(BVFloat vrCredMes2) {
		this.vrCredMes2 = vrCredMes2;
	}

	/**
	 * @return the vrDebMes3
	 */
	public BVFloat getVrDebMes3() {
		return vrDebMes3;
	}

	/**
	 * @return the vrDebMes3 wrapped
	 */
	public Double getVrDebMes3Wrapped() {
		 if (vrDebMes3 != null) {
			 try {
				 return Double.parseDouble(vrDebMes3.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrDebMes3 the vrDebMes3 to set
	 */
	public void setVrDebMes3(BVFloat vrDebMes3) {
		this.vrDebMes3 = vrDebMes3;
	}

	/**
	 * @return the vrCredMes3
	 */
	public BVFloat getVrCredMes3() {
		return vrCredMes3;
	}

	/**
	 * @return the vrCredMes3 wrapped
	 */
	public Double getVrCredMes3Wrapped() {
		 if (vrCredMes3 != null) {
			 try {
				 return Double.parseDouble(vrCredMes3.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrCredMes3 the vrCredMes3 to set
	 */
	public void setVrCredMes3(BVFloat vrCredMes3) {
		this.vrCredMes3 = vrCredMes3;
	}

	/**
	 * @return the vrDebMes4
	 */
	public BVFloat getVrDebMes4() {
		return vrDebMes4;
	}

	/**
	 * @return the vrDebMes4 wrapped
	 */
	public Double getVrDebMes4Wrapped() {
		 if (vrDebMes4 != null) {
			 try {
				 return Double.parseDouble(vrDebMes4.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrDebMes4 the vrDebMes4 to set
	 */
	public void setVrDebMes4(BVFloat vrDebMes4) {
		this.vrDebMes4 = vrDebMes4;
	}

	/**
	 * @return the vrCredMes4
	 */
	public BVFloat getVrCredMes4() {
		return vrCredMes4;
	}

	/**
	 * @return the vrCredMes4 wrapped
	 */
	public Double getVrCredMes4Wrapped() {
		 if (vrCredMes4 != null) {
			 try {
				 return Double.parseDouble(vrCredMes4.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrCredMes4 the vrCredMes4 to set
	 */
	public void setVrCredMes4(BVFloat vrCredMes4) {
		this.vrCredMes4 = vrCredMes4;
	}

	/**
	 * @return the vrDebMes5
	 */
	public BVFloat getVrDebMes5() {
		return vrDebMes5;
	}

	/**
	 * @return the vrDebMes5 wrapped
	 */
	public Double getVrDebMes5Wrapped() {
		 if (vrDebMes5 != null) {
			 try {
				 return Double.parseDouble(vrDebMes5.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrDebMes5 the vrDebMes5 to set
	 */
	public void setVrDebMes5(BVFloat vrDebMes5) {
		this.vrDebMes5 = vrDebMes5;
	}

	/**
	 * @return the vrCredMes5
	 */
	public BVFloat getVrCredMes5() {
		return vrCredMes5;
	}

	/**
	 * @return the vrCredMes5 wrapped
	 */
	public Double getVrCredMes5Wrapped() {
		 if (vrCredMes5 != null) {
			 try {
				 return Double.parseDouble(vrCredMes5.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrCredMes5 the vrCredMes5 to set
	 */
	public void setVrCredMes5(BVFloat vrCredMes5) {
		this.vrCredMes5 = vrCredMes5;
	}

	/**
	 * @return the vrDebMes6
	 */
	public BVFloat getVrDebMes6() {
		return vrDebMes6;
	}

	/**
	 * @return the vrDebMes6 wrapped
	 */
	public Double getVrDebMes6Wrapped() {
		 if (vrDebMes6 != null) {
			 try {
				 return Double.parseDouble(vrDebMes6.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrDebMes6 the vrDebMes6 to set
	 */
	public void setVrDebMes6(BVFloat vrDebMes6) {
		this.vrDebMes6 = vrDebMes6;
	}

	/**
	 * @return the vrCredMes6
	 */
	public BVFloat getVrCredMes6() {
		return vrCredMes6;
	}

	/**
	 * @return the vrCredMes6 wrapped
	 */
	public Double getVrCredMes6Wrapped() {
		 if (vrCredMes6 != null) {
			 try {
				 return Double.parseDouble(vrCredMes6.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}

	/**
	 * @param vrCredMes6 the vrCredMes6 to set
	 */
	public void setVrCredMes6(BVFloat vrCredMes6) {
		this.vrCredMes6 = vrCredMes6;
	}

	
	public BVFloat getVrCompCambMes1() {
		return vrCompCambMes1;
	}
	/**
	 * @return the vrCompCambMes1 wrapped
	 */
	public Double getVrCompCambMes1Wrapped() {
		 if (vrCompCambMes1 != null) {
			 try {
				 return Double.parseDouble(vrCompCambMes1.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrCompCambMes1(BVFloat vrCompCambMes1) {
		this.vrCompCambMes1 = vrCompCambMes1;
	}

	public BVFloat getVrVendCambMes1() {
		return vrVendCambMes1;
	}
	/**
	 * @return the vrVendCambMes1 wrapped
	 */
	public Double getVrVendCambMes1Wrapped() {
		 if (vrVendCambMes1 != null) {
			 try {
				 return Double.parseDouble(vrVendCambMes1.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrVendCambMes1(BVFloat vrVendCambMes1) {
		this.vrVendCambMes1 = vrVendCambMes1;
	}

	public BVFloat getVrTranCambMes1() {
		return vrTranCambMes1;
	}
	/**
	 * @return the vrTranCambMes1 wrapped
	 */
	public Double  getVrTranCambMes1Wrapped() {
		 if (vrTranCambMes1 != null) {
			 try {
				 return Double.parseDouble(vrTranCambMes1.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrTranCambMes1(BVFloat vrTranCambMes1) {
		this.vrTranCambMes1 = vrTranCambMes1;
	}

	public BVFloat getVrCompCambMes2() {
		return vrCompCambMes2;
	}
	/**
	 * @return the vrCompCambMes2 wrapped
	 */
	public Double getVrCompCambMes2Wrapped() {
		 if (vrCompCambMes2 != null) {
			 try {
				 return Double.parseDouble(vrCompCambMes2.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrCompCambMes2(BVFloat vrCompCambMes2) {
		this.vrCompCambMes2 = vrCompCambMes2;
	}

	public BVFloat getVrVendCambMes2() {
		return vrVendCambMes2;
	}
	/**
	 * @return the vrVendCambMes2 wrapped
	 */
	public Double getVrVendCambMes2Wrapped() {
		 if (vrVendCambMes2 != null) {
			 try {
				 return Double.parseDouble(vrVendCambMes2.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrVendCambMes2(BVFloat vrVendCambMes2) {
		this.vrVendCambMes2 = vrVendCambMes2;
	}

	public BVFloat getVrTranCambMes2() {
		return vrTranCambMes2;
	}
	/**
	 * @return the vrTranCambMes2 wrapped
	 */
	public Double  getVrTranCambMes2Wrapped() {
		 if (vrTranCambMes2 != null) {
			 try {
				 return Double.parseDouble(vrTranCambMes2.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrTranCambMes2(BVFloat vrTranCambMes2) {
		this.vrTranCambMes2 = vrTranCambMes2;
	}

	public BVFloat getVrCompCambMes3() {
		return vrCompCambMes3;
	}
	/**
	 * @return the vrCompCambMes3 wrapped
	 */
	public Double getVrCompCambMes3Wrapped() {
		 if (vrCompCambMes3 != null) {
			 try {
				 return Double.parseDouble(vrCompCambMes3.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrCompCambMes3(BVFloat vrCompCambMes3) {
		this.vrCompCambMes3 = vrCompCambMes3;
	}

	public BVFloat getVrVendCambMes3() {
		return vrVendCambMes3;
	}
	/**
	 * @return the vrVendCambMes3 wrapped
	 */
	public Double getVrVendCambMes3Wrapped() {
		 if (vrVendCambMes3 != null) {
			 try {
				 return Double.parseDouble(vrVendCambMes3.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrVendCambMes3(BVFloat vrVendCambMes3) {
		this.vrVendCambMes3 = vrVendCambMes3;
	}

	public BVFloat getVrTranCambMes3() {
		return vrTranCambMes3;
	}
	/**
	 * @return the vrTranCambMes3 wrapped
	 */
	public Double  getVrTranCambMes3Wrapped() {
		 if (vrTranCambMes3 != null) {
			 try {
				 return Double.parseDouble(vrTranCambMes3.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrTranCambMes3(BVFloat vrTranCambMes3) {
		this.vrTranCambMes3 = vrTranCambMes3;
	}

	public BVFloat getVrCompCambMes4() {
		return vrCompCambMes4;
	}
	/**
	 * @return the vrCompCambMes4 wrapped
	 */
	public Double getVrCompCambMes4Wrapped() {
		 if (vrCompCambMes4 != null) {
			 try {
				 return Double.parseDouble(vrCompCambMes4.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrCompCambMes4(BVFloat vrCompCambMes4) {
		this.vrCompCambMes4 = vrCompCambMes4;
	}

	public BVFloat getVrVendCambMes4() {
		return vrVendCambMes4;
	}
	/**
	 * @return the vrVendCambMes4 wrapped
	 */
	public Double getVrVendCambMes4Wrapped() {
		 if (vrVendCambMes4 != null) {
			 try {
				 return Double.parseDouble(vrVendCambMes4.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrVendCambMes4(BVFloat vrVendCambMes4) {
		this.vrVendCambMes4 = vrVendCambMes4;
	}

	public BVFloat getVrTranCambMes4() {
		return vrTranCambMes4;
	}
	/**
	 * @return the vrTranCambMes4 wrapped
	 */
	public Double  getVrTranCambMes4Wrapped() {
		 if (vrTranCambMes4 != null) {
			 try {
				 return Double.parseDouble(vrTranCambMes4.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrTranCambMes4(BVFloat vrTranCambMes4) {
		this.vrTranCambMes4 = vrTranCambMes4;
	}

	public BVFloat getVrCompCambMes5() {
		return vrCompCambMes5;
	}
	/**
	 * @return the vrCompCambMes5 wrapped
	 */
	public Double getVrCompCambMes5Wrapped() {
		 if (vrCompCambMes5 != null) {
			 try {
				 return Double.parseDouble(vrCompCambMes5.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrCompCambMes5(BVFloat vrCompCambMes5) {
		this.vrCompCambMes5 = vrCompCambMes5;
	}

	public BVFloat getVrVendCambMes5() {
		return vrVendCambMes5;
	}
	/**
	 * @return the vrVendCambMes5 wrapped
	 */
	public Double getVrVendCambMes5Wrapped() {
		 if (vrVendCambMes5 != null) {
			 try {
				 return Double.parseDouble(vrVendCambMes5.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrVendCambMes5(BVFloat vrVendCambMes5) {
		this.vrVendCambMes5 = vrVendCambMes5;
	}

	public BVFloat getVrTranCambMes5() {
		return vrTranCambMes5;
	}
	/**
	 * @return the vrTranCambMes5 wrapped
	 */
	public Double  getVrTranCambMes5Wrapped() {
		 if (vrTranCambMes5 != null) {
			 try {
				 return Double.parseDouble(vrTranCambMes5.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrTranCambMes5(BVFloat vrTranCambMes5) {
		this.vrTranCambMes5 = vrTranCambMes5;
	}

	public BVFloat getVrCompCambMes6() {
		return vrCompCambMes6;
	}
	/**
	 * @return the vrCompCambMes6 wrapped
	 */
	public Double getVrCompCambMes6Wrapped() {
		 if (vrCompCambMes6 != null) {
			 try {
				 return Double.parseDouble(vrCompCambMes6.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrCompCambMes6(BVFloat vrCompCambMes6) {
		this.vrCompCambMes6 = vrCompCambMes6;
	}

	public BVFloat getVrVendCambMes6() {
		return vrVendCambMes6;
	}
	/**
	 * @return the vrVendCambMes6 wrapped
	 */
	public Double getVrVendCambMes6Wrapped() {
		 if (vrVendCambMes6 != null) {
			 try {
				 return Double.parseDouble(vrVendCambMes6.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrVendCambMes6(BVFloat vrVendCambMes6) {
		this.vrVendCambMes6 = vrVendCambMes6;
	}

	public BVFloat getVrTranCambMes6() {
		return vrTranCambMes6;
	}
	/**
	 * @return the vrTranCambMes6 wrapped
	 */
	public Double  getVrTranCambMes6Wrapped() {
		 if (vrTranCambMes6 != null) {
			 try {
				 return Double.parseDouble(vrTranCambMes6.toString());
			 } catch (Exception e) {
				return null;
			}
		 }
		 return null;
	}
	public void setVrTranCambMes6(BVFloat vrTranCambMes6) {
		this.vrTranCambMes6 = vrTranCambMes6;
	}
	
}
