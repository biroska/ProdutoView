/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;


import java.util.List;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.PersistenceException;
import br.com.bvsistemas.framework.exception.ValidationException;


/**
 * Servi�os de manuten��o de agendamentos.
 * 
 * @author Bianca Paulino
 * @version 1.0
 * @created 27-Fev-2016
 */

@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface NaturezaJuridicaServices {
	
	/**
	 * 
	 * Lista todos as naturezas juridicas conforme filtro.
	 * 
	 * @param vo
	 *          objeto natureza juridica
	 * 
	 * @return Lista de objetos <code>NaturezaJuridicaVO</code>
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<NaturezaJuridicaVO> listar(NaturezaJuridicaVO vo) 
			throws ValidationException;

	/**
	 * 
	 * VErifica se existe registro na tabela de Natureza Juridica com a flag indicada.
	 * 
	 * @param flag
	 *          �S�, �N� e �D� 
	 * 
	 * @return boolean existe algum registro com a flag informada
	 * 
	 * @exception ValidationException
	 */
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.existePorFlag", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	boolean existePorFlag( String flag ) throws PersistenceException, ValidationException;
}