package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

public class MesVO extends AbstractValueObject<IdentifierPK> {

	/**
	 *	Serial 
	 */
	private static final long serialVersionUID = -2834451284102012574L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador da liminar
	 */
	public MesVO(final IdentifierPK pk) {
		super(pk);
	}
	

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador da liminar
	 */
	public MesVO(final IdentifierPK pk, String nomeMes ) {
		super(pk);
		this.nomeMes = nomeMes;
	}
	
	private String nomeMes;

	public String getNomeMes() {
		return nomeMes;
	}


	public void setNomeMes(String nomeMes) {
		this.nomeMes = nomeMes;
	}

}
