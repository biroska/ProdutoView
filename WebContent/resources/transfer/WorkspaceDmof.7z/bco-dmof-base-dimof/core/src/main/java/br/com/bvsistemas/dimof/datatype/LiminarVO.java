/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;

/**
 * Informa��es das liminares (medidas judiciais).
 * 
 * @author ematsuda
 * @version 1.0
 * @created 08-Oct-2008 
 */
public class LiminarVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 3840683817266544529L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador da liminar
	 */
	public LiminarVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * N�mero da liminar.
	 */
	private long nuLiminar;
	
	/**
	 * Cliente que possui a liminar.
	 */
	private PessoaVO cliente;
	
	/**
	 * N�mero da vara de tramita��o.
	 */
	private int nuVaraTramitacao;
	
	/**
	 * N�mero da se��o judici�ria.
	 */
	private int nuSecaoJudiciaria;

	/**
	 * Value Object da se��o judici�ria.
	 */
	private SecaoJudiciariaVO secaoJudiciaria;
	
	/**
	 * Nome da subse��o Judici�ria.
	 */
	private String nmSubsecaoJudiciaria;
	
	/**
	 * Data de in�cio da vig�ncia.
	 */
	private BVDate dtIniVigencia;
	
	/**
	 * Data de expedi��o.
	 */
	private BVDate dtExpedicao;
	
	/**
	 * Data fim da vig�ncia.
	 */
	private BVDate dtFimVigencia;
	
	/**
	 * Data e hora em que a data fim de vig�ncia foi informada.
	 */
	private BVDatetime dtInformeFimVigencia;
	
	/**
	 * Cassa��o retroativa?.
	 */
	private BooleanEnum flCassacaoRetroativa;
	
	/**
	 * Usu�rio que incluiu a liminar.
	 */
	private String dsLoginInclusao;
	
	/**
	 * Data/hora de inclus�o da liminar.
	 */
	private BVDatetime dtInclusao;
	
	/**
	 * Data do Processamento
	 */
	private BVDate dtProcessamento;
	
	/**
	 * @return the dtProcessamento
	 */
	public BVDate getDtProcessamento() {
		return dtProcessamento;
	}



	/**
	 * @param dtProcessamento the dtProcessamento to set
	 */
	public void setDtProcessamento(BVDate dtProcessamento) {
		this.dtProcessamento = dtProcessamento;
	}



	/**
	 * Retorna o n�mero da liminar do cliente.
	 * 
	 * @return nuLiminar
	 */
	public long getNuLiminar() {
		return nuLiminar;
	}
	
	

	/**
	 * Seta o n�mero da liminar.
	 *  
	 * @param nuLiminar Liminar a ser setada
	 */
	public void setNuLiminar(long nuLiminar) {
		this.nuLiminar = nuLiminar;
	}

	/**
	 * Retorna o cliente da liminar.
	 * 
	 * @return cliente
	 */
	public PessoaVO getCliente() {
		return cliente;
	}

	/**
	 * Seta o cliente da liminar.
	 * 
	 * @param cliente Cliente a ser setado
	 */
	public void setCliente(PessoaVO cliente) {
		this.cliente = cliente;
	}

	/**
	 * Retorna o n�mero da vara de tramita��o da liminar.
	 * 
	 * @return nuVaraTramitacao
	 */
	public int getNuVaraTramitacao() {
		return nuVaraTramitacao;
	}

	/**
	 * Seta o n�mero da vara de tramita��o da liminar.
	 * 
	 * @param nuVaraTramitacao N�mero a ser setado
	 */
	public void setNuVaraTramitacao(int nuVaraTramitacao) {
		this.nuVaraTramitacao = nuVaraTramitacao;
	}

	/**
	 * Retorna a se��o judici�ria da liminar.
	 * 
	 * @return secaoJuidicaria
	 */
	public int getNuSecaoJudiciaria() {
		return nuSecaoJudiciaria;
	}

	/**
	 * Seta a se��o judici�ria da liminar.
	 * 
	 * @param secaoJuidicaria Se��o a ser setada
	 */
	public void setNuSecaoJudiciaria(int nuSecaoJudiciaria) {
		this.nuSecaoJudiciaria = nuSecaoJudiciaria;
	}

	/**
	 * Retorna o nome da subse��o judici�ria da liminar.
	 * 
	 * @return nmSubsecaoJudiciaria
	 */
	public String getNmSubsecaoJudiciaria() {
		return nmSubsecaoJudiciaria;
	}

	/**
	 * Seta o nome da subse��o judici�ria da liminar.
	 * 
	 * @param nmSubsecaoJudiciaria Nome a ser setado
	 */
	public void setNmSubsecaoJudiciaria(String nmSubsecaoJudiciaria) {
		this.nmSubsecaoJudiciaria = nmSubsecaoJudiciaria;
	}

	/**
	 * Retorna a data de in�cio de vig�ncia da liminar.
	 * 
	 * @return dtIniVigencia
	 */
	public BVDate getDtIniVigencia() {
		return dtIniVigencia;
	}

	/**
	 * Seta a data de in�cio de vig�ncia da liminar.
	 * 
	 * @param dtIniVigencia Data a ser setada
	 */
	public void setDtIniVigencia(BVDate dtIniVigencia) {
		this.dtIniVigencia = dtIniVigencia;
	}

	/**
	 * Retorna a data fim de vig�ncia da liminar.
	 * 
	 * @return dtFimVigencia
	 */
	public BVDate getDtFimVigencia() {
		return dtFimVigencia;
	}

	/**
	 * Seta a data fim de vig�ncia da liminar.
	 * 
	 * @param dtFimVigencia Data a ser setada
	 */
	public void setDtFimVigencia(BVDate dtFimVigencia) {
		this.dtFimVigencia = dtFimVigencia;
	}

	/**
	 * Retorna a data em que a data fim de vig�ncia foi informada.
	 * 
	 * @return dtInformeFimVigencia
	 */
	public BVDatetime getDtInformeFimVigencia() {
		return dtInformeFimVigencia;
	}

	/**
	 * Seta a data em que a data fim de vig�ncia foi informada.
	 * 
	 * @param dtInformeFimVigencia Data a ser setada
	 */
	public void setDtInformeFimVigencia(BVDatetime dtInformeFimVigencia) {
		this.dtInformeFimVigencia = dtInformeFimVigencia;
	}

	/**
	 * Retorna o usu�rio que inseriu a liminar.
	 * 
	 * @return dsLoginInclusao
	 */
	public String getDsLoginInclusao() {
		return dsLoginInclusao;
	}

	/**
	 * Seta o usu�rio que inserir a liminar.
	 * 
	 * @param dsLoginInclusao Usu�rio a ser setado
	 */
	public void setDsLoginInclusao(String dsLoginInclusao) {
		this.dsLoginInclusao = dsLoginInclusao;
	}

	/**
	 * Retorna a data de inclus�o da liminar.
	 * 
	 * @return dtInclusao
	 */
	public BVDatetime getDtInclusao() {
		return dtInclusao;
	}

	/**
	 * Seta a data de inclus�o da liminar.
	 * 
	 * @param dtInclusao Data a ser setada
	 */
	public void setDtInclusao(BVDatetime dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	/**
	 * Retorna a data de expedi��o.
	 * 
	 * @return the dtExpedicao
	 */
	public BVDate getDtExpedicao() {
		return dtExpedicao;
	}

	/**
	 * Seta a data de expedi��o.
	 * 
	 * @param dtExpedicao Data a ser setada
	 */
	public void setDtExpedicao(BVDate dtExpedicao) {
		this.dtExpedicao = dtExpedicao;
	}

	/**
	 * Retorna se a cassa��o � retroativa.
	 * 
	 * @return flCassacaoRetroativa
	 */
	public BooleanEnum getFlCassacaoRetroativa() {
		return flCassacaoRetroativa;
	}

	/**
	 * Seta o indicador de cassa��o retroativa.
	 * 
	 * @param flCassacaoRetroativa Flag a ser setada
	 */
	public void setFlCassacaoRetroativa(BooleanEnum flCassacaoRetroativa) {
		this.flCassacaoRetroativa = flCassacaoRetroativa;
	}

	/**
	 * @return the secaoJudiciaria
	 */
	public SecaoJudiciariaVO getSecaoJudiciaria() {
		return secaoJudiciaria;
	}

	/**
	 * @param secaoJudiciaria the secaoJudiciaria to set
	 */
	public void setSecaoJudiciaria(SecaoJudiciariaVO secaoJudiciaria) {
		this.secaoJudiciaria = secaoJudiciaria;
	}

}
