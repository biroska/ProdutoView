/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import java.util.List;

import javax.xml.bind.ValidationException;

import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;

/**
 * Servi�os de manuten��o de cadastro de parametriza��ess.
 * 
 * @author rtomiayam
 * @version 1.0
 * @created 03-Mar-2016
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface ParametrizacaoNaturezaJuridicaServices {

	
	/**
	 * 
	 * Lista todos os agendamentos conforme filtro.
	 * 
	 * @param cdNaturezaJuridica
	 *            C�digo da Natureza Juridica
	 * 
	 * @return O nome da Natureza Juridica
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.getNomeNaturezaJuridica", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract String getNomeNaturezaJuridica(String cdNaturezaJuridica) 
			throws ValidationException, CamposObrigatoriosNaoPreenchidosException;
	
	/**
	 * 
	 * Lista todos os agendamentos conforme filtro.
	 * 
	 * @param cdNaturezaJuridica
	 *            C�digo da Natureza Juridica
	 * 
	 * @return Lista de objetos <code>ParametrizacaoNaturezaJuridicaVO</code>
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.listarParametrizacoes", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<ParametrizacaoNaturezaJuridicaVO> listarParametrizacoes(String cdNaturezaJuridica ) 
			throws ValidationException, CamposObrigatoriosNaoPreenchidosException;

	
	/**
	 * 
	 * Incluir parametrizacao.
	 * 
	 * @param parametrizacao
	 *            Parametrizacao a ser salva
	 * 
	 * @return Inclui nova parametrizacao <code>ParametrizacaoNaturezaJuridicaVO</code>
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.incluirParametrizacao", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract int incluirParametrizacao(ParametrizacaoNaturezaJuridicaVO parametrizacao) 
			throws ValidationException, CamposObrigatoriosNaoPreenchidosException;

	
	/**
	 * 
	 * Atualizar parametrizacao.
	 * 
	 * @param parametrizacao
	 *            Parametrizacao a ser salva
	 * 
	 * @return Atualiza dados de uma parametrizacao <code>ParametrizacaoNaturezaJuridicaVO</code>
	 * 
	 * @exception ValidationException
	 * @exception CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.NaturezaJuridica.atualizarParametrizacao", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract int atualizarParametrizacao(ParametrizacaoNaturezaJuridicaVO parametrizacao) 
			throws ValidationException, CamposObrigatoriosNaoPreenchidosException;

}
