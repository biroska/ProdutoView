package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

public class ParametrizacaoNaturezaJuridicaVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7006273155323059224L;

	
    /** Identificador da Natureza Juridica  */
    private String cdNaturezaJuridica;
    
    /** Nome da Natureza Juridica */
    private String nmNaturezaJuridica;	
	
    /** Flag envia infirmacao eFinanceira */
    private String flEnviaInformacaoEFinanceira;
    
    private BVDate dtInicioVigencia;
    
    private BVDate dtFimVigencia;
    
    private String dsLogin;
    
    private String flAtivo;

    private BVDatetime dtInclusao;
    
    private BVDatetime dtAlteracao;

	/**
	 * Usu�rio que incluiu a parametriza��o.
	 */
	private String dsLoginInclusao;
	    
    
    
    
    //private BVDate dtInicioVigenciaAnterior;
    
    private String txtInicioVigencia;
    private String txtFimVigencia;

    /**
     * Construtor da Classe
     * @param pk Identificador do log
     */
    public ParametrizacaoNaturezaJuridicaVO(IdentifierPK pk) {
    	super(pk);
    	
    }     
      
    
	public String getCdNaturezaJuridica() {
		return cdNaturezaJuridica;
	}

	public void setCdNaturezaJuridica(String cdNaturezaJuridica) {
		this.cdNaturezaJuridica = cdNaturezaJuridica;
	}

	public String getNmNaturezaJuridica() {
		return nmNaturezaJuridica;
	}

	public void setNmNaturezaJuridica(String nmNaturezaJuridica) {
		this.nmNaturezaJuridica = nmNaturezaJuridica;
	}

	public String getFlEnviaInformacaoEFinanceira() {
		return flEnviaInformacaoEFinanceira;
	}

	public void setFlEnviaInformacaoEFinanceira(String flEnviaInformacaoEFinanceira) {
		this.flEnviaInformacaoEFinanceira = flEnviaInformacaoEFinanceira;
	}

	public BVDate getDtInicioVigencia() {
		return dtInicioVigencia;
	}

	public void setDtInicioVigencia(BVDate dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}

	public BVDate getDtFimVigencia() {
		return dtFimVigencia;
	}

	public void setDtFimVigencia(BVDate dtFimVigencia) {
		this.dtFimVigencia = dtFimVigencia;
	}

	public String getTxtInicioVigencia() {
		return txtInicioVigencia;
	}

	public void setTxtInicioVigencia(String txtInicioVigencia) {
		this.txtInicioVigencia = txtInicioVigencia;
	}

	public String getTxtFimVigencia() {
		return txtFimVigencia;
	}

	public void setTxtFimVigencia(String txtFimVigencia) {
		this.txtFimVigencia = txtFimVigencia;
	}

	public String getDsLogin() {
		return dsLogin;
	}

	public void setDsLogin(String dsLogin) {
		this.dsLogin = dsLogin;
	}

	public String getFlAtivo() {
		return flAtivo;
	}

	public void setFlAtivo(String flAtivo) {
		this.flAtivo = flAtivo;
	}

	public BVDatetime getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(BVDatetime dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public BVDatetime getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(BVDatetime dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	
	
	public String getDsLoginInclusao() {
		return dsLoginInclusao;
	}


	public void setDsLoginInclusao(String dsLoginInclusao) {
		this.dsLoginInclusao = dsLoginInclusao;
	}


//	public BVDate getDtInicioVigenciaAnterior() {
//		return dtInicioVigenciaAnterior;
//	}
//
//	public void setDtInicioVigenciaAnterior(BVDate dtInicioVigenciaAnterior) {
//		this.dtInicioVigenciaAnterior = dtInicioVigenciaAnterior;
//	}

	
    
}
