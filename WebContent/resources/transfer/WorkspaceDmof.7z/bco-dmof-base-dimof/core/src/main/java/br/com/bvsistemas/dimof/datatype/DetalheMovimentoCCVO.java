/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.bvsistemas.dimof.util.DimofUtils;
import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Value Object com detalhe de movimenta��es de d�bito e cr�dito 
 * em conta corrente. 
 * 
 * @author elias.yoshida
 * @created 18-07-2012 
 */
public class DetalheMovimentoCCVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public DetalheMovimentoCCVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Data do movimento da operacao de conta corrente
	 */
	private Date dtMovimento;
	
	/**
	 * Valor da operacao de conta corrente
	 */
	private BigDecimal vrOperacao;
	
	/**
	 * Tipo de operacao de conta corrente: debito ou credito
	 */
	private String tpDebitoCredito;

	/**
	 * Cpf / Cnpj da pessoa debitada
	 */
	private String nuCpfCnpjDebitado;

	/**
	 * Cpf / Cnpj da pessoa creditada
	 */
	private String nuCpfCnpjCreditado;

	/**
	 * Numero da Conta Corrente
	 */
	private String nuContaCorrente;
	
	public Date getDtMovimento() {
		return dtMovimento;
	}
	
	/**
	 * Retorna a data no formato dd/mm/aaaa
	 */
	public String getDtMovimentoFormatado() {
		if(dtMovimento != null){
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			return df.format(dtMovimento);
		}
		return "";
	}

	public void setDtMovimento(Date dtMovimento) {
		this.dtMovimento = dtMovimento;
	}

	public BigDecimal getVrOperacao() {
		return vrOperacao;
	}

	public void setVrOperacao(BigDecimal vrOperacao) {
		this.vrOperacao = vrOperacao;
	}

	public String getTpDebitoCredito() {
		return tpDebitoCredito;
	}

	public void setTpDebitoCredito(String tpDebitoCredito) {
		this.tpDebitoCredito = tpDebitoCredito;
	}

	public String getNuCpfCnpjDebitadoFormatado() {
		if(nuCpfCnpjDebitado != null)
			return DimofUtils.formatarCpfCnpj(nuCpfCnpjDebitado);
		return nuCpfCnpjDebitado;
	}

	public void setNuCpfCnpjDebitado(String nuCpfCnpjDebitado) {
		this.nuCpfCnpjDebitado = nuCpfCnpjDebitado;
	}

	public String getNuCpfCnpjCreditadoFormatado() {
		if(nuCpfCnpjCreditado != null)
			return DimofUtils.formatarCpfCnpj(nuCpfCnpjCreditado);
		return nuCpfCnpjCreditado;
	}

	public void setNuCpfCnpjCreditado(String nuCpfCnpjCreditado) {
		this.nuCpfCnpjCreditado = nuCpfCnpjCreditado;
	}

	/**
	 * @return the nuContaCorrente
	 */
	public String getNuContaCorrente() {
		return nuContaCorrente;
	}

	/**
	 * @param nuContaCorrente the nuContaCorrente to set
	 */
	public void setNuContaCorrente(String nuContaCorrente) {
		this.nuContaCorrente = nuContaCorrente;
	}
	
}
