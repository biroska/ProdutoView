/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.MaskFormatter;

import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Classe util para formata��es de valores
 *
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com.br">Edilson Almeida</a>
 *
 * @created 06/09/2012
 * 
 */
public final class DimofUtils {
	
	/**
	 * Componente de logging.
	 */
	private static final BVLogger logger = BVLogger.getLogger(DimofUtils.class);
	
	/**
	 * M�todo respons�vel por formatar um conjunto de caracteres num�ricos no padrao de CPNJ ##.###.###/####-##
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param value o conjunto de caracteres a ser formatado
	 * 
	 * @return o valor recebido como parametro no formato esperado ou o valor recebido se houver erro na formata��o
	 */
	private static String formataCnpj(String value) {
		
		try {			
			while(value.length() < 14){
				value = "0" + value;
			}						
			MaskFormatter mascaraCnpj = new MaskFormatter("##.###.###/####-##") ;
			mascaraCnpj.setValueContainsLiteralCharacters(false);  
			return mascaraCnpj.valueToString(value);
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		return value;
	}
	
	/**
	 * M�todo respons�vel por formatar um conjunto de caracteres num�ricos no padrao de CPF ###.###.###-##
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param value o conjunto de caracteres a ser formatado
	 * 
	 * @return o valor recebido como parametro no formato esperado ou o valor recebido se houver erro na formata��o
	 */
	private static String formataCpf(String value){
		try {
			
			while(value.length() < 11){
				value = "0" + value;
			}
			
			MaskFormatter mascaraCpf = new MaskFormatter("###.###.###-##");
			mascaraCpf.setValueContainsLiteralCharacters(false);  
			return mascaraCpf.valueToString(value);
			
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		
		return value;
	}
	
	
	/**
	 * M�todo respons�vel por receber um conjunto de caracteres numericos, validar se contem um formato que coincida com 
	 * um CNPJ ou CPF e retornar a valida��o devida
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param value o conjunto de caracteres a ser formatado
	 * 
	 * @return o valor recebido como parametro no formato esperado ou o valor recebido se houver erro na formata��o
	 */
	public static String formatarCpfCnpj(String value){
		
		if(value == null || !StringUtils.isNumeric(value.trim())){
			logger.workflow.error(" Valor Informado para formata��o � inv�lido  "+value);
			return value;
		}
		
		//Pattern que verifica se o mumeral passado termina com o formato '/0000-00'
		Pattern p = Pattern.compile(".*(0001\\d{2}$)");
		Matcher match = p.matcher(value);
		
		if(match.matches()){
			return formataCnpj(value);
		}else{
			return formataCpf(value);
		}		
	}
	
	
	
	/**
	 * M�todo respons�vel por formatar uma data v�lida recebida no formato String ou um Calendar
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param data um Calendar da data a ser formatada
	 * 
	 * @param dataStr Uma String representando a Data
	 * 
	 * @param formato o formato a ser considerado
	 * 
	 * @return Uma String no formato definido ou o valor enviado se houver erro;
	 */
	public static String formataData(Calendar data, String dataStr, String formato){
		
		DateFormat df ;
		try{
			df = new SimpleDateFormat(formato);
		if(dataStr == null || dataStr.trim().equals("")){
			if(data == null){
				logger.workflow.error("Nenhuma data foi informada!");
				return dataStr;
			}else{
				return df.format(data);						
			}
		}
		
		Date saida =df.parse(dataStr); 
		return df.format(saida);
		
		}catch(IllegalArgumentException iae){
			logger.workflow.error("Format informado � inv�lido: '"+formato+"'");
			iae.printStackTrace();
		} catch (ParseException e) {
			logger.workflow.error("Erro ao formatar a Data "+e);
			e.printStackTrace();
		}
		return dataStr;		 
		
	}
}