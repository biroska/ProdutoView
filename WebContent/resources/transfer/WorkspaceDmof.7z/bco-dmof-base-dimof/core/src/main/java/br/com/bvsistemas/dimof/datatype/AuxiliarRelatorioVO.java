/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.datatype;

import br.com.bvsistemas.framework.datatype.AbstractValueObject;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;

/**
 * <code>ValueObject</code> que representa a entidade AuxiliarRelatorio. 
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 */
public class AuxiliarRelatorioVO extends AbstractValueObject<IdentifierPK> {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Construtor da classe.
	 * 
	 * @param pk Identificador do log
	 */
	public AuxiliarRelatorioVO(final IdentifierPK pk) {
		super(pk);
	}

	/**
	 * Ano do relat�rio.
	 */
	private int ano;
	
	/**
	 * N�mero do semestre.
	 */
	private int nuSemestre;

	/**
	 * Flag que indica se a declara��o � retificadora.
	 */
	private BooleanEnum flRetificadora;

	/**
	 * C�digo do status de processamento.
	 */
	private int tpProcessado;

	/**
	 * @return the ano
	 */
	public int getAno() {
		return ano;
	}

	/**
	 * @param ano the ano to set
	 */
	public void setAno(int ano) {
		this.ano = ano;
	}

	/**
	 * @return the nuSemestre
	 */
	public int getNuSemestre() {
		return nuSemestre;
	}

	/**
	 * @param nuSemestre the nuSemestre to set
	 */
	public void setNuSemestre(int nuSemestre) {
		this.nuSemestre = nuSemestre;
	}

	/**
	 * @return the flRetificadora
	 */
	public BooleanEnum getFlRetificadora() {
		return flRetificadora;
	}

	/**
	 * @param flRetificadora the flRetificadora to set
	 */
	public void setFlRetificadora(BooleanEnum flRetificadora) {
		this.flRetificadora = flRetificadora;
	}

	/**
	 * @return the tpProcessado
	 */
	public int getTpProcessado() {
		return tpProcessado;
	}

	/**
	 * @param tpProcessado the tpProcessado to set
	 */
	public void setTpProcessado(int tpProcessado) {
		this.tpProcessado = tpProcessado;
	}
}
