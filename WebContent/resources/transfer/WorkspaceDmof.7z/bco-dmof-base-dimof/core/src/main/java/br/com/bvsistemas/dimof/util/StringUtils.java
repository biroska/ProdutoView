package br.com.bvsistemas.dimof.util;
/**
 * Classe respons�vel por centralizar os m�todos de manipula��o de string. 
 * 
 * @author cit.sxavier
 *
 */
public class StringUtils {

	/**
	 * Retira os acentos das palavras.
	 * 
	 * @param input -
	 *            String de entrada com acentos
	 * @return String - Saida sem acentos
	 */
	public final static String removeAccents(String input) {
		final StringBuffer output = new StringBuffer();
		for (int i = 0; i < input.length(); i++) {
			switch (input.charAt(i)) {
			case '\u00C0': // �
			case '\u00C1': // �
			case '\u00C2': // �
			case '\u00C3': // �
			case '\u00C4': // �
			case '\u00C5': // �
				output.append("A");
				break;
			case '\u00C6': // �
				output.append("AE");
				break;
			case '\u00C7': // �
				output.append("C");
				break;
			case '\u00C8': // �
			case '\u00C9': // �
			case '\u00CA': // �
			case '\u00CB': // �
				output.append("E");
				break;
			case '\u00CC': // �
			case '\u00CD': // �
			case '\u00CE': // �
			case '\u00CF': // �
				output.append("I");
				break;
			case '\u00D0': // �
				output.append("D");
				break;
			case '\u00D1': // �
				output.append("N");
				break;
			case '\u00D2': // �
			case '\u00D3': // �
			case '\u00D4': // �
			case '\u00D5': // �
			case '\u00D6': // �
			case '\u00D8': // �
				output.append("O");
				break;
			case '\u0152': // �
				output.append("OE");
				break;
			case '\u00DE': // �
				output.append("TH");
				break;
			case '\u00D9': // �
			case '\u00DA': // �
			case '\u00DB': // �
			case '\u00DC': // �
				output.append("U");
				break;
			case '\u00DD': // �
			case '\u0178': // �
				output.append("Y");
				break;
			case '\u00E0': // �
			case '\u00E1': // �
			case '\u00E2': // �
			case '\u00E3': // �
			case '\u00E4': // �
			case '\u00E5': // �
				output.append("a");
				break;
			case '\u00E6': // �
				output.append("ae");
				break;
			case '\u00E7': // �
				output.append("c");
				break;
			case '\u00E8': // �
			case '\u00E9': // �
			case '\u00EA': // �
			case '\u00EB': // �
				output.append("e");
				break;
			case '\u00EC': // �
			case '\u00ED': // �
			case '\u00EE': // �
			case '\u00EF': // �
				output.append("i");
				break;
			case '\u00F0': // �
				output.append("d");
				break;
			case '\u00F1': // �
				output.append("n");
				break;
			case '\u00F2': // �
			case '\u00F3': // �
			case '\u00F4': // �
			case '\u00F5': // �
			case '\u00F6': // �
			case '\u00F8': // �
				output.append("o");
				break;
			case '\u0153': // �
				output.append("oe");
				break;
			case '\u00DF': // �
				output.append("ss");
				break;
			case '\u00FE': // �
				output.append("th");
				break;
			case '\u00F9': // �
			case '\u00FA': // �
			case '\u00FB': // �
			case '\u00FC': // �
				output.append("u");
				break;
			case '\u00FD': // �
			case '\u00FF': // �
				output.append("y");
				break;
			default:
				output.append(input.charAt(i));
				break;
			}
		}
		return output.toString();
	}
}
