/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.services;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.OrigemTransacaoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.services.ESBCatalogAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBServiceAnnotation;
import br.com.bvsistemas.framework.esb.services.ESBTransactionTypeEnum;
import br.com.bvsistemas.framework.exception.ValidationException;

/**
 * Servi�os de Movimenta��es
 * 
 * @author ematsuda
 * @version 1.0
 * @created 09-Oct-2008
 */
@ESBCatalogAnnotation(name = "BV-DIMOF")
public interface TransacaoEstornoServices {

	/**
	 * 
	 * Metodo Respons�vel por listar as Transacoes de Estorno de acordo com os par�metros informados
	 * 
	 * @author talent.ealmeida
	 * 
	 * @return Uma lista de Transa��es de Estorno
	 * 
	 * @exception ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.listar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public abstract List<TransacaoEstornoVO> listar(Integer cdOrigem, Integer cdTransacao, 
		String raizCnpj) throws ValidationException, CamposObrigatoriosNaoPreenchidosException;
	
	
	/**
	 * M�todo Respons�vel por resgatar a Lista de Origens cadastradas
	 *  
	 * @author talent.ealmeida
	 * 
	 * @return A lista de Orgens cadastradas
	 * 
	 * @throws ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException
	 */	
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.listarOrigem", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<OrigemTransacaoVO> listarOrigem()throws ValidationException, CamposObrigatoriosNaoPreenchidosException;
	    

	
	/**
	 * M�todo Respons�vel por resgatar a lista de Transa��es cadastradas
	 * 
	 * @author talent.ealmeida
	 * 
	 * @return A Lista de Transa��es cadastradas
	 * 
	 * @throws ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException 
	 */
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.listarTransacao", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public List<TransacaoVO> listarTransacao()throws ValidationException, CamposObrigatoriosNaoPreenchidosException;

	

	/**
	 * M�todo Respons�vel por Inserir uma nova Transa��o de Estorno
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param transacaoEstornoVO O VO a ser persistido
	 * 
	 * @return IdentifierPK o ID do registro inclu�do
	 * 
	 * @throws ValidationException
	 * 
	 * @throws CamposObrigatoriosNaoPreenchidosException
	 */	
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.inserir", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public IdentifierPK inserir(TransacaoEstornoVO transacaoEstornoVO) throws ValidationException, CamposObrigatoriosNaoPreenchidosException;

	/**
	 * M�todo respons�vel por alterar um registro de Transa��o de Estorno
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param transacaoEstornoVO o VO do registro a ser Alterado
	 * 
	 * @return int, a quantidade de registros afetados 
	 * 
	 * @throws ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException 
	 */
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.alterar", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public int alterar(TransacaoEstornoVO transacaoEstornoVO)throws ValidationException, CamposObrigatoriosNaoPreenchidosException;

	
	/**
	 * M�todo Respons�vel por retornar o nome da Origem de acordo com o identificador informado
	 * 
	 * @author talent.ealmeida
	 * 
	 * @param cdOrigem O identificador da Origem a qual se quer saber o nome
	 * 
	 * @return O nome da Origem
	 * 
	 * @throws ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.getNomeOrigem", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public String getNomeOrigem(Integer cdOrigem)throws ValidationException, CamposObrigatoriosNaoPreenchidosException;
	
	
	/**
	 * M�todo Respons�vel por retornar o nome da Transa��o de acordo com o identificador informado
	 *  
	 * @author talent.ealmeida
	 * 
	 * @param cdTransacao O identofocador da transa��o que deve retornar o nome
	 * 
	 * @return O nome da Transa��o
	 * 
	 * @throws ValidationException
	 * 
	 * @{@link Exception} CamposObrigatoriosNaoPreenchidosException
	 */
	@ESBServiceAnnotation(name = "Dimof.TransacaoEstorno.getNomeTransacao", transactionType = ESBTransactionTypeEnum.SUPPORTS)
	public String getNomeTransacao(Integer cdTransacao)throws ValidationException, CamposObrigatoriosNaoPreenchidosException;
	
}
