var Mask = new Object();

// Defini��o de m�scaras para inputs
Mask.intMask = "\\d";
Mask.intMask2 = "\\d-";
Mask.decimalMask = "\\d,";
Mask.cepMask = new Array( "\\d-", "#####-###" );
Mask.dataMask = new Array( "\\d/", "##/##/####" );
Mask.timeMask = new Array( "\\d/", "##:##" );
Mask.cpfMask = new Array( "\\d.-", "###.###.###-##" );
Mask.phoneMask = new Array( "\\d()-", "(##) ####-####" );
Mask.cnpjMask = new Array( "\\d./-", "##.###.###/####-##" );
Mask.cdNaturezaJuridica = new Array( "\\d-", "###-#" );
Mask.anoMask = new Array( "\\d", "####" );

addEvent = function(o, e, f, s) {
    var r = o[r = "_" + (e = "on" + e)] = o[r] || (o[e] ? [[o[e], o]] : []), a, c, d;
    r[r.length] = [f, s || o], o[e] = function(e){
        try{
            (e = e || event).preventDefault || (e.preventDefault = function(){e.returnValue = false;});
            e.stopPropagation || (e.stopPropagation = function(){e.cancelBubble = true;});
            e.target || (e.target = e.srcElement || null);
            e.key = (e.which + 1 || e.keyCode + 1) - 1 || 0;
        }catch(f){}
        for (d = 1, f = r.length; f; r[--f] && (a = r[f][0], o = r[f][1], a.call ? c = a.call(o, e) : (o._ = a, c = o._(e), o._ = null), d &= c !== false));
        return e = null, !!d;
    }
};

removeEvent = function(o, e, f, s) {
    for (var i = (e = o["_on" + e] || []).length; i;)
        if(e[--i] && e[i][0] == f && (s || o) == e[i][1])
            return delete e[i];
    return false;
};


Restrict = function(form){
    this.form = form, this.field = {}, this.mask = {};
}

Restrict.field = Restrict.inst = Restrict.c = null;

Restrict.prototype.start = function(){
    var $, __ = document.forms[this.form], s, x, j, c, sp, o = this, l;
    var p = {".":/./, w:/\w/, W:/\W/, d:/\d/, D:/\D/, s:/\s/, a:/[\xc0-\xff]/, A:/[^\xc0-\xff]/};
    for(var _ in $ = this.field)
        if(/text|textarea|password/i.test(__[_].type)){
            x = $[_].split(""), c = j = 0, sp, s = [[],[]];
            for(var i = 0, l = x.length; i < l; i++)
                if(x[i] == "\\" || sp){
                    if(sp = !sp) continue;
                    s[j][c++] = p[x[i]] || x[i];
                }
                else if(x[i] == "^") c = (j = 1) - 1;
                else s[j][c++] = x[i];
            o.mask[__[_].name] && (__[_].maxLength = o.mask[__[_].name].length);
            __[_].pt = s, addEvent(__[_], "keydown", function(e){
                var r = Restrict.field = e.target;
                if(!o.mask[r.name]) return;
                r.l = r.value.length, Restrict.inst = o; Restrict.c = e.key;
                setTimeout(o.onchanged, r.e = 1);
            });
            addEvent(__[_], "keyup", function(e){
                (Restrict.field = e.target).e = 0;
            });
            addEvent(__[_], "keypress", function(e){
                o.restrict(e) || e.preventDefault();
                var r = Restrict.field = e.target;
                if(!o.mask[r.name]) return;
                if(!r.e){
                    r.l = r.value.length, Restrict.inst = o, Restrict.c = e.key || 0;
                    setTimeout(o.onchanged, 1);
                }
            });
        }
}

Restrict.prototype.restrict = function(e){
    var o, c = e.key, n = (o = e.target).name, r;
    var has = function(c, r){
        for(var i = r.length; i--;)
            if((r[i] instanceof RegExp && r[i].test(c)) || r[i] == c) return true;
        return false;
    }
    var inRange = function(c){
        return has(c, o.pt[0]) && !has(c, o.pt[1]);
    }
    return (c < 30 || inRange(String.fromCharCode(c))) ?
        (this.onKeyAccept && this.onKeyAccept(o, c), !0) :
        (this.onKeyRefuse && this.onKeyRefuse(o, c),  !1);
}

Restrict.prototype.onchanged = function(){
    var ob = Restrict, si, moz = false, o = ob.field, t, lt = (t = o.value).length, m = ob.inst.mask[o.name];
    if(o.l == o.value.length) return;
    if(si = o.selectionStart) moz = true;
    else if(o.createTextRange){
        var obj = document.selection.createRange(), r = o.createTextRange();
        if(!r.setEndPoint) return false;
        r.setEndPoint("EndToStart", obj); si = r.text.length;
    }
    else return false;
    for(var i in m = m.split(""))
        if(m[i] != "#")
            t = t.replace(m[i] == "\\" ? m[++i] : m[i], "");
    var j = 0, h = "", l = m.length, ini = si == 1, t = t.split("");
    for(i = 0; i < l; i++)
        if(m[i] != "#"){
            if(m[i] == "\\" && (h += m[++i])) continue;
            h += m[i], i + 1 == l && (t[j - 1] += h, h = "");
        }
        else{
            if(!t[j] && !(h = "")) break;
            (t[j] = h + t[j++]) && (h = "");
        }
    o.value = o.maxLength > -1 && o.maxLength < (t = t.join("")).length ? t.slice(0, o.maxLength) : t;
    if(ob.c && ob.c != 46 && ob.c != 8){
        if(si != lt){
            while(m[si] != "#" && m[si]) si++;
            ini && m[0] != "#" && si++;
        }
        else si = o.value.length;
    }
    !moz ? (obj.move("character", si), obj.select()) : o.setSelectionRange(si, si);
}


Mascaras = {
    IsIE: navigator.appName.toLowerCase().indexOf('microsoft') != -1,
    AZ: /[A-Z]/i,
    Acentos: /[�-�]/i,
    Num: /[0-9]/,
    

    carregar: function(parte){
        var Tags = ['input','textarea'];
        if (typeof parte == "undefined")
            parte = document;
        for(var z=0; z<Tags.length; z++){
            Inputs = parte.getElementsByTagName(Tags[z]);
            for(var i=0; i<Inputs.length; i++)
                if(('button,image,hidden,submit,reset').indexOf(Inputs[i].type.toLowerCase()) == -1)
            this.aplicar(Inputs[i]);
        }
    },

    aplicar: function(campo){
        tipo = campo.getAttribute('tipo');
        if (!tipo || campo.type == "select-one") return;
        orientacao = campo.getAttribute('orientacao');
        mascara    = campo.getAttribute('mascara');
        if (tipo.toLowerCase() == "decimal"){
            orientacao    = "esquerda";
            casasdecimais = campo.getAttribute('casasdecimais');
            tamanho       = campo.getAttribute('maxLength');
            if (!tamanho || tamanho > 50)
                tamanho = 10;
            if (!casasdecimais)
                casasdecimais = 2;
            campo.setAttribute("mascara", this.geraMascaraDecimal(tamanho, casasdecimais));
            campo.setAttribute("tipo", "numerico");
            campo.setAttribute("orientacao", orientacao);
        }
        if (orientacao && orientacao.toLowerCase() == "esquerda") campo.style.textAlign = "right";
        if (mascara) campo.setAttribute("maxLength", mascara.length);
        if (tipo){
            campo.onkeypress = function(e){ return Mascaras.onkeypress(e?e:event); };
            campo.onkeyup    = function(e){ Mascaras.onkeyup(e?e:event, campo) };
        }
        campo.setAttribute("snegativo", ((campo.value).substr(0,1) == "-" ? "s" : "n"));
    },

    onkeypress: function(e){
        KeyCode  = this.IsIE ? event.keyCode : e.which;
        campo    =  this.IsIE ? event.srcElement : e.target;
        readonly = campo.getAttribute('readonly');
        if (readonly) return;
        maxlength = campo.getAttribute('maxlength');
        pt        = campo.getAttribute('pt');
        selecao   = this.selecao(campo);
        if (selecao.length > 0 && KeyCode != 0){
            campo.value = ""; return true;
        }
        if (KeyCode == 0) return true;
        Char    = String.fromCharCode(KeyCode);
        valor   = campo.value;
        mascara = campo.getAttribute('mascara');
        if (KeyCode != 8){
            tipo     = campo.getAttribute('tipo').toLowerCase();
            negativo = campo.getAttribute('negativo');
            if(negativo && KeyCode == 45){
                snegativo = campo.getAttribute('snegativo');
                snegativo = (snegativo == "s" ? "n" : "s");
                campo.setAttribute("snegativo", snegativo);
            }else{
                valor += Char
                if (tipo == "numerico" && Char.search(this.Num) == -1) return false;
                if (KeyCode != 32 && tipo == "caracter" && Char.search(this.AZ) == -1 && Char.search(this.Acentos) == -1) return false;
            }
        }
        if (mascara){
            this.aplicarMascara(campo, valor);
            return false;
        }
        this.clear(campo, valor, '(');
        try{ calcular(); } catch (e){}
        return true;
    },

    onkeyup: function(e, campo){
        KeyCode = this.IsIE ? event.keyCode : e.which;
        if (KeyCode != 9 && KeyCode != 16 && KeyCode != 109){
            valor = campo.value;
            if (KeyCode == 8 && !this.IsIE) valor = valor.substr(0,valor.length-1);
            this.aplicarMascara(campo, valor);
        }
        this.clear(campo, valor, '(');
        try{ calcular(); } catch (e){}
    },

    aplicarMascara: function(campo, valor){
        mascara = campo.getAttribute('mascara');
        if (!mascara) return;
        negativo = campo.getAttribute('negativo');
        snegativo = campo.getAttribute('snegativo');
        if (negativo && valor.substr(0,1) == "-")
            valor = valor.substr(1,valor.length-1);
        orientacao = campo.getAttribute('orientacao');
        var i = 0;
        for(i=0;i<mascara.length;i++){
            caracter = mascara.substr(i,1);
            if (caracter != "#") valor = valor.replace(caracter, "");
        }
        retorno = "";
        if (orientacao != "esquerda"){
            contador = 0;
            for(i=0;i<mascara.length;i++){
                caracter = mascara.substr(i,1);
                if (caracter == "#"){
                    retorno += valor.substr(contador,1);
                    contador++;
                }else
                    retorno += caracter;
                if(contador >= valor.length) break;
            }
        }else{
            contador = valor.length-1;
            for(i=mascara.length-1;i>=0;i--){
                if(contador < 0) break;
                caracter = mascara.substr(i,1);
                if (caracter == "#"){
                    retorno = valor.substr(contador,1) + retorno;
                    contador--;
                }else
                    retorno = caracter + retorno;
            }
        }
        //if (negativo && snegativo == "s")
            //retorno = "-" + retorno;
        campo.value = retorno;
    },

    geraMascaraDecimal: function(tam, decimais){
        var retorno = "", contador = 0, i = 0;
        decimais    = parseInt(decimais);
        for (i=0;i<(tam-(decimais+1));i++){
            retorno = "#" + retorno;
            contador++;
            if (contador == 3){
                retorno  = "." + retorno;
                contador = 0;
            }
        }
        retorno = retorno + ",";
        for (i=0;i<decimais;i++)
            retorno += "#";
        return retorno;
    },

    selecao: function(campo){
        if (this.IsIE)
            return document.selection.createRange().text;
        else
            return (campo.value).substr(campo.selectionStart, (campo.selectionEnd - campo.selectionStart));
    },

    formataValor: function(valor, decimais){
        valor = valor.split('.');
        if (valor.length == 1)
            valor[1] = "";
        for(var i=valor[1].length;i<decimais;i++)
            valor[1] += "0";
        valor[1] = valor[1].substr(0,2);
        return (valor[0] + "." + valor[1]);
    },

    clear: function(campo, valor, caracter){
        if ((valor == caracter) && (valor.length == 1))
            campo.value = "";
    }
};
