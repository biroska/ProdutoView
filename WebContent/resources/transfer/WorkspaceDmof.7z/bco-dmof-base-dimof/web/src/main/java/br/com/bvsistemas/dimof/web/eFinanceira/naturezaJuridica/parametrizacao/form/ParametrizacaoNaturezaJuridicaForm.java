/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.parametrizacao.form;

import java.util.ArrayList;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.MesVO;
import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;


/**
 * <code>ActionForm</code> respons�vel por armazenar as informa��es do 
 * form de consulta de parametrizacoes 
 * (RQT006	Altera��o de par�metros de natureza jur�dica
 * Origem	RF006 - Altera��o de par�metros de Natureza Jur�dica).
 * 
 * @author <a href="mailto:resource.rtomiyama@bancovotorantim.com.br">Ricardo Takehi</a>
 * 
 * @struts.form name="parametrizacaoNaturezaJuridicaForm"
 * 
 */
public class ParametrizacaoNaturezaJuridicaForm extends AbstractBaseValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2628650917450704700L;

	private IdentifierPK pkParametrizacao;
	
	/** Operacao a ser realizada */
	private String operacao;

	/** Codigo da Natureza Juridica */
	private String cdNaturezaJuridica;
	
	/** Nome da Natureza Juridica */
	private String nmNaturezaJuridica;
	
	/** Envia informacao e-financeira */
	private String flEnviaInformacaoEFinanceira;
	
	private BVDate dtInicioVigencia;
	
	/** Mes inicial da vigencia */
	//private String txtMesInicioVigencia;

	private Integer mesInicioVigencia;
	//private Integer anoInicioVigencia;
	
	private Integer anoInicioVigencia;
	
	
	/** Ano inicial da vigencia */
	//private String txtAnoInicioVigencia;
	
	private List<MesVO> listaMeses;
	
	//private List<Integer> listaAnos;
	
	/**
	 * 
	 * Lista de resultado da consulta.
	 */
	private List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoesNaturezaJuridica;
		
	public ParametrizacaoNaturezaJuridicaForm() {
		
		listaMeses = new ArrayList<MesVO>();
		listaMeses.addAll( DataUtils.montaListaDeMeses() );
		
		//int anoCorrente = Calendar.getInstance().get( Calendar.YEAR );		
		//listaAnos = new ArrayList<Integer>();
		//for (int ano = 2015; ano <= anoCorrente; ano++) {
		//	listaAnos.add( ano );	
		//}		
				
	}
	
	
	
	public IdentifierPK getPkParametrizacao() {
		return pkParametrizacao;
	}



	public void setPkParametrizacao(IdentifierPK pkParametrizacao) {
		this.pkParametrizacao = pkParametrizacao;
	}



	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	public String getCdNaturezaJuridica() {
		return cdNaturezaJuridica;
	}

	public void setCdNaturezaJuridica(String cdNaturezaJuridica) {
		this.cdNaturezaJuridica = cdNaturezaJuridica;
	}

	public String getNmNaturezaJuridica() {
		return nmNaturezaJuridica;
	}

	public void setNmNaturezaJuridica(String nmNaturezaJuridica) {
		this.nmNaturezaJuridica = nmNaturezaJuridica;
	}




//	public String getTxtMesInicioVigencia() {
//		return txtMesInicioVigencia;
//	}
//
//
//
//	public void setTxtMesInicioVigencia(String txtMesInicioVigencia) {
//		this.txtMesInicioVigencia = txtMesInicioVigencia;
//	}
//
//
//
//	public String getTxtAnoInicioVigencia() {
//		return txtAnoInicioVigencia;
//	}
//
//
//
//	public void setTxtAnoInicioVigencia(String txtAnoInicioVigencia) {
//		this.txtAnoInicioVigencia = txtAnoInicioVigencia;
//	}



	public String getFlEnviaInformacaoEFinanceira() {
		return flEnviaInformacaoEFinanceira;
	}

	public void setFlEnviaInformacaoEFinanceira(String flEnviaInformacaoEFinanceira) {
		this.flEnviaInformacaoEFinanceira = flEnviaInformacaoEFinanceira;
	}

	public List<ParametrizacaoNaturezaJuridicaVO> getListaParametrizacoesNaturezaJuridica() {			
		return listaParametrizacoesNaturezaJuridica;
	}

	public void setListaParametrizacoesNaturezaJuridica(
			List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoesNaturezaJuridica) {
		this.listaParametrizacoesNaturezaJuridica = listaParametrizacoesNaturezaJuridica;
	}

	

	public BVDate getDtInicioVigencia() {
		return dtInicioVigencia;
	}



	public void setDtInicioVigencia(BVDate dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}



	public List<MesVO> getListaMeses() {
		return listaMeses;
	}



	public void setListaMeses(List<MesVO> listaMeses) {
		this.listaMeses = listaMeses;
	}



	//public List<Integer> getListaAnos() {
	//	return listaAnos;
	//}


	//public void setListaAnos(List<Integer> listaAnos) {
	//	this.listaAnos = listaAnos;
	//}



	public Integer getMesInicioVigencia() {
		return mesInicioVigencia;
	}



	public void setMesInicioVigencia(Integer mesInicioVigencia) {
		this.mesInicioVigencia = mesInicioVigencia;
	}



	public Integer getAnoInicioVigencia() {
		return anoInicioVigencia;
	}



	public void setAnoInicioVigencia(Integer anoInicioVigencia) {
		this.anoInicioVigencia = anoInicioVigencia;
	}

	

	//public Integer getAnoInicioVigencia() {
	//	return anoInicioVigencia;
	//}

	//public void setAnoInicioVigencia(Integer anoInicioVigencia) {
	//	this.anoInicioVigencia = anoInicioVigencia;
	//}

	
	
	
}

