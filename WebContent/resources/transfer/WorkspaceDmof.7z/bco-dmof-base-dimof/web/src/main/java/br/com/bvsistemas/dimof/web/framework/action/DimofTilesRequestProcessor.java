/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.framework.action;

import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.split;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.tiles.TilesRequestProcessor;

import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.util.PermissaoUtils;

import com.vf.util.data.vLogin;

/**
 * Processador de requisi��es.
 * 
 * Reimplementa os m�todos <code>processPreprocess</code> e
 * <code>processRoles</code>
 * 
 * @author cit.fuechi
 * 
 */
public class DimofTilesRequestProcessor extends TilesRequestProcessor {

	/**
	 * Verifica se o usu�rio est� logado, caso positivo prossegue caso negativo
	 * redireciona para tela de login. Checa se existe sess�o aberta e se a
	 * chave <code>Constantes.SESSION_USER_LOGIN</code> encontra-se nela.
	 * 
	 * Ignora as urls login.do e logout.do nessa checagem.
	 * 
	 * @see org.apache.struts.action.RequestProcessor#processPreprocess(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected boolean processPreprocess(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		// Se o usu�rio est� tentando acessar a tela de login deixa passar
		if (request.getServletPath().equals("/logout.do")
				|| request.getServletPath().equals("/login.do"))
			return true;

		// Checa se o objeto VLogin est� na sess�o
		// Caso positivo, o usu�rio j� est� logado
		if (session != null
				&& session.getAttribute(Constantes.SESSION_USER_LOGIN) != null)
			return true;
		else {
			try {
				// Caso contr�rio redirecionar para a tela de login
				request.getRequestDispatcher("/").forward(request, response);
				// response.sendRedirect(location)
			} catch (Exception ex) {
			}
		}
		return false;
	}

	/**
	 * Verifica se o usu�rio logado tem permiss�o para acessar a action/opera��o
	 * corrente.
	 * 
	 * O atributo roles deve ser setado da seguinte forma:
	 * 
	 * transacao:operacao
	 * 
	 * @author cit.fuechi
	 * @see org.apache.struts.action.RequestProcessor#processRoles(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse,
	 *      org.apache.struts.action.ActionMapping)
	 */
	@Override
	protected boolean processRoles(HttpServletRequest request,
			HttpServletResponse response, ActionMapping mapping)
			throws IOException, ServletException {

		// Esta action est� protegida?
		String roles[] = mapping.getRoleNames();
		if ((roles == null) || (roles.length < 1)) {
			return (true);
		}

		// Esta opera��o est� protegida?
		String operacaoCorrente = request.getParameter(mapping.getParameter());
		String transacaoCorrente = isProtectedOperation(operacaoCorrente, roles);
		if (isEmpty(transacaoCorrente)) {
			if (log.isInfoEnabled()) {
				log.info("Opera��o " + operacaoCorrente
						+ " desprotegida na action " + mapping.getPath());
			}
			return (true);
		} else {
			if (userHasPermission(request, transacaoCorrente)) {
				return (true);
			}
		}

		// O usu�rio logado n�o tem permiss�o para acessar essa action
		if (log.isDebugEnabled()) {
			HttpSession session = request.getSession(false);
			vLogin usuario = (vLogin) session
					.getAttribute(Constantes.SESSION_USER_LOGIN);
			log.debug(" Usu�rio '" + usuario.getUsuario()
					+ " n�o tem permiss�o para acessar: " + transacaoCorrente
					+ ":" + operacaoCorrente + ", negando acesso");
		}

		response.sendError(HttpServletResponse.SC_FORBIDDEN, getInternal()
				.getMessage("notAuthorized", mapping.getPath()));

		return (false);
	}

	/**
	 * Verifica se a opera��o corrente est� protegida. Uma opera��o �
	 * considerada protegida quando est� declarada em qualquer uma das roles da
	 * action corrente.
	 * 
	 * @param operacaoCorrente -
	 *            nome da opera��o corrente (extra�do do request)
	 * @param roles -
	 *            os roles definidos para a action corrente
	 * @return <code>null</code> se for desprotegida e o nome da transa��o
	 *         caso contr�rio
	 */
	private String isProtectedOperation(String operacaoCorrente, String[] roles) {

		if (isEmpty(operacaoCorrente)) {
			return (null);
		}

		for (int i = 0; i < roles.length; i++) {
			String tranOper[] = split(roles[i], ':');
			String transacao = tranOper[0];
			String operacao = tranOper.length > 1 ? tranOper[1] : null;
			if (operacaoCorrente.equalsIgnoreCase(operacao)) {
				if (log.isInfoEnabled()) {
					log.info("A opera��o : '" + operacao + "' est� protegida: "
							+ roles[i]);
				}
				return (transacao);
			}
		}

		return (null);
	}

	/**
	 * Verifica se o usuario logado tem acesso a uma transa��o espec�fica.
	 * 
	 * @param request -
	 *            requisi��o corrente
	 * @param transacao -
	 *            transa��o
	 * @return true se o usu�rio tem permiss�o e false caso contr�rio
	 */
	private boolean userHasPermission(HttpServletRequest request,
			String transacao) {
		boolean temPremissao = false;
		HttpSession session = request.getSession(false);
		vLogin usuario = (vLogin) session
				.getAttribute(Constantes.SESSION_USER_LOGIN);
		Map transacoes = usuario.getHtTransacoes();
		for (Iterator iterator = transacoes.keySet().iterator(); iterator
				.hasNext();) {
			String key = (String) iterator.next();
			temPremissao = PermissaoUtils.verificaPermissao(transacao,
					(String) transacoes.get(key));
			if (temPremissao) {
				break;
			}
		}
		if (temPremissao) {
			if (log.isDebugEnabled()) {
				log.debug("Concedendo acesso a transa��o: " + transacao
						+ " para o usu�rio " + usuario.getUsuario());
			}
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Negando acesso a transa��o: " + transacao
						+ " para o usu�rio " + usuario.getUsuario());
			}
		}
		return temPremissao;
	}

}
