/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.eFinanceira.agendamento.form;

import java.util.ArrayList;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.ResultadoProcessamentoSistemaVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela ....
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.form name="visualizarDetalhesAgendamentoForm"
 * 
 */
public class VisualizarDetalhesAgendamentoForm extends AbstractBaseValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    
	private String txtPeriodo;
	
	/**
	 * Lista de Clientes relacionados ao agendamento.
	 */
	private List<PessoaVO> listaClientes = new ArrayList<PessoaVO>();

	/**
	 * Lista de Empresas relacionadas ao agendamento.
	 */
	private List<PessoaVO> listaEmpresas = new ArrayList<PessoaVO>();
	
	
	private List<ResultadoProcessamentoSistemaVO> listaResultadoSistema = new ArrayList<ResultadoProcessamentoSistemaVO>();
	
	//VO agendamento
	private AgendamentoVO agendamentoVO;	
   
	public String getTxtPeriodo() {
		return txtPeriodo;
	}

	public void setTxtPeriodo(String txtPeriodo) {
		this.txtPeriodo = txtPeriodo;
	}

	/**
	 * 
	 * @return the agendamentoVO
	 */
	public AgendamentoVO getAgendamentoVO() {
		return agendamentoVO;
	}

	/**
	 * @param AgendamentoVO the agendamentoVO to set
	 */
	public void setAgendamentoVO(AgendamentoVO agendamentoVO) {
		this.agendamentoVO = agendamentoVO;
	}

	public List<PessoaVO> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(List<PessoaVO> listaClientes) {
		this.listaClientes = listaClientes;
	}

	public List<PessoaVO> getListaEmpresas() {
		return listaEmpresas;
	}

	public void setListaEmpresas(List<PessoaVO> listaEmpresas) {
		this.listaEmpresas = listaEmpresas;
	}

	public List<ResultadoProcessamentoSistemaVO> getListaResultadoSistema() {
		return listaResultadoSistema;
	}

	public void setListaResultadoSistema(
			List<ResultadoProcessamentoSistemaVO> listaResultadoSistema) {
		this.listaResultadoSistema = listaResultadoSistema;
	}


}
