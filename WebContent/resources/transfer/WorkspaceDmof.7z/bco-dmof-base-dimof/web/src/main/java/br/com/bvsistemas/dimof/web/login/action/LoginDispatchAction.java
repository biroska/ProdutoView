/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.login.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.services.auth.enums.DominioEnum;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.util.UsuarioPermissao;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.login.form.LoginForm;
import br.com.bvsistemas.framework.utils.StringUtils;

import com.vf.util.SLoginEJB;
import com.vf.util.UTILException;
import com.vf.util.cException;
import com.vf.util.cUTILLocator;
import com.vf.util.data.vLogin;

/**
 * Action responsavel pela funcionalidade de login e logout da aplica��o, acessa
 * e provem informa��es de usuario e permiss�o de acesso.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.action name="loginForm" path="/login" scope="request"
 *                parameter="operacao" input="dimof.login" validate="false"
 * 
 * 
 * @struts.action-forward name="paginaPrincipal" path="dimof.login"
 * 
 * @struts.action-forward name="home" path="dimof.home"
 * 
 * @struts.action-forward name="menu" path="/public_jsp/menu.jsp"
 * 
 */
public class LoginDispatchAction extends AbstractBaseDispatchAction {

	/**
	 * 
	 * Action respons�vel por inicializar o UC de login
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Configura os par�metros iniciais para ir para o login.
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	public ActionForward executarLogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Obtem o formulario
		LoginForm loginForm = (LoginForm) form;

		// Valida os parametros obrigatorios do sistema
		ActionMessages erros = loginForm.validate(mapping, request);

		if (erros.isEmpty()) {

			vLogin login = null;

			SLoginEJB logEJB = null;
			try {
				logEJB = cUTILLocator.getInstance().getSLoginEJB();
			}

			catch (cException e) {
				String msg = clearJsMessage(e.getMessage());
				log.error("Erro ao coletar o EJB: " + msg);
				erros.add(obtemCampoErroLoginAcesso(msg), new ActionMessage(
						Constantes.BUNDLE_LOGIN_ERRO, msg));
				saveErrors(request, erros);

				return (mapping
						.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
			}

			try {

				// Tenta executar o login
				login = logEJB.efetuaLoginAcesso(loginForm.getTxtUsuario(),
						loginForm.getTxtSenha(),
						DominioEnum.DIMOF.innerValue(), java.net.InetAddress
								.getLocalHost().toString(), StringUtils.EMPTY,
						StringUtils.EMPTY);

				// Obtem as permiss�es do usu�rio
				UsuarioPermissao permissao = new UsuarioPermissao(
						login.getHtTransacoes());

				// Coloca as permissoes do usuario na sess�o
				request.getSession().setAttribute(Constantes.SESSION_PERMISSAO,
						permissao);
				// Coloca o usuario na sess�o
				request.getSession().setAttribute(
						Constantes.SESSION_USER_LOGIN, login);
			}

			catch (UTILException e) {
				String msg = clearJsMessage(e.getMessage());
				erros.add(obtemCampoErroLoginAcesso(msg), new ActionMessage(
						Constantes.BUNDLE_LOGIN_ERRO, e.getMessage()));
				saveErrors(request, erros);

				return (mapping
						.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
			}

			catch (cException e) {
				erros.add(ActionMessages.GLOBAL_MESSAGE,
						new ActionMessage(Constantes.BUNDLE_LOGIN_ERRO,
								clearJsMessage(e.getMessage())));
				saveErrors(request, erros);

				return (mapping
						.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
			}

		}

		else {
			saveErrors(request, erros);
			return (mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
		}

		return (mapping.findForward(Constantes.FORWARD_HOME));
	}

	/**
	 * Retorna o campo que ocorreu erro na opera��o de login, dado uma mensagem
	 * de erro do VFAcesso
	 * 
	 * @param message
	 *            - Mensagem de erro do VFAcesso
	 * @return - campo invalido
	 */
	private String obtemCampoErroLoginAcesso(String message) {

		// Obtem valor default
		String result = ActionMessages.GLOBAL_MESSAGE;

		// Verifica se a mensagem � valida
		if (!GenericValidator.isBlankOrNull(message)) {

			// Caso seja erro de senha invalida
			if (StringUtils.contains(message.toLowerCase(), "senha")) {
				result = "txtSenha";
			}

			// Caso seja erro de login invalido
			if (StringUtils.contains(message.toLowerCase(), "usu�rio")) {
				result = "txtUsuario";
			}

		}

		return result;

	}

	/**
	 * 
	 * Action respons�vel por executar logoff
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public ActionForward executarLogoff(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		vLogin login = null;

		SLoginEJB logEJB = null;
		try {
			logEJB = cUTILLocator.getInstance().getSLoginEJB();
		}

		catch (cException e) {
			log.error("Erro ao coletar o EJB: " + e.getMessage());
			return (mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
		}

		try {

			// Tenta executar o logoff
			String id = obterSessionId(request);

			// Verifica se a sess�o do usuario n�o expirou
			if (!GenericValidator.isBlankOrNull(id)) {
				logEJB.efetuaLogout(id);
			}
		}

		catch (cException e) {
			log.error(e);
		}

		// Remove os atributos do usuario da sess�o
		request.getSession().removeAttribute(Constantes.SESSION_PERMISSAO);
		request.getSession().removeAttribute(Constantes.SESSION_USER_LOGIN);

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Normaliza String para ser usado em JS
	 * 
	 * @param message
	 *            - Mensagem
	 * @return - String normalizada
	 */
	private String clearJsMessage(String message) {

		String result = StringUtils.replace(message, "\n", " ");
		result = StringUtils.replace(result, "\t", "  ");

		return result;
	}

}
