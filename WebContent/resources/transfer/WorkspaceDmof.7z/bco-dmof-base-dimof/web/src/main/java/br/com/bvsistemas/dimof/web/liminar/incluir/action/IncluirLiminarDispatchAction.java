/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.incluir.action;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.exception.LiminarDuplicadaException;
import br.com.bvsistemas.dimof.services.LiminarServices;
import br.com.bvsistemas.dimof.services.PessoaServices;
import br.com.bvsistemas.dimof.services.SecaoJudiciariaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.liminar.incluir.form.IncluirLiminarForm;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.utils.BVEnumUtils;
import br.com.bvsistemas.framework.utils.StringUtils;

import com.vf.util.data.vLogin;

/**
 * Action responsavel pela funcionalidade ...
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.action name="incluirLiminarForm" path="/incluirLiminar"
 *                scope="request" parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.liminar.incluirLiminar"
 * 
 * @struts.action-forward name="home" path="dimof.home"
 * 
 */
public class IncluirLiminarDispatchAction extends AbstractBaseDispatchAction {

	/**
	 * Mascara de formatacao de data.
	 */
	private static final String DD_MM_YYYY = "dd/MM/yyyy";

	/*
	 * (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction#preProcessa(
	 *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public void preProcessa(ActionForm form, HttpServletRequest request)
			throws Exception {

		// Recupera o form
		IncluirLiminarForm theForm = (IncluirLiminarForm) form;

		// Obtem o servi�o
		SecaoJudiciariaServices services = 
			(SecaoJudiciariaServices) getProxy(request, 
					SecaoJudiciariaServices.class);

		// Obtem a lista de secoes judiciarias
		List<SecaoJudiciariaVO> listaSecoes = services.listar();

		theForm.setListaSecaoJudiciaria(listaSecoes);
	}

	/**
	 * 
	 * Action respons�vel por inicializar a Tela ...
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * 
	 * Action respons�vel por executar a inclusao.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward incluir(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception, LiminarDuplicadaException {

		// Instancia do form
		IncluirLiminarForm liminarForm = (IncluirLiminarForm) form;

		// Validacoes
		ActionMessages erros = liminarForm.validate(mapping, request);

		if (erros.isEmpty()) {
			if (StringUtils.isNotBlank(liminarForm.getTxtDataInicio())
					&& StringUtils.isNotBlank(liminarForm.getTxtDataFim())) {

				BVDate dtInicio = new BVDate(liminarForm.getTxtDataInicio(),
						DD_MM_YYYY);
				BVDate dtFim = new BVDate(liminarForm.getTxtDataFim(),
						DD_MM_YYYY);

				// Compara as datas
				boolean result = !(dtInicio.compareTo(dtFim) > 0);

				if (!result) {
					// Intervalo de datas inv�lido
					erros.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.liminar.periodoInvalido"));
				}
			}
			if (erros.isEmpty()) {
			try {
				// instancia do objeto
				IdentifierPK pk = new IdentifierPK();
				LiminarVO liminar = new LiminarVO(pk);
				// preenche o objeto
				liminar = (LiminarVO) preencherLiminar(request, liminarForm,
						liminar);
				LiminarServices service = (LiminarServices) getProxy(request,
						LiminarServices.class);
				// incluir

				service.incluirLiminar(liminar);

				Limpar(request, liminarForm);
				// mensagem sucesso
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.success.liminarIncluidaComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				// erros
			} catch (ValidationException e) {
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.valorInvalido"));
				saveErrors(request, messages);
				return (mapping
						.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
			} catch (LiminarDuplicadaException e) {
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.liminar.liminarDuplicada"));
				saveErrors(request, messages);
				return (mapping
						.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));
			} catch (Exception e) {

				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.erroInesperado"));
				saveErrors(request, messages);
				return (mapping
						.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL));

			}
			}
			else {
				saveErrors(request, erros);
			}
		} else {
			saveErrors(request, erros);

		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	private LiminarVO preencherLiminar(final HttpServletRequest request,
			IncluirLiminarForm incluirForm, LiminarVO liminar) {
		try {
			// Declaracao de variaveis par auxiliar preenchimento do LIminarVO
			PessoaServices pessoaService = (PessoaServices) getProxy(request,
					PessoaServices.class);
			Long numero;
			vLogin usuarioLogado = (vLogin) request.getSession().getAttribute(
					Constantes.SESSION_USER_LOGIN);
			// cliente
			Long codCliente = new Long(incluirForm.getIdCliente());
			IdentifierPK pkCliente = new IdentifierPK(codCliente);
			PessoaVO cliente = new PessoaVO(pkCliente);
			cliente.setNmPessoa(incluirForm.getTxtCliente());
			liminar.setCliente(cliente);

			// Datas
			liminar.setDtIniVigencia(new BVDate(incluirForm.getTxtDataInicio(),
					DD_MM_YYYY));
			liminar.setDtExpedicao(new BVDate(
					incluirForm.getTxtDataExpedicao(), DD_MM_YYYY));
			if (incluirForm.getTxtDataFim() != null
					&& !StringUtils.isBlank(incluirForm.getTxtDataFim())) {
				liminar.setDtFimVigencia(new BVDate(
						incluirForm.getTxtDataFim(), DD_MM_YYYY));
				liminar.setDtInformeFimVigencia(new BVDatetime());
			} else {
				// caso a data fim vigencia nao seja informada
				// limpa a data informe fim vigencia
				liminar.setDtInformeFimVigencia(null);
			}

			// numeros
			numero = new Long(incluirForm.getTxtNumLiminar());
			liminar.setNuLiminar(numero.longValue());
			numero = new Long(incluirForm.getTxtNumSecao());
			liminar.setNuSecaoJudiciaria(numero.intValue());
			numero = new Long(incluirForm.getTxtNumVara());
			liminar.setNuVaraTramitacao(numero.intValue());

			// flag
			BooleanEnum flag = null;
			if (StringUtils.isNotBlank(incluirForm.getFlCassacao())) {
				flag = BVEnumUtils.getEnum(BooleanEnum.class,
						new Character('S'));
			} else {
				flag = BVEnumUtils.getEnum(BooleanEnum.class,
						new Character('N'));
			}
			liminar.setFlCassacaoRetroativa(flag);
			liminar.setDtProcessamento(null);
			liminar.setNmSubsecaoJudiciaria(incluirForm.getTxtNomeSubsecao());
			liminar.setDsLoginInclusao(usuarioLogado.getUsuario());
		} catch (ParseException e) {

		}
		return liminar;

	}

	/**
	 * Action respons�vel por voltar para a pagina inicial da aplicacao.
	 * 
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}

	/**
	 * metodo para limpar o form
	 * 
	 * @param request
	 * @param theForm
	 */
	private void Limpar(final HttpServletRequest request, ActionForm theForm) {
		// popula form
		IncluirLiminarForm form = (IncluirLiminarForm) theForm;
		form.setTxtRetroativa(null);
		form.setTxtCliente(null);
		form.setTxtDataExpedicao(null);
		form.setTxtDataFim(null);
		form.setTxtDataInicio(null);
		form.setTxtNomeSubsecao(null);
		form.setTxtNumLiminar(null);
		form.setTxtNumSecao(null);
		form.setTxtNumVara(null);
		form.setIdCliente(null);
		form.setFlCassacao(null);

	}

}
