package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;

/**
 * Mapeia o Objeto de permiss�es do VFAcesso
 * 
 * @author cmiranda
 * 
 */
public class DimofLiminarAdmPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10000000092L;

	/**
	 * Atributos do objeto DimofLiminarPermissao
	 */
	private Boolean isAlterar;

	/**
	 * 
	 */
	public DimofLiminarAdmPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transa��es do VFAcesso e monta o objeto
	 * 
	 * @param transacoesMap
	 */
	public DimofLiminarAdmPermissao(Hashtable<String, String> transacoesMap) {
		super();

		// Obtem a lista de transacoes para Liminar Adm
		String listTransacoes = (String) transacoesMap.get("Dimof_Liminar");

		// Seta as permissoes vindas da hash
		this.setIsAlterar(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Liminar_Alterar_Master", listTransacoes)));

	}

	/**
	 * @return the isAlterar
	 */
	public Boolean getIsAlterar() {
		return isAlterar;
	}

	/**
	 * @param isAlterar
	 *            the isAlterar to set
	 */
	public void setIsAlterar(Boolean isAlterar) {
		this.isAlterar = isAlterar;
	}

}
