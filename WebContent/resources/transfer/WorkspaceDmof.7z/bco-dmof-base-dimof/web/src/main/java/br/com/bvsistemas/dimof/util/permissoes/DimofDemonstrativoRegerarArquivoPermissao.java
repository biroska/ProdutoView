package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;

/**
 * Mapeia o Objeto de permiss�es do VFAcesso
 * 
 * @author cmiranda
 * 
 */
public class DimofDemonstrativoRegerarArquivoPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10000000091L;

	/**
	 * Atributos do objeto DimofLiminarPermissao
	 */
	private Boolean isGerar;

	/**
	 * 
	 */
	public DimofDemonstrativoRegerarArquivoPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transa��es do VFAcesso e monta o objeto
	 * 
	 * @param transacoesMap
	 */
	public DimofDemonstrativoRegerarArquivoPermissao(
			Hashtable<String, String> transacoesMap) {
		super();

		// Obtem a lista de transacoes para 
		String listTransacoes = (String) transacoesMap
				 .get("Dimof_Demonstrativo_RegerarArquivo");

		// Seta as permissoes vindas da hash
		this.setIsGerar(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Demonstrativo_RegerarArquivo_Gerar", listTransacoes)));

	}

	/**
	 * @return the isGerar
	 */
	public Boolean getIsGerar() {
		return isGerar;
	}

	/**
	 * @param isGerar
	 *            the isGerar to set
	 */
	public void setIsGerar(Boolean isGerar) {
		this.isGerar = isGerar;
	}

}
