package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;

/**
 * Mapeia o Objeto de permiss�es do VFAcesso
 * 
 * @author cmiranda
 * 
 */
public class DimofParametrosPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10000000095L;

	/**
	 * Atributos do objeto DimofLiminarPermissao
	 */
	private Boolean isAlterar;

	/**
	 * 
	 */
	public DimofParametrosPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transa��es do VFAcesso e monta o objeto
	 * 
	 * @param transacoesMap
	 */
	public DimofParametrosPermissao(Hashtable<String, String> transacoesMap) {
		super();

		// Obtem a lista de transacoes para Manter Parametros
		String listTransacoes = (String) transacoesMap
				.get("Dimof_Parametros");

		// Seta as permissoes vindas da hash
		this.setIsAlterar(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Parametros_Alterar", listTransacoes)));
	}

	/**
	 * @return the isAlterar
	 */
	public Boolean getIsAlterar() {
		return isAlterar;
	}

	/**
	 * @param isAlterar
	 *            the isAlterar to set
	 */
	public void setIsAlterar(Boolean isAlterar) {
		this.isAlterar = isAlterar;
	}

}
