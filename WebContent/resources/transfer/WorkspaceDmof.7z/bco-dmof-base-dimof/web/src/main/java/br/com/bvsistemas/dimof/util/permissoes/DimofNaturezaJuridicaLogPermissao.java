package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;


public class DimofNaturezaJuridicaLogPermissao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6435265727400814431L;
	/**
	 * 
	 */

	private Boolean isConsultar;



	public DimofNaturezaJuridicaLogPermissao(){
		super();
	}


	public DimofNaturezaJuridicaLogPermissao(Hashtable<String, String> transacoesMap){
		super();

		// Obtem a lista de transacoes para Liminar
		String listTransacoes = (String) transacoesMap
				.get("DMOF_Natureza_Juridica_HistoricoAlteracoes");


		this.setIsConsultar(Boolean.valueOf(PermissaoUtils.verificaPermissao(
				"DMOF_Natureza_Juridica_HistoricoAlteracoes_Consultar", listTransacoes)));
	}


	public Boolean getIsConsultar() {
		return isConsultar;
	}


	public void setIsConsultar(Boolean isConsultar) {
		this.isConsultar = isConsultar;
	}


}
