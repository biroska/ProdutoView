/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.parametros.estorno.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.dimof.services.TransacaoEstornoServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.parametros.estorno.form.TransacaoEstornoForm;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;

/**
 * Classe respons�vel por controlar as opera��es referentes � transa��es de
 * estorno na tela de Altera��o de Parametros.
 * 
 * @author <a
 *         href="mailto:talent.ealmeida@bvsistemas.com.br">talent.ealmeida</a>
 * 
 * @struts.action name="transacaoEstornoForm" path="/transacaoEstorno"
 *                scope="session" parameter="operacao"
 *                input="dimof.parametros.consultarTransacaoEstorno"
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.parametros.consultarTransacaoEstorno"
 * 
 * @struts.action-forward name="paginaIncluir"
 *                        path="dimof.parametros.incluirTransacaoEstorno"
 * 
 * @struts.action-forward name="home" path="dimof.home"
 * 
 */
public class TransacaoEstornoDispatchAction extends AbstractBaseDispatchAction {

	private static final String PAGINA_INCLUSAO = "paginaIncluir";

	/**
	 * Objeto para gerar log.
	 */
	private static final BVLogger logger = BVLogger
			.getLogger(TransacaoEstornoDispatchAction.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction
	 * #execute(org.apache.struts.action.ActionMapping,
	 * org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {

			final String operacao = request.getParameter("operacao") != null ? request
					.getParameter("operacao") : "";

			if (operacao.equals("consultar")) {
				return consultar(mapping, form, request, response);
			}
			if (operacao.equals("incluir")) {
				return incluir(mapping, form, request, response);
			}
			if (operacao.equals("salvar")) {
				return salvar(mapping, form, request, response);
			}
			if (operacao.equals("excluir")) {
				return excluir(mapping, form, request, response);
			}
			return prepararTela(mapping, form, request, response);

		} catch (Exception e) {
			logger.workflow.error(e);
		}
		return null;
	};

	/**
	 * Action respons�vel por inicializar a tela de Transa��es.
	 * 
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		TransacaoEstornoForm theForm = (TransacaoEstornoForm) form;

		// Limpa o form
		limparForm(theForm);
		// Obtem os servi�os
		TransacaoEstornoServices transacaoEstornoServices = (TransacaoEstornoServices) getProxy(
				request, TransacaoEstornoServices.class);

		theForm.setListaOrigem(transacaoEstornoServices.listarOrigem());
		theForm.setListaTransacoes(transacaoEstornoServices.listarTransacao());

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Action respons�vel por salvar os dados de Parametros.
	 * 
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward salvar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		TransacaoEstornoForm theForm = (TransacaoEstornoForm) form;

		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		if (erros.isEmpty()) {
			try {
				//Servico de mensagens
				ActionMessages messages = new ActionMessages();

				// Obtem o servi�o
				TransacaoEstornoServices transacaoEstornoServices = (TransacaoEstornoServices) getProxy(
						request, TransacaoEstornoServices.class);
				IdentifierPK pk = new IdentifierPK();
				TransacaoEstornoVO vo = new TransacaoEstornoVO(pk);

				vo.setCdOrigem(Integer.valueOf(theForm.getCdOrigem()));
				vo.setCdTransacao(Integer.valueOf(theForm.getCdTransacao()));
				vo.setRaizCnpj(theForm.getRaizCNPJ());
				vo.setDataInclusao(new Date());
				
				if(registroJaCadastrado(vo, transacaoEstornoServices)){
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.transacaoJaCadastrada"));
					saveErrors(request, messages);
					return mapping.findForward(PAGINA_INCLUSAO);
				}
				
				transacaoEstornoServices.inserir(vo);

				// Parametro alterado com sucesso
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.success.transacaoIncluidaComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				limparForm(theForm);
			} catch (ValidationException e) {
				logger.workflow.warn(e);
				// Erro inesperado
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.erroInesperado"));
				saveErrors(request, messages);
			}
		} else {
			// Ocorreu erro
			saveErrors(request, erros);
			logger.workflow.warn(erros);
			return mapping.findForward(PAGINA_INCLUSAO);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	private boolean registroJaCadastrado(TransacaoEstornoVO vo, TransacaoEstornoServices transacaoEstornoServices){
		 
		try {
			List<TransacaoEstornoVO> lista = transacaoEstornoServices.listar(vo.getCdOrigem(), vo.getCdTransacao(), vo.getRaizCnpj());
			if(lista.size() > 0)
				return Boolean.TRUE;
		} catch (Exception e) {

		}
		
		
		return Boolean.FALSE;
		
	}
	
	
	/**
	 * Action respons�vel por voltar para a pagina inicial da aplicacao.
	 * 
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}

	/**
	 * Prepara a tela de inclus�o para um cadastro de uma nova Transa��o
	 * 
	 * @author talent.ealmeida
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward Redireciona para a tela de Inclus�o
	 * 
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward incluir(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		limparForm((TransacaoEstornoForm) form);

		return mapping.findForward(PAGINA_INCLUSAO);
	}

	/**
	 * M�todo que faz a pesquisa baseado nos par�metros passados
	 * 
	 * @author talent.ealmeida
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * 
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward consultar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		TransacaoEstornoForm theForm = (TransacaoEstornoForm) form;

		// Limpa os Resultados anteriores
		theForm.setListaTransacaoEstorno(new ArrayList<TransacaoEstornoVO>());

		String raizCnpj = theForm.getRaizCNPJ() != null && !theForm.getRaizCNPJ().trim().equals("") ? theForm.getRaizCNPJ().trim() : null;
		if(raizCnpj != null && !Pattern.matches("[\\d]{0,8}", raizCnpj)){
			ActionMessages messages = new ActionErrors();
			messages.add(Globals.MESSAGE_KEY, new ActionMessage(
					"errors.integer", "Raiz CNPJ"));
			saveErrors(request, messages);
		}else{
		
			Integer cdOrigem = theForm.getCdOrigem() != null && !theForm.getCdOrigem().trim().equals("") ? Integer.valueOf(theForm.getCdOrigem()) : null;
			Integer cdTransacao = theForm.getCdTransacao() != null && !theForm.getCdTransacao().trim().equals("") ? Integer.valueOf(theForm.getCdTransacao()) : null;
			
			
			//Obtem o servi�o
			TransacaoEstornoServices transacaoEstornoServices = (TransacaoEstornoServices) getProxy(request, TransacaoEstornoServices.class);
		
			List<TransacaoEstornoVO> lista = transacaoEstornoServices.listar(cdOrigem, cdTransacao, raizCnpj);
	
			if (lista.size() > 0) {
				for (TransacaoEstornoVO vo : lista) {
					vo.setNmOrigem(transacaoEstornoServices.getNomeOrigem(vo.getCdOrigem()));
					vo.setNmTransacao(transacaoEstornoServices.getNomeTransacao(vo.getCdTransacao()));
				}
				theForm.setListaTransacaoEstorno(lista);
			} else {
				// Nenhum item encontrado
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.buscaSemRegistro"));
				saveErrors(request, messages);
			}
		}
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * M�todo respons�vel por marcar a flag flAtivo do registro selecionado como
	 * 'N', desativando o mesmo
	 * 
	 * @author talent.ealmeida
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	private ActionForward excluir(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		TransacaoEstornoForm theForm = (TransacaoEstornoForm) form;

		Integer cdTransacaoEstorno = Integer.valueOf(theForm
				.getCdTransacaoEstorno());

		IdentifierPK pk = new IdentifierPK(cdTransacaoEstorno);

		// Preencher os campos do VO que ser�o alterados com os novos valores
		TransacaoEstornoVO vo = new TransacaoEstornoVO(pk);
		vo.setFlAtivo("N");
		vo.setDataAlteracao(new Date());

		// Obtem o servi�o
		TransacaoEstornoServices transacaoEstornoServices = (TransacaoEstornoServices) getProxy(
				request, TransacaoEstornoServices.class);

		int resultadoOperacao = transacaoEstornoServices.alterar(vo);

		if (resultadoOperacao > 0) {
			// Transacao de Estorno alterada com sucesso
			ActionMessages messages = new ActionMessages();
			messages.add(Globals.MESSAGE_KEY, new ActionMessage(
					"message.success.transacaoExclu�daComSucesso"));
			saveMessages(request, messages);
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			limparForm(theForm);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * M�todo respons�vel por limpar o form
	 * 
	 * @author talent.ealmeida
	 * @param theForm
	 *            o Formul�rio a ser limpo
	 */
	private void limparForm(TransacaoEstornoForm theForm) {
		theForm.setListaTransacaoEstorno(new ArrayList<TransacaoEstornoVO>());
		theForm.setCdOrigem(null);
		theForm.setCdTransacao(null);
		theForm.setRaizCNPJ(null);
	}

}
