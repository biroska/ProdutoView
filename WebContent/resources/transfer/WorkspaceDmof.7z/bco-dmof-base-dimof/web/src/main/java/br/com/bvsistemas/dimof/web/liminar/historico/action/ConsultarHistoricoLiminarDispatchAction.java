/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.historico.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.services.LiminarServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.liminar.historico.form.ConsultarHistoricoLiminarForm;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Action responsavel pela funcionalidade consulta Historico de liminar.
 * 
 * @author <a href="mailto:palmeida@ciandt.com">Priscila Almeida</a>
 * 
 * @struts.action name="consultarHistoricoLiminarForm"
 *                path="/consultarHistoricoLiminar" scope="session"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.liminar.consultarHistorico"
 * 
 */
public class ConsultarHistoricoLiminarDispatchAction extends
		AbstractBaseDispatchAction {
	/**
	 * formato da data.
	 */
	private static final String DD_MM_YYYY = "dd/MM/yyyy";

	/**
	 * 
	 * Action respons�vel por inicializar a Tela de Consulta de historico 
	 * de liminar
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		ConsultarHistoricoLiminarForm theForm = 
			(ConsultarHistoricoLiminarForm) form;

		// Limpa o form
		limparForm(theForm);

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	/**
	 * 
	 * Action respons�vel por executar a consulta de historico de liminar.
	 * 
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward executar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		ConsultarHistoricoLiminarForm theForm = 
			(ConsultarHistoricoLiminarForm) form;

		// Obtem o servi�o
		LiminarServices liminarServices = 
			(LiminarServices) getProxy(request, LiminarServices.class);


		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		// Recupera os campos do filtro da pesquisa
		String strCdCliente = theForm.getIdCliente();
		String strNuLiminar = theForm.getTxtNumLiminar();
		String strDtInicioAlterado = theForm.getTxtPeriodoIni();
		String strDtFimAlterado = theForm.getTxtPeriodoFim();


		if (erros.isEmpty()) {
			// Verifica obrigatoriedade de campos
			if (StringUtils.isBlank(strCdCliente) 
					&& StringUtils.isBlank(strNuLiminar)
					&& StringUtils.isBlank(strDtInicioAlterado) 
					&& StringUtils.isBlank(strDtFimAlterado)) {

				// Nenhum campo preenchido
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
				"message.error.historicoLiminar.camposObrigatorios"));

			} else if (StringUtils.isNotBlank(strDtInicioAlterado)					
					&& StringUtils.isBlank(strDtFimAlterado)) {
				// Data inicial preenchida e final n�o preenchida
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
				"message.error.historicoLiminar.camposObrigatorios"));

			} else if (StringUtils.isBlank(strDtInicioAlterado) 
					&& StringUtils.isNotBlank(strDtFimAlterado)) {
				// Data inicial n�o preenchida e final preenchida
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
				"message.error.historicoLiminar.camposObrigatorios"));

			} else if (StringUtils.isNotBlank(strDtInicioAlterado) 
					&& StringUtils.isNotBlank(strDtFimAlterado)) {

				BVDate dtInicio = new BVDate(strDtInicioAlterado, DD_MM_YYYY);
				BVDate dtFim = new BVDate(strDtFimAlterado, DD_MM_YYYY);

				// Compara as datas
				boolean result = !(dtInicio.compareTo(dtFim) > 0);

				if (!result) {
					// Intervalo de datas inv�lido
					// Data inicial maior que data final
					erros.add(Globals.MESSAGE_KEY, new ActionMessage(
					"message.error.periodoInvalido"));
				}
			}
		}

		if (erros.isEmpty()) {
			IdentifierPK pkPessoa = null;
			if (StringUtils.isNotBlank(strCdCliente)) {
				pkPessoa = new IdentifierPK(new Long(strCdCliente));
			}

			if (StringUtils.isNotBlank(strNuLiminar)) {
				strNuLiminar = strNuLiminar.trim();
			}

			BVDate dtInicioAlterado = null;
			if (StringUtils.isNotBlank(strDtInicioAlterado)) {
				dtInicioAlterado = new BVDate(strDtInicioAlterado, 
						Constantes.DATE_PATTERN);
			}

			BVDate dtFimAlterado = null;
			if (StringUtils.isNotBlank(strDtFimAlterado)) {
				dtFimAlterado= new BVDate(strDtFimAlterado, 
						Constantes.DATE_PATTERN);
			}

			// Chama o servi�o da consulta		
			List<HistoricoLiminarVO> listaLiminar = 
				liminarServices.listarHistoricoLiminar(pkPessoa, strNuLiminar, 
						dtInicioAlterado, dtFimAlterado);

			// Verifica o resultado da consulta
			if ((listaLiminar == null) || (listaLiminar.isEmpty())) {
				// N�o h� retorno de dados
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.buscaSemRegistro"));
				saveErrors(request, messages);
				theForm.setListaLiminar(null);

			} else {
				// Seta lista de resultados da cosnulta
				theForm.setListaLiminar(listaLiminar);
			}

		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Limpa o form.
	 */
	private void limparForm(ConsultarHistoricoLiminarForm theForm) {
		theForm.setIdCliente(null);
		theForm.setTxtCliente(null);
		theForm.setTxtNumLiminar(null);
		theForm.setTxtPeriodoIni(null);
		theForm.setTxtPeriodoFim(null);
		theForm.setListaLiminar(null);
	}

}
