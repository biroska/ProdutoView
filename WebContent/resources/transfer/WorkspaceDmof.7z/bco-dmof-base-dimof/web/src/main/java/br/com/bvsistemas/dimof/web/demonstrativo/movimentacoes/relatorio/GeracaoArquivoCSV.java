/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.relatorio;

import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoVO;

/**
 * Classe usado para a geracao de arquivo CSV
 * 
 * @author elias.yoshida
 * 
 */
public class GeracaoArquivoCSV {

	private String SEPARADOR_CSV = "; ";

	/**
	 * Classe que gera o arquivo CSV
	 */
	public String gerarArquivo(PrintWriter pWriter,
			DetalheMovimentoVO detalheMovimentoVO) {

		List<DetalheMovimentoCambioVO> listaMovCambio = null;
		List<DetalheMovimentoCCVO> listaMovCCorrente = null;

		// carrega a lista de detalhe de movimentacoes de cambio
		if (detalheMovimentoVO.getListaMovCambio() != null
				&& !detalheMovimentoVO.getListaMovCambio().isEmpty()) {
			listaMovCambio = detalheMovimentoVO.getListaMovCambio();
		}
		// carrega a lista de detalhe de movimentacoes de conta corrente
		if (detalheMovimentoVO.getListaMovContaCC() != null
				&& !detalheMovimentoVO.getListaMovContaCC().isEmpty()) {
			listaMovCCorrente = detalheMovimentoVO.getListaMovContaCC();
		}
	
		pWriter.print("Nome / Raz�o Social" + SEPARADOR_CSV);
		pWriter.println(detalheMovimentoVO.getCliente().getNmPessoa());
		pWriter.print("CPF / CNPJ" + SEPARADOR_CSV);
		pWriter.print(detalheMovimentoVO.getCliente().getNuCpfCnpjFormatado() + SEPARADOR_CSV);
		pWriter.print(" " + SEPARADOR_CSV);
		pWriter.println(detalheMovimentoVO.getNuContaCorrente());
		pWriter.println("");
		pWriter.println("Detalhe de Movimenta��o de Conta Corrente");
		pWriter.print("Data Movimento" + SEPARADOR_CSV);
		pWriter.print("Valor" + SEPARADOR_CSV);
		pWriter.print("Cred/Deb" + SEPARADOR_CSV);
		pWriter.print("Cpf/Cnpj creditado" + SEPARADOR_CSV);
		pWriter.print("Cpf/Cnpj debitado"+ SEPARADOR_CSV);
		pWriter.println("N�mero Conta Corrente");
		if (listaMovCCorrente != null) {
			for (DetalheMovimentoCCVO detalheMovimentoCCVO : listaMovCCorrente) {

				pWriter.print(detalheMovimentoCCVO.getDtMovimentoFormatado() + SEPARADOR_CSV);
				NumberFormat f = NumberFormat.getCurrencyInstance();
			    f.setMinimumFractionDigits(2);  
			    f.setMaximumFractionDigits(2);  			    
				pWriter.print(f.format(detalheMovimentoCCVO.getVrOperacao())+ SEPARADOR_CSV);
				String tipo = detalheMovimentoCCVO.getTpDebitoCredito()==null? "":detalheMovimentoCCVO.getTpDebitoCredito();
				if(tipo.equalsIgnoreCase("C")){
					pWriter.print( "CR�DITO"+ SEPARADOR_CSV);	
				}else if(tipo.equalsIgnoreCase("D")){
					pWriter.print( "D�BITO"+ SEPARADOR_CSV);
				}else{
					pWriter.print( tipo+ SEPARADOR_CSV);
				}
				pWriter.print(detalheMovimentoCCVO.getNuCpfCnpjCreditadoFormatado()+ SEPARADOR_CSV);
				pWriter.print(detalheMovimentoCCVO.getNuCpfCnpjDebitadoFormatado()+ SEPARADOR_CSV);
				pWriter.println(detalheMovimentoCCVO.getNuContaCorrente());
			}
		} else {
			pWriter.println("Nenhum item encontrado");
		}

		pWriter.println("");
		pWriter.println("Detalhe de Movimenta��o de C�mbio");
		pWriter.print("Data Movimento" + SEPARADOR_CSV);
		pWriter.print("Valor" + SEPARADOR_CSV);
		pWriter.println("Compra/Venda");
		if (listaMovCambio != null) {
			for (DetalheMovimentoCambioVO detalheMovimentoCambioVO : listaMovCambio) {
				pWriter.print(detalheMovimentoCambioVO.getDtMovimentoFormatado() + SEPARADOR_CSV);
				NumberFormat f = NumberFormat.getCurrencyInstance();
			    f.setMinimumFractionDigits(2);  
			    f.setMaximumFractionDigits(2);  
				pWriter.print(f.format(detalheMovimentoCambioVO.getVrOperacao())+ SEPARADOR_CSV);
				String tipo = detalheMovimentoCambioVO.getTpOperacao() == null ? "" : detalheMovimentoCambioVO.getTpOperacao();
				if(tipo.equalsIgnoreCase("C")){
					pWriter.println("COMPRA");
				}else if(tipo.equalsIgnoreCase("V")) {
					pWriter.println("VENDA");
				}else{
					pWriter.println(tipo);
				}
				
			}
		} else {
			pWriter.println("Nenhum item encontrado");
		}


		pWriter.println("");

		return "relatorio_cliente"
				+ detalheMovimentoVO.getCliente().getPk().getId() + ".csv";
	}
}
