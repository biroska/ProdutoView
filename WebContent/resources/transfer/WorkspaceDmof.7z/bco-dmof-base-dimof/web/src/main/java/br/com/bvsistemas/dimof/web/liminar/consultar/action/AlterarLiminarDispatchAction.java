/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.consultar.action;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.exception.LiminarDuplicadaException;
import br.com.bvsistemas.dimof.services.LiminarServices;
import br.com.bvsistemas.dimof.services.SecaoJudiciariaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.liminar.consultar.form.AlterarLiminarForm;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.utils.StringUtils;

import com.vf.util.data.vLogin;

/**
 * Action responsavel pela funcionalidade ...
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.action name="alterarLiminarForm" path="/alterarLiminar"
 *                scope="request" parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.liminar.alterarLiminar"
 * 
 */
public class AlterarLiminarDispatchAction extends AbstractBaseDispatchAction {

	/**
	 * Constante nome do parametro
	 */
	public final String COD_LIMINAR = "codLiminar";

	/**
	 * Mascara de formatacao de data.
	 */
	private static final String DD_MM_YYYY = "dd/MM/yyyy";

	/*
	 * (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction#preProcessa(
	 *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public void preProcessa(ActionForm form, HttpServletRequest request)
			throws Exception {

		// Recupera o form
		AlterarLiminarForm theForm = (AlterarLiminarForm) form;

		// Obtem o servi�o
		SecaoJudiciariaServices services = 
			(SecaoJudiciariaServices) getProxy(request, 
					SecaoJudiciariaServices.class);

		// Obtem a lista de secoes judiciarias
		List<SecaoJudiciariaVO> listaSecoes = services.listar();

		theForm.setListaSecaoJudiciaria(listaSecoes);
	}

	/**
	 * 
	 * Action respons�vel por inicializar a Tela ...
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// Obtem o servi�o

		LiminarServices liminarServices = (LiminarServices) getProxy(request,
				LiminarServices.class);

		// declara��o das variaveis
		// recupera o codigo do parametro
		Long codLiminar = (Long) new Long(request.getParameter(COD_LIMINAR)
				.toString());
		LiminarVO liminar = null;
		IdentifierPK pkLiminar = new IdentifierPK(codLiminar);

		try {
			liminar = liminarServices.consultarLiminar(pkLiminar);
		} catch (Exception e) {

		}

		AlterarLiminarForm alterarForm = (AlterarLiminarForm) form;

		if (liminar != null) {
			preencherLiminarForm(liminar, alterarForm);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Metodo que preenche os campos do form
	 * 
	 * @param LiminarVO
	 *            liminar
	 */
	private void preencherLiminarForm(LiminarVO liminar, 
			AlterarLiminarForm form) {

		// popula form
		form.setTxtCassacao(liminar.getCliente().getPk().getId().toString());
		form.setTxtCliente(liminar.getCliente().getNmPessoa());

		form.setTxtDataExpedicao(liminar.getDtExpedicao().toString(DD_MM_YYYY));
		if (liminar.getDtFimVigencia() != null) {
			form.setTxtDataFim(liminar.getDtFimVigencia().toString(DD_MM_YYYY));
			form.setTxtDataFimAnterior(liminar.getDtFimVigencia()
					.toString(DD_MM_YYYY));
		}
		form.setTxtDataInicio(liminar.getDtIniVigencia().toString(DD_MM_YYYY));
		if (liminar.getNmSubsecaoJudiciaria() != null) {
			form.setTxtNomeSubsecao(liminar.getNmSubsecaoJudiciaria());
		}
		form.setTxtNumLiminar(new Long(liminar.getNuLiminar()).toString());
		form.setTxtNumSecao(new Long(
				liminar.getNuSecaoJudiciaria()).toString());
		form.setTxtNumVara(new Long(liminar.getNuVaraTramitacao()).toString());
		form.setIdLiminar(liminar.getPk().getId().toString());
		form.setIdCliente(liminar.getCliente().getPk().getId().toString());
		form.setTxtCassacao(liminar.getFlCassacaoRetroativa().toString());

	}

	/**
	 * 
	 * Action respons�vel por executar o comando de alterar.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward executarAlterar(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		// servi�o
		LiminarServices liminarServices = (LiminarServices) getProxy(request,
				LiminarServices.class);
		// form
		AlterarLiminarForm altForm = (AlterarLiminarForm) form;

		// validacoes
		ActionMessages erros = form.validate(mapping, request);
		if (erros.isEmpty()) {

			if (StringUtils.isNotBlank(altForm.getTxtDataInicio())
					&& StringUtils.isNotBlank(altForm.getTxtDataFim())) {

				BVDate dtInicio = new BVDate(altForm.getTxtDataInicio(),
						DD_MM_YYYY);
				BVDate dtFim = new BVDate(altForm.getTxtDataFim(), DD_MM_YYYY);

				// Compara as datas
				boolean result = !(dtInicio.compareTo(dtFim) > 0);

				if (!result) {
					// Intervalo de datas inv�lido
					// Data inicial maior que data final
					erros.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.liminar.periodoInvalido"));
				}
			}
			if (erros.isEmpty()) {
				try {
					// metodo que popula o objeto
					LiminarVO liminar = preencherLiminarVO(altForm, request);

					if (liminar != null) {
						vLogin usuarioLogado = (vLogin) request.getSession()
								.getAttribute(Constantes.SESSION_USER_LOGIN);
						liminarServices.atualizarLiminar(liminar, usuarioLogado
								.getUsuario());
					}
					// mensagem de sucesso
					ActionMessages messages = new ActionMessages();
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.success.liminarAlteradoComSucesso"));
					saveMessages(request, messages);
					request.setAttribute(Globals.MESSAGE_KEY, messages);

					// erros
				} catch (ValidationException e) {
					ActionMessages messages = new ActionErrors();
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.erroInesperado"));
					saveErrors(request, messages);

				} catch (LiminarDuplicadaException e) {
					ActionMessages messages = new ActionErrors();
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.liminar.liminarDuplicada"));
					saveErrors(request, messages);
				} /*catch (Exception e) {
					ActionMessages messages = new ActionErrors();
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.erroInesperado"));
					saveErrors(request, messages);
				}*/
			} else {
				saveErrors(request, erros);
			}
		} else {
			saveErrors(request, erros);
		}

		if (erros.isEmpty()) {
			// Atualiza o campo hidden de controle
			altForm.setTxtDataFimAnterior(altForm.getTxtDataFim());
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Metodo que preenche o campos do objeto.
	 * 
	 * @param AlterarLiminarForm
	 *            form.
	 * 
	 * @return LiminarVO liminar preenchida
	 * 
	 */
	private LiminarVO preencherLiminarVO(AlterarLiminarForm form, 
			HttpServletRequest request) {

		// Liminar
		Long idLiminar = new Long(form.getIdLiminar());
		IdentifierPK pkLiminar = new IdentifierPK(idLiminar);
		LiminarVO liminar = new LiminarVO(pkLiminar);

		// Pessoa
		Long idPessoa = new Long(form.getIdCliente());
		IdentifierPK pkPessoa = new IdentifierPK(idPessoa);
		PessoaVO cliente = new PessoaVO(pkPessoa);
		cliente.setNmPessoa(form.getTxtCliente());

		// servi�o
		LiminarServices liminarServices = (LiminarServices) getProxy(request,
				LiminarServices.class);
		
		try {
			// setta os atributos no objeto
			liminar.setCliente(cliente);
			if (form.getTxtCassacao().equals("SIM")) {
				liminar.setFlCassacaoRetroativa(BooleanEnum.SIM);
			} else {
				liminar.setFlCassacaoRetroativa(BooleanEnum.NAO);
			}

			liminar.setDtExpedicao(new BVDate(form.getTxtDataExpedicao(),
					DD_MM_YYYY));
			
			// recupera o codigo do parametro
			LiminarVO liminarAntiga = null;
			
			try {
				// Recupera a liminar salva para comparar as datas de fim de vigencia
				liminarAntiga = liminarServices.consultarLiminar(pkLiminar);
				
				// Se foi informada uma data fim de vigencia
				if (form.getTxtDataFim() != null
						&& StringUtils.isNotBlank(form.getTxtDataFim())) {
					
					// Recupera a data do campo
					BVDate dataFimVigencia = new BVDate(form.getTxtDataFim(), DD_MM_YYYY);
							
					// Seta a data fim de vigencia
					liminar.setDtFimVigencia(dataFimVigencia);
					
					// Se a data fim da vigencia foi alterada comparada com a antiga
					if ((liminarAntiga.getDtFimVigencia() == null)||
							(!dataFimVigencia.equals(liminarAntiga.getDtFimVigencia()))) {
						// Seta a data de informe para a data atual
						liminar.setDtInformeFimVigencia(new BVDatetime());
					} else {
						liminar.setDtInformeFimVigencia(liminarAntiga.getDtInformeFimVigencia());
					}
								
				} else {
					// caso a data fim vigencia nao seja informada
					// limpa a data informe fim vigencia
					liminar.setDtInformeFimVigencia(null);
				}

				liminar.setDtIniVigencia(new BVDate(form.getTxtDataInicio(),
						DD_MM_YYYY));
				liminar.setNuLiminar(new Long(form.getTxtNumLiminar()).longValue());
				if (StringUtils.isNotBlank(form.getTxtNomeSubsecao())) {
					liminar.setNmSubsecaoJudiciaria(form.getTxtNomeSubsecao());
				}
				liminar.setNuVaraTramitacao(new Integer(form.getTxtNumVara())
						.intValue());
				liminar.setNuSecaoJudiciaria(new Integer(form.getTxtNumSecao())
						.intValue());
				
			} catch (Exception e) {
				// Nao foi possivel consultar a liminar
			}
			
		} catch (ParseException e) {
		}

		return liminar;
	}
}
