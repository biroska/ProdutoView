// JavaScript Document
function showMensagemSucesso() {
document.getElementById("mensagemSucesso").style.display='block';
}

function scrolla(campo) {
	document.getElementById('Layer1').scrollLeft=campo.scrollLeft
}