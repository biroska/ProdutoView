package br.com.bvsistemas.dimof.web.eFinanceira.agendamento.action;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.datatype.MesVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.StatusProcessamentoVO;
import br.com.bvsistemas.dimof.services.AgendamentoServices;
import br.com.bvsistemas.dimof.services.NaturezaJuridicaServices;
import br.com.bvsistemas.dimof.services.PessoaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.util.DimofUtils;
import br.com.bvsistemas.dimof.web.eFinanceira.agendamento.form.IncluirAgendamentoForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

import com.vf.util.data.vLogin;

/**
 * Action responsavel pela funcionalidade de agendamentos.
 * 
 * @author Aimbere Galdino
 * 
 * @struts.action name="incluirAgendamentoForm" 
 *                path="/incluirAgendamento"
 *                scope="session" 
 *                parameter="operacao" 
 *                input="dimof.eFinanceira.incluirAgendamento" 
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.eFinanceira.incluirAgendamento"
 * 
 */
@SuppressWarnings("deprecation")
public class IncluirAgendamentoDispatchAction extends AbstractBaseDispatchAction {
	
	public IncluirAgendamentoDispatchAction(){}
	
	/**
	 * Inicializa a tela da agendamentos.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		IncluirAgendamentoForm theForm = (IncluirAgendamentoForm ) form;

		try {
			
			limparForm( theForm );
			
			// Obtem o servi�o
			PessoaServices pessoaService = (PessoaServices) getProxy(request, PessoaServices.class);
			
			
			List<PessoaVO> empresas = pessoaService.listarEmpresasParaAgendamento();
				
			if ( empresas != null && !empresas.isEmpty() ){
				theForm.setListaEmpresas( new ArrayList<PessoaVO>() );
				theForm.getListaEmpresas().addAll( empresas );
			}
			
	//		 metodo para verificar pendencia em razao juridica
			NaturezaJuridicaServices natJuridicaService = (NaturezaJuridicaServices) getProxy(request, NaturezaJuridicaServices.class);
			
			boolean existePendenciaNatJur = natJuridicaService.existePorFlag( "D" );
			
			if ( existePendenciaNatJur ){
				
				request.setAttribute( "EXIBE_BOTAO", "N" );
				
				ActionMessages erros = theForm.validate(mapping, request);
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.pendencia.natureza.juridica") );
				saveErrors(request, erros);
				
			} else {
				request.setAttribute( "EXIBE_BOTAO", "S" );
			}
			
		} catch (Exception e ){
			
			e.printStackTrace();
			
			ActionMessages erros = theForm.validate(mapping, request);
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.erroInesperado") );
			saveErrors(request, erros);
		}
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	/**
	 * Inicializa a tela da agendamentos.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward removerCliente(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		IncluirAgendamentoForm theForm = (IncluirAgendamentoForm ) form;
		
		if ( !StringUtils.isNumeric( theForm.getIdCliente() ) ){
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		}
		
		int clienteRemover = -1;
		
		for (int i = 0; i < theForm.getListaPessoas().size(); i++) {
			
			PessoaVO cliente = theForm.getListaPessoas().get( i );
			
			if ( cliente != null ){
				if ( cliente.getPk().getId().equals( Long.valueOf( theForm.getIdCliente() ) )  ){
					clienteRemover = i;
					break;
				}
			}
		}
		
		theForm.getListaPessoas().remove( clienteRemover );
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	/**
	 * Remove uma empresa do grid
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward removerEmpresa(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		IncluirAgendamentoForm theForm = (IncluirAgendamentoForm ) form;
		
		if ( !StringUtils.isNumeric( theForm.getIdEmpresaRemover() ) ){
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		}
		
		int empresaRemover = -1;
		
		for (int i = 0; i < theForm.getListaEmpresas().size(); i++) {
			
			PessoaVO empresa = theForm.getListaEmpresas().get( i );
			
			if ( empresa != null ){
				if ( empresa.getPk().getId().equals( Long.valueOf( theForm.getIdEmpresaRemover() ) )  ){
					empresaRemover = i;
					break;
				}
			}
		}
		
		theForm.getListaEmpresas().remove( empresaRemover );
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	/**
	 * Inicializa a tela da agendamentos.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward adicionarPessoa(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		IncluirAgendamentoForm theForm = (IncluirAgendamentoForm ) form;
		
		if ( !StringUtils.isNumeric( theForm.getIdCliente() ) ||
			  StringUtils.isBlank( theForm.getTxtCliente() ) ||
			  StringUtils.isBlank( theForm.getTxtDocumentoCliente() ) ){
			
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		}
		
		IdentifierPK pk = new IdentifierPK( Long.valueOf( theForm.getIdCliente() ) );

		PessoaVO pessoa = new PessoaVO( pk, theForm.getTxtCliente(), DimofUtils.formatarCpfCnpj( theForm.getTxtDocumentoCliente() ) );
		
		if ( !theForm.getListaPessoas().contains( pessoa ) ){
			theForm.getListaPessoas().add( pessoa );
		}
		
		theForm.setTxtCliente( null );
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
		/**
		 * salvar a tela da agendamentos.
		 * 
		 * @param mapping
		 *            ActionMapping, mapping com os atributos do struts
		 * @param form
		 *            ActionForm, formulario com os dados da tela
		 * @param request
		 *            HttpServletRequest, request do servidor
		 * @param response
		 *            HttpServletResponse, response do servidor
		 * @return ActionForward Forward de redirecionamento
		 * @throws Exception Excecao nao tratada
		 */
		public ActionForward salvar(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception {

			// Recupera o form
			IncluirAgendamentoForm theForm = (IncluirAgendamentoForm ) form;
			
			// Executa as valida��es
			ActionMessages erros = theForm.validate(mapping, request);

			if ( erros.isEmpty() ){
				validaForm( theForm, erros );
			}
			
			if ( erros.isEmpty() ){
				
				AgendamentoServices service = (AgendamentoServices) getProxy(request, AgendamentoServices.class);
					
				vLogin usuarioLogado = (vLogin) request.getSession().getAttribute( Constantes.SESSION_USER_LOGIN );
			
				AgendamentoVO agendamento = montaAgendamento(theForm.getTxtMesInicio(), theForm.getAnoInicio(),
						                                     theForm.getTxtMesFinal(), theForm.getAnoFinal() );
				
				agendamento.setUsuario( usuarioLogado.getUsuario() );
				
				service.incluirAgendamento(agendamento, theForm.getListaEmpresas(), theForm.getListaPessoas() );
				
				request.setAttribute( "EXIBE_BOTAO", "N" );
				
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage("message.success.agendamento.eFinanceira.realizadoComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				
			} else {
				// Ocorreu erro
				saveErrors(request, erros);
			}
			
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		}
	
	/**
	 * Inicializa a tela da agendamentos.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward paginacao(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	/**
	 * Volta para a pagina inicial da aplicacao.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}
	
	private void validaForm( IncluirAgendamentoForm theForm, ActionMessages erros ){
		
		boolean camposValidos = validarCamposObrigatorios(theForm, erros);
		
		if ( camposValidos ){
		
			Calendar cal1 = Calendar.getInstance();
			
			cal1.set( Calendar.MONTH, Integer.valueOf( theForm.getTxtMesInicio() ) -1 );
			cal1.set( Calendar.YEAR, Integer.valueOf( theForm.getAnoInicio() ) );
			
			Calendar cal2 = Calendar.getInstance();
			
			cal2.set( Calendar.MONTH, Integer.valueOf( theForm.getTxtMesFinal() ) -1 );
			cal2.set( Calendar.YEAR, Integer.valueOf( theForm.getAnoFinal() ) );
			
	//		Verifica se o periodo final eh superior ao inicial
			if ( cal1.compareTo( cal2 ) > 0 ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.periodoInvalido") );
				return;
			}
			
	//		Os anos devem ser iguais
			if ( !theForm.getAnoInicio().equals( theForm.getAnoFinal() ) ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.periodo.mesmo.ano") );
				return;
			}
			
	//		Se mes inicio estiver no primeiro periodo e o mes fim no segundo
	//		Os meses devem estar dentro do mesmo periodo
			if ( Integer.valueOf( theForm.getTxtMesInicio() ) -1 <= Calendar.JUNE &&
			 	 Integer.valueOf( theForm.getTxtMesFinal() ) -1 > Calendar.JUNE ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.periodo.dentro.janela.semestral") );
				return;
			}
			
	//		Verifica se o mes final � no maximo 6 meses maior do que o inicial
			cal1.add( Calendar.MONTH, Constantes.PERIODO_MAXIMO );
			if ( cal2.compareTo( cal1 ) >= 0  ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.limite.periodo.excedido",
															      Constantes.PERIODO_MAXIMO ));
				return;
			}
		}
	}

	private boolean validarCamposObrigatorios(IncluirAgendamentoForm theForm,
			ActionMessages erros) {
		
		if ( theForm.getListaEmpresas() == null || theForm.getListaEmpresas().isEmpty() ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.empresa.obrigatoria") );
			return false;
		}
		
//		Mes inicial nao preenchido
		if ( StringUtils.isBlank( theForm.getTxtMesInicio() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return false;
		}

//		ano inicial nao preenchido
		if ( StringUtils.isBlank( theForm.getAnoInicio() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return false;
		}

//		Mes Final nao preenchido
		if ( StringUtils.isBlank( theForm.getTxtMesFinal() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return false;
		}
		
//		ano final nao preenchido
		if ( StringUtils.isBlank( theForm.getAnoFinal() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return false;
		}
		
		return true;
	}
	
	private AgendamentoVO montaAgendamento( String txtMesInicio, String txtAnoInicio,
                							String txtMesFinal, String txtAnoFinal ){
		
		IdentifierPK pk = new IdentifierPK();
		AgendamentoVO agendamento = new AgendamentoVO( pk );
		
		agendamento.setStatusProcessamento( new StatusProcessamentoVO( new IdentifierPK( Constantes.CD_STATUS_AGENDADO ) ) );
		agendamento.setDtProcessamento( null );
		agendamento.setDtAtualizacao( null );
		
		Integer mesInicio = Integer.valueOf( txtMesInicio );
		Integer mesFinal = Integer.valueOf( txtMesFinal );
		Integer anoInicio = Integer.valueOf( txtAnoInicio );
		Integer anoFinal = Integer.valueOf( txtAnoFinal );
		
		agendamento.setMesInicial( new MesVO( new IdentifierPK( mesInicio ) ) );
		agendamento.setMesFinal( new MesVO( new IdentifierPK( mesFinal ) ) );
		agendamento.setAnoInicial( anoInicio );
		agendamento.setAnoFinal( anoFinal );
		
		return agendamento;
	}
	
	/**
	 * Limpa o form.
	 */
	private void limparForm(IncluirAgendamentoForm theForm) {
		
		theForm.setAnoFinal( null );
		theForm.setAnoInicio( null );
		theForm.setTxtMesFinal( null );
		theForm.setTxtMesInicio( null );
		theForm.setIdCliente( null );
		theForm.setTxtDocumentoCliente( null );
		theForm.setIdEmpresaRemover( null );
		theForm.setListaPessoas( new ArrayList<PessoaVO>() );
	}
}
