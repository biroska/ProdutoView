/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.consultar.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * <code>ActionForm</code> do UC002 Manter Liminar (Fluxo Alternativo 
 * Alterar Liminar).
 *
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 *
 * @struts.form name="alterarLiminarForm"
 *
 */
public class AlterarLiminarForm extends AbstractBaseValidatorForm {

	/**
	 * The serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;

	private String txtCliente;

	private String txtNumLiminar;

	private String txtNumVara;

	private String txtDataInicio;

	/**
	 * Data fim de vigencia. 
	 */
	private String txtDataFim;

	/**
	 * Data fim de vigencia anterior (TRANSIENT). 
	 */
	private String txtDataFimAnterior;

	private String txtDataExpedicao;

	private String txtCassacao;

	private String txtNumSecao;

	private String txtNomeSubsecao;

	private String idCliente;

	private String idLiminar;

	/**
	 * Lista de secoes judiciarias.
	 */
	private List<SecaoJudiciariaVO> listaSecaoJudiciaria;

	/**
	 * @return the txtCliente
	 */
	public String getTxtCliente() {
		return txtCliente;
	}

	/**
	 * @param txtCliente the txtCliente to set
	 */
	public void setTxtCliente(String txtCliente) {
		this.txtCliente = txtCliente;
	}

	/**
	 * @return the txtNumLiminar
	 */
	public String getTxtNumLiminar() {
		return txtNumLiminar;
	}

	/**
	 * @param txtNumLiminar the txtNumLiminar to set
	 */
	public void setTxtNumLiminar(String txtNumLiminar) {
		this.txtNumLiminar = txtNumLiminar;
	}

	/**
	 * @return the txtNumVara
	 */
	public String getTxtNumVara() {
		return txtNumVara;
	}

	/**
	 * @param txtNumVara the txtNumVara to set
	 */
	public void setTxtNumVara(String txtNumVara) {
		this.txtNumVara = txtNumVara;
	}

	/**
	 * @return the txtDataInicio
	 */
	public String getTxtDataInicio() {
		return txtDataInicio;
	}

	/**
	 * @param txtDataInicio the txtDataInicio to set
	 */
	public void setTxtDataInicio(String txtDataInicio) {
		this.txtDataInicio = txtDataInicio;
	}

	/**
	 * @return the txtDataFim
	 */
	public String getTxtDataFim() {
		return txtDataFim;
	}

	/**
	 * @param txtDataFim the txtDataFim to set
	 */
	public void setTxtDataFim(String txtDataFim) {
		this.txtDataFim = txtDataFim;
	}

	/**
	 * @return the txtDataExpedicao
	 */
	public String getTxtDataExpedicao() {
		return txtDataExpedicao;
	}

	/**
	 * @param txtDataExpedicao the txtDataExpedicao to set
	 */
	public void setTxtDataExpedicao(String txtDataExpedicao) {
		this.txtDataExpedicao = txtDataExpedicao;
	}

	/**
	 * @return the txtCassacao
	 */
	public String getTxtCassacao() {
		return txtCassacao;
	}

	/**
	 * @param txtCassacao the txtCassacao to set
	 */
	public void setTxtCassacao(String txtCassacao) {
		this.txtCassacao = txtCassacao;
	}

	/**
	 * @return the txtNumSecao
	 */
	public String getTxtNumSecao() {
		return txtNumSecao;
	}

	/**
	 * @param txtNumSecao the txtNumSecao to set
	 */
	public void setTxtNumSecao(String txtNumSecao) {
		this.txtNumSecao = txtNumSecao;
	}

	/**
	 * @return the txtNomeSubsecao
	 */
	public String getTxtNomeSubsecao() {
		return txtNomeSubsecao;
	}

	/**
	 * @param txtNomeSubsecao the txtNomeSubsecao to set
	 */
	public void setTxtNomeSubsecao(String txtNomeSubsecao) {
		this.txtNomeSubsecao = txtNomeSubsecao;
	}

	/**
	 * @return the idCliente
	 */
	public String getIdCliente() {
		return idCliente;
	}

	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}

	/**
	 * @return the idLiminar
	 */
	public String getIdLiminar() {
		return idLiminar;
	}

	/**
	 * @param idLiminar the idLiminar to set
	 */
	public void setIdLiminar(String idLiminar) {
		this.idLiminar = idLiminar;
	}

	/**
	 * @return the txtDataFimAnterior
	 */
	public String getTxtDataFimAnterior() {
		return txtDataFimAnterior;
	}

	/**
	 * @param txtDataFimAnterior the txtDataFimAnterior to set
	 */
	public void setTxtDataFimAnterior(String txtDataFimAnterior) {
		this.txtDataFimAnterior = txtDataFimAnterior;
	}

	/**
	 * @return the listaSecaoJudiciaria
	 */
	public List<SecaoJudiciariaVO> getListaSecaoJudiciaria() {
		return listaSecaoJudiciaria;
	}

	/**
	 * @param listaSecaoJudiciaria the listaSecaoJudiciaria to set
	 */
	public void setListaSecaoJudiciaria(
			List<SecaoJudiciariaVO> listaSecaoJudiciaria) {
		this.listaSecaoJudiciaria = listaSecaoJudiciaria;
	}
}
