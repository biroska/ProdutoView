/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.parametros.estorno.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.OrigemTransacaoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoEstornoVO;
import br.com.bvsistemas.dimof.datatype.TransacaoVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Classe respons�vel por armazenar as informa��es do form de Transa��es de Estorno.
 * 
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com.br">talent.ealmeida</a>
 * 
 * @struts.form name="transacaoEstornoForm"
 */
public class TransacaoEstornoForm extends AbstractBaseValidatorForm {

	/** serialVersionUID */
    	private static final long serialVersionUID = -4845456679036621057L;
    	
    	/** Identificador da Transacao de Estorno */
    	private String cdTransacaoEstorno;
    	
	/** Lista de origens */
	private List<OrigemTransacaoVO> listaOrigem;

	/** Codigo da origem */
	private String cdOrigem;
	
	/** Lista de Transa�oes	 */
	private List<TransacaoVO> listaTransacoes;
	
	/** Lista de Transa��es de estorno */
	private List<TransacaoEstornoVO> listaTransacaoEstorno;

	/** N�mero Raiz do CNPJ */
	private String raizCNPJ;
	
	/** Codigo da Transa��o */
	private String cdTransacao;
		
	
	public List<OrigemTransacaoVO> getListaOrigem() {
	    return listaOrigem;
	}

	public void setListaOrigem(List<OrigemTransacaoVO> listaOrigem) {
	    this.listaOrigem = listaOrigem;
	}

	public String getCdOrigem() {
	    return cdOrigem;
	}

	public void setCdOrigem(String cdOrigem) {
	    this.cdOrigem = cdOrigem;
	}

	public List<TransacaoVO> getListaTransacoes() {
	    return listaTransacoes;
	}

	public void setListaTransacoes(List<TransacaoVO> listaTransacoes) {
	    this.listaTransacoes = listaTransacoes;
	}

	public List<TransacaoEstornoVO> getListaTransacaoEstorno() {
	    return this.listaTransacaoEstorno;
	}

	public String getRaizCNPJ() {	    
	    return raizCNPJ == null ? raizCNPJ : raizCNPJ.trim();
	}

	public void setRaizCNPJ(String raizCNPJ) {
	    this.raizCNPJ = raizCNPJ;
	}

	public String getCdTransacao() {
	    return cdTransacao;
	}

	public void setCdTransacao(String cdTransacao) {
	    this.cdTransacao = cdTransacao;
	}

	public void setListaTransacaoEstorno(List<TransacaoEstornoVO> listaTransacaoEstorno) {
	    this.listaTransacaoEstorno = listaTransacaoEstorno;
	}

	public String getCdTransacaoEstorno() {
	    return cdTransacaoEstorno;
	}

	public void setCdTransacaoEstorno(String cdTransacaoEstorno) {
	    this.cdTransacaoEstorno = cdTransacaoEstorno;
	}
}
