/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela ....
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.form name="consultarMovimentacoesForm"
 * 
 */
public class ConsultarMovimentacoesForm extends AbstractBaseValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * semestre a ser gerado
	 */
	private String txtSemestre;
	
	private String txtAno;
	
	private String txtCliente;
	
	private List<MovimentacaoVO> listaMovimentacao;
	
	private String idCliente;
	
	private String operacao;

	/**
	 * @return the txtSemestre
	 */
	public String getTxtSemestre() {
		return txtSemestre;
	}

	/**
	 * @param txtSemestre the txtSemestre to set
	 */
	public void setTxtSemestre(String txtSemestre) {
		this.txtSemestre = txtSemestre;
	}

	/**
	 * @return the txtAno
	 */
	public String getTxtAno() {
		return txtAno;
	}

	/**
	 * @param txtAno the txtAno to set
	 */
	public void setTxtAno(String txtAno) {
		this.txtAno = txtAno;
	}

	/**
	 * @return the txtCliente
	 */
	public String getTxtCliente() {
		return txtCliente;
	}

	/**
	 * @param txtCliente the txtCliente to set
	 */
	public void setTxtCliente(String txtCliente) {
		this.txtCliente = txtCliente;
	}

	/**
	 * @return the listaMovimentacao
	 */
	public List<MovimentacaoVO> getListaMovimentacao() {
		return listaMovimentacao;
	}

	/**
	 * @param listaMovimentacao the listaMovimentacao to set
	 */
	public void setListaMovimentacao(List<MovimentacaoVO> listaMovimentacao) {
		this.listaMovimentacao = listaMovimentacao;
	}

	/**
	 * @return the idCliente
	 */
	public String getIdCliente() {
		return idCliente;
	}

	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}

	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	

	

}
