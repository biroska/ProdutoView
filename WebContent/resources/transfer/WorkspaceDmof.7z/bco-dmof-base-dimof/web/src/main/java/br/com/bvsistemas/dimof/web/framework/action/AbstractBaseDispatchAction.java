/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.framework.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.util.RequestUtils;

import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.validator.GenericTypeValidator;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.esb.services.ServiceBus;
import br.com.bvsistemas.framework.esb.services.ServiceBusProxyFactory;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.StringUtils;

import com.vf.util.data.vLogin;

/**
 * 
 * @author <a href="mailto:cmiranda@cit.com.br">cmiranda</a>
 * 
 */
public abstract class AbstractBaseDispatchAction extends DispatchAction {
	
	/**
	 * Arquivo de bundle
	 */
	private static final String APPLICATION_RESOURCES_SIC_PRECOS_PROPERTIES = "ApplicationResources_DIMOF";
	
	/**
	 * Formato padr�o de valor decimal para campos de edi��o.
	 */
	private static final String DECIMAL_FORMAT = "##########.##########";
	
	/**
	 * Properties para o arquivo de bundle
	 */
	private static ResourceBundle bundle;
	
    /** 
     * Simple date format
     * */
    private static SimpleDateFormat sdf;
    
    /** Chave no arquivo tiles-defs contendo a p�gina de erro. */
    private static final String GENERIC_ERROR = "erroGenerico";
    
	/**
	 * Objeto para gerar log.
	 */
	private static final BVLogger logger = 
		BVLogger.getLogger(AbstractBaseDispatchAction.class);
	
    static {
        if (sdf == null) {
            String formato = Constantes.DATE_PATTERN;
            sdf = new SimpleDateFormat(formato);
            sdf.setLenient(false);
        }
    }

    /*
     * @see org.apache.struts.action.Action#execute(
     * org.apache.struts.action.ActionMapping,
     * org.apache.struts.action.ActionForm,
     * javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse)
     * @param mapping mapping
     * @param form form
     * @param request request
     * @param response response
     * @return  ActionForward
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form, 
    		HttpServletRequest request, HttpServletResponse response) {

        // P�gina de retorno
        ActionForward forward = null;

        try {
        	// Chama o pr�-processamento
            preProcessa(form, request);
            forward = super.execute(mapping, form, request, response);
        } catch (Exception exc) {
            salvaExcecao(exc, request);
            forward = mapping.findForward(GENERIC_ERROR);
        }
        
        return forward;
    }

    /**
     * Executa um c�digo comum antes da opera��o especificada e da valida��o.
     *
     * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
     *
     * @param form
     *            ActionForm
     * @param request
     *            HttpServletRequest
     * @throws Exception
     *             Exce��o gerada pelo m�todo filho
     */
    public void preProcessa(ActionForm form, HttpServletRequest request)
        throws Exception {
        // Implementa��o default n�o faz nada
    }

	/**
	 * Obtem o login do usuario
	 * 
	 * @param request
	 * @return
	 */
	public vLogin obterLoginUsuario(HttpServletRequest request) {

		Object login = (vLogin) request.getSession().getAttribute(
				Constantes.SESSION_USER_LOGIN);

		return (vLogin) login;

	}

	/**
	 * Obtem o session id
	 * 
	 * @param request
	 * @return
	 */
	public String obterSessionId(HttpServletRequest request) {

		// Obtem o login do usuario
		vLogin login = obterLoginUsuario(request);

		// Caso a sess�o tenha expirado
		if (login == null)
			return null;

		return login.getSessionId();
	}

	/**
	 * 
	 * Obtem a lista de permissoes do usuario
	 * 
	 * @param request
	 * @return
	 */
	public String obtemPermissao(HttpServletRequest request) {

		return (String) request.getSession().getAttribute(
				Constantes.SESSION_PERMISSAO);

	}

	/**
	 * 
	 * Retorna interface de servi�o
	 * 
	 * @param businessInterface
	 * @param request
	 * @return
	 */
	public Object getProxy(HttpServletRequest request,
			Class... serviceInterfaces) {

		Object proxy = ServiceBusProxyFactory.getProxy(serviceInterfaces);
		ServiceBus serviceBus = (ServiceBus) proxy;
		serviceBus.setSessionId(obterSessionId(request));

		return proxy;
	}

	/**
	 * Verifica se o codigo e -1
	 * 
	 * @param selecionado
	 * @return IdentifierPK ou null
	 */
	protected IdentifierPK getIdSelecionado(String selecionado) {

		if (StringUtils.isNotEmpty(selecionado) && !selecionado.equals("-1")) {
			return new IdentifierPK(Long.parseLong(selecionado));
		} else {
			return null;
		}
	}

	/**
	 * Converte uma string para um {@link BVFloat}. O <code>valor</code>,
	 * para ser considerado v�lida N�O pode ter separador de milhar nem nenhum
	 * outro tipo caractere agrupador.
	 * 
	 * @param request -
	 *            a requisi��o corrente
	 * @param valor -
	 *            string com o n�mero a ser convertido
	 * @return null se o valor for inv�lido e um BVFloat representando o valor
	 *         caso contr�rio
	 */
	protected BVFloat converteStringParaBVFloat(HttpServletRequest request,
			String valor) {
		Locale locale = RequestUtils.getUserLocale(request, null);
		return GenericTypeValidator.formatBVFloat(valor, locale);
	}

	/**
	 * Converte um {@link BVFloat} para string a ser exibida em campo de edi��o
	 * utilizando v�rgula como separador decimal.
	 * 
	 * @param request -
	 *            a requisi��o corrente
	 * @param valor -
	 *            Valor a ser convertido para String
	 * @return null se o valor n�o for informado ou valor convertido para string
	 */
	protected String converteBVFloatParaStringEdicao(
			HttpServletRequest request, BVFloat valor) {
		if (valor != null) {
			Locale locale = RequestUtils.getUserLocale(request, null);
			return valor.toString(DECIMAL_FORMAT, locale);
		} else {
			return null;
		}
	}

	/**
	 * Cria utilitario para bundle
	 * 
	 * @return Propertie
	 * @throws IOException -
	 *             Exception caso nao consiga obter o propertie
	 */
	private ResourceBundle createPropertie() throws IOException {

		if (bundle == null) {
			bundle = ResourceBundle
					.getBundle(APPLICATION_RESOURCES_SIC_PRECOS_PROPERTIES);
		}

		return bundle;
	}

	/**
	 * Obtem os properties
	 * 
	 * @param key -
	 *            Chave a ser obtida
	 * @return - String com o valor do bundle
	 */
	protected String getPropertie(String key) {

		if (log.isDebugEnabled())
			log.debug("Obtendo propertie: " + key);

		String result = key;

		if (!GenericValidator.isBlankOrNull(key)) {

			try {
				result = createPropertie().getString(key);

				if (log.isDebugEnabled())
					log.debug("Value: " + result);

			} catch (Exception e) {
				log.error("Erro ao obter o propertie. " + e);
			}

		}

		return result;

	}
	
    /**
     * Converte um BVDate para String, utilizando o formato 
     * default 'dd/MM/yyyy'. Se a entrada for nula, retorna null.
     * 
     * @param data Data a ser convertida
     * @return Objeto String representando a data especificada.
     */
	protected String converteBVDateParaStringEdicao(final BVDate data) {
        if (data != null) {
            return sdf.format(data.getTime());
        } else {
            return null;
        }
    }

    /**
     * Salva a stack trace da excecao no request.
     * 
     * @param exception
     *            Exce��o a ser salva
     * @param request
     *            HttpServletRequest
     * 
     * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
     */
    private void salvaExcecao(Exception exception, HttpServletRequest request) {

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		pw.write(exception.getClass().getName() + "\n");
		exception.printStackTrace(pw);

		// Coloca a excess�o na request
		request.setAttribute("exception", exception.getMessage());
		request.setAttribute("stack", sw.toString());
    }
}
