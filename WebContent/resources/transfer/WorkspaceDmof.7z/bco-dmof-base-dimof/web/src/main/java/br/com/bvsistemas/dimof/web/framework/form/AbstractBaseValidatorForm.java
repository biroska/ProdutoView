/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.framework.form;

import org.apache.struts.validator.ValidatorForm;

public abstract class AbstractBaseValidatorForm extends ValidatorForm {

	/**
	 * O metodo a ser chamado pela action.
	 */
	private String operacao;

	/**
	 * O numero de paginacao da tabela na tela de consulta, utilizada para
	 * retorno.
	 */
	private String pagina;

	/**
	 * Retorna o numero de paginacao na tela de consulta, utilizada para
	 * retorno.
	 * 
	 * @return O numero da pagina na tela de consulta
	 */
	public String getPagina() {
		return pagina;
	}

	/**
	 * Seta o numero de paginacao na tela de consulta, utilizada para retorno.
	 * 
	 * @param pagina -
	 *            O numero da pagina para retornar
	 */
	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao
	 *            the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

}
