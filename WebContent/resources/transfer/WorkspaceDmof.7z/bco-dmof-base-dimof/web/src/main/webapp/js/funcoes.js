
 /*
  Para o retorno e necessario criar um metodo com o nome retorno q recebe o id
   e o nome como parametro
  exemplo

  function retorno(nome,id){
   document.forms[0].campoNome.value=nome;
     document.forms[0].campoId.value=id; 
} 

 */
/*
 * Parametrizacao para devolvar o numero do documento
 * */
function abrirPopPessoa( devolveDocumento ) { //v3.0        
      document.getElementById('div1').style.display = 'inline';
      
      var target = CTX_PATH  +'/buscaPessoa.do?operacao=prepararTela&passaDocumento=' + ( devolveDocumento == 'S' ? 'S' : 'N');            
      var pop = window.open(target,'buscaPessoa','width=650,height=440');
  
        if (window.focus){
            pop.focus();                 
          }          
 }

 //fun��o que desativa a transparencia com retorno
 function desativaTransparencia(nome, id){   
    document.getElementById('div1').style.display = 'none'; 
    retorno(nome,id);   
    
 }
 
//fun��o que desativa a transparencia com retorno
	 function desativaTransparenciaComDocumento(nome, id, cnpj){
	    document.getElementById('div1').style.display = 'none'; 
	    retorno(nome, id, cnpj);   
	    
	 }
 

    //fun��o que desativa a transparencia sem retorno
    function desativaTransparenciaclose(){
        document.getElementById('div1').style.display = 'none';
    }

    /*
     * Fecha a popup e redireciona para a tela de login.
     * Esta fun��o � chamada quando a sess�o expirar e ocorrer 
     * alguma opera��o na tela de popup.
     * Caso a tela n�o seja uma popup, a exce��o ser� capturada
     * para evitar erro de java script na p�gina.
     */
    function closePopupWindowAndRedirectToLogin() {
        try {
            window.opener.document.location = CTX_PATH;
            window.close();
        } catch (Exception) {}
    }
