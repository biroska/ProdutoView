package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;


public class DimofNaturezaJuridicaPermissao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9145989006062924416L;

	private Boolean isConsultar;
	private Boolean isAlterar;
	private Boolean isIncluir;


	public DimofNaturezaJuridicaPermissao(){
		super();
	}


	public DimofNaturezaJuridicaPermissao(Hashtable<String, String> transacoesMap){
		super();

		// Obtem a lista de transacoes para Liminar
		String listTransacoes = (String) transacoesMap
				.get("DMOF_Natureza_Juridica");

		// Seta as permissoes vindas da hash
		this.setIsAlterar(PermissaoUtils.verificaPermissao(
				"DMOF_Natureza_Juridica_Alterar", listTransacoes));

		this.setIsConsultar(PermissaoUtils.verificaPermissao(
				"DMOF_Natureza_Juridica_Consultar", listTransacoes));

		this.setIsIncluir(PermissaoUtils.verificaPermissao(
				"DMOF_Natureza_Juridica_Incluir", listTransacoes));

	}


	public Boolean getIsConsultar() {
		return isConsultar;
	}


	public void setIsConsultar(Boolean isConsultar) {
		this.isConsultar = isConsultar;
	}


	public Boolean getIsAlterar() {
		return isAlterar;
	}


	public void setIsAlterar(Boolean isAlterar) {
		this.isAlterar = isAlterar;
	}


	public Boolean getIsIncluir() {
		return isIncluir;
	}


	public void setIsIncluir(Boolean isIncluir) {
		this.isIncluir = isIncluir;
	}

}
