package br.com.bvsistemas.dimof.util.permissoes;


import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;


public class DimofAgendamentoFinanceiroPermissao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2901428014944515692L;
	/**
	 * 
	 */

	private Boolean isConsultar;
	private Boolean isCancelar;
	private Boolean isIncluir;


	public DimofAgendamentoFinanceiroPermissao(){
		super();
	}


	public DimofAgendamentoFinanceiroPermissao(Hashtable<String, String> transacoesMap){
		super();

		// Obtem a lista de transacoes para Liminar
		String listTransacoes = (String) transacoesMap
				.get("DMOF_Agendamento");

		// Seta as permissoes vindas da hash
		this.setIsCancelar(PermissaoUtils.verificaPermissao(
				"DMOF_Agendamento_Cancelar", listTransacoes));

		this.setIsConsultar(PermissaoUtils.verificaPermissao(
				"DMOF_Agendamento_Consultar", listTransacoes));

		this.setIsIncluir(PermissaoUtils.verificaPermissao(
				"DMOF_Agendamento_Incluir", listTransacoes));

	}


	public Boolean getIsConsultar() {
		return isConsultar;
	}


	public void setIsConsultar(Boolean isConsultar) {
		this.isConsultar = isConsultar;
	}


	public Boolean getIsIncluir() {
		return isIncluir;
	}


	public void setIsIncluir(Boolean isIncluir) {
		this.isIncluir = isIncluir;
	}


	public Boolean getIsCancelar() {
		return isCancelar;
	}


	public void setIsCancelar(Boolean isCancelar) {
		this.isCancelar = isCancelar;
	}

}
