/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.incluir.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.SecaoJudiciariaVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela ....
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.form name="incluirLiminarForm"
 * 
 */
public class IncluirLiminarForm extends AbstractBaseValidatorForm {

	/**
	 * The serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * campo do form com o nome do cliente
	 */
	private String txtCliente;
	
	/*
	 * Campo da flag de cassa��o
	 */
	private String flCassacao;
	
	
	/*
	 * campo com o numero da liminar.
	 */
	private String txtNumLiminar;
	
	/*
	 * Numero da Vara.
	 */
	private String txtNumVara;
	
	/*
	 * Data do Inicio da Liminar.
	 */
	private String txtDataInicio;
	
	/*
	 * Data do Fim da Vigencia
	 */
	private String txtDataFim;
	
	/*
	 * Data de Expedi��o da liminar.
	 */
	private String txtDataExpedicao;
	
	/*
	 * Flag de Cassa��o retroativo.
	 */
	private String txtRetroativa;
	
	/*
	 * Numero da secao Judiciaria.
	 */
	private String txtNumSecao;
	
	/*
	 * Nome da subsecao Judiciaria.
	 */
	private String txtNomeSubsecao;
	
	/*
	 * id do Cliente
	 */
	private String idCliente;

	/**
	 * Lista de secoes judiciarias.
	 */
	private List<SecaoJudiciariaVO> listaSecaoJudiciaria;
	

	/**
	 * @return the txtCliente
	 */
	public String getTxtCliente() {
		return txtCliente;
	}

	/**
	 * @param txtCliente the txtCliente to set
	 */
	public void setTxtCliente(String txtCliente) {
		this.txtCliente = txtCliente;
	}

	/**
	 * @return the txtNumLiminar
	 */
	public String getTxtNumLiminar() {
		return txtNumLiminar;
	}

	/**
	 * @param txtNumLiminar the txtNumLiminar to set
	 */
	public void setTxtNumLiminar(String txtNumLiminar) {
		this.txtNumLiminar = txtNumLiminar;
	}

	/**
	 * @return the txtNumVara
	 */
	public String getTxtNumVara() {
		return txtNumVara;
	}

	/**
	 * @param txtNumVara the txtNumVara to set
	 */
	public void setTxtNumVara(String txtNumVara) {
		this.txtNumVara = txtNumVara;
	}

	/**
	 * @return the txtDataInicio
	 */
	public String getTxtDataInicio() {
		return txtDataInicio;
	}

	/**
	 * @param txtDataInicio the txtDataInicio to set
	 */
	public void setTxtDataInicio(String txtDataInicio) {
		this.txtDataInicio = txtDataInicio;
	}

	/**
	 * @return the txtDataFim
	 */
	public String getTxtDataFim() {
		return txtDataFim;
	}

	/**
	 * @param txtDataFim the txtDataFim to set
	 */
	public void setTxtDataFim(String txtDataFim) {
		this.txtDataFim = txtDataFim;
	}

	/**
	 * @return the txtDataExpedicao
	 */
	public String getTxtDataExpedicao() {
		return txtDataExpedicao;
	}

	/**
	 * @param txtDataExpedicao the txtDataExpedicao to set
	 */
	public void setTxtDataExpedicao(String txtDataExpedicao) {
		this.txtDataExpedicao = txtDataExpedicao;
	}

	

	/**
	 * @return the txtNumSecao
	 */
	public String getTxtNumSecao() {
		return txtNumSecao;
	}

	/**
	 * @param txtNumSecao the txtNumSecao to set
	 */
	public void setTxtNumSecao(String txtNumSecao) {
		this.txtNumSecao = txtNumSecao;
	}

	/**
	 * @return the txtNomeSubsecao
	 */
	public String getTxtNomeSubsecao() {
		return txtNomeSubsecao;
	}

	/**
	 * @param txtNomeSubsecao the txtNomeSubsecao to set
	 */
	public void setTxtNomeSubsecao(String txtNomeSubsecao) {
		this.txtNomeSubsecao = txtNomeSubsecao;
	}

	/**
	 * @return the idCliente
	 */
	public String getIdCliente() {
		return idCliente;
	}

	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}

	/**
	 * @return the txtRetroativa
	 */
	public String getTxtRetroativa() {
		return txtRetroativa;
	}

	/**
	 * @param txtRetroativa the txtRetroativa to set
	 */
	public void setTxtRetroativa(String txtRetroativa) {
		this.txtRetroativa = txtRetroativa;
	}

	/**
	 * @return the flCassacao
	 */
	public String getFlCassacao() {
		return flCassacao;
	}

	/**
	 * @param flCassacao the flCassacao to set
	 */
	public void setFlCassacao(String flCassacao) {
		this.flCassacao = flCassacao;
	}

	/**
	 * @return the listaSecaoJudiciaria
	 */
	public List<SecaoJudiciariaVO> getListaSecaoJudiciaria() {
		return listaSecaoJudiciaria;
	}

	/**
	 * @param listaSecaoJudiciaria the listaSecaoJudiciaria to set
	 */
	public void setListaSecaoJudiciaria(
			List<SecaoJudiciariaVO> listaSecaoJudiciaria) {
		this.listaSecaoJudiciaria = listaSecaoJudiciaria;
	}
}
