/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.historico.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.HistoricoLiminarVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario da tela de consulta de Historico de liminar.
 * 
 * @author <a href="mailto:palmeida@ciandt.com">Priscila Almeida</a>
 * 
 * @struts.form name="consultarHistoricoLiminarForm"
 * 
 */
public class ConsultarHistoricoLiminarForm extends AbstractBaseValidatorForm {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * campo do form com nome cliente.
	 */	
	private String txtCliente;
	/**
	 * campo do form com id do cliente.
	 */
	private String idCliente;
	
	/**
	 * Campo com o numero da liminar.
	 */
	private String txtNumLiminar;
	
	/**
	 * Campo com a Data Inicio do periodo procurado.
	 */
	private String txtPeriodoIni;
	
	/**
	 * Data fim do periodo procurado.
	 */
	private String txtPeriodoFim;
	
	/** Lista de liminares */
	private List<HistoricoLiminarVO> listaLiminar;

	/** Operacao a ser realizada */
	private String operacao;
	
	/**
	 * @return the txtCliente
	 */
	public String getTxtCliente() {
		return txtCliente;
	}

	/**
	 * @return the listaLiminar
	 */
	public List<HistoricoLiminarVO> getListaLiminar() {
		return listaLiminar;
	}

	/**
	 * @param listaLiminar the listaLiminar to set
	 */
	public void setListaLiminar(List<HistoricoLiminarVO> listaLiminar) {
		this.listaLiminar = listaLiminar;
	}

	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	/**
	 * @param txtCliente the txtCliente to set
	 */
	public void setTxtCliente(String txtCliente) {
		this.txtCliente = txtCliente;
	}

	/**
	 * @return the txtNumLiminar
	 */
	public String getTxtNumLiminar() {
		return txtNumLiminar;
	}

	/**
	 * @param txtNumLiminar the txtNumLiminar to set
	 */
	public void setTxtNumLiminar(String txtNumLiminar) {
		this.txtNumLiminar = txtNumLiminar;
	}

	/**
	 * @return the txtPeriodoIni
	 */
	public String getTxtPeriodoIni() {
		return txtPeriodoIni;
	}

	/**
	 * @param txtPeriodoIni the txtPeriodoIni to set
	 */
	public void setTxtPeriodoIni(String txtPeriodoIni) {
		this.txtPeriodoIni = txtPeriodoIni;
	}

	/**
	 * @return the txtPeriodoFim
	 */
	public String getTxtPeriodoFim() {
		return txtPeriodoFim;
	}

	/**
	 * @param txtPeriodoFim the txtPeriodoFim to set
	 */
	public void setTxtPeriodoFim(String txtPeriodoFim) {
		this.txtPeriodoFim = txtPeriodoFim;
	}

	/**
	 * @return the idCliente
	 */
	public String getIdCliente() {
		return idCliente;
	}

	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}
	
}
