/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.clientes.buscaPessoa.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.services.PessoaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.util.StringUtils;
import br.com.bvsistemas.dimof.web.clientes.buscaPessoa.form.BuscaPessoaForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
/**
 * Action responsavel pela funcionalidade Busca de Pessoas.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.action name="buscaPessoaForm" path="/buscaPessoa" scope="request"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.clientes.buscaPessoas"
 * 
 */
public class BuscaPessoaDispatchAction extends AbstractBaseDispatchAction {
	
	
	/**
	 * 
	 * Action respons�vel por inicializar a Popup de Busca de Pessoas.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {	
		
		String passaDocumento = request.getParameter("passaDocumento");
		
		BuscaPessoaForm buscaPessoaForm = (BuscaPessoaForm) form;
		
		buscaPessoaForm.setPassaDocumento( passaDocumento );
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * 
	 * Action respons�vel por executar a pesquisa de Pessoas.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward executarPesquisa(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		/* Obtem o servi�o para obten��o de pessoas*/
		PessoaServices service = (PessoaServices) getProxy(request,
				PessoaServices.class);
		
		/* Mensagem */
		ActionMessages messages = new ActionMessages();
		
		/* Obtem instancia do form*/
		BuscaPessoaForm buscaPessoaForm = (BuscaPessoaForm) form;
		
		/*Verifica se pelo menos um dos campos foi preenchido*/
		if(buscaPessoaForm.getTxtCpfCnpj().trim().equals("") && 
				buscaPessoaForm.getTxtRazaoSocial().trim().equals("")){
			
			messages.add(Globals.MESSAGE_KEY, new ActionMessage(
					"message.error.minimoCamposPreenchido"));
			saveErrors(request, messages);
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		}
        
		/* Executa a pesquisa de pessoas*/
		List<PessoaVO> pessoas = service.listar(StringUtils.removeAccents(buscaPessoaForm
				.getTxtRazaoSocial().trim()), buscaPessoaForm.getTxtCpfCnpj().trim());
		
		
		/*setta no Form a lista de resultado*/
		buscaPessoaForm.setPessoasList(pessoas);
		
		/*Verifica resultado da consulta e lan�a erro.*/ 
		if(buscaPessoaForm.getPessoasList() == null ||
				buscaPessoaForm.getPessoasList().isEmpty()){

			messages.add(Globals.MESSAGE_KEY, new ActionMessage(
					"message.error.buscaSemRegistro"));			
			saveErrors(request, messages);		
			
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
			
		}
		

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
}
