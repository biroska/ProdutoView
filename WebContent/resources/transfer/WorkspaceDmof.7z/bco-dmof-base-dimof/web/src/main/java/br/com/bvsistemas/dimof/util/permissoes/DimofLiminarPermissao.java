package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;

/**
 * Mapeia o Objeto de permiss�es do VFAcesso
 * 
 * @author cmiranda
 * 
 */
public class DimofLiminarPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10000000094L;

	/**
	 * Atributos do objeto DimofLiminarPermissao
	 */
	private Boolean isConsultar;
	private Boolean isAlterar;
	private Boolean isIncluir;

	/**
	 * 
	 */
	public DimofLiminarPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transa��es do VFAcesso e monta o objeto
	 * 
	 * @param transacoesMap
	 */
	public DimofLiminarPermissao(Hashtable<String, String> transacoesMap) {
		super();

		// Obtem a lista de transacoes para Liminar
		String listTransacoes = (String) transacoesMap
				.get("Dimof_Liminar");

		// Seta as permissoes vindas da hash
		this.setIsAlterar(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Liminar_Alterar", listTransacoes)));

		this.setIsConsultar(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Liminar_Consultar", listTransacoes)));

		this.setIsIncluir(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Liminar_Incluir", listTransacoes)));

	}

	/**
	 * @return the isConsultar
	 */
	public Boolean getIsConsultar() {
		return isConsultar;
	}

	/**
	 * @param isConsultar
	 *            the isConsultar to set
	 */
	public void setIsConsultar(Boolean isConsultar) {
		this.isConsultar = isConsultar;
	}

	/**
	 * @return the isAlterar
	 */
	public Boolean getIsAlterar() {
		return isAlterar;
	}

	/**
	 * @param isAlterar
	 *            the isAlterar to set
	 */
	public void setIsAlterar(Boolean isAlterar) {
		this.isAlterar = isAlterar;
	}

	/**
	 * @return the isIncluir
	 */
	public Boolean getIsIncluir() {
		return isIncluir;
	}

	/**
	 * @param isIncluir
	 *            the isIncluir to set
	 */
	public void setIsIncluir(Boolean isIncluir) {
		this.isIncluir = isIncluir;
	}

}
