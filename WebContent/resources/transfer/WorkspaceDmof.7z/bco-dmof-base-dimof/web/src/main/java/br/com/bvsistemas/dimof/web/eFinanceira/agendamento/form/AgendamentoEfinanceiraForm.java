package br.com.bvsistemas.dimof.web.eFinanceira.agendamento.form;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.datatype.MesVO;
import br.com.bvsistemas.dimof.datatype.StatusProcessamentoVO;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * <code>ActionForm</code> respons�vel por armazenar as informa��es do agendamento 
 * 
 * @author Aimbere Galdino
 * 
 * @struts.form name="agendamentoEfinanceiraForm"
 * 
 */
public class AgendamentoEfinanceiraForm extends AbstractBaseValidatorForm {

	private static final long serialVersionUID = -5096370566414191636L;
	
	public AgendamentoEfinanceiraForm () {
		
		listaMeses = new ArrayList<MesVO>();
		listaMeses.addAll( DataUtils.montaListaDeMeses() );
		
		int anoCorrente = Calendar.getInstance().get( Calendar.YEAR );
		listaAnos = new ArrayList<Integer>();

		for (int ano = Constantes.ANO_INICIO; ano <= anoCorrente; ano++) {
			listaAnos.add( ano );	
		}
		
		listaStatusProcessamento = new ArrayList<StatusProcessamentoVO>();
		listaStatusProcessamento.add( new StatusProcessamentoVO( new IdentifierPK( 1 ) ) );
		listaStatusProcessamento.add( new StatusProcessamentoVO( new IdentifierPK( 2 ) ) );
		listaStatusProcessamento.add( new StatusProcessamentoVO( new IdentifierPK( 3 ) ) );
		listaStatusProcessamento.add( new StatusProcessamentoVO( new IdentifierPK( 4 ) ) );
		listaStatusProcessamento.add( new StatusProcessamentoVO( new IdentifierPK( 5 ) ) );
	}
	
	private String operacao;

	private Long codAgendamento;

	private String txtStatusProcessamento;
	private List<StatusProcessamentoVO> listaStatusProcessamento;
	
	private String txtMesInicio;
	
	private String anoInicio;
	
	private String txtMesFinal;
	
	private String anoFinal;
	
	private List<Integer> listaAnos;
	
	private List<MesVO> listaMeses;
	
	private List<AgendamentoVO> listaAgendamentos;
	
	public String getOperacao() {
		return operacao;
	}

	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}
	
	public Long getCodAgendamento() {
		return codAgendamento;
	}

	public void setCodAgendamento(Long codAgendamento) {
		this.codAgendamento = codAgendamento;
	}

	public String getTxtStatusProcessamento() {
		return txtStatusProcessamento;
	}

	public void setTxtStatusProcessamento(String txtStatusProcessamento) {
		this.txtStatusProcessamento = txtStatusProcessamento;
	}

	public List<StatusProcessamentoVO> getListaStatusProcessamento() {
		return listaStatusProcessamento;
	}

	public void setListaStatusProcessamento(
			List<StatusProcessamentoVO> listaStatusProcessamento) {
		this.listaStatusProcessamento = listaStatusProcessamento;
	}

	public String getTxtMesInicio() {
		return txtMesInicio;
	}

	public void setTxtMesInicio(String txtMesInicio) {
		this.txtMesInicio = txtMesInicio;
	}

	public String getAnoInicio() {
		return anoInicio;
	}

	public void setAnoInicio(String anoInicio) {
		this.anoInicio = anoInicio;
	}

	public String getTxtMesFinal() {
		return txtMesFinal;
	}

	public void setTxtMesFinal(String txtMesFinal) {
		this.txtMesFinal = txtMesFinal;
	}

	public String getAnoFinal() {
		return anoFinal;
	}

	public void setAnoFinal(String anoFinal) {
		this.anoFinal = anoFinal;
	}
	
	public List<Integer> getListaAnos() {
		return listaAnos;
	}

	public void setListaAnos(List<Integer> listaAnos) {
		this.listaAnos = listaAnos;
	}

	public List<MesVO> getListaMeses() {
		return listaMeses;
	}

	public void setListaMeses(List<MesVO> listaMeses) {
		this.listaMeses = listaMeses;
	}

	public List<AgendamentoVO> getListaAgendamentos() {
		return listaAgendamentos;
	}

	public void setListaAgendamentos(List<AgendamentoVO> listaAgendamentos) {
		this.listaAgendamentos = listaAgendamentos;
	}
}