/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.util;

/**
 * 
 * Classe com as principais constantes para a camada de apresentacao
 * 
 * @author cit.mcardoso
 * 
 */
public class Constantes {

	/**
	 * Chave para o parametro id da request
	 */
	public static final String REQUEST_PARAM_ID = "id";

	/**
	 * Chave para o campo raz�o social
	 */
	public static final String REQUEST_PARAM_RAZAO_SOCIAL_FIELD = "rzSocial";

	/**
	 * Constante para as permissoes do usuario
	 */
	public static final String SESSION_PERMISSAO = "SESSION_PERMISSAO";

	/**
	 * Constante para o login do usuario
	 */
	public static final String SESSION_USER_LOGIN = "SESSION_USER_LOGIN";

	/**
	 * Chaves para o bundle do sistema
	 */
	public static final String BUNDLE_LOGIN_ERRO = "login.erro";

	/**
	 * Constante de forward para home
	 */
	public static final String FORWARD_HOME = "home";

	/**
	 * Constante de forward para pagina principal
	 */
	public static final String FORWARD_PAGINA_PRINCIPAL = "paginaPrincipal";
	
    /** 
     * Constante que representa o pattern de data
     * */
    public static final String DATE_PATTERN = "dd/MM/yyyy";
    
    /**
	 * Constante de forward para home
	 */
	public static final String SIM = "Sim";
	
	/**
	 * Constante de forward para home
	 */
	public static final String NAO = "N�o";

    /** 
     * Constante que representa o status do tipo "N�o processado".
     */
    public static final int STATUS_NAO_PROCESSADO = 0;

    /** 
     * Constante que representa o status do tipo "Em Processamento".
     */
    public static final int STATUS_EM_PROCESSAMENTO = 1;

    /** 
     * Constante que representa o status do tipo "Processado".
     */
    public static final int STATUS_PROCESSADO = 2;

    /** 
     * Constante que representa o status do tipo "Erro".
     */
    public static final int STATUS_ERRO = 3;

    /** 
     * Ano de inicio padrao para o sistema.
     */
    public static final int ANO_INICIO = 2014;
    
    /** 
     * Quantidade de meses que define o periodo maximo para o agendamento.
     */
    public static final int PERIODO_MAXIMO = 6;
    
    /** 
     * Constante que representa o status do processamento do agendamento "Cancelado".
     */
    public static final int CD_STATUS_AGENDADO = 1;
    public static final int CD_STATUS_GERADO = 2;
    public static final int CD_STATUS_GERADO_RESTRICOES = 3;
    public static final int CD_STATUS_ERRO_PROCESSAMENTO = 4;
    public static final int CD_STATUS_CANCELADO = 5;
}
