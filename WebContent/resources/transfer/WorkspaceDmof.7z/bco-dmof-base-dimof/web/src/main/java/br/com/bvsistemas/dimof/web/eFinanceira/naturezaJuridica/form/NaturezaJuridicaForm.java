package br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.form;


import java.util.List;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela ....
 * 
 * @struts.form name="naturezaJuridicaForm"
 * 
 */

public class NaturezaJuridicaForm extends AbstractBaseValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3276435858920605293L;
	
	
	private String operacao;
	private String cdNaturezaJuridica;
	private String txtCodigoNaturezaJuridica;
	private String txtNmNaturezaJuridica;
	private String txtEfinanceira;
	private List<NaturezaJuridicaVO> listaNaturezaJuridica;
	
	public String getOperacao() {
		return operacao;
	}
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}
	public String getCdNaturezaJuridica() {
		return cdNaturezaJuridica;
	}
	public void setCdNaturezaJuridica(String cdNaturezaJuridica) {
		this.cdNaturezaJuridica = cdNaturezaJuridica;
	}
	public String getTxtCodigoNaturezaJuridica() {
		return txtCodigoNaturezaJuridica;
	}
	public void setTxtCodigoNaturezaJuridica(String txtCodigoNaturezaJuridica) {
		this.txtCodigoNaturezaJuridica = txtCodigoNaturezaJuridica;
	}
	public String getTxtNmNaturezaJuridica() {
		return txtNmNaturezaJuridica;
	}
	public void setTxtNmNaturezaJuridica(String txtNmNaturezaJuridica) {
		this.txtNmNaturezaJuridica = txtNmNaturezaJuridica;
	}
	public String getTxtEfinanceira() {
		return txtEfinanceira;
	}
	public void setTxtEfinanceira(String txtEfinanceira) {
		this.txtEfinanceira = txtEfinanceira;
	}
	public List<NaturezaJuridicaVO> getListaNaturezaJuridica() {
		return listaNaturezaJuridica;
	}
	public void setListaNaturezaJuridica(
			List<NaturezaJuridicaVO> listaNaturezaJuridica) {
		this.listaNaturezaJuridica = listaNaturezaJuridica;
	}	
}

