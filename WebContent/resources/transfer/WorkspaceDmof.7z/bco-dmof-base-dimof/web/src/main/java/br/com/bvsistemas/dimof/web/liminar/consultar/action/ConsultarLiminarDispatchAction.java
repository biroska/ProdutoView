/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.consultar.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.services.LiminarServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.liminar.consultar.form.ConsultarLiminarForm;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.utils.BVEnumUtils;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Action responsavel pela funcionalidade de consultar liminares.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 * 
 * @struts.action name="consultarLiminarForm" 
 *                path="/consultarLiminar"
 *                scope="session" 
 *                parameter="operacao" 
 *                input="dimof.liminar.consultarLiminar" 
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.liminar.consultarLiminar"
 * 
 * @struts.action-forward name="home" 
 *                        path="dimof.home"
 * 
 */
public class ConsultarLiminarDispatchAction extends AbstractBaseDispatchAction {

	/**
	 * Mascara de formatacao de data.
	 */
	private static final String DD_MM_YYYY = "dd/MM/yyyy";

	/**
	 * Inicializa a tela da consulta.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		ConsultarLiminarForm theForm = (ConsultarLiminarForm) form;
		
		// Limpa o form
		limparForm(theForm);

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Realiza a consulta de liminares.
	 * 
	 * @param mapping
	 *            O ActionMapping utilizado para escolher essa inst�ncia.
	 * @param form
	 *            O ActionForm relativo � a��o corrente.
	 * @param request
	 *            Objeto com dados da requisi��o HTTP.
	 * @param response
	 *            Objeto com dados da resposta HTTP.
	 * 
	 * @return ActionForward para onde o fluxo deve ser direcionado.
	 * 
	 * @throws Exception
	 *             Se ocorrer qualquer erro n�o trat�vel pela aplica��o.
	 */
	public ActionForward listar(ActionMapping mapping, 
			ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {

		// Obtem o servi�o
		LiminarServices liminarServices = 
			(LiminarServices) getProxy(request, LiminarServices.class);

		// Recupera o form
		ConsultarLiminarForm theForm = (ConsultarLiminarForm) form;

		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		// Recupera os campos do filtro da pesquisa
		String strCdCliente = theForm.getCdCliente();
		String strNuLiminar = theForm.getNuLiminar();
		String strDtInicioVigencia = theForm.getDtInicioVigencia();
		String strDtFimVigencia = theForm.getDtFimVigencia();
		String strSomenteVigentes = theForm.getSomenteVigentes();

		if (erros.isEmpty()) {
			// Verifica obrigatoriedade de campos
			if (StringUtils.isBlank(strCdCliente) 
					&& StringUtils.isBlank(strNuLiminar)
					&& StringUtils.isBlank(strDtInicioVigencia) 
					&& StringUtils.isBlank(strDtFimVigencia)
					&& StringUtils.isBlank(strSomenteVigentes)) {
				// Nenhum campo preenchido
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.liminar.camposObrigatorios"));
			} else if (StringUtils.isNotBlank(strDtInicioVigencia) 
					&& StringUtils.isBlank(strDtFimVigencia)) {
				// Data inicial preenchida e final n�o preenchida
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.liminar.camposObrigatorios"));
			} else if (StringUtils.isBlank(strDtInicioVigencia) 
					&& StringUtils.isNotBlank(strDtFimVigencia)) {
				// Data inicial n�o preenchida e final preenchida
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.liminar.camposObrigatorios"));
			} else if (StringUtils.isNotBlank(strDtInicioVigencia) 
					&& StringUtils.isNotBlank(strDtFimVigencia)) {
	
				BVDate dtInicio = new BVDate(strDtInicioVigencia, DD_MM_YYYY);
				BVDate dtFim = new BVDate(strDtFimVigencia, DD_MM_YYYY);
	
				// Compara as datas
				boolean result = !(dtInicio.compareTo(dtFim) > 0);
	
				if (!result) {
					// Intervalo de datas inv�lido
					// Data inicial maior que data final
					erros.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.periodoInvalido"));
				}
			}
		}
		

		if (erros.isEmpty()) {
			IdentifierPK pkPessoa = null;
			if (StringUtils.isNotBlank(strCdCliente)) {
				pkPessoa = new IdentifierPK(new Long(strCdCliente));
			}

			if (StringUtils.isNotBlank(strNuLiminar)) {
				strNuLiminar = strNuLiminar.trim();
			}

			BVDate dtInicioVigencia = null;
			if (StringUtils.isNotBlank(strDtInicioVigencia)) {
				dtInicioVigencia = new BVDate(strDtInicioVigencia, 
						Constantes.DATE_PATTERN);
			}

			BVDate dtFimVigencia = null;
			if (StringUtils.isNotBlank(strDtFimVigencia)) {
				dtFimVigencia = new BVDate(strDtFimVigencia, 
						Constantes.DATE_PATTERN);
			}

			BooleanEnum somenteVigentes = null;
			if (StringUtils.isNotBlank(strSomenteVigentes)) {
				somenteVigentes = BVEnumUtils.getEnum(
						BooleanEnum.class, new Character('S'));
			}

			// Chama o servi�o da consulta
			List<LiminarVO> listaLiminar = liminarServices.listar(pkPessoa, 
					strNuLiminar, dtInicioVigencia, dtFimVigencia, 
					somenteVigentes);

			// Verifica o resultado da consulta
			if((listaLiminar == null) || (listaLiminar.isEmpty())) {
				// N�o h� retorno de dados 
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.buscaSemRegistro"));			
				saveErrors(request, messages);

				// Limpa a lista de resultados da cosnulta
				theForm.setListaLiminar(null);
				
			} else {
				// Seta lista de resultados da cosnulta
				theForm.setListaLiminar(listaLiminar);
			}
		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Volta para a pagina inicial da aplicacao.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}

	/**
	 * Limpa o form.
	 */
	private void limparForm(ConsultarLiminarForm theForm) {
		theForm.setCdCliente(null);
		theForm.setNmCliente(null);
		theForm.setNuLiminar(null);
		theForm.setDtInicioVigencia(null);
		theForm.setDtFimVigencia(null);
		theForm.setSomenteVigentes(null);
		theForm.setListaLiminar(null);
	}
}
