/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.framework.validator;

import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Locale;

import br.com.bvsistemas.framework.datatype.BVFloat;

/**
 * Esta classe cont�m m�todos b�sicos que fazem valida��es e retornam o objeto
 * devidamente tipado pra a classe cuja a valida��o foi executada.
 * 
 * @author cit.fuechi
 * 
 */
public class GenericTypeValidator extends
		org.apache.commons.validator.GenericTypeValidator {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = -3819278099381018076L;
	
	/**
	 * Caracter a ser substituido na formatacao de String para BVFloat. 
	 */
	private static final char OLD_CHAR = ',';
	
	/**
	 * Novo caracter a ser usado na formatacao de String para BVFloat. 
	 */
	private static final char NEW_CHAR = '.';

	/**
	 * Checa se o valor podes ser convertido para  {@link BVFloat}
	 * 
	 * @param value
	 *            The value validation is being performed on.
	 * @param locale
	 *            The locale to use to parse the number (system default if null)
	 * @return o {@link BVFloat} convertido.
	 */
	public static BVFloat formatBVFloat(String value, Locale locale) {

		BVFloat result = null;

		if (value != null) {
			NumberFormat formatter = null;
			if (locale != null) {
				formatter = NumberFormat.getInstance(locale);
			} else {
				formatter = NumberFormat.getInstance(Locale.getDefault());
			}

			formatter.setGroupingUsed(false);
			ParsePosition pos = new ParsePosition(0);
			Number num = formatter.parse(value, pos);

			// If there was no error and we used the whole string
			if (pos.getErrorIndex() == -1 && pos.getIndex() == value.length()) {
				if (num.doubleValue() >= (Double.MAX_VALUE * -1)
						&& num.doubleValue() <= Double.MAX_VALUE) {
					result = new BVFloat(value.replace(OLD_CHAR, NEW_CHAR));
				}
			}
		}

		return result;
	}

}
