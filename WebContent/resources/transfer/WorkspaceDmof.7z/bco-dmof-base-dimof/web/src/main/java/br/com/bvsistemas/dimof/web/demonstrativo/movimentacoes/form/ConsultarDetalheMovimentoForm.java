/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.util.DimofUtils;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Form com os detalhes de movimenta��o do cliente
 * 
 * @author elias.yoshida
 * @struts.form name="consultarDetalheMovimentoForm"
 */
public class ConsultarDetalheMovimentoForm extends AbstractBaseValidatorForm {

	private static final long serialVersionUID = 1L;

	/**
	 * codigo da Pessoa
	 */
	private String cdPessoa;
	
	/**
	 * nome da Pessoa
	 */
	private String nmPessoa;
	
	/**
	 * cpf / cnpj da Pessoa
	 */
	private String nuCpfCnpj;
	
	/**
	 * tipo da Pessoa
	 */
	private String tpPessoa;
	
	/**
	 * numero da conta da Pessoa
	 */
	private String nuContaCorrente;
	
	/**
	 * semestre a ser gerado
	 */
	private String txtSemestre;
	
	/**
	 * ano a ser gerado
	 */
	private String txtAno;
	
	/**
	 * Lista de detalhe de movimento de conta corrente
	 */
	private List<DetalheMovimentoCCVO> listaDetalheMovimentoCC;
	
	/**
	 * Lista de detalhe de movimento de cambio
	 */
	private List<DetalheMovimentoCambioVO> listaDetalheMovimentoCambio;
	
	// ******************************
	// metodos getter's e setter's
	// ******************************
	public String getCdPessoa() {
		return cdPessoa;
	}
	public void setCdPessoa(String cdPessoa) {
		this.cdPessoa = cdPessoa;
	}
	public String getNmPessoa() {
		return nmPessoa;
	}
	public void setNmPessoa(String nmPessoa) {
		this.nmPessoa = nmPessoa;
	}
	public String getNuCpfCnpj() {
		return nuCpfCnpj;
	}
	public String getNuCpfCnpjFormatado() {
		return DimofUtils.formatarCpfCnpj(nuCpfCnpj);
	}	
	public void setNuCpfCnpj(String nuCpfCnpj) {
		this.nuCpfCnpj = nuCpfCnpj;
	}
	public String getTpPessoa() {
		return tpPessoa;
	}
	public void setTpPessoa(String tpPessoa) {
		this.tpPessoa = tpPessoa;
	}	
	public String getNuContaCorrente() {
		return nuContaCorrente;
	}
	public void setNuContaCorrente(String nuContaCorrente) {
		this.nuContaCorrente = nuContaCorrente;
	}
	public List<DetalheMovimentoCCVO> getListaDetalheMovimentoCC() {
		return listaDetalheMovimentoCC;
	}
	public void setListaDetalheMovimentoCC(List<DetalheMovimentoCCVO> listaDetalheMovimentoCC) {
		this.listaDetalheMovimentoCC = listaDetalheMovimentoCC;
	}
	public List<DetalheMovimentoCambioVO> getListaDetalheMovimentoCambio() {
		return listaDetalheMovimentoCambio;
	}
	public void setListaDetalheMovimentoCambio(List<DetalheMovimentoCambioVO> listaDetalheMovimentoCambio) {
		this.listaDetalheMovimentoCambio = listaDetalheMovimentoCambio;
	}
	public String getTxtSemestre() {
		return txtSemestre;
	}
	public void setTxtSemestre(String txtSemestre) {
		this.txtSemestre = txtSemestre;
	}
	public String getTxtAno() {
		return txtAno;
	}
	public void setTxtAno(String txtAno) {
		this.txtAno = txtAno;
	}

}
