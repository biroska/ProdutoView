/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.parametrizacao.action;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.ValidationException;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.ParametrizacaoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.services.ParametrizacaoNaturezaJuridicaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.parametrizacao.form.ParametrizacaoNaturezaJuridicaForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.utils.StringUtils;

import com.vf.util.data.vLogin;

/**
 * Action responsavel pela funcionalidade de consultar parametrizacoes.
 * 
 * @author <a href="mailto:resource.rtomiyama@bvsistemas.com.br">Ricardo Takeshi</a>
 * 
 * @struts.action name="parametrizacaoNaturezaJuridicaForm" 
 *                path="/parametrizacaoNaturezaJuridica"
 *                scope="session" 
 *                parameter="operacao" 
 *                input="dimof.eFinanceira.naturezaJuridica.parametrizacao" 
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.eFinanceira.naturezaJuridica.parametrizacao"
 * 
 * @struts.action-forward name="home" 
 *                        path="dimof.home"
 * 
 */
@SuppressWarnings("deprecation")
public class ParametrizacaoNaturezaJuridicaDispatchAction extends AbstractBaseDispatchAction {

	
	/**
	 * Constante nome do parametro
	 */
	private static final String CD_PARAMETRIZACAO_NATUREZA_JURIDICA = "cdParametrizacaoNaturezaJuridica";
	private static final String CD_NATUREZA_JURIDICA = "cdNaturezaJuridica";
	private static final String DT_INICIO_VIGENCIA = "inicioVigencia";
	private static final String FL_ENVIA_EFINANCEIRA = "flEnviaInformacaoEFinanceira";
	//private final String DT_INICIO_VIGENCIA = "dtInicioVigencia";
	
	private static final int CT_ANO_VALIDO = 1970;
	
	//private static final String DD_MM_YYYY = "dd/MM/yyyy";
	
	/**
	 * Inicializa a tela da consulta.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		// Recupera o form
		ParametrizacaoNaturezaJuridicaForm parametrizacaoForm = (ParametrizacaoNaturezaJuridicaForm) form;
		ParametrizacaoNaturezaJuridicaServices service = (ParametrizacaoNaturezaJuridicaServices) getProxy(request,
				ParametrizacaoNaturezaJuridicaServices.class);				
		
		//limparForm(parametrizacaoForm);			
		parametrizacaoForm.setFlEnviaInformacaoEFinanceira(null);
		parametrizacaoForm.setMesInicioVigencia(null);
		parametrizacaoForm.setAnoInicioVigencia(null);
		
		// recupera parametros
		String cdNaturezaJuridica = request.getParameter(CD_NATUREZA_JURIDICA).toString();
		
		parametrizacaoForm.setCdNaturezaJuridica(cdNaturezaJuridica);
		
		parametrizacaoForm.setNmNaturezaJuridica(service.getNomeNaturezaJuridica(cdNaturezaJuridica));
		
		parametrizacaoForm.setPkParametrizacao(new IdentifierPK());
		parametrizacaoForm.setListaParametrizacoesNaturezaJuridica(obterParametrizacoes(parametrizacaoForm.getCdNaturezaJuridica(), request));
		
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	
	/**
	 * Inicializa a tela da consulta.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTelaInclusao(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		// Recupera o form
		ParametrizacaoNaturezaJuridicaForm parametrizacaoForm = (ParametrizacaoNaturezaJuridicaForm) form;
				
		//limparForm(parametrizacaoForm);			
		parametrizacaoForm.setFlEnviaInformacaoEFinanceira(null);
		parametrizacaoForm.setMesInicioVigencia(null);
		parametrizacaoForm.setAnoInicioVigencia(null);

		
		parametrizacaoForm.setPkParametrizacao(new IdentifierPK());
		parametrizacaoForm.setListaParametrizacoesNaturezaJuridica(obterParametrizacoes(parametrizacaoForm.getCdNaturezaJuridica(), request));		
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}	
	
	/**
	 * Inicializa a tela da consulta.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTelaAlteracaoParametrizacao(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		ParametrizacaoNaturezaJuridicaForm parametrizacaoForm = (ParametrizacaoNaturezaJuridicaForm) form;
				
		
		// recupera parametros
		String strPK = request.getParameter(CD_PARAMETRIZACAO_NATUREZA_JURIDICA).toString();		
		//String strInicioVigencia = request.getParameter(INICIO_VIGENCIA).toString();		
		String strFlEnviaInformacaoEFInanceira = request.getParameter(FL_ENVIA_EFINANCEIRA).toString();		
		String txtDataInicioVigencia = request.getParameter(DT_INICIO_VIGENCIA).toString();
				
		if (!strPK.equalsIgnoreCase("")) {			
			parametrizacaoForm.setPkParametrizacao(new IdentifierPK(new Integer(strPK)));			
			parametrizacaoForm.setFlEnviaInformacaoEFinanceira(strFlEnviaInformacaoEFInanceira);
						
			Date data  = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			data = sdf.parse(txtDataInicioVigencia);
						
			Calendar cal = Calendar.getInstance();
			cal.setTime(data);
			//cal.set( Calendar.MONTH, Integer.valueOf( theForm.getTxtMesInicio() ) -1 );
			//cal.set( Calendar.YEAR, Integer.valueOf( theForm.getAnoInicio() ) );
			
			
			parametrizacaoForm.setDtInicioVigencia(new BVDate(data));
			
			parametrizacaoForm.setMesInicioVigencia(cal.get(Calendar.MONTH)+1);
			parametrizacaoForm.setAnoInicioVigencia(cal.get(Calendar.YEAR));
		}
			
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}	
	
//	/**
//	 * Volta para a pagina inicial da aplicacao.
//	 * 
//	 * @param mapping 
//	 *            O mapeamento da action
//	 * @param form 
//	 *            O form de alteracao
//	 * @param request 
//	 *            O request recebido
//	 * @param response 
//	 *            A response recebida
//	 * @return ActionForward 
//	 *             A acao enviada
//	 * @throws Exception 
//	 *             Excecao da acao do struts
//	 */
//	public ActionForward fechar(ActionMapping mapping, ActionForm form,
//			HttpServletRequest request, HttpServletResponse response)
//			throws Exception {
//
//		return mapping.findForward(Constantes.FORWARD_HOME);
//	}	
	
	/**
	 * Inicializa a tela da consulta.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward salvarParametrizacao(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		ParametrizacaoNaturezaJuridicaForm parametrizacaoForm = (ParametrizacaoNaturezaJuridicaForm) form;
				
		ActionMessages erros = parametrizacaoForm.validate(mapping, request);
		
		// recupera o codigo do parametro
		IdentifierPK pk = parametrizacaoForm.getPkParametrizacao();
		
		if (erros.isEmpty()) {
			// Verifica obrigatoriedade de campos
			if (StringUtils.isBlank(parametrizacaoForm.getFlEnviaInformacaoEFinanceira()) 
					|| parametrizacaoForm.getMesInicioVigencia() == 0
					|| parametrizacaoForm.getAnoInicioVigencia() == 0) {
					//|| parametrizacaoForm.getAnoInicioVigencia() == 0) {
				// Nenhum campo preenchido
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.parametrizacaoNaturezaJuridica.camposObrigatorios"));
			}
			// Verifica se ano de in�cio de vig�ncia � ano v�lido
			else if (parametrizacaoForm.getAnoInicioVigencia() < CT_ANO_VALIDO) {
					erros.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.parametrizacaoNaturezaJuridica.anoVigenciaInvalido", 
							CT_ANO_VALIDO));
					
			}			
			// Verifica se esta alterando ou incluindo um in�cio de vig�ncia que j� existe
			else if (verificaRegistroDuplicado(parametrizacaoForm)) {
					erros.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.parametrizacaoNaturezaJuridica.registroDuplicado", 
							parametrizacaoForm.getListaMeses().get(parametrizacaoForm.getMesInicioVigencia()-1).getNomeMes() + "/" + 
									(parametrizacaoForm.getAnoInicioVigencia())));
			}
			
			if (erros.isEmpty()) {			
			
				processaAtualizacao(request, parametrizacaoForm, pk);
				
				
				// mensagem sucesso
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.success.parametrizacaoSalvaComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				
				//limparForm(parametrizacaoForm);			
				parametrizacaoForm.setFlEnviaInformacaoEFinanceira(null);
				parametrizacaoForm.setMesInicioVigencia(null);
				parametrizacaoForm.setAnoInicioVigencia(null);
				
				parametrizacaoForm.setListaParametrizacoesNaturezaJuridica(obterParametrizacoes(parametrizacaoForm.getCdNaturezaJuridica(), request));
				
				
				parametrizacaoForm.setPkParametrizacao(new IdentifierPK());
				
				return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
				
			}
			else {
				saveErrors(request, erros);
			}
		} else {
			saveErrors(request, erros);

		}
			
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}


	private void processaAtualizacao(HttpServletRequest request,
			ParametrizacaoNaturezaJuridicaForm parametrizacaoForm,
			IdentifierPK pk) throws Exception, ValidationException,
			CamposObrigatoriosNaoPreenchidosException {
		vLogin usuarioLogado = (vLogin) request.getSession()
				.getAttribute(Constantes.SESSION_USER_LOGIN);
		
		
		List<ParametrizacaoNaturezaJuridicaVO> listaAtualizacao;
		listaAtualizacao = preparaListaAtualizacaoParametrizacoes(parametrizacaoForm, pk, usuarioLogado.getUsuario());				
						
		ParametrizacaoNaturezaJuridicaServices service = (ParametrizacaoNaturezaJuridicaServices) getProxy(request,
				ParametrizacaoNaturezaJuridicaServices.class);

		for (Iterator<ParametrizacaoNaturezaJuridicaVO> iterator = listaAtualizacao.iterator(); iterator.hasNext(); ) {
			ParametrizacaoNaturezaJuridicaVO parametrizacao = (ParametrizacaoNaturezaJuridicaVO) iterator.next();
			
			if (parametrizacao.getPk().getId() == null) {
				service.incluirParametrizacao(parametrizacao);
			}
			else {
				service.atualizarParametrizacao(parametrizacao);
			}
			
		}
	}	

	
	/**
	 * Verifica se a data de in�cio de vig�ncia inclu�da ou alterada j� est� registrado.
	 * 
	 * @param  pk
	 *            pk do registro (null se inclus�o)
	 * @return boolean 
	 *             true se o registro j� existe e false cc
	 */
	private boolean verificaRegistroDuplicado(ParametrizacaoNaturezaJuridicaForm parametrizacaoForm) throws Exception {
		List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoes = parametrizacaoForm.getListaParametrizacoesNaturezaJuridica();
		
		DecimalFormat df = new DecimalFormat("00");
		String txtDataInclusao;
		BVDate dtInclusao;
		txtDataInclusao = (parametrizacaoForm.getAnoInicioVigencia()).toString().
				concat(df.format(parametrizacaoForm.getMesInicioVigencia())).concat("01");		
		
		dtInclusao = new BVDate(txtDataInclusao);
		
		for (Iterator<ParametrizacaoNaturezaJuridicaVO> iterator = listaParametrizacoes.iterator(); iterator.hasNext(); ) {
			ParametrizacaoNaturezaJuridicaVO parametrizacao = (ParametrizacaoNaturezaJuridicaVO) iterator.next();
			
			if (parametrizacao.getDtInicioVigencia().compareTo(dtInclusao) == 0 && 
					(parametrizacaoForm.getPkParametrizacao().getId() == null || 
							parametrizacaoForm.getPkParametrizacao().getId().longValue() != parametrizacao.getPk().getId().longValue())) {
				// In�cio de Vig�ncia duplicada
				return true;						
			}			
		}
		return false;
	}
	
	
	private List<ParametrizacaoNaturezaJuridicaVO> obterParametrizacoes(String cdNaturezaJuridica,
			HttpServletRequest request) throws Exception {
		List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoes;
		
		// Obtem o servi�o
		ParametrizacaoNaturezaJuridicaServices parametrizacaoNaturezaJuridicaServices = 
			(ParametrizacaoNaturezaJuridicaServices) getProxy(request, ParametrizacaoNaturezaJuridicaServices.class);

		
		listaParametrizacoes = parametrizacaoNaturezaJuridicaServices.listarParametrizacoes(cdNaturezaJuridica);	
		
		
		return listaParametrizacoes;
	}
	

	//@SuppressWarnings("unchecked")
	private List<ParametrizacaoNaturezaJuridicaVO> preparaListaAtualizacaoParametrizacoes (
			ParametrizacaoNaturezaJuridicaForm parametrizacaoForm, IdentifierPK pk, String usuarioLogado) throws Exception {
		
		List<ParametrizacaoNaturezaJuridicaVO> listaParametrizacoes = parametrizacaoForm.getListaParametrizacoesNaturezaJuridica();
		
		Map<BVDate, ParametrizacaoNaturezaJuridicaVO> mapParametrizacoes = new HashMap<BVDate, ParametrizacaoNaturezaJuridicaVO>();
		ArrayList<BVDate> dtInicioVigencias = new ArrayList<BVDate>();
		
		//Calendar cal = Calendar.getInstance();		
		DecimalFormat df = new DecimalFormat("00");
		String txtDataInclusao;
		ParametrizacaoNaturezaJuridicaVO dadosParametrizacao;
		
		txtDataInclusao = (parametrizacaoForm.getAnoInicioVigencia().toString()).
				concat(df.format(parametrizacaoForm.getMesInicioVigencia())).concat("01");		
		
		BVDate dtInclusao;
						
		dtInclusao = new BVDate(txtDataInclusao, "yyyyMMdd");
		
		
		//Se inclus�o
		if (pk.getId() == null) {
			IdentifierPK newPk = new IdentifierPK();
			dadosParametrizacao = new ParametrizacaoNaturezaJuridicaVO(newPk);
			dadosParametrizacao.setCdNaturezaJuridica(parametrizacaoForm.getCdNaturezaJuridica());				
			//dadosParametrizacao.setFlEnviaInformacaoEFinanceira(
			//		parametrizacaoForm.getFlEnviaInformacaoEFinanceira().equalsIgnoreCase("Sim")?"S":"N");
			dadosParametrizacao.setFlEnviaInformacaoEFinanceira(parametrizacaoForm.getFlEnviaInformacaoEFinanceira());
			
			dadosParametrizacao.setDtInicioVigencia(dtInclusao);		
			dadosParametrizacao.setDsLogin(usuarioLogado);
			// Ser� atualizado na montagem da lista de atualiza��es
			dadosParametrizacao.setDtInclusao(new BVDatetime(new Date())); //dadosParametrizacao.setDtInclusao(null); //new BVDate(new Date()));		
			//dadosParametrizacao.setDtInicioVigencia(null);		
			mapParametrizacoes.put(dtInclusao, dadosParametrizacao);
			
			dtInicioVigencias.add(dtInclusao);
		}
		
		for (Iterator<ParametrizacaoNaturezaJuridicaVO> iterator = listaParametrizacoes.iterator(); iterator.hasNext(); ) {
			ParametrizacaoNaturezaJuridicaVO parametrizacao = (ParametrizacaoNaturezaJuridicaVO) iterator.next();

			// Se altera��o e data inicio != data inicio anterior a altera��o 
			if (pk.getId() != null && pk.getId().longValue() == parametrizacao.getPk().getId().longValue()) {
				parametrizacao.setFlEnviaInformacaoEFinanceira(parametrizacaoForm.getFlEnviaInformacaoEFinanceira());
				mapParametrizacoes.put(dtInclusao, parametrizacao);
				dtInicioVigencias.add(dtInclusao);				
			}
			else {
				mapParametrizacoes.put(parametrizacao.getDtInicioVigencia(), parametrizacao);
				dtInicioVigencias.add(parametrizacao.getDtInicioVigencia());
			}
		}
		
		
		return ajustaVigencias(mapParametrizacoes, dtInicioVigencias, pk, usuarioLogado);
	}
	
	
	@SuppressWarnings("unchecked")
	private List<ParametrizacaoNaturezaJuridicaVO> ajustaVigencias (
			Map<BVDate, ParametrizacaoNaturezaJuridicaVO> mapParametrizacoes, ArrayList<BVDate> dtInicioVigencias,
			IdentifierPK pk, String usuarioLogado) throws Exception {
	
		List<ParametrizacaoNaturezaJuridicaVO> listaAtualizacao = new ArrayList<ParametrizacaoNaturezaJuridicaVO>();
		ParametrizacaoNaturezaJuridicaVO parametrizacao;
		
		Calendar cal = Calendar.getInstance();		
		
		Collections.sort(dtInicioVigencias);
		
		BVDate dtFimVigencia = null;
		for (int i = dtInicioVigencias.size()-1; i >= 0; i--) {
			parametrizacao = mapParametrizacoes.get(dtInicioVigencias.get(i));
			
			adicionaParametrizacao(dtInicioVigencias, pk, usuarioLogado, 
					listaAtualizacao, parametrizacao, dtFimVigencia, i);
			
			cal.setTime(dtInicioVigencias.get(i).getTime());
			cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - 1);
			dtFimVigencia = new BVDate(cal.getTime());								
			
		}
		
		return listaAtualizacao;
	}



	private void adicionaParametrizacao(ArrayList<BVDate> dtInicioVigencias,
			IdentifierPK pk, String usuarioLogado, 
			List<ParametrizacaoNaturezaJuridicaVO> listaAtualizacao,
			ParametrizacaoNaturezaJuridicaVO parametrizacao,
			BVDate dtFimVigencia, int i) {
		// Se pk = null: Inser��o de nova data inicial de vig�ncia
		if (parametrizacao.getPk().getId() == null) {
			parametrizacao.setDtInicioVigencia(dtInicioVigencias.get(i));				
			parametrizacao.setDtFimVigencia(dtFimVigencia);
			parametrizacao.setDsLoginInclusao(usuarioLogado);
			listaAtualizacao.add(parametrizacao);
			
		}				
		else {
			// Atualiza��o da data inicial de vig�ncia
			if (pk.getId() == null || pk.getId().longValue() == parametrizacao.getPk().getId().longValue()) {
				parametrizacao.setDtInicioVigencia(dtInicioVigencias.get(i));
				parametrizacao.setDtFimVigencia(dtFimVigencia);
				parametrizacao.setDsLogin(usuarioLogado);
				parametrizacao.setDtAlteracao(new BVDatetime(new Date()));
				
				listaAtualizacao.add(parametrizacao);											
			}
			else if ((dtFimVigencia != null && parametrizacao.getDtFimVigencia() != null)) {
				// Atualiza��o da data final de vig�ncia devido a altera��o de uma data inicial
				if (dtFimVigencia.compareTo(parametrizacao.getDtFimVigencia()) != 0) {
					parametrizacao.setDtInicioVigencia(dtInicioVigencias.get(i));
					parametrizacao.setDtFimVigencia(dtFimVigencia);
					parametrizacao.setDsLogin(usuarioLogado);
					parametrizacao.setDtAlteracao(new BVDatetime(new Date()));

					listaAtualizacao.add(parametrizacao);
				}
			}
			else if ((dtFimVigencia != null || parametrizacao.getDtFimVigencia() != null)) {
				// Atualiza��o da data final de vig�ncia devido a altera��o de uma data inicial
				parametrizacao.setDtInicioVigencia(dtInicioVigencias.get(i));
				parametrizacao.setDtFimVigencia(dtFimVigencia);
				parametrizacao.setDsLogin(usuarioLogado);
				parametrizacao.setDtAlteracao(new BVDatetime(new Date()));

				listaAtualizacao.add(parametrizacao);					
			}
		}
	}
	
}
