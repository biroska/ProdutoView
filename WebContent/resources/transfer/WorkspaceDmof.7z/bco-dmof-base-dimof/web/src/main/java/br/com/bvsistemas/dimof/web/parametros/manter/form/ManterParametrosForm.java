/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.parametros.manter.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Classe respons�vel por armazenar as informa��es do form de Parametros.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 * 
 * @struts.form name="manterParametrosForm"
 */
public class ManterParametrosForm extends AbstractBaseValidatorForm {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** Operacao a ser realizada */
	private String operacao;
	
	/** Codigo do parametro */
	private String cdParametroSistema;
	
	/** Tipo pessoa selecionado */
	private String tpPessoaSelecionado;

	/** Valor limite pessoa fisica */
	private String vrLimitePf;
	
	/** Valor limite pessoa juridica */
	private String vrLimitePj;

	/** Codigo pessoa declarante */
	private String cdPessoaDeclarante;
	
	/** Nome pessoa declarante */
	private String nmPessoaDeclarante;
	
	/** Codigo pessoa representante legal */
	private String cdPessoaReprLegal;
	
	/** Nome pessoa representante legal */
	private String nmPessoaReprLegal;
	
	/** Codigo pessoa responsavel preenchimento */
	private String cdPessoaRespPreench;
	
	/** Nome pessoa responsavel preenchimento */
	private String nmPessoaRespPreench;
	
	/** Codigo pessoa responsavel atendimento RMF */
	private String cdPessoaRespAtendRmf;
	
	/** Nome pessoa responsavel atendimento RMF */
	private String nmPessoaRespAtendRmf;

	/** Tipo situacao especial */
	private String tpSituacaoEspecial;
	
	/** Data do evento */
	private String dtEnvioSituacaoEspecial;
	
	/** Codigo do tipo de logradouro */
	private String cdTipoLogradouro;
	
	/** Nome do arquivo */
	private String nmArquivo;

	/** Lista de tipos de logradouros */
	private List<TipoLogradouroVO> listaTipoLogradouro;


	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	/**
	 * @return the vrLimitePf
	 */
	public String getVrLimitePf() {
		return vrLimitePf;
	}

	/**
	 * @param vrLimitePf the vrLimitePf to set
	 */
	public void setVrLimitePf(String vrLimitePf) {
		this.vrLimitePf = vrLimitePf;
	}

	/**
	 * @return the vrLimitePj
	 */
	public String getVrLimitePj() {
		return vrLimitePj;
	}

	/**
	 * @param vrLimitePj the vrLimitePj to set
	 */
	public void setVrLimitePj(String vrLimitePj) {
		this.vrLimitePj = vrLimitePj;
	}

	/**
	 * @return the cdPessoaDeclarante
	 */
	public String getCdPessoaDeclarante() {
		return cdPessoaDeclarante;
	}

	/**
	 * @param cdPessoaDeclarante the cdPessoaDeclarante to set
	 */
	public void setCdPessoaDeclarante(String cdPessoaDeclarante) {
		this.cdPessoaDeclarante = cdPessoaDeclarante;
	}

	/**
	 * @return the nmPessoaDeclarante
	 */
	public String getNmPessoaDeclarante() {
		return nmPessoaDeclarante;
	}

	/**
	 * @param nmPessoaDeclarante the nmPessoaDeclarante to set
	 */
	public void setNmPessoaDeclarante(String nmPessoaDeclarante) {
		this.nmPessoaDeclarante = nmPessoaDeclarante;
	}

	/**
	 * @return the cdPessoaReprLegal
	 */
	public String getCdPessoaReprLegal() {
		return cdPessoaReprLegal;
	}

	/**
	 * @param cdPessoaReprLegal the cdPessoaReprLegal to set
	 */
	public void setCdPessoaReprLegal(String cdPessoaReprLegal) {
		this.cdPessoaReprLegal = cdPessoaReprLegal;
	}

	/**
	 * @return the nmPessoaReprLegal
	 */
	public String getNmPessoaReprLegal() {
		return nmPessoaReprLegal;
	}

	/**
	 * @param nmPessoaReprLegal the nmPessoaReprLegal to set
	 */
	public void setNmPessoaReprLegal(String nmPessoaReprLegal) {
		this.nmPessoaReprLegal = nmPessoaReprLegal;
	}

	/**
	 * @return the cdPessoaRespPreench
	 */
	public String getCdPessoaRespPreench() {
		return cdPessoaRespPreench;
	}

	/**
	 * @param cdPessoaRespPreench the cdPessoaRespPreench to set
	 */
	public void setCdPessoaRespPreench(String cdPessoaRespPreench) {
		this.cdPessoaRespPreench = cdPessoaRespPreench;
	}

	/**
	 * @return the nmPessoaRespPreench
	 */
	public String getNmPessoaRespPreench() {
		return nmPessoaRespPreench;
	}

	/**
	 * @param nmPessoaRespPreench the nmPessoaRespPreench to set
	 */
	public void setNmPessoaRespPreench(String nmPessoaRespPreench) {
		this.nmPessoaRespPreench = nmPessoaRespPreench;
	}

	/**
	 * @return the cdPessoaRespAtendRmf
	 */
	public String getCdPessoaRespAtendRmf() {
		return cdPessoaRespAtendRmf;
	}

	/**
	 * @param cdPessoaRespAtendRmf the cdPessoaRespAtendRmf to set
	 */
	public void setCdPessoaRespAtendRmf(String cdPessoaRespAtendRmf) {
		this.cdPessoaRespAtendRmf = cdPessoaRespAtendRmf;
	}

	/**
	 * @return the nmPessoaRespAtendRmf
	 */
	public String getNmPessoaRespAtendRmf() {
		return nmPessoaRespAtendRmf;
	}

	/**
	 * @param nmPessoaRespAtendRmf the nmPessoaRespAtendRmf to set
	 */
	public void setNmPessoaRespAtendRmf(String nmPessoaRespAtendRmf) {
		this.nmPessoaRespAtendRmf = nmPessoaRespAtendRmf;
	}

	/**
	 * @return the tpSituacaoEspecial
	 */
	public String getTpSituacaoEspecial() {
		return tpSituacaoEspecial;
	}

	/**
	 * @param tpSituacaoEspecial the tpSituacaoEspecial to set
	 */
	public void setTpSituacaoEspecial(String tpSituacaoEspecial) {
		this.tpSituacaoEspecial = tpSituacaoEspecial;
	}

	/**
	 * @return the dtEnvioSituacaoEspecial
	 */
	public String getDtEnvioSituacaoEspecial() {
		return dtEnvioSituacaoEspecial;
	}

	/**
	 * @param dtEnvioSituacaoEspecial the dtEnvioSituacaoEspecial to set
	 */
	public void setDtEnvioSituacaoEspecial(String dtEnvioSituacaoEspecial) {
		this.dtEnvioSituacaoEspecial = dtEnvioSituacaoEspecial;
	}

	/**
	 * @return the cdTipoLogradouro
	 */
	public String getCdTipoLogradouro() {
		return cdTipoLogradouro;
	}

	/**
	 * @param cdTipoLogradouro the cdTipoLogradouro to set
	 */
	public void setCdTipoLogradouro(String cdTipoLogradouro) {
		this.cdTipoLogradouro = cdTipoLogradouro;
	}

	/**
	 * @return the nmArquivo
	 */
	public String getNmArquivo() {
		return nmArquivo;
	}

	/**
	 * @param nmArquivo the nmArquivo to set
	 */
	public void setNmArquivo(String nmArquivo) {
		this.nmArquivo = nmArquivo;
	}

	/**
	 * @return the listaTipoLogradouro
	 */
	public List<TipoLogradouroVO> getListaTipoLogradouro() {
		return listaTipoLogradouro;
	}

	/**
	 * @param listaTipoLogradouro the listaTipoLogradouro to set
	 */
	public void setListaTipoLogradouro(List<TipoLogradouroVO> listaTipoLogradouro) {
		this.listaTipoLogradouro = listaTipoLogradouro;
	}

	/**
	 * @return the tpPessoaSelecionado
	 */
	public String getTpPessoaSelecionado() {
		return tpPessoaSelecionado;
	}

	/**
	 * @param tpPessoaSelecionado the tpPessoaSelecionado to set
	 */
	public void setTpPessoaSelecionado(String tpPessoaSelecionado) {
		this.tpPessoaSelecionado = tpPessoaSelecionado;
	}

	/**
	 * @return the cdParametroSistema
	 */
	public String getCdParametroSistema() {
		return cdParametroSistema;
	}

	/**
	 * @param cdParametroSistema the cdParametroSistema to set
	 */
	public void setCdParametroSistema(String cdParametroSistema) {
		this.cdParametroSistema = cdParametroSistema;
	}
}
