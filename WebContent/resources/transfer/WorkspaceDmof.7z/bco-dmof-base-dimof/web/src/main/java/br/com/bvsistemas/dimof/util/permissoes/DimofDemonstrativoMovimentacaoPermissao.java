package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;

/**
 * Mapeia o Objeto de permiss�es do VFAcesso
 * 
 * @author cmiranda
 * 
 */
public class DimofDemonstrativoMovimentacaoPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10000000090L;

	/**
	 * Atributos do objeto DimofLiminarPermissao
	 */
	private Boolean isConsultar;

	/**
	 * 
	 */
	public DimofDemonstrativoMovimentacaoPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transa��es do VFAcesso e monta o objeto
	 * 
	 * @param transacoesMap
	 */
	public DimofDemonstrativoMovimentacaoPermissao(
			Hashtable<String, String> transacoesMap) {
		super();

		// Obtem a lista de transacoes para Demonstrativo Movimentacoes
		String listTransacoes = (String) transacoesMap
				.get("Dimof_Demonstrativo_Movimentacao");

		// Seta as permissoes vindas da hash
		this.setIsConsultar(new Boolean(PermissaoUtils.verificaPermissao(
				"Dimof_Demonstrativo_Movimentacao_Consultar", listTransacoes)));
	}

	/**
	 * @return the isConsultar
	 */
	public Boolean getIsConsultar() {
		return isConsultar;
	}

	/**
	 * @param isConsultar
	 *            the isConsultar to set
	 */
	public void setIsConsultar(Boolean isConsultar) {
		this.isConsultar = isConsultar;
	}

}
