package br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.action;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.HistoricoNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.datatype.LogNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.services.HistoricoNaturezaJuridicaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.form.HistoricoNaturezaJuridicaForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVDatetime;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Action responsavel pela funcionalidade consultar Hist�rico Natureza Juridica
 * 
 * @struts.action name="historicoNaturezaJuridicaForm"
 *                path="/historicoAlteracaoNaturezaJuridica" scope="session"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.eFinanceira.historicoNaturezaJuridica"
 * 
 */

public class HistoricoNaturezaJuridicaDispatchAction extends
		AbstractBaseDispatchAction {

	private static final String DD_MM_YYYY = "dd/MM/yyyy";
	
	private static final String CT_EFINANCEIRA = "E-FINANCEIRA";
	private static final String CT_DATA_INICIO = "DATA IN�CIO";
	private static final String CT_DATA_FIM = "DATA FIM";
	
//	public HistoricoNaturezaJuridicaDispatchAction() {
//	}

	
	/**
	 * Inicializa a tela de Hist�rico de Natureza Juridica.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception
	 *             Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		HistoricoNaturezaJuridicaForm theForm = (HistoricoNaturezaJuridicaForm) form;

		// Limpa o form
		//limparForm(theForm);

		theForm.setTxtPeriodoIni(null);
		theForm.setTxtPeriodoFim(null);
		theForm.setTxtCodigoNaturezaJuridica(null);
		theForm.setTxtEfinanceira(null);
		theForm.setTxtNmNaturezaJuridica(null);
		theForm.setListaHistoricoNaturezaJuridica(null);
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}


	/**
	 * Realiza a consulta de liminares.
	 * 
	 * @param mapping
	 *            O ActionMapping utilizado para escolher essa inst�ncia.
	 * @param form
	 *            O ActionForm relativo � a��o corrente.
	 * @param request
	 *            Objeto com dados da requisi��o HTTP.
	 * @param response
	 *            Objeto com dados da resposta HTTP.
	 * 
	 * @return ActionForward para onde o fluxo deve ser direcionado.
	 * 
	 * @throws Exception
	 *             Se ocorrer qualquer erro n�o trat�vel pela aplica��o.
	 */
	public ActionForward listar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		HistoricoNaturezaJuridicaForm theForm = (HistoricoNaturezaJuridicaForm) form;

		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		this.validar(theForm, erros);

		if (erros.isEmpty()) {
			// realiza a pesquisa

			// Obtem o servi�o
			HistoricoNaturezaJuridicaServices historicoNaturezaJuridicaService = (HistoricoNaturezaJuridicaServices) getProxy(
								request, HistoricoNaturezaJuridicaServices.class);

			try {

				
				List<HistoricoNaturezaJuridicaVO> listaHistorico = historicoNaturezaJuridicaService.listar(this.preencherVO(theForm,request));

				// Verifica o resultado da consulta
				if ((listaHistorico == null) || (listaHistorico.isEmpty())) {

					// N�o h� retorno de dados
					ActionMessages messages = new ActionErrors();
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.buscaSemRegistro"));
					saveErrors(request, messages);

					// Limpa a lista de resultados da consulta
					theForm.setListaHistoricoNaturezaJuridica(null);

				} 
				else {
/*					// Seta lista de resultados da consulta
					theForm.setListaHistoricoNaturezaJuridica(listaHistorico);
*/
					BVDatetime dataInicio = null;
					
					if (theForm.getTxtPeriodoIni() != null && !theForm.getTxtPeriodoIni().equalsIgnoreCase("")) {
						dataInicio = new BVDatetime(theForm.getTxtPeriodoIni(), DD_MM_YYYY);
					}
					theForm.setListaHistoricoNaturezaJuridica(geraListaHistorico(listaHistorico, dataInicio));
					
				}

				theForm.setTxtPeriodoIni(null);
				theForm.setTxtPeriodoFim(null);
				theForm.setTxtCodigoNaturezaJuridica(null);
				theForm.setTxtEfinanceira(null);
				theForm.setTxtNmNaturezaJuridica(null);

			} catch (ValidationException e) {
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.valorInvalido"));
				saveErrors(request, erros);

			} catch (Exception e) {
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.erroInesperado"));
				saveErrors(request, erros);
			}

		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}


	private void validar(HistoricoNaturezaJuridicaForm form,
			ActionMessages erros) throws ParseException {

		if (StringUtils.isNotBlank(form.getTxtPeriodoIni())
				&& StringUtils.isBlank(form.getTxtPeriodoFim())) {
			// Data inicial preenchida e final n�o preenchida
			erros.add(
					Globals.MESSAGE_KEY,
					new ActionMessage(
							"message.error.historicoNaturezaJuridica.camposObrigatorios"));

		} else if (StringUtils.isBlank(form.getTxtPeriodoIni())
				&& StringUtils.isNotBlank(form.getTxtPeriodoFim())) {
			// Data inicial n�o preenchida e final preenchida
			erros.add(
					Globals.MESSAGE_KEY,
					new ActionMessage(
							"message.error.historicoNaturezaJuridica.camposObrigatorios"));

		} else if (StringUtils.isNotBlank(form.getTxtPeriodoIni())
				&& StringUtils.isNotBlank(form.getTxtPeriodoFim())) {

			BVDate dtInicio = new BVDate(form.getTxtPeriodoIni(), DD_MM_YYYY);
			BVDate dtFim = new BVDate(form.getTxtPeriodoFim(), DD_MM_YYYY);

			// Compara as datas
			boolean result = !(dtInicio.compareTo(dtFim) > 0);

			if (!result) {
				// Intervalo de datas inv�lido
				// Data inicial maior que data final
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.historicoNaturezaJuridica.PeriodoDataInvalido"));
			}
		}

	}

	private HistoricoNaturezaJuridicaVO preencherVO(
			HistoricoNaturezaJuridicaForm form, HttpServletRequest request) throws ParseException {

		HistoricoNaturezaJuridicaVO historico = new HistoricoNaturezaJuridicaVO(
				new IdentifierPK());
		NaturezaJuridicaVO naturezaJuridica = new NaturezaJuridicaVO(
				new IdentifierPK());

		preencheCondicoesVo(form, historico, naturezaJuridica);

		historico.setNaturezaJuridica(naturezaJuridica);

		return historico;

	}

	private void preencheCondicoesVo(HistoricoNaturezaJuridicaForm form,
			HistoricoNaturezaJuridicaVO historico,
			NaturezaJuridicaVO naturezaJuridica) throws ParseException {
		
		preencheCondicoesVo2(form, naturezaJuridica);

		if (form.getTxtPeriodoIni() != null
				&& !form.getTxtPeriodoIni().isEmpty()) {
			
			BVDate dtInicioAlterado = null;
			dtInicioAlterado = new BVDate(form.getTxtPeriodoIni(), 
					Constantes.DATE_PATTERN);
			historico.setDtLogInicio(dtInicioAlterado);

		}

		if (form.getTxtPeriodoFim() != null
				&& !form.getTxtPeriodoFim().isEmpty()) {
			
			BVDate dtFimAlterado = null;
			dtFimAlterado = new BVDate(form.getTxtPeriodoFim(), 
					Constantes.DATE_PATTERN);
			historico.setDtLogFim(dtFimAlterado);

		}
	}

	private void preencheCondicoesVo2(HistoricoNaturezaJuridicaForm form,
			NaturezaJuridicaVO naturezaJuridica) {
		if (form.getTxtCodigoNaturezaJuridica() != null
				&& !form.getTxtCodigoNaturezaJuridica().isEmpty()) {
			naturezaJuridica.setCdNaturezaJuridica(form
					.getTxtCodigoNaturezaJuridica());
		}

		if (form.getTxtNmNaturezaJuridica() != null
				&& !form.getTxtNmNaturezaJuridica().isEmpty()) {
			naturezaJuridica.setNmNaturezaJuridica(form
					.getTxtNmNaturezaJuridica());

		}

		if (form.getTxtEfinanceira() != null
				&& !form.getTxtEfinanceira().isEmpty()) {
			naturezaJuridica.setFlEnviaInformacaoEFinanceira(form
					.getTxtEfinanceira());
		}
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<LogNaturezaJuridicaVO> geraListaHistorico(List<HistoricoNaturezaJuridicaVO> listaHistorico, BVDatetime dtInicio) throws ParseException {
		List<LogNaturezaJuridicaVO> lista = new ArrayList<LogNaturezaJuridicaVO>();
		long i = 1;
		
		Long cdNaturezaJuridicaEscrituracao = null;
		String eFinanceiraAnterior = "";
		String dtInicioAnterior = "";
		String dtFimAnterior = "";
				
		for (Iterator<HistoricoNaturezaJuridicaVO> iterator = listaHistorico.iterator(); iterator.hasNext(); ) {
			HistoricoNaturezaJuridicaVO historico = (HistoricoNaturezaJuridicaVO) iterator.next();
				
			// No caso em que o usu�rio especifica as datas inicial e final,
			// a consulta deve trazer todos os registros at� a  data final
			// para recuperar os valores anteriores � data inicial, mas apenas as datas maiores
			// devem ser apresentadas na tela. 
			//Se n�o trouxer todos os valores, os valores anteriores podem ficar incorretos
			if (dtInicio == null || (dtInicio != null && 
					dtInicio.compareTo(historico.getDtLogNaturezaJuridica()) < 0) ) {
				i = insereLog(lista, i, cdNaturezaJuridicaEscrituracao,
						eFinanceiraAnterior, dtInicioAnterior, dtFimAnterior,
						historico);
			}
			
			cdNaturezaJuridicaEscrituracao = historico.getCdNaturezaJuridicaEscrituracao();
			eFinanceiraAnterior = historico.getNaturezaJuridica().getFlEnviaInformacaoEFinanceira();
			dtInicioAnterior = historico.getNaturezaJuridica().getDtInicio();
			dtFimAnterior = historico.getNaturezaJuridica().getDtFim() == null ? "" : historico.getNaturezaJuridica().getDtFim();		
		
		}			
		
		// Ordena lista pela data/hora da altera��o
        Collections.sort (lista, new Comparator() {
            public int compare(Object o1, Object o2) {
            	LogNaturezaJuridicaVO log1 = (LogNaturezaJuridicaVO) o1;
            	LogNaturezaJuridicaVO log2 = (LogNaturezaJuridicaVO) o2;
            	
                return log1.getDtLogNaturezaJuridica().compareTo(log2.getDtLogNaturezaJuridica()) < 0 ? -1 : 
                	(log1.getDtLogNaturezaJuridica().compareTo(log2.getDtLogNaturezaJuridica()) > 0 ? +1 :0);                
            }
        });		
		
		
		return lista;
	}

	private long insereLog(List<LogNaturezaJuridicaVO> lista, long i,
			Long cdNaturezaJuridicaEscrituracao, String eFinanceiraAnterior,
			String dtInicioAnterior, String dtFimAnterior,
			HistoricoNaturezaJuridicaVO historico) {
		if (cdNaturezaJuridicaEscrituracao == null ||
				cdNaturezaJuridicaEscrituracao.longValue() != historico.getCdNaturezaJuridicaEscrituracao().longValue()) {								
			
			lista.add(insereHistoricoLog(historico, i++, CT_EFINANCEIRA, "-", 
					historico.getNaturezaJuridica().getFlEnviaInformacaoEFinanceira()));
						
			lista.add(insereHistoricoLog(historico, i++, CT_DATA_INICIO, "-", 
					historico.getNaturezaJuridica().getDtInicio()));
			
			
			if (historico.getNaturezaJuridica().getDtFim() != null) {
				lista.add(insereHistoricoLog(historico, i++, CT_DATA_FIM, "-", 
						historico.getNaturezaJuridica().getDtFim()));
			}
			
		}
		else {
						
			if (!eFinanceiraAnterior.equalsIgnoreCase(historico.getNaturezaJuridica().getFlEnviaInformacaoEFinanceira())) {
				
				lista.add(insereHistoricoLog(historico, i++, CT_EFINANCEIRA, 
						eFinanceiraAnterior, historico.getNaturezaJuridica().getFlEnviaInformacaoEFinanceira()))	;
			}
			
			if (!dtInicioAnterior.equalsIgnoreCase(historico.getNaturezaJuridica().getDtInicio())) {
				lista.add(insereHistoricoLog(historico, i++, CT_DATA_INICIO, dtInicioAnterior, 
						historico.getNaturezaJuridica().getDtInicio()));
			}
			
			
			if ((historico.getNaturezaJuridica().getDtFim() == null)) {
				if (!dtFimAnterior.equalsIgnoreCase("")) {
					lista.add(insereHistoricoLog(historico, i++, CT_DATA_FIM, dtFimAnterior, "-"));

				}
			}
			else if (!dtFimAnterior.equalsIgnoreCase(historico.getNaturezaJuridica().getDtFim())) {
				lista.add(insereHistoricoLog(historico, i++, CT_DATA_FIM, dtFimAnterior, historico.getNaturezaJuridica().getDtFim()));
			}
		}
		return i;
	}
	
	
	
	private LogNaturezaJuridicaVO insereHistoricoLog(HistoricoNaturezaJuridicaVO historico,
			long indice, String campoAlterado, String dadoAnterior, String dadoNovo) {
		LogNaturezaJuridicaVO historicoLog = null;;
		IdentifierPK pk;
	    Calendar cal = Calendar.getInstance();
		
		pk = new IdentifierPK(indice);
		historicoLog = new LogNaturezaJuridicaVO(pk);
		historicoLog.setCdNaturezaJuridicaEscrituracao(historico.getCdNaturezaJuridicaEscrituracao());
		
		if (campoAlterado.equalsIgnoreCase(CT_DATA_INICIO)) {		
	        cal.setTime(historico.getDtLogNaturezaJuridica().getTime());
	        // Para Data in�cio aparecer como primeiro campo alterado, 
	        //no caso de haver outros campos com altera��o
	        cal.add(Calendar.SECOND, -1);
			
			historicoLog.setDtLogNaturezaJuridica(new BVDatetime(cal.getTime()));
		}
		else {
			historicoLog.setDtLogNaturezaJuridica(historico.getDtLogNaturezaJuridica());
		}
		historicoLog.setCdNaturezaJuridica(historico.getNaturezaJuridica().getCdNaturezaJuridica());
		historicoLog.setNmNaturezaJuridica(historico.getNaturezaJuridica().getNmNaturezaJuridica());
		historicoLog.setDsLogin(historico.getNaturezaJuridica().getDsLogin());
		historicoLog.setNmCampoAlterado(campoAlterado);
		if (campoAlterado.equalsIgnoreCase(CT_EFINANCEIRA)) {
			historicoLog.setVlAnterior(dadoAnterior.equalsIgnoreCase("S")? "Sim": 
				dadoAnterior.equalsIgnoreCase("N")? "N�o":"-");
			historicoLog.setVlAtual(dadoNovo.equalsIgnoreCase("S")? "Sim": 
				dadoNovo.equalsIgnoreCase("N")? "N�o":"-");			
		}
		else {
			historicoLog.setVlAnterior(dadoAnterior);
			historicoLog.setVlAtual(dadoNovo);
		}
		
		
		return historicoLog;
	}

	
}
