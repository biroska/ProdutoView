/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.login.form;

import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.form name="loginForm"
 * 
 */
public class LoginForm extends AbstractBaseValidatorForm {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Usu�rio.
	 */
	private String txtUsuario;
	
	/**
	 * Senha.
	 */
	private String txtSenha;

	public String getTxtUsuario() {
		return txtUsuario;
	}

	public void setTxtUsuario(String txtUsuario) {
		this.txtUsuario = txtUsuario;
	}

	public String getTxtSenha() {
		return txtSenha;
	}

	public void setTxtSenha(String txtSenha) {
		this.txtSenha = txtSenha;
	}
}
