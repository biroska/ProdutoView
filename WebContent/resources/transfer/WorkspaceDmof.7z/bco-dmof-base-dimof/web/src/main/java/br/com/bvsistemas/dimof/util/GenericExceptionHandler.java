/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;

import br.com.bvsistemas.framework.logging.BVLogger;

/**
 * Handler para capturar excess�es n�o tratadas pela aplica��o
 * 
 * @author cit.cmiranda
 * 
 */
public class GenericExceptionHandler extends ExceptionHandler {

	private static BVLogger logger = BVLogger
			.getLogger(GenericExceptionHandler.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ExceptionHandler#execute(java.lang.Exception,
	 *      org.apache.struts.config.ExceptionConfig,
	 *      org.apache.struts.action.ActionMapping,
	 *      org.apache.struts.action.ActionForm,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward execute(java.lang.Exception ex, ExceptionConfig ae,
			ActionMapping mapping, ActionForm formInstance,
			HttpServletRequest request, HttpServletResponse response)
			throws javax.servlet.ServletException {

		logger.workflow.fatal("Exce��o inesperada: ", ex);

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		pw.write(ex.getClass().getName() + "\n");
		ex.printStackTrace(pw);

		// Coloca a excess�o na request
		request.setAttribute("exception", ex.getMessage());
		request.setAttribute("stack", sw.toString());

		return mapping.findForward("erroGenerico");
	}

}
