/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.util;

import java.util.StringTokenizer;

import org.apache.commons.validator.GenericValidator;

/**
 * 
 * Classe utilitaria para verificacao VFAcesso
 * 
 * @author <a href="mailto:cmiranda@cit.com.br">cmiranda</a>
 * 
 */
public class PermissaoUtils {

	/**
	 * Token de separacao das permissoes do usuario retornadas pelo VFAcesso.
	 */
	private static final String PERMISSION_TOKEN = ";";

	/**
	 * Verifica se determinada permiss�o esta na lista de transacoes do usuario.
	 * Tal lista e obtida do VFAcesso atraves do processo de login
	 * 
	 * 
	 * @param trans -
	 *            Transacao a ser verficada
	 * @param lista -
	 *            Lista de permissoes do usuario
	 * @return - True caso o usuario possua tal permissao
	 */
	public static boolean verificaPermissao(String trans, String lista) {

		// Verifica se transacao e lista de transacoes nao estao vazias
		if (!GenericValidator.isBlankOrNull(trans)
				&& !GenericValidator.isBlankOrNull(lista)) {

			trans = trans.trim();
			StringTokenizer token = new StringTokenizer(lista, PERMISSION_TOKEN);
			while (token.hasMoreTokens()) {
				if ((trans.length() > 0)
						&& (token.nextToken().trim().equalsIgnoreCase(trans))) {
					return true;
				}
			}
		}
		return false;
	}

}
