package br.com.bvsistemas.dimof.util.permissoes;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.PermissaoUtils;

/**
 * Mapeia o Objeto de permiss�es do VFAcesso
 * 
 * @author cmiranda
 * 
 */
public class DimofLiminarHistoricoAlteracoesPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 10000000093L;

	/**
	 * Atributos do objeto DimofLiminarPermissao
	 */
	private Boolean isConsultar;

	/**
	 * 
	 */
	public DimofLiminarHistoricoAlteracoesPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transa��es do VFAcesso e monta o objeto
	 * 
	 * @param transacoesMap
	 */
	public DimofLiminarHistoricoAlteracoesPermissao(
			Hashtable<String, String> transacoesMap) {
		super();

		// Obtem a lista de transacoes para Log Alteracoes Liminar
		String listTransacoes = (String) transacoesMap
			.get("Dimof_Liminar_HistoricoAlteracoes");

		// Seta as permissoes vindas da hash
		this.setIsConsultar(new Boolean(PermissaoUtils.verificaPermissao(
			"Dimof_Liminar_HistoricoAlteracoes_Consultar", listTransacoes)));

	}

	/**
	 * @return the isConsultar
	 */
	public Boolean getIsConsultar() {
		return isConsultar;
	}

	/**
	 * @param isConsultar
	 *            the isConsultar to set
	 */
	public void setIsConsultar(Boolean isConsultar) {
		this.isConsultar = isConsultar;
	}

}
