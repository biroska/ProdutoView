package br.com.bvsistemas.dimof.web.eFinanceira.agendamento.form;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.MesVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.util.DataUtils;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;
import br.com.bvsistemas.framework.datatype.BVDate;

/**
 * <code>ActionForm</code> respons�vel por armazenar as informa��es do agendamento 
 * 
 * @author Aimbere Galdino
 * 
 * @struts.form name="incluirAgendamentoForm"
 * 
 */
public class IncluirAgendamentoForm extends AbstractBaseValidatorForm {

	private static final long serialVersionUID = 9073669641528171419L;

	public IncluirAgendamentoForm () {
		System.out.println("IncluirAgendamentoForm.IncluirAgendamentoForm()");
		
		listaMeses = new ArrayList<MesVO>();
		listaMeses.addAll( DataUtils.montaListaDeMeses() );
		
		int anoCorrente = Calendar.getInstance().get( Calendar.YEAR );
		listaAnos = new ArrayList<Integer>();

		for (int ano = Constantes.ANO_INICIO; ano <= anoCorrente; ano++) {
			listaAnos.add( ano );	
		}
		
		setDtInclusao( new BVDate( new Date() ) );
		
		listaPessoas = new ArrayList<PessoaVO>();
	}
	
	private String operacao;

	private String txtMesInicio;
	
	private String anoInicio;
	
	private String txtMesFinal;
	
	private String anoFinal;
	
	private String txtLogin;
	
	private BVDate dtInclusao;
	
	private String idCliente;
	
	private String txtCliente;
	
	private String txtDocumentoCliente;
	
	private String idEmpresaRemover;
	
	private List<PessoaVO> listaEmpresas;
	
	private List<PessoaVO> listaPessoas;
	
	/* variaveis auxiliares para a tela */
	private ArrayList<MesVO> listaMeses;
	
	private ArrayList<Integer> listaAnos;
	
	public String getOperacao() {
		return operacao;
	}

	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	public String getTxtMesInicio() {
		return txtMesInicio;
	}

	public void setTxtMesInicio(String txtMesInicio) {
		this.txtMesInicio = txtMesInicio;
	}

	public String getAnoInicio() {
		return anoInicio;
	}

	public void setAnoInicio(String anoInicio) {
		this.anoInicio = anoInicio;
	}

	public String getTxtMesFinal() {
		return txtMesFinal;
	}

	public void setTxtMesFinal(String txtMesFinal) {
		this.txtMesFinal = txtMesFinal;
	}

	public String getAnoFinal() {
		return anoFinal;
	}

	public void setAnoFinal(String anoFinal) {
		this.anoFinal = anoFinal;
	}

	public ArrayList<MesVO> getListaMeses() {
		return listaMeses;
	}

	public void setListaMeses(ArrayList<MesVO> listaMeses) {
		this.listaMeses = listaMeses;
	}

	public ArrayList<Integer> getListaAnos() {
		return listaAnos;
	}

	public void setListaAnos(ArrayList<Integer> listaAnos) {
		this.listaAnos = listaAnos;
	}

	public String getTxtLogin() {
		return txtLogin;
	}

	public void setTxtLogin(String txtLogin) {
		this.txtLogin = txtLogin;
	}
	
	public BVDate getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(BVDate dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}

	public String getTxtCliente() {
		return txtCliente;
	}
	
	public String getTxtDocumentoCliente() {
		return txtDocumentoCliente;
	}

	public void setTxtDocumentoCliente(String txtDocumentoCliente) {
		this.txtDocumentoCliente = txtDocumentoCliente;
	}

	public void setTxtCliente(String txtCliente) {
		this.txtCliente = txtCliente;
	}

	public String getIdEmpresaRemover() {
		return idEmpresaRemover;
	}

	public void setIdEmpresaRemover(String idEmpresaRemover) {
		this.idEmpresaRemover = idEmpresaRemover;
	}

	public List<PessoaVO> getListaEmpresas() {
		
		if ( listaEmpresas == null || listaEmpresas.isEmpty() ){
			listaEmpresas = new ArrayList<PessoaVO>();
		}
		
		return listaEmpresas;
	}

	public void setListaEmpresas(List<PessoaVO> listaEmpresas) {
		this.listaEmpresas = listaEmpresas;
	}

	public List<PessoaVO> getListaPessoas() {
		if ( listaPessoas == null ){
			listaPessoas = new ArrayList<PessoaVO>();
		}
		
		return listaPessoas;
	}

	public void setListaPessoas(List<PessoaVO> listaPessoas) {
		this.listaPessoas = listaPessoas;
	}
}