/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.framework.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.util.ValidatorUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.RequestUtils;
import org.apache.struts.validator.FieldChecks;
import org.apache.struts.validator.Resources;

import br.com.bvsistemas.framework.datatype.BVFloat;

/**
 * Realiza valida��es de campos.
 *
 * @author <a href="mailto:canova@cit.com.br">canova</a>
 *
 */
public class ValidadorCampos extends FieldChecks {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param bean
	 * @param field
	 * @return
	 */
	private static String evaluateBean(Object bean, Field field) {
		String value;

		if (isString(bean)) {
			value = (String) bean;
		} else {
			value = ValidatorUtils.getValueAsString(bean, field.getProperty());
		}

		return value;
	}

	/**
	 * Valida intervalo de datas.
	 *
	 * @param bean
	 * @param validation
	 * @param field
	 * @param errors
	 * @param request
	 * @return "true" se o intervalo for considerado v�lido.
	 */
	public static boolean validaIntervaloData(Object bean,
			ValidatorAction validation, Field field, ActionMessages errors,
			HttpServletRequest request) {

		boolean result = true;

		// recupera as datas de in�cio e fim
		String dataInicio = ValidatorUtils.getValueAsString(bean, field
				.getProperty());
		String dataFim = ValidatorUtils.getValueAsString(bean, field
				.getVarValue("dataFim"));

		// Verifica se as datas est�o preenchidas, para permitir compara��o
		if (!((GenericValidator.isBlankOrNull(dataInicio)) && (GenericValidator
				.isBlankOrNull(dataFim)))) {

			// recupera o formato de data
			String datePattern = field.getVarValue("datePattern");
			SimpleDateFormat sdf = new SimpleDateFormat(datePattern);

			try {
				Date dataMenor = sdf.parse(dataInicio);
				Date dataMaior = sdf.parse(dataFim);

				// compara datas
				result = !(dataMenor.compareTo(dataMaior) > 0);

				// Se o per�odo for inv�lido
				if (!result) {
					ActionMessages mensagens = new ActionErrors();
					ActionMessage mensagem = new ActionMessage(field
							.getMsg("validaIntervaloData"), field.getArg(0)
							.getKey());
					mensagens.add(field.getProperty(), mensagem);
					errors.add(mensagens);
				}
			} catch (ParseException e) {
				// Erro em uma das datas, n�o posta mensagem de compara��o.
				// A valida��o de formato de datas deve utilizar seu pr�prio
				// validador.
				result = true;
			}
		}

		return result;
	}

	/**
	 * Verifica se o float (v�lido) possui a quantidade m�xima de casas 
	 * inteiras.
	 *
	 * @param bean
	 *            The bean validation is being performed on.
	 * @param va
	 *            The <code>ValidatorAction</code> that is currently being
	 *            performed.
	 * @param valor
	 * 			  Valor digitado pelo usu�rio (string).
	 * @param field
	 *            The <code>Field</code> object associated with the current
	 *            field being validated.
	 * @param limite
	 * 			  Nome do campo a ser validado.
	 * @param errors
	 *            The <code>ActionMessages</code> object to add errors to if
	 *            any validation errors occur.
	 * @param validator
	 *            The <code>Validator</code> instance, used to access other
	 *            field values.
	 * @param request
	 *            Current request object.
	 * @param qtdInteira
	 * 			   Quantidade m�xima de casas inteiras.
	 * @return true if valid, false otherwise.
	 */
	public static Boolean validaCasasInteiras(Object bean, ValidatorAction va,
			String valor, Field field, String limite, ActionMessages errors, 
			Validator validator, HttpServletRequest request, String qtdInteira) {

		boolean result = true;
		
		if (!GenericValidator.isBlankOrNull(qtdInteira)) {

			if (GenericValidator.isFloat(valor.replace(',', '.'))) {
	
				// Verifica se o valor est� preenchido
				if (!((GenericValidator.isBlankOrNull(valor)))) {
	
					String casasInteiras = valor;
					
					if (valor.contains(",")) {
						casasInteiras = valor.substring(0, valor.indexOf(","));
					}
	
					// Remove sinal, caso haja
					if ((casasInteiras.length() != 0 
							&& casasInteiras.charAt(0) == '-')) {
						casasInteiras = casasInteiras.substring(1);
					}
	
					if (casasInteiras.length() > Integer.parseInt(qtdInteira)) {
						// O valor ultrapassou o tamanho m�ximo de casas 
						// inteiras
						result = false;
					}
	
					if (!result) {
						// N�mero de casas inteiras inv�lida
						ActionMessages mensagens = new ActionErrors();
						ActionMessage mensagem = new ActionMessage(field
								.getMsg("validaCasasInteiras"), limite);
						mensagens.add(limite, mensagem);
						errors.add(mensagens);
					}
				}
			}
		}
		return result;
	}


	/**
	 * Verifica se o float (v�lido) possui a quantidade m�xima de casas 
	 * decimais.
	 *
	 * @param bean
	 *            The bean validation is being performed on.
	 * @param va
	 *            The <code>ValidatorAction</code> that is currently being
	 *            performed.
	 * @param valor
	 * 			  Valor digitado pelo usu�rio (string).
	 * @param field
	 *            The <code>Field</code> object associated with the current
	 *            field being validated.
	 * @param limite
	 * 			  Nome do campo a ser validado.
	 * @param errors
	 *            The <code>ActionMessages</code> object to add errors to if
	 *            any validation errors occur.
	 * @param validator
	 *            The <code>Validator</code> instance, used to access other
	 *            field values.
	 * @param request
	 *            Current request object.
	 * @param qtdDecimal
	 * 			  Quantidade m�xima de casas decimais.
	 * @return true if valid, false otherwise.
	 */
	public static Object validaCasasDecimais(Object bean, ValidatorAction va,
			String valor, Field field, String limite, ActionMessages errors, 
			Validator validator, HttpServletRequest request, 
			String qtdDecimal) {

		boolean result = true;

		if (!GenericValidator.isBlankOrNull(qtdDecimal)) {
				
			if (GenericValidator.isFloat(valor.replace(',', '.'))) {
	
				// Verifica se o valor est� preenchido
				if (!((GenericValidator.isBlankOrNull(valor)))) {
	
					if (valor.contains(",")) {
						String casasDecimais = valor.substring(
								valor.indexOf(",")+1);
	
						if (casasDecimais.length() > Integer.parseInt(
								qtdDecimal)) {
							// O valor ultrapassou n�mero m�ximo de casas 
							// decimais
							result = false;
						}
					}
	
					if (!result) {
						// N�mero de casas decimais inv�lido
						ActionMessages mensagens = new ActionErrors();
						ActionMessage mensagem = new ActionMessage(field
								.getMsg("validaCasasDecimais"), limite);
						mensagens.add(limite, mensagem);
						errors.add(mensagens);
					}
				}
			}
		}
		
		return result;
	}

	/**
	 * Verifica se o float (v�lido) possui um ponto. Se sim, informa o usu�rio
	 * de que o separador decimal � v�rgula.
	 *
	 * @param bean
	 *            The bean validation is being performed on.
	 * @param va
	 *            The <code>ValidatorAction</code> that is currently being
	 *            performed.
	 * @param valor
	 * 			  Valor digitado pelo usu�rio (string).
	 * @param field
	 *            The <code>Field</code> object associated with the current
	 *            field being validated.
	 * @param limite
	 * 			  Nome do campo a ser validado.
	 * @param errors
	 *            The <code>ActionMessages</code> object to add errors to if
	 *            any validation errors occur.
	 * @param validator
	 *            The <code>Validator</code> instance, used to access other
	 *            field values.
	 * @param request
	 *            Current request object.
	 * @return true if valid, false otherwise.
	 */
	public static Object validaSeparadorDecimal(Object bean, ValidatorAction va,
			String valor, Field field, String limite, ActionMessages errors, 
			Validator validator, HttpServletRequest request) {

		boolean result = true;
	
		if (GenericValidator.isFloat(valor.replace(',', '.'))) {

			// Verifica se o valor est� preenchido
			if (!((GenericValidator.isBlankOrNull(valor)))) {

				if (valor.contains(".")) {
					// O valor possui ponto como separador decimal
					result = false;
				}

				// Se o valor for inv�lido
				if (!result) {
					// Separador decimal inv�lido
					ActionMessages mensagens = new ActionErrors();
					ActionMessage mensagem = new ActionMessage(field
							.getMsg("validaSeparadorDecimal"), limite);
					mensagens.add(limite, mensagem);
					errors.add(mensagens);
				}
			}
		}

		return result;
	}

	/**
	 * Checks if the field can safely be converted to a double primitive.
	 *
	 * @param bean
	 *            The bean validation is being performed on.
	 * @param va
	 *            The <code>ValidatorAction</code> that is currently being
	 *            performed.
	 * @param valor
	 * 			  Valor digitado pelo usu�rio (string).
	 * @param field
	 *            The <code>Field</code> object associated with the current
	 *            field being validated.
	 * @param limite
	 * 			  Nome do campo a ser validado.
	 * @param errors
	 *            The <code>ActionMessages</code> object to add errors to if
	 *            any validation errors occur.
	 * @param validator
	 *            The <code>Validator</code> instance, used to access other
	 *            field values.
	 * @param request
	 *            Current request object.
	 * @return true if valid, false otherwise.
	 */
	public static Object validateBVFloat(Object bean, ValidatorAction va,
			String valor, Field field, String limite, ActionMessages errors, 
			Validator validator, HttpServletRequest request) {

		boolean result = false;

		if (GenericValidator.isBlankOrNull(valor)) {
			return true;
		}

		if (GenericValidator.isFloat(valor.replace(',', '.')) 
				&& valor.charAt(0) != '.' 
				&& valor.charAt(valor.length()-1) != ','
				&& valor.charAt(0) != ','
				&& valor.charAt(valor.length()-1) != ',') {
			return true;
		} else {

			// Verifica se h� letras no valor digitado, para emitir uma
			// mensagem diferenciada

			Boolean caracter = false;

			for (int i=0; i < valor.length() && !caracter; i++) {
				if (valor.charAt(i) != '0' && valor.charAt(i) != '1'
					&& valor.charAt(i) != '2' && valor.charAt(i) != '3'
					&& valor.charAt(i) != '4' && valor.charAt(i) != '5'
					&& valor.charAt(i) != '6' && valor.charAt(i) != '7'
					&& valor.charAt(i) != '8' && valor.charAt(i) != '9'
					&& valor.charAt(i) != ',' && valor.charAt(i) != '.'
					&& valor.charAt(i) != '-') {
					caracter = true;
				}
			}

			if (caracter) {
				// Mensagem espec�fica para utilizar somente n�meros
				ActionMessages mensagens = new ActionErrors();
				ActionMessage mensagem = new ActionMessage(field
						.getMsg("validaValorNumerico"), limite);
				mensagens.add(limite, mensagem);
				errors.add(mensagens);

			} else {
				// Mensagem gen�rica de valor inv�lido
				ActionMessages mensagens = new ActionErrors();
				ActionMessage mensagem = new ActionMessage(field
						.getMsg("validaFloat"), limite);
				mensagens.add( limite, mensagem);
				errors.add(mensagens);
			}
			result = false;
		}

		return result;
	}

	/**
	 * Valida intervalo de valores.
	 *
	 * @param bean
	 * @param validation
	 * @param field
	 * @param errors
	 * @param request
	 * @return "true" se o intervalo for considerado v�lido.
	 */
	public static Object validaIntervaloBVFloat(Object bean,
			ValidatorAction validation, Field field, ActionMessages errors,
			Validator validator, HttpServletRequest request) {

		boolean result = true;
	
		boolean erroMin = false;
		boolean erroMax = false;
		
		// recupera os valores m�ximo e m�nimo
		String txtValorMinimo = ValidatorUtils.getValueAsString(bean, field
				.getProperty());
		String txtValorMaximo = ValidatorUtils.getValueAsString(bean, field
				.getVarValue("valorMaximo"));

		// Recupera quantidade de casas inteiras e decimais
		String casasInteiras = field.getVarValue("vrCasasInteiras");		
		String casasDecimais = field.getVarValue("vrCasasDecimais");		
		
		String limite = field.getVarValue("valorMinimo");
		// LIMITE MINIMO
		// Valida separador decimal
		if (!(Boolean)validaSeparadorDecimal(bean, validation, txtValorMinimo, 
				field, limite, errors, validator, request)) {
			erroMin = true;
		} else if (!(Boolean)validaCasasInteiras(bean, validation, 
				txtValorMinimo, field, limite, errors, validator, request,
				casasInteiras)) {
			// Valida casas inteiras
			erroMin = true;
		} else if (!(Boolean)validaCasasDecimais(bean, validation, 
				txtValorMinimo, field, limite, errors, validator, request,
				casasDecimais)) {
			// Valida cadas decimais
			erroMin = true;
		} else if (!(Boolean)validateBVFloat(bean, validation, txtValorMinimo, 
				field, limite, errors, validator, request)) {
			// Valida float sem caracteres
			erroMin = true;
		}
		
		limite = field.getVarValue("valorMaximo");		
		// LIMITE MAXIMO
		// Valida separador decimal
		if (!(Boolean)validaSeparadorDecimal(bean, validation, txtValorMaximo, 
				field, limite, errors, validator, request)) {
			erroMax = true;
		} else if (!(Boolean)validaCasasInteiras(bean, validation, 
				txtValorMaximo, field, limite, errors, validator, request,
				casasInteiras)) {
			// Valida casas inteiras
			erroMax = true;
		} else if (!(Boolean)validaCasasDecimais(bean, validation, 
				txtValorMaximo, field, limite, errors, validator, request,
				casasDecimais)) {
			// Valida cadas decimais
			erroMax = true;
		} else if (!(Boolean)validateBVFloat(bean, validation, 
				txtValorMaximo, field, limite, errors, validator, request)) {
			// Valida float sem caracteres
			erroMax = true;
		}		
		
		// Verifica intervalo, somente se n�o tiver dado outro erro.
		if (!(erroMin || erroMax)) {
			
			// Verifica se os valores est�o preenchidos, para permitir 
			// compara��o
			if (!((GenericValidator.isBlankOrNull(txtValorMinimo))
					&& (GenericValidator.isBlankOrNull(txtValorMaximo)))) {
	
				Locale locale = RequestUtils.getUserLocale(request, null);
	
				BVFloat valorMinimo = GenericTypeValidator.formatBVFloat(
						txtValorMinimo, locale);
	
				BVFloat valorMaximo = GenericTypeValidator.formatBVFloat(
						txtValorMaximo, locale);
	
				if ( valorMinimo != null && valorMaximo != null ) {
					// O valor m�nimo deve ser MENOR que o m�ximo (n�o pode ser
					// igual)
					result = valorMinimo.isLessThan(valorMaximo);
				} else {
					result = true;
				}
	
				// Se o limite for inv�lido
				if (!result) {
					errors.add(field.getKey(), Resources.getActionMessage(
							validator, request, validation, field));
				}
			}
		}
		
		return result;
	}

	/**
	 * Checks if the field can safely be converted to a double primitive.
	 *
	 * @param bean
	 *            The bean validation is being performed on.
	 * @param va
	 *            The <code>ValidatorAction</code> that is currently being
	 *            performed.
	 * @param field
	 *            The <code>Field</code> object associated with the current
	 *            field being validated.
	 * @param errors
	 *            The <code>ActionMessages</code> object to add errors to if
	 *            any validation errors occur.
	 * @param validator
	 *            The <code>Validator</code> instance, used to access other
	 *            field values.
	 * @param request
	 *            Current request object.
	 * @return true if valid, false otherwise.
	 */
	public static Object validateBVFloatLocale(Object bean, ValidatorAction va,
			Field field, ActionMessages errors, Validator validator,
			HttpServletRequest request) {

		Object result = null;
		String value = null;

		value = evaluateBean(bean, field);

		if (GenericValidator.isBlankOrNull(value)) {
			return Boolean.TRUE;
		}

		Locale locale = RequestUtils.getUserLocale(request, null);
		result = GenericTypeValidator.formatBVFloat(value, locale);

		if (result == null) {
			errors.add(field.getKey(), Resources.getActionMessage(validator,
					request, va, field));
		}

		return (result == null) ? Boolean.FALSE : result;
	}
}
