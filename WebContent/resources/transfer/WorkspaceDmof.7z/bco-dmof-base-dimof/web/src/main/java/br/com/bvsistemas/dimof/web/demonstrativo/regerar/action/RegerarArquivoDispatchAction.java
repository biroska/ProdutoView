/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.regerar.action;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.AuxiliarRelatorioVO;
import br.com.bvsistemas.dimof.services.AuxiliarRelatorioServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.demonstrativo.regerar.form.RegerarArquivoForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.datatype.enums.BooleanEnum;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.utils.BVEnumUtils;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Classe respons�vel por controlar as opera��es referentes � 
 * tela do UC012 Regerar Arquivo.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 * 
 * @struts.action name="regerarArquivoForm" 
 *                path="/regerarArquivo"
 *                scope="session" 
 *                parameter="operacao" 
 *                input="dimof.demonstrativo.regerarArquivo" 
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.demonstrativo.regerarArquivo"
 * 
 */
public class RegerarArquivoDispatchAction extends AbstractBaseDispatchAction {

	/**
	 * Inicializa a tela.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		RegerarArquivoForm theForm = (RegerarArquivoForm) form;
		
		// Limpa o form (setando os campos default)
		resetForm(theForm);

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Atualiza ou insere um registro de relatorio.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward regerar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		RegerarArquivoForm theForm = (RegerarArquivoForm) form;
		
		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		if (erros.isEmpty()) {
			try {
				// Obtem o servi�o
				AuxiliarRelatorioServices services = 
					(AuxiliarRelatorioServices) getProxy(request, 
							AuxiliarRelatorioServices.class);

				Integer nuSemestre = new Integer(theForm.getNuSemestre());
				Integer ano = new Integer(theForm.getAno());

				BooleanEnum flRetificador = null;
				if (StringUtils.isNotBlank(theForm.getFlRetificador())) {
					flRetificador = BVEnumUtils.getEnum(
							BooleanEnum.class, new Character('S'));
				} else {
					flRetificador = BVEnumUtils.getEnum(
							BooleanEnum.class, new Character('N'));
				}

				IdentifierPK pk = new IdentifierPK(1);
				AuxiliarRelatorioVO vo = new AuxiliarRelatorioVO(pk);
				vo.setNuSemestre(new Integer(nuSemestre));
				vo.setAno(new Integer(ano));
				vo.setFlRetificadora(flRetificador);
				vo.setTpProcessado(0);

				// Chama o servi�o				
				services.regerar(vo);
				
				// Operacao realizada com sucesso
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.success.demonstrativo.regeradoComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);

			} catch (ValidationException e) {
				// Erro inesperado
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.erroInesperado"));
				saveErrors(request, messages);
			}

		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/*
	 * Limpa o form (setando os campos default).
	 */
	private void resetForm(RegerarArquivoForm theForm) {

		Date dataAtual = new Date();

		Calendar calendar = new GregorianCalendar();
		calendar.setTime(dataAtual);

		int mesAtual = calendar.get(Calendar.MONTH);
		Integer nuSemestre = null;
		Integer ano = calendar.get(Calendar.YEAR);

		if (mesAtual > 6) {
			// Recupera o n�mero do semestre anterior
			// Mantem o ano atual
			nuSemestre = new Integer(1);

		} else {
			// Recupera o n�mero do semestre anterior
			// Recupera o ano anterior
			nuSemestre = new Integer(2);
			ano--;
		}
		
		theForm.setAno(ano.toString());
		theForm.setNuSemestre(nuSemestre.toString());
		theForm.setFlRetificador(null);
	}
}
