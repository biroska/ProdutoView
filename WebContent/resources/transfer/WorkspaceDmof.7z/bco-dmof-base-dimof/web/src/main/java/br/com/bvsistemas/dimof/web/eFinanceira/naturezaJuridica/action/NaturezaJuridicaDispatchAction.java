package br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.NaturezaJuridicaVO;
import br.com.bvsistemas.dimof.services.NaturezaJuridicaServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.form.NaturezaJuridicaForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;

import com.vf.util.data.vLogin;

/**
 * Action responsavel pela funcionalidade consultar Natureza Juridica
 * 
 * @struts.action name="naturezaJuridicaForm" path="/consultarNaturezaJuridica"
 *                scope="session" parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.eFinanceira.naturezaJuridica"
 * 
 */

public class NaturezaJuridicaDispatchAction extends AbstractBaseDispatchAction {

	public NaturezaJuridicaDispatchAction() {
	}

	/**
	 * Inicializa a tela da Natureza Juridica.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception
	 *             Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		NaturezaJuridicaForm theForm = (NaturezaJuridicaForm) form;

		// Limpa o form
		limparForm(theForm);

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Volta para a pagina inicial da aplicacao.
	 * 
	 * @param mapping
	 *            O mapeamento da action
	 * @param form
	 *            O form de alteracao
	 * @param request
	 *            O request recebido
	 * @param response
	 *            A response recebida
	 * @return ActionForward A acao enviada
	 * @throws Exception
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}

	/**
	 * Realiza a consulta de liminares.
	 * 
	 * @param mapping
	 *            O ActionMapping utilizado para escolher essa inst�ncia.
	 * @param form
	 *            O ActionForm relativo � a��o corrente.
	 * @param request
	 *            Objeto com dados da requisi��o HTTP.
	 * @param response
	 *            Objeto com dados da resposta HTTP.
	 * 
	 * @return ActionForward para onde o fluxo deve ser direcionado.
	 * 
	 * @throws Exception
	 *             Se ocorrer qualquer erro n�o trat�vel pela aplica��o.
	 */
	public ActionForward listar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		NaturezaJuridicaForm theForm = (NaturezaJuridicaForm) form;

		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		if (erros.isEmpty()) {
			// realiza a pesquisa

			// Obtem o servi�o
			NaturezaJuridicaServices naturezaJuridicaService = (NaturezaJuridicaServices) getProxy(
					request, NaturezaJuridicaServices.class);

			try {
				
				List<NaturezaJuridicaVO> listaNaturezaJuridica = naturezaJuridicaService.listar(this.preencherVO(theForm, request));
				
				// Verifica o resultado da consulta
				if ((listaNaturezaJuridica == null)
						|| (listaNaturezaJuridica.isEmpty())) {
					
					// N�o h� retorno de dados
					ActionMessages messages = new ActionErrors();
					messages.add(Globals.MESSAGE_KEY, new ActionMessage(
							"message.error.buscaSemRegistro"));
					saveErrors(request, messages);

					// Limpa a lista de resultados da cosnulta
					theForm.setListaNaturezaJuridica(null);
					
				} else {
					// Seta lista de resultados da consulta
					theForm.setListaNaturezaJuridica(listaNaturezaJuridica);
				}
				
				theForm.setCdNaturezaJuridica(null);
				theForm.setTxtCodigoNaturezaJuridica(null);
				theForm.setTxtEfinanceira(null);
				theForm.setTxtNmNaturezaJuridica(null);
				
				
			} catch (ValidationException e) {
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.valorInvalido"));
				saveErrors(request, erros);

			} catch (Exception e) {
				erros.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.erroInesperado"));
				saveErrors(request, erros);
			}

		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Limpa o form.
	 */
	private void limparForm(NaturezaJuridicaForm theForm) {
		theForm.setCdNaturezaJuridica(null);
		theForm.setTxtCodigoNaturezaJuridica(null);
		theForm.setTxtEfinanceira(null);
		theForm.setTxtNmNaturezaJuridica(null);
		theForm.setListaNaturezaJuridica(null);
	}

	private NaturezaJuridicaVO preencherVO(NaturezaJuridicaForm form, HttpServletRequest request) {

		vLogin usuarioLogado = (vLogin) request.getSession().getAttribute(
				Constantes.SESSION_USER_LOGIN);
	
		NaturezaJuridicaVO vo = new NaturezaJuridicaVO(new IdentifierPK());

		 vo.setDsLogin(usuarioLogado.getUsuario());
		
		if (form.getTxtCodigoNaturezaJuridica() != null
				&& !form.getTxtCodigoNaturezaJuridica().isEmpty()) {
			vo.setCdNaturezaJuridica(form.getTxtCodigoNaturezaJuridica());
		}

		if (form.getTxtNmNaturezaJuridica() != null
				&& !form.getTxtNmNaturezaJuridica().isEmpty()) {
			vo.setNmNaturezaJuridica(form.getTxtNmNaturezaJuridica().trim());

		}

		if (form.getTxtEfinanceira() != null
				&& !form.getTxtEfinanceira().isEmpty()) {
			vo.setFlEnviaInformacaoEFinanceira(form.getTxtEfinanceira());
		}

		return vo;

	}
}
