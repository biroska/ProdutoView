/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoVO;
import br.com.bvsistemas.dimof.services.MovimentacaoServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.form.ConsultarDetalheMovimentoForm;
import br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.relatorio.GeradorRelatorioExcel;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;

/**
 * Action para exibi��o de detalhe de movimento
 * 
 * @author elias.yoshida
 * 
 * @struts.action name="consultarDetalheMovimentoForm"
 *                path="/consultarDetalheMovimento" scope="session"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.demonstrativo.consultarDetalheMovimento"
 * 
 */
public class ConsultarDetalheMovimentoDispatchAction extends AbstractBaseDispatchAction {

	/**
	 * Action respons�vel por exibir os detalhes de movimento
	 * 
	 */
	public ActionForward detalharMovimento(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		// instancia do form
		ConsultarDetalheMovimentoForm theForm = (ConsultarDetalheMovimentoForm) form;
		limparForm(theForm);
		// instancia do servi�o
		MovimentacaoServices movimentacaoService = (MovimentacaoServices) getProxy(request, MovimentacaoServices.class);
		
		Integer cdPessoa = new Integer(request.getParameter("cdPessoa"));
		String ano       = request.getParameter("ano");
		String semestre  = request.getParameter("semestre");
		theForm.setTxtAno(ano);
		theForm.setTxtSemestre(semestre);
		
		DetalheMovimentoVO detalheMovimentoVO = movimentacaoService.detalharMovimento(semestre, ano, cdPessoa);
		if (detalheMovimentoVO != null) {
			theForm.setNuContaCorrente(detalheMovimentoVO.getNuContaCorrente());
			
			// carrega as informacoes do cliente
			if (detalheMovimentoVO.getCliente() != null) {
				theForm.setCdPessoa(detalheMovimentoVO.getCliente().getPk().getId().toString());
				theForm.setNmPessoa(detalheMovimentoVO.getCliente().getNmPessoa());
				theForm.setNuCpfCnpj(detalheMovimentoVO.getCliente().getNuCpfCnpj());
				theForm.setTpPessoa(detalheMovimentoVO.getCliente().getTpPessoa().toString());
			}
			// carrega a lista de detalhe de movimentacoes de cambio
			if (detalheMovimentoVO.getListaMovCambio() != null && !detalheMovimentoVO.getListaMovCambio().isEmpty()) {
				theForm.setListaDetalheMovimentoCambio(detalheMovimentoVO.getListaMovCambio());
			}
			// carrega a lista de detalhe de movimentacoes de conta corrente
			if (detalheMovimentoVO.getListaMovContaCC() != null && !detalheMovimentoVO.getListaMovContaCC().isEmpty()) {
				theForm.setListaDetalheMovimentoCC(detalheMovimentoVO.getListaMovContaCC());
			}
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	
	/**
	 * Action que gera o arquivo CSV conforme o cliente exibido
	 */
	public ActionForward gerarArquivo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		Integer cdPessoa = new Integer(request.getParameter("cdPessoa"));
		String ano       = request.getParameter("txtAno");
		String semestre  = request.getParameter("txtSemestre");

		// instancia do servi�o
		MovimentacaoServices movimentacaoService = (MovimentacaoServices) getProxy(request, MovimentacaoServices.class);
		
		DetalheMovimentoVO detalheMovimentoVO = movimentacaoService.detalharMovimento(semestre, ano, cdPessoa);
		if (detalheMovimentoVO != null) {
			try {

		 		GeradorRelatorioExcel gerador = new GeradorRelatorioExcel();
				gerador.gerarRelatorio(response, detalheMovimentoVO);

		 	}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	
	private void limparForm(ConsultarDetalheMovimentoForm form){
		form.setListaDetalheMovimentoCambio(new ArrayList<DetalheMovimentoCambioVO>());
		form.setListaDetalheMovimentoCC(new ArrayList<DetalheMovimentoCCVO>());
		
	}
	
}
