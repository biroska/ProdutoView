/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.consultar.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.services.LiminarServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.liminar.consultar.form.VisualizarDetalheLiminarForm;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Action respons�vel pela funcionalidade Vizualizar Detalhes Liminar.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.action name="visualizarDetalheLiminarForm"
 *                path="/visualizarDetalheLiminar" scope="request"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.liminar.visualizarDetalhe"
 * 
 */
public class VisualizarDetalheLiminarDispatchAction extends
		AbstractBaseDispatchAction {

	
	/**
	 * Constante nome do parametro
	 */
	public final String COD_LIMINAR = "codLiminar";
	
	/**
	 * 
	 * Action respons�vel por inicializar a Tela de vizualizar liminar.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {		
		
		// Obtem o servi�o
		LiminarServices liminarServices = 
			(LiminarServices) getProxy(request, LiminarServices.class);		
		
		//declara��o das variaveis
		//recupera o codigo do parametro
		Long codLiminar = (Long) new Long(request.getParameter(COD_LIMINAR).
				toString());
		LiminarVO liminar = null;
		IdentifierPK pkLiminar = new IdentifierPK(codLiminar);
		try{
			liminar = liminarServices.consultarLiminar(pkLiminar);

		} catch(Exception e) {
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		
		}	
		//Instancia do form
		VisualizarDetalheLiminarForm visualizarForm = 
			(VisualizarDetalheLiminarForm) form;	
		
		//Sseta o VO no form
		visualizarForm.setLiminarVO(liminar);
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	/**
	 * Action respons�vel por voltar para a pagina inicial da aplicacao.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}

}
