/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.action;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.MovimentacaoVO;
import br.com.bvsistemas.dimof.services.MovimentacaoServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.form.ConsultarMovimentacoesForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Action responsavel pela funcionalidade consultar Movimentacoes
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * @autor <a href="mailto:palmeida@ciandt.com">Priscila Almeida</a>
 * 
 * @struts.action name="consultarMovimentacoesForm"
 *                path="/consultarMovimentacoes" scope="session"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.demonstrativo.consultarMovimentacoes"
 * 
 */
public class ConsultarMovimentacoesDispatchAction extends
		AbstractBaseDispatchAction {
	/**
	 * constante de formato da data
	 */
	public final String DD_MM_YYYY="dd/MM/yyyy";
	
	/**
	 * constante valor do primeiro semestre
	 */
	public final String PRIMEIRO_SEMESTRE="1";
	
	/**
	 * Valor do segundo semestre
	 */
	public final String SEGUNDO_SEMESTRE="2";
	
	/**
	 * Nome do campo de erro
	 */
	public final String TXT_ANO="txtAno";
	

	/**
	 * Action respons�vel por inicializar a Tela de Consulta de Movimentacoes
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 * @autor <a href="mailto:palmeida@ciandt.com">Priscila Almeida</a>
	 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		ConsultarMovimentacoesForm theForm = (ConsultarMovimentacoesForm) form;
		
		// Limpa o form
		limparForm(theForm);

		Date dataAtual = new Date();

		Calendar calendar = new GregorianCalendar();
		calendar.setTime(dataAtual);

		int mesAtual = calendar.get(Calendar.MONTH);
		String nuSemestre = null;
		Integer ano = calendar.get(Calendar.YEAR);

		if (mesAtual > 6) {
			// Recupera o n�mero do semestre anterior
			// Mantem o ano atual
			nuSemestre = PRIMEIRO_SEMESTRE;

		} else {
			// Recupera o n�mero do semestre anterior
			// Recupera o ano anterior
			nuSemestre = SEGUNDO_SEMESTRE;
			ano--;
		}

		theForm.setTxtSemestre(nuSemestre);
		theForm.setTxtAno(ano.toString());

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Action respons�vel por realizar consulta de movimentacaoes.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward consultar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// instancia do form
		ConsultarMovimentacoesForm theForm = (ConsultarMovimentacoesForm) form;

		// Validacoes
		ActionMessages erros = theForm.validate(mapping, request);

		if (erros.isEmpty()) {
			// instancia do servi�o
			MovimentacaoServices movimentacaoService = 
				(MovimentacaoServices) getProxy(
						request, MovimentacaoServices.class);
			// instancia o objeto
			IdentifierPK pkCliente = new IdentifierPK();

			// preenchimento do filtro cliente
			if (theForm.getIdCliente() != null
					&& StringUtils.isNotBlank(theForm.getIdCliente())
					&& StringUtils.isNumeric(theForm.getIdCliente())) {
				pkCliente.setId(new Long(theForm.getIdCliente()));
			}
			List<MovimentacaoVO> listaMovimentacaoes = movimentacaoService
					.listar(theForm.getTxtSemestre(), theForm.getTxtAno(),
							pkCliente);
			// Verifica o resultado da consulta
			if ((listaMovimentacaoes == null)
					|| (listaMovimentacaoes.isEmpty())) {
				// N�o h� retorno de dados
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.buscaSemRegistro"));
				saveErrors(request, messages);

				// Limpa a lista de resultados da cosnulta
				theForm.setListaMovimentacao(null);
			} else {
				// Seta lista de resultados da cosnulta
				theForm.setListaMovimentacao(listaMovimentacaoes);
			}
		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Limpa o form.
	 */
	private void limparForm(ConsultarMovimentacoesForm theForm) {
		theForm.setIdCliente(null);
		theForm.setTxtCliente(null);
		theForm.setTxtAno(null);
		theForm.setTxtSemestre(null);
		theForm.setListaMovimentacao(null);
	}
}
