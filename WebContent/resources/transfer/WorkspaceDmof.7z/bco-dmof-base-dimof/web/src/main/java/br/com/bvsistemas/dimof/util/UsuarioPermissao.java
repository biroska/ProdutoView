package br.com.bvsistemas.dimof.util;

import java.io.Serializable;
import java.util.Hashtable;

import br.com.bvsistemas.dimof.util.permissoes.AgendamentoPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofDemonstrativoMovimentacaoPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofDemonstrativoRegerarArquivoPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofLiminarAdmPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofLiminarHistoricoAlteracoesPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofLiminarPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofNaturezaJuridicaLogPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofNaturezaJuridicaPermissao;
import br.com.bvsistemas.dimof.util.permissoes.DimofParametrosPermissao;

/**
 * Classe para manipulacao das permissoes de acesso do usuario provindas do
 * VFAcesso
 * 
 * @author cit.cmiranda
 * 
 */
public class UsuarioPermissao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1793575772173928003L;

	/**
	 * Objetos com de transacoes
	 */
	private DimofDemonstrativoMovimentacaoPermissao demonstrativoMovimentacao;
	private DimofDemonstrativoRegerarArquivoPermissao regerarArquivo;
	private DimofLiminarAdmPermissao liminarAdm;
	private DimofLiminarHistoricoAlteracoesPermissao liminarHistorico;
	private DimofLiminarPermissao liminarPermissao;
	private DimofParametrosPermissao parametroPermissao;
	private AgendamentoPermissao agendamentoPermissao;
	private DimofNaturezaJuridicaPermissao naturezaJuridicaPermissao;
	private DimofNaturezaJuridicaLogPermissao naturezaJuridicaLogPermissao;

	/**
	 * @return the parametroPermissao
	 */
	public DimofParametrosPermissao getParametroPermissao() {
		return parametroPermissao;
	}

	/**
	 * @param parametroPermissao
	 *            the parametroPermissao to set
	 */
	public void setParametroPermissao(
			DimofParametrosPermissao parametroPermissao) {
		this.parametroPermissao = parametroPermissao;
	}

	public UsuarioPermissao() {
		super();
	}

	/**
	 * 
	 * Construtor que recebe a hash de transacoes
	 * 
	 * @param transacoesMap
	 */
	public UsuarioPermissao(Hashtable<String, String> transacoesMap) {

		// Montas os objetos de transacoes
		this.setDemonstrativoMovimentacao(new 
				DimofDemonstrativoMovimentacaoPermissao(transacoesMap));
		this.setLiminarAdm(new DimofLiminarAdmPermissao(transacoesMap));
		this.setLiminarHistorico(new DimofLiminarHistoricoAlteracoesPermissao(
				transacoesMap));
		this.setLiminarPermissao(new DimofLiminarPermissao(transacoesMap));
		this.setRegerarArquivo(new DimofDemonstrativoRegerarArquivoPermissao(
				transacoesMap));
		this.setParametroPermissao(new DimofParametrosPermissao(transacoesMap));
		this.setAgendamentoPermissao( new AgendamentoPermissao( transacoesMap ) );

		this.setNaturezaJuridicaPermissao(new DimofNaturezaJuridicaPermissao(transacoesMap));
		this.setNaturezaJuridicaLogPermissao(new DimofNaturezaJuridicaLogPermissao(transacoesMap));
		
	}

	/**
	 * @return the demonstrativoMovimentacao
	 */
	public DimofDemonstrativoMovimentacaoPermissao 
		getDemonstrativoMovimentacao() {
		return demonstrativoMovimentacao;
	}

	/**
	 * @param demonstrativoMovimentacao
	 *            the demonstrativoMovimentacao to set
	 */
	public void setDemonstrativoMovimentacao(
			DimofDemonstrativoMovimentacaoPermissao demonstrativoMovimentacao) {
		this.demonstrativoMovimentacao = demonstrativoMovimentacao;
	}

	/**
	 * @return the regerarArquivo
	 */
	public DimofDemonstrativoRegerarArquivoPermissao getRegerarArquivo() {
		return regerarArquivo;
	}

	/**
	 * @param regerarArquivo
	 *            the regerarArquivo to set
	 */
	public void setRegerarArquivo(
			DimofDemonstrativoRegerarArquivoPermissao regerarArquivo) {
		this.regerarArquivo = regerarArquivo;
	}

	/**
	 * @return the liminarAdm
	 */
	public DimofLiminarAdmPermissao getLiminarAdm() {
		return liminarAdm;
	}

	/**
	 * @param liminarAdm
	 *            the liminarAdm to set
	 */
	public void setLiminarAdm(DimofLiminarAdmPermissao liminarAdm) {
		this.liminarAdm = liminarAdm;
	}

	/**
	 * @return the liminarHistorico
	 */
	public DimofLiminarHistoricoAlteracoesPermissao getLiminarHistorico() {
		return liminarHistorico;
	}

	/**
	 * @param liminarHistorico
	 *            the liminarHistorico to set
	 */
	public void setLiminarHistorico(
			DimofLiminarHistoricoAlteracoesPermissao liminarHistorico) {
		this.liminarHistorico = liminarHistorico;
	}

	/**
	 * @return the liminarPermissao
	 */
	public DimofLiminarPermissao getLiminarPermissao() {
		return liminarPermissao;
	}

	/**
	 * @param liminarPermissao
	 *            the liminarPermissao to set
	 */
	public void setLiminarPermissao(DimofLiminarPermissao liminarPermissao) {
		this.liminarPermissao = liminarPermissao;
	}

	public AgendamentoPermissao getAgendamentoPermissao() {
		return agendamentoPermissao;
	}

	public void setAgendamentoPermissao(AgendamentoPermissao agendamentoPermissao) {
		this.agendamentoPermissao = agendamentoPermissao;
	}
	/**
	 * @return the naturezaJuridicaLogPermissao
	 */	
	public DimofNaturezaJuridicaLogPermissao getNaturezaJuridicaLogPermissao() {
		return naturezaJuridicaLogPermissao;
	}

	/**
	 * @param naturezaJuridicaLogPermissao
	 *            the naturezaJuridicaLogPermissao to set
	 */
	public void setNaturezaJuridicaLogPermissao(
			DimofNaturezaJuridicaLogPermissao naturezaJuridicaLogPermissao) {
		this.naturezaJuridicaLogPermissao = naturezaJuridicaLogPermissao;
	}

	/**
	 * @return the naturezaJuridicaPermissao
	 */	
	public DimofNaturezaJuridicaPermissao getNaturezaJuridicaPermissao() {
		return naturezaJuridicaPermissao;
	}

	/**
	 * @param naturezaJuridicaPermissao
	 *            the naturezaJuridicaPermissao to set
	 */	
	public void setNaturezaJuridicaPermissao(
			DimofNaturezaJuridicaPermissao naturezaJuridicaPermissao) {
		this.naturezaJuridicaPermissao = naturezaJuridicaPermissao;
	}

	
	
}
