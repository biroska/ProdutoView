package br.com.bvsistemas.dimof.web.eFinanceira.naturezaJuridica.form;

import java.util.List;

import br.com.bvsistemas.dimof.datatype.LogNaturezaJuridicaVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela ....
 * 
 * @struts.form name="historicoNaturezaJuridicaForm"
 * 
 */

public class HistoricoNaturezaJuridicaForm extends AbstractBaseValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3805281053925448759L;

	private String operacao;
	private String txtCodigoNaturezaJuridica;
	private String txtNmNaturezaJuridica;
	private String txtEfinanceira;
	private String txtPeriodoIni;
	private String txtPeriodoFim;
	/*private List<HistoricoNaturezaJuridicaVO> listaHistoricoNaturezaJuridica;*/
	private List<LogNaturezaJuridicaVO> listaHistoricoNaturezaJuridica;
	
	public String getOperacao() {
		return operacao;
	}

	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	public String getTxtCodigoNaturezaJuridica() {
		return txtCodigoNaturezaJuridica;
	}

	public void setTxtCodigoNaturezaJuridica(String txtCodigoNaturezaJuridica) {
		this.txtCodigoNaturezaJuridica = txtCodigoNaturezaJuridica;
	}

	public String getTxtNmNaturezaJuridica() {
		return txtNmNaturezaJuridica;
	}

	public void setTxtNmNaturezaJuridica(String txtNmNaturezaJuridica) {
		this.txtNmNaturezaJuridica = txtNmNaturezaJuridica;
	}

	public String getTxtEfinanceira() {
		return txtEfinanceira;
	}

	public void setTxtEfinanceira(String txtEfinanceira) {
		this.txtEfinanceira = txtEfinanceira;
	}

	public String getTxtPeriodoIni() {
		return txtPeriodoIni;
	}

	public void setTxtPeriodoIni(String txtPeriodoIni) {
		this.txtPeriodoIni = txtPeriodoIni;
	}

	public String getTxtPeriodoFim() {
		return txtPeriodoFim;
	}

	public void setTxtPeriodoFim(String txtPeriodoFim) {
		this.txtPeriodoFim = txtPeriodoFim;
	}

	public List<LogNaturezaJuridicaVO> getListaHistoricoNaturezaJuridica() {
		return listaHistoricoNaturezaJuridica;
	}

	public void setListaHistoricoNaturezaJuridica(
			List<LogNaturezaJuridicaVO> listaHistoricoNaturezaJuridica) {
		this.listaHistoricoNaturezaJuridica = listaHistoricoNaturezaJuridica;
	}

/*	public List<HistoricoNaturezaJuridicaVO> getListaHistoricoNaturezaJuridica() {
		return listaHistoricoNaturezaJuridica;
	}

	public void setListaHistoricoNaturezaJuridica(
			List<HistoricoNaturezaJuridicaVO> listaHistoricoNaturezaJuridica) {
		this.listaHistoricoNaturezaJuridica = listaHistoricoNaturezaJuridica;
	}*/
	
	
}
