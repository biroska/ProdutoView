package br.com.bvsistemas.dimof.web.eFinanceira.agendamento.action;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.exception.CamposObrigatoriosNaoPreenchidosException;
import br.com.bvsistemas.dimof.services.AgendamentoServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.eFinanceira.agendamento.form.AgendamentoEfinanceiraForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;

/**
 * Action responsavel pela funcionalidade de agendamentos.
 * 
 * @author Aimbere Galdino
 * 
 * @struts.action name="agendamentoEfinanceiraForm" 
 *                path="/agendamentoEfinanceira"
 *                scope="request" 
 *                parameter="operacao" 
 *                input="dimof.eFinanceira.agendamento" 
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.eFinanceira.agendamento"
 * 
 */
public class AgendamentoEfinanceiraDispatchAction extends AbstractBaseDispatchAction {
	
	public AgendamentoEfinanceiraDispatchAction(){
	}
	
	private static final BVLogger logger = BVLogger.getLogger(AgendamentoEfinanceiraDispatchAction.class);
	
	/**
	 * Inicializa a tela da agendamentos.
	 * 
	 * @param mapping
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form
	 *            ActionForm, formulario com os dados da tela
	 * @param request
	 *            HttpServletRequest, request do servidor
	 * @param response
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward Forward de redirecionamento
	 * @throws Exception Excecao nao tratada
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// Recupera o form
		AgendamentoEfinanceiraForm theForm = (AgendamentoEfinanceiraForm) form;
		
		// Limpa o form
		limparForm(theForm);
		
		request.setAttribute( "EXIBE_GRID", "N" );

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	/**
	 * Volta para a pagina inicial da aplicacao.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}
	
	/**
	 * Realiza a consulta de agendamentos.
	 * 
	 * @param mapping
	 *            O ActionMapping utilizado para escolher essa inst�ncia.
	 * @param form
	 *            O ActionForm relativo � a��o corrente.
	 * @param request
	 *            Objeto com dados da requisi��o HTTP.
	 * @param response
	 *            Objeto com dados da resposta HTTP.
	 * 
	 * @return ActionForward para onde o fluxo deve ser direcionado.
	 * 
	 * @throws Exception
	 *             Se ocorrer qualquer erro n�o trat�vel pela aplica��o.
	 */
	public ActionForward cancelar(ActionMapping mapping, 
			ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) {
		
		
			// Recupera o form
			AgendamentoEfinanceiraForm theForm = (AgendamentoEfinanceiraForm) form;
			
			// Executa as valida��es
			ActionMessages erros = theForm.validate(mapping, request);
			
		try{
			
			// Obtem o servi�o
			AgendamentoServices service = (AgendamentoServices) getProxy(request, AgendamentoServices.class);
			if ( validaCancelamentoAgendamento( theForm ) ){
				
				service.cancelar( theForm.getCodAgendamento() );
				
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage("message.success.agendamento.eFinanceira.canceladoComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				
			} else {
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.parametroInvalido", "Codigo do Agendamento"));
				saveErrors(request, erros);
			}
			
//			Executa a consulta e atualiza a lista no formulario
			executaConsulta(theForm, service);
			
		} catch ( Exception e ){
			logger.workflow.info("Aconteceu um erro \n: ", new Exception( e.toString() )  );
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.erroInesperado") );
			saveErrors(request, erros);
		}
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

//	Executa a consulta e atualiza a lista no formulario
	private void executaConsulta(AgendamentoEfinanceiraForm theForm, AgendamentoServices service)
			throws CamposObrigatoriosNaoPreenchidosException {
		
		List<AgendamentoVO> listar = service.listar( theForm.getTxtStatusProcessamento(), theForm.getTxtMesInicio(),
				 									 theForm.getAnoInicio(), theForm.getTxtMesFinal(), theForm.getAnoFinal() );

		if (listar != null && !listar.isEmpty()) {
			theForm.setListaAgendamentos(new ArrayList<AgendamentoVO>());
			theForm.getListaAgendamentos().addAll(listar);
		} else {
			theForm.setListaAgendamentos(null);
		}
	}
	
	/**
	 * Realiza a consulta de agendamentos.
	 * 
	 * @param mapping
	 *            O ActionMapping utilizado para escolher essa inst�ncia.
	 * @param form
	 *            O ActionForm relativo � a��o corrente.
	 * @param request
	 *            Objeto com dados da requisi��o HTTP.
	 * @param response
	 *            Objeto com dados da resposta HTTP.
	 * 
	 * @return ActionForward para onde o fluxo deve ser direcionado.
	 * 
	 * @throws Exception
	 *             Se ocorrer qualquer erro n�o trat�vel pela aplica��o.
	 */
	public ActionForward listar(ActionMapping mapping, 
			ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {

		// Recupera o form
		AgendamentoEfinanceiraForm theForm = (AgendamentoEfinanceiraForm) form;

		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		if ( erros.isEmpty() ){
			validaForm( theForm, erros );
		}
		
		if ( erros.isEmpty() ){
			
			// Obtem o servi�o
			AgendamentoServices agendamentoServices = (AgendamentoServices) getProxy(request, AgendamentoServices.class);
			
			try {
				
//				Executa a consulta e atualiza a lista no formulario
				executaConsulta(theForm, agendamentoServices);
				
			} catch ( ValidationException e ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.valorInvalido") );
				saveErrors(request, erros);
				
			} catch ( CamposObrigatoriosNaoPreenchidosException e ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios") );
				saveErrors(request, erros);
				
			} catch ( Exception e ){
				erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.erroInesperado") );
				saveErrors(request, erros);
			}
			
//			realiza a pesquisa
		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
	private void validaForm( AgendamentoEfinanceiraForm theForm, ActionMessages erros ){
		
//		Mes inicial nao preenchido
		if ( StringUtils.isBlank( theForm.getTxtMesInicio() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return;
		}

//		Mes inicial nao preenchido
		if ( StringUtils.isBlank( theForm.getAnoInicio() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return;
		}

//		Mes Final nao preenchido
		if ( StringUtils.isBlank( theForm.getTxtMesFinal() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return;
		}
		
//		Mes final nao preenchido
		if ( StringUtils.isBlank( theForm.getAnoFinal() ) ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.eFinanceira.camposObrigatorios"));
			return;
		}
		
		Calendar cal1 = Calendar.getInstance();
		
		cal1.set( Calendar.MONTH, Integer.valueOf( theForm.getTxtMesInicio() ) -1 );
		cal1.set( Calendar.YEAR, Integer.valueOf( theForm.getAnoInicio() ) );
		
		Calendar cal2 = Calendar.getInstance();
		
		cal2.set( Calendar.MONTH, Integer.valueOf( theForm.getTxtMesFinal() ) -1 );
		cal2.set( Calendar.YEAR, Integer.valueOf( theForm.getAnoFinal() ) );
		
//		Verifica se o periodo final eh superior ao inicial
		if ( cal1.compareTo( cal2 ) > 0 ){
			erros.add(Globals.MESSAGE_KEY, new ActionMessage( "message.error.periodoInvalido") );
			return;
		}
	}
	
	private boolean validaCancelamentoAgendamento( AgendamentoEfinanceiraForm theForm ){
		
		boolean isValido = true;
		
		if ( theForm.getCodAgendamento() < 0 ){
			isValido = false;
		}

		return isValido;
	}
	
	
	/**
	 * Limpa o form.
	 */
	private void limparForm(AgendamentoEfinanceiraForm theForm) {
		
		theForm.setAnoFinal( null );
		theForm.setAnoInicio( null );
		theForm.setTxtStatusProcessamento( null );
		theForm.setTxtMesFinal( null );
		theForm.setTxtMesInicio( null );
	}
}
