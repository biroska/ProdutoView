/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.clientes.buscaPessoa.form;

import java.util.ArrayList;
import java.util.List;

import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela de Busca de Pessoas.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.form name="buscaPessoaForm"
 * 
 */
public class BuscaPessoaForm extends AbstractBaseValidatorForm {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;
	
	private String passaDocumento;
	
	public String getPassaDocumento() {
		return passaDocumento;
	}

	public void setPassaDocumento(String passaDocumento) {
		this.passaDocumento = passaDocumento;
	}

	/**
	 * Campo texto razao Social ou nome do Cliente.
	 */
	private String txtRazaoSocial;
	
	/**
	 * Campo texto do Cnpj ou Cpf. 
	 */
	private String txtCpfCnpj;
	
	/**
	 * Lista de resultado da consulta.
	 */
	private List<PessoaVO> pessoasList = new ArrayList<PessoaVO>();

	/**
	 * 
	 * @return the txtRazaoSocial
	 */
	public String getTxtRazaoSocial() {
		return txtRazaoSocial;
	}

	/**
	 * @param txtRazaoSocial
	 *            the txtRazaoSocial to set
	 */
	public void setTxtRazaoSocial(String txtRazaoSocial) {
		this.txtRazaoSocial = txtRazaoSocial;
	}

	/**
	 * @return the txtCpfCnpj
	 */
	public String getTxtCpfCnpj() {
		return txtCpfCnpj;
	}

	/**
	 * @param txtCpfCnpj
	 *            the txtCpfCnpj to set
	 */
	public void setTxtCpfCnpj(String txtCpfCnpj) {
		this.txtCpfCnpj = txtCpfCnpj;
	}

	/**
	 * @return the pessoasList
	 */
	public List<PessoaVO> getPessoasList() {
		return pessoasList;
	}

	/**
	 * @param pessoasList
	 *            the pessoasList to set
	 */
	public void setPessoasList(List<PessoaVO> pessoasList) {
		this.pessoasList = pessoasList;
	}
}