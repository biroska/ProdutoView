/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.demonstrativo.regerar.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * <code>ActionForm</code> do UC012 Regerar Arquivo.
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 * 
 * @struts.form name="regerarArquivoForm"
 * 
 */
public class RegerarArquivoForm extends AbstractBaseValidatorForm {

	/**
	 * Serial.
	 */
	private static final long serialVersionUID = 1L;

	/** 
	 * Operacao a ser realizada.
	 */
	private String operacao;

	/** 
	 * N�mero do semestre.
	 */
	private String nuSemestre;

	/** 
	 * Ano.
	 */
	private String ano;

	/** 
	 * Flag retificador.
	 */
	private String flRetificador;

	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	/**
	 * @return the nuSemestre
	 */
	public String getNuSemestre() {
		return nuSemestre;
	}

	/**
	 * @param nuSemestre the nuSemestre to set
	 */
	public void setNuSemestre(String nuSemestre) {
		this.nuSemestre = nuSemestre;
	}

	/**
	 * @return the ano
	 */
	public String getAno() {
		return ano;
	}

	/**
	 * @param ano the ano to set
	 */
	public void setAno(String ano) {
		this.ano = ano;
	}

	/**
	 * @return the flRetificador
	 */
	public String getFlRetificador() {
		return flRetificador;
	}

	/**
	 * @param flRetificador the flRetificador to set
	 */
	public void setFlRetificador(String flRetificador) {
		this.flRetificador = flRetificador;
	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		flRetificador = null;
	}
}
