/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.parametros.manter.action;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.bvsistemas.dimof.datatype.ParametroSistemaVO;
import br.com.bvsistemas.dimof.datatype.PessoaVO;
import br.com.bvsistemas.dimof.datatype.TipoLogradouroVO;
import br.com.bvsistemas.dimof.exception.DataInvalidaSituacaoEspecialException;
import br.com.bvsistemas.dimof.services.ParametroSistemaServices;
import br.com.bvsistemas.dimof.services.TipoLogradouroServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.dimof.web.parametros.manter.form.ManterParametrosForm;
import br.com.bvsistemas.framework.datatype.BVDate;
import br.com.bvsistemas.framework.datatype.BVFloat;
import br.com.bvsistemas.framework.datatype.IdentifierPK;
import br.com.bvsistemas.framework.exception.ValidationException;
import br.com.bvsistemas.framework.logging.BVLogger;
import br.com.bvsistemas.framework.utils.StringUtils;

/**
 * Classe respons�vel por controlar as opera��es referentes � 
 * tela de Altera��o de Parametros.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 * 
 * @struts.action name="manterParametrosForm" 
 *                path="/manterParametros"
 *                scope="session" 
 *                parameter="operacao" 
 *                input="dimof.paramentros.manterParametros" 
 *                validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.paramentros.manterParametros"
 * 
 * @struts.action-forward name="home" 
 *                        path="dimof.home"
 * 
 */
public class ManterParametrosDispatchAction extends AbstractBaseDispatchAction {
	
	/**
	 * Formato padr�o de data.
	 */
	private static final String DATE_FORMAT = "dd/MM/yyyy";

	/**
	 * Valor do tipo de situa��o especial "N�o se Aplica".
	 */
	private static final String NAO_SE_APLICA = "00";
	
	/**
	 * Objeto para gerar log.
	 */
	private static final BVLogger logger = 
		BVLogger.getLogger(ManterParametrosDispatchAction.class);

	/*
	 * (non-Javadoc)
	 * @see br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction#preProcessa(
	 *      org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public void preProcessa(ActionForm form, HttpServletRequest request)
			throws Exception {

		// Recupera o form
		ManterParametrosForm theForm = (ManterParametrosForm) form;

		if (NAO_SE_APLICA.equals(theForm.getTpSituacaoEspecial())) {
			theForm.setDtEnvioSituacaoEspecial(null);
		}
	}

	/**
	 * Action respons�vel por inicializar a tela de Parametros.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		// Recupera o form
		ManterParametrosForm theForm = (ManterParametrosForm) form;
		
		// Limpa o form
		limparForm(theForm);

		// Obtem os servi�os
		ParametroSistemaServices parametroSistemaServices = 
			(ParametroSistemaServices) getProxy(request, 
					ParametroSistemaServices.class);
		TipoLogradouroServices tipoLogradouroServices = 
			(TipoLogradouroServices) getProxy(request, 
					TipoLogradouroServices.class);

		// Obtem os parametros do sistema
		ParametroSistemaVO parametro = parametroSistemaServices.consultar();

		theForm.setCdParametroSistema(parametro.getPk().getId().toString());
		theForm.setVrLimitePf(converteBVFloatParaStringEdicao(
				request, parametro.getVrLimitePF()));
		theForm.setVrLimitePj(converteBVFloatParaStringEdicao(
				request, parametro.getVrLimitePJ()));
		theForm.setCdPessoaDeclarante(
				(parametro.getDeclarante().getPk().getId()).toString());
		theForm.setNmPessoaDeclarante(
				parametro.getDeclarante().getNmPessoa());
		theForm.setCdPessoaReprLegal(
				(parametro.getRepresentanteLegal().getPk().getId()).toString());
		theForm.setNmPessoaReprLegal(
				parametro.getRepresentanteLegal().getNmPessoa());
		theForm.setCdPessoaRespPreench(
				(parametro.getRespPreenchimento().getPk().getId()).toString());
		theForm.setNmPessoaRespPreench(
				parametro.getRespPreenchimento().getNmPessoa());
		theForm.setCdPessoaRespAtendRmf(
				(parametro.getRespAtendimentoRMF().getPk().getId()).toString());
		theForm.setNmPessoaRespAtendRmf(
				parametro.getRespAtendimentoRMF().getNmPessoa());
		theForm.setTpSituacaoEspecial(parametro.getTpSituacaoEspecial());
		theForm.setDtEnvioSituacaoEspecial(converteBVDateParaStringEdicao(
				parametro.getDtEnvioSituacaoEspecial()));
		TipoLogradouroVO tipoLogradouro = parametro.getTipoLogradouroRespRMF();
		if (tipoLogradouro != null) {
			theForm.setCdTipoLogradouro(
					tipoLogradouro.getPk().getId().toString());
		}
		theForm.setNmArquivo(parametro.getNmArquivo());

		// Obtem a lista de tipos de logradouros
		List<TipoLogradouroVO> listaTipoLogradouro = 
			tipoLogradouroServices.listar();

		theForm.setListaTipoLogradouro(listaTipoLogradouro);

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Action respons�vel por salvar os dados de Parametros.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward salvar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		// Recupera o form
		ManterParametrosForm theForm = (ManterParametrosForm) form;
		
		// Executa as valida��es
		ActionMessages erros = theForm.validate(mapping, request);

		if (erros.isEmpty()) {
			try {
				// Obtem o servi�o
				ParametroSistemaServices parametroSistemaServices = 
					(ParametroSistemaServices) getProxy(request, 
							ParametroSistemaServices.class);

				Long cdParametro = new Long(theForm.getCdParametroSistema());
				IdentifierPK parametroPK = new IdentifierPK(cdParametro);
				ParametroSistemaVO parametro = 
					new ParametroSistemaVO(parametroPK);

				// Chama servi�o para alterar o Parametro				
				parametroSistemaServices.alterar(obterParametroSistema(
						request, theForm, parametro));
				
				// Parametro alterado com sucesso
				ActionMessages messages = new ActionMessages();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.success.parametroAlteradoComSucesso"));
				saveMessages(request, messages);
				request.setAttribute(Globals.MESSAGE_KEY, messages);

			} catch (ValidationException e) {
				// Erro inesperado
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.erroInesperado"));
				saveErrors(request, messages);
				
			} catch (DataInvalidaSituacaoEspecialException e) {
				// Data Evento nao informada
				ActionMessages messages = new ActionErrors();
				messages.add(Globals.MESSAGE_KEY, new ActionMessage(
						"message.error.dataEventoNaoInformada"));
				saveErrors(request, messages);
			}
		} else {
			// Ocorreu erro
			saveErrors(request, erros);
		}

		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}

	/**
	 * Action respons�vel por voltar para a pagina inicial da aplicacao.
	 * 
	 * @param mapping 
	 *            O mapeamento da action
	 * @param form 
	 *            O form de alteracao
	 * @param request 
	 *            O request recebido
	 * @param response 
	 *            A response recebida
	 * @return ActionForward 
	 *             A acao enviada
	 * @throws Exception 
	 *             Excecao da acao do struts
	 */
	public ActionForward voltar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward(Constantes.FORWARD_HOME);
	}

	/*
	 * Limpa o form.
	 */
	private void limparForm(ManterParametrosForm theForm) {
		theForm.setCdParametroSistema(null);
		theForm.setTpPessoaSelecionado(null);
		theForm.setVrLimitePf(null);
		theForm.setVrLimitePj(null);
		theForm.setCdPessoaDeclarante(null);
		theForm.setNmPessoaDeclarante(null);
		theForm.setCdPessoaReprLegal(null);
		theForm.setNmPessoaReprLegal(null);
		theForm.setCdPessoaRespPreench(null);
		theForm.setNmPessoaRespPreench(null);
		theForm.setCdPessoaRespAtendRmf(null);
		theForm.setNmPessoaRespAtendRmf(null);
		theForm.setTpSituacaoEspecial(null);
		theForm.setDtEnvioSituacaoEspecial(null);
		theForm.setCdTipoLogradouro(null);
		theForm.setNmArquivo(null);
	}
	
	/**
	 * M�todo que inicializa um objeto do tipo ParametroSistemaV de
	 * acordo com as informa��es passadas pelo usu�rio e o retorna.
	 * 
	 * @param request
	 *            O request recebido
	 * @param theForm
	 *            O formulario de alteracao
	 * @param parametro
	 *            Objeto ParametroSistemaVO
	 * @return Objeto ParametroSistemaVO inicializado
	 * @throws ParseException
	 *             Excecao de parse da data
	 */
	@SuppressWarnings("deprecation")
	private ParametroSistemaVO obterParametroSistema(
			final HttpServletRequest request, ManterParametrosForm theForm, 
			ParametroSistemaVO parametro) throws ParseException {

		// Informa��es de Limites Movimenta��es
		BVFloat vrLimitePF = converteStringParaBVFloat(request,
				theForm.getVrLimitePf());
		BVFloat vrLimitePJ = converteStringParaBVFloat(request,
				theForm.getVrLimitePj());
		
		// Informa��es de Respons�veis pelo Arquivo de Movimenta��es
		PessoaVO declarante = getPessoaVOPorTipo(
				"declarante", theForm);
		PessoaVO representanteLegal = getPessoaVOPorTipo(
				"representanteLegal", theForm);
		PessoaVO respPreenchimento = getPessoaVOPorTipo(
				"respPreenchimento", theForm);
		PessoaVO respAtendimentoRMF = getPessoaVOPorTipo(
				"respAtendimentoRMF", theForm);
		
		// Informa��es de Configura��o do Arquivo de Movimenta��es

		// Data Evento
		BVDate dtEvento = null;
		if (StringUtils.isNotBlank(theForm.getDtEnvioSituacaoEspecial())) {
			try {
				dtEvento = new BVDate(theForm.getDtEnvioSituacaoEspecial(), 
						DATE_FORMAT);
			} catch (ParseException p) {
				logger.workflow.error("Erro ao converter campo data evento " +
						"para o formato BVDate", p);
			}
		}
		
		// Tipo Logradouro
		TipoLogradouroVO tipoLogradouroVO = new TipoLogradouroVO(
				getIdSelecionado(theForm.getCdTipoLogradouro()));

		// Preenche o parametro
		parametro.setVrLimitePF(vrLimitePF);
		parametro.setVrLimitePJ(vrLimitePJ);
		parametro.setDeclarante(declarante);
		parametro.setRepresentanteLegal(representanteLegal);
		parametro.setRespPreenchimento(respPreenchimento);
		parametro.setRespAtendimentoRMF(respAtendimentoRMF);
		parametro.setTpSituacaoEspecial(theForm.getTpSituacaoEspecial());
		parametro.setDtEnvioSituacaoEspecial(dtEvento);
		parametro.setTipoLogradouroRespRMF(tipoLogradouroVO);
		parametro.setNmArquivo(theForm.getNmArquivo().trim());

		return parametro;	
	}
	
	/*
	 * Obt�m um VO de um determinado tipo de Pessoa.
	 * @return Objeto <code>PessoaVO</code>
	 */
	@SuppressWarnings("deprecation")
    private PessoaVO getPessoaVOPorTipo(final String tipo, 
    		ManterParametrosForm theForm) {

		PessoaVO vo = null;

		if ("declarante".equals(tipo)) {
			final Long cdPessoa = new Long(theForm.getCdPessoaDeclarante());
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = theForm.getNmPessoaDeclarante();
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		} else if ("representanteLegal".equals(tipo)) {
			final Long cdPessoa = new Long(theForm.getCdPessoaReprLegal());
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = theForm.getNmPessoaReprLegal();
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		} else if ("respPreenchimento".equals(tipo)) {
			final Long cdPessoa = new Long(theForm.getCdPessoaRespPreench());
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = theForm.getNmPessoaRespPreench();
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		} else if ("respAtendimentoRMF".equals(tipo)) {
			final Long cdPessoa = new Long(theForm.getCdPessoaRespAtendRmf());
			IdentifierPK cdPessoaPK = new IdentifierPK(cdPessoa);
			final String nmPessoa = theForm.getNmPessoaRespAtendRmf();
			
			vo = new PessoaVO(cdPessoaPK);
			vo.setNmPessoa(nmPessoa);
		}

		return vo;
	}
}
