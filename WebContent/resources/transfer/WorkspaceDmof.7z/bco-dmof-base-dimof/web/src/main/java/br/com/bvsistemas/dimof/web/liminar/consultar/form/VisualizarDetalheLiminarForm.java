/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.consultar.form;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * Formulario com os dados da tela ....
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.form name="visualizarDetalheLiminarForm"
 * 
 */
public class VisualizarDetalheLiminarForm extends AbstractBaseValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    
	//VO liminar
   private LiminarVO liminarVO;	
   
	

	/**
	 * 
	 * @return the liminarVO
	 */
	public LiminarVO getLiminarVO() {
		return liminarVO;
	}

	/**
	 * @param liminarVO the liminarVO to set
	 */
	public void setLiminarVO(LiminarVO liminarVO) {
		this.liminarVO = liminarVO;
	}
	


}
