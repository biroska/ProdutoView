/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.eFinanceira.agendamento.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.com.bvsistemas.dimof.datatype.AgendamentoVO;
import br.com.bvsistemas.dimof.services.AgendamentoServices;
import br.com.bvsistemas.dimof.util.Constantes;
import br.com.bvsistemas.dimof.web.eFinanceira.agendamento.form.VisualizarDetalhesAgendamentoForm;
import br.com.bvsistemas.dimof.web.framework.action.AbstractBaseDispatchAction;
import br.com.bvsistemas.framework.datatype.IdentifierPK;

/**
 * Action respons�vel pela funcionalidade Vizualizar Detalhes Liminar.
 * 
 * @author <a href="mailto:cit.mcardoso@bvsistemas.com.br">cit.mcardoso</a>
 * 
 * @struts.action name="visualizarDetalhesAgendamentoForm"
 *                path="/visualizarDetalhesAgendamento" scope="request"
 *                parameter="operacao" input="" validate="false"
 * 
 * @struts.action-forward name="paginaPrincipal"
 *                        path="dimof.eFinanceira.agendamento.visualizarDetalhes"
 * 
 */
public class VisualizarDetalhesAgendamentoDispatchAction extends
		AbstractBaseDispatchAction {

	
	/**
	 * Constante nome do parametro
	 */
	private static final String COD_AGENDAMENTO = "codAgendamento";
	
	/**
	 * 
	 * Action respons�vel por inicializar a Tela de vizualizar detalhes de agendamento.
	 * 
	 * @param mapping -
	 *            ActionMapping, mapping com os atributos do struts
	 * @param form -
	 *            ActionForm, formulario com os dados da tela
	 * @param request -
	 *            HttpServletRequest, request do servidor
	 * @param response -
	 *            HttpServletResponse, response do servidor
	 * @return ActionForward - Forward de redirecionamento
	 * @throws Exception,
	 *             excecao nao tratada
	 * 
	 */
	public ActionForward prepararTela(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {		
		
		String txtPeriodo="";
		
		// Obtem o servi�o
		AgendamentoServices agendamentoServices = 
			(AgendamentoServices) getProxy(request, AgendamentoServices.class);		
		
		//declara��o das variaveis
		//recupera o codigo do parametro
		Long codAgendamento = (Long) new Long(request.getParameter(COD_AGENDAMENTO).
				toString());
		AgendamentoVO agendamento = null;
		IdentifierPK pkAgendamento = new IdentifierPK(codAgendamento);
		try{
			agendamento = agendamentoServices.consultarAgendamento(pkAgendamento);			

		} catch(Exception e) {
			return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
		
		}	
		//Instancia do form
		VisualizarDetalhesAgendamentoForm visualizarForm = 
			(VisualizarDetalhesAgendamentoForm) form;	
		
		//Sseta o VO no form
		visualizarForm.setAgendamentoVO(agendamento);
				
		if (agendamento != null) {
			txtPeriodo = agendamento.getMesInicial().getNomeMes() + "/" + agendamento.getAnoInicial() +
				" � " + agendamento.getMesFinal().getNomeMes() + "/" + agendamento.getAnoFinal();
		}
		
		visualizarForm.setTxtPeriodo(txtPeriodo);
		
		visualizarForm.setListaEmpresas(agendamentoServices.listarEmpresas(codAgendamento));
		visualizarForm.setListaClientes(agendamentoServices.listarClientes(codAgendamento));
		
		visualizarForm.setListaResultadoSistema(agendamentoServices.listarSistemas(codAgendamento));
		
		return mapping.findForward(Constantes.FORWARD_PAGINA_PRINCIPAL);
	}
	
//	/**
//	 * Action respons�vel por voltar para a pagina inicial da aplicacao.
//	 * 
//	 * @param mapping 
//	 *            O mapeamento da action
//	 * @param form 
//	 *            O form de alteracao
//	 * @param request 
//	 *            O request recebido
//	 * @param response 
//	 *            A response recebida
//	 * @return ActionForward 
//	 *             A acao enviada
//	 * @throws Exception 
//	 *             Excecao da acao do struts
//	 */
//	public ActionForward voltar(ActionMapping mapping, ActionForm form,
//			HttpServletRequest request, HttpServletResponse response)
//			throws Exception {
//
//		return mapping.findForward(Constantes.FORWARD_HOME);
//	}

	
	
	
}
