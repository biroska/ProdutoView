/*
 * Copyright(c) by Votorantim Finan�as - BV Sistemas
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * Votorantim Finan�as ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with Votorantim Finan�as.
 */
package br.com.bvsistemas.dimof.web.liminar.consultar.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import br.com.bvsistemas.dimof.datatype.LiminarVO;
import br.com.bvsistemas.dimof.web.framework.form.AbstractBaseValidatorForm;

/**
 * <code>ActionForm</code> respons�vel por armazenar as informa��es do 
 * form de consulta de Liminares (fluxo alternativo do UC002 Manter Liminar).
 * 
 * @author <a href="mailto:diegoa@cit.com.br">Diego A. Poli Roberto</a>
 * 
 * @struts.form name="consultarLiminarForm"
 * 
 */
public class ConsultarLiminarForm extends AbstractBaseValidatorForm {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** Operacao a ser realizada */
	private String operacao;

	/** Codigo do cliente */
	private String cdCliente;
	
	/** Nome do cliente */
	private String nmCliente;
	
	/** Numero da liminar */
	private String nuLiminar;
	
	/** Data inicial da vigencia */
	private String dtInicioVigencia;
	
	/** Data final da vigencia */
	private String dtFimVigencia;
	
	/** Filtro para consultar somente por liminares vigentes */
	private String somenteVigentes;

	/** Lista de liminares */
	private List<LiminarVO> listaLiminar;

	/**
	 * @return the operacao
	 */
	public String getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	/**
	 * @return the cdCliente
	 */
	public String getCdCliente() {
		return cdCliente;
	}

	/**
	 * @param cdCliente the cdCliente to set
	 */
	public void setCdCliente(String cdCliente) {
		this.cdCliente = cdCliente;
	}

	/**
	 * @return the nmCliente
	 */
	public String getNmCliente() {
		return nmCliente;
	}

	/**
	 * @param nmCliente the nmCliente to set
	 */
	public void setNmCliente(String nmCliente) {
		this.nmCliente = nmCliente;
	}

	/**
	 * @return the nuLiminar
	 */
	public String getNuLiminar() {
		return nuLiminar;
	}

	/**
	 * @param nuLiminar the nuLiminar to set
	 */
	public void setNuLiminar(String nuLiminar) {
		this.nuLiminar = nuLiminar;
	}

	/**
	 * @return the dtInicioVigencia
	 */
	public String getDtInicioVigencia() {
		return dtInicioVigencia;
	}

	/**
	 * @param dtInicioVigencia the dtInicioVigencia to set
	 */
	public void setDtInicioVigencia(String dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}

	/**
	 * @return the dtFimVigencia
	 */
	public String getDtFimVigencia() {
		return dtFimVigencia;
	}

	/**
	 * @param dtFimVigencia the dtFimVigencia to set
	 */
	public void setDtFimVigencia(String dtFimVigencia) {
		this.dtFimVigencia = dtFimVigencia;
	}

	/**
	 * @return the somenteVigentes
	 */
	public String getSomenteVigentes() {
		return somenteVigentes;
	}

	/**
	 * @param somenteVigentes the somenteVigentes to set
	 */
	public void setSomenteVigentes(String somenteVigentes) {
		this.somenteVigentes = somenteVigentes;
	}

	/**
	 * @return the listaLiminar
	 */
	public List<LiminarVO> getListaLiminar() {
		return listaLiminar;
	}

	/**
	 * @param listaLiminar the listaLiminar to set
	 */
	public void setListaLiminar(List<LiminarVO> listaLiminar) {
		this.listaLiminar = listaLiminar;
	}
	
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		somenteVigentes = null;
	}
}
