package br.com.bvsistemas.dimof.web.demonstrativo.movimentacoes.relatorio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPrintSetup;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;

import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCCVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoCambioVO;
import br.com.bvsistemas.dimof.datatype.DetalheMovimentoVO;


/**
 * Classe respons�vel por criar uma planilhas de dados do excel com as informa��es das
 * movimenta��es financeiras do cliente, tanto de c�mbio como de conta corrente.
 * Esta planilha deve conter as mesmas informa��es apresentadas na pagina de 
 * Detalhes de Movimenta��o Financeira
 *
 * @author <a href="mailto:talent.ealmeida@bvsistemas.com.br">Edilson Almeida</a>
 *
 * @created 14/09/2012
 * 
 */
public class GeradorRelatorioExcel {

	private List<DetalheMovimentoCambioVO> listaMovCambio = new ArrayList<DetalheMovimentoCambioVO>();
	private List<DetalheMovimentoCCVO> listaMovCCorrente = new ArrayList<DetalheMovimentoCCVO>();

		private Locale ptBr = new Locale("pt", "BR"); //Locale para o Brasil
		private NumberFormat nf = NumberFormat.getCurrencyInstance(ptBr);
		
	    private static final String[] titlesCC = {
	    	"Data Movimento",	 "Valor",	 "Cred/Deb",	 
	    	"Cpf/Cnpj creditado",	 "Cpf/Cnpj debitado",	 "N�mero Conta Corrente"
	    };

	    private static final String[] titlesCambio = {
	    	"Data Movimento",	 "Valor",	 "Compra/Venda"	 
	    };

	    /**
	     * M�todo Respons�vel por criar a planilha
	     * 
	     * @author talent.ealmeida
	     * 
	     * @param response - o response que usado para emitir o arquivo gerado
	     *  
	     * @param detalhe - o DetalheMovimentoVO que cont�m os valores base da planilha
	     */
	    public void gerarRelatorio(HttpServletResponse response, DetalheMovimentoVO detalhe){	    	
	        HSSFWorkbook  wb = new HSSFWorkbook();
	        	        
			// carrega a lista de detalhe de movimentacoes de cambio
			if (detalhe.getListaMovCambio() != null && !detalhe.getListaMovCambio().isEmpty()) {
				listaMovCambio = detalhe.getListaMovCambio();
			}
			// carrega a lista de detalhe de movimentacoes de conta corrente
			if (detalhe.getListaMovContaCC() != null && !detalhe.getListaMovContaCC().isEmpty()) {
				listaMovCCorrente = detalhe.getListaMovContaCC();
			}
			//Inicializa o Mpa de estilos
	        Map<String, HSSFCellStyle> styles = createStyles(wb);
	        
	        //Cria uma nova planilha
	        HSSFSheet sheet = wb.createSheet("Relat�rio Detalhado do Cliente");
	        HSSFPrintSetup printSetup = sheet.getPrintSetup();
	        printSetup.setLandscape(true);
	        sheet.setFitToPage(true);
	        sheet.setHorizontallyCenter(true);

	        //Linha do T�tulo
	        HSSFRow titleRow = sheet.createRow(0);
	        titleRow.setHeightInPoints(45);
	        HSSFCell titleCell = titleRow.createCell((short)0);
	        titleCell.setCellValue("Detalhe de Movimenta��o");
	        titleCell.setCellStyle(styles.get("title"));
	        
	        sheet.addMergedRegion(new Region(0, (short)0, 0, (short) 5));
	        sheet.setDisplayGridlines(false);
	        
	        //identificador do cliente
	        HSSFRow identRow = sheet.createRow(1);
	        HSSFCell nome = identRow.createCell((short)0);
	        nome.setCellStyle(styles.get("identifier"));
	        nome.setCellValue("Nome / Raz�o Social");
	        HSSFCell nomeValue = identRow.createCell((short)1);
	        nomeValue.setCellStyle(styles.get("identifier"));
	        nomeValue.setCellValue(detalhe.getCliente().getNmPessoa());		
	        sheet.addMergedRegion(new Region(1, (short)1, 1, (short) 5));
	        	        
	        HSSFRow identCnpj = sheet.createRow(2);
	        HSSFCell cnpj = identCnpj.createCell((short)0);
	        cnpj.setCellStyle(styles.get("identifier"));
	        cnpj.setCellValue("CPF / CNPJ");
	        HSSFCell cnpjValue = identCnpj.createCell((short)1);
	        cnpjValue.setCellStyle(styles.get("identifier"));
	        cnpjValue.setCellValue(detalhe.getCliente().getNuCpfCnpjFormatado());
	        sheet.addMergedRegion(new Region(2, (short)1, 2, (short) 5));
	        
	        //identificador de movimenta��o de conta corrente
	        HSSFRow contaRow = sheet.createRow(3);
	        HSSFCell contaCell = contaRow.createCell((short)0);	        
	        contaCell.setCellValue("Movimenta��o de Conta Corrente");
	        contaCell.setCellStyle(styles.get("header"));	        
	        sheet.addMergedRegion(new Region(3, (short)0, 3, (short) 5));
	        	        
	        //cabe�alho de movimenta��o de conta corrente
	        HSSFRow headerRow = sheet.createRow(4);
	        headerRow.setHeightInPoints(40);
	        HSSFCell headerCellCC;
	        for (int i = 0; i < titlesCC.length; i++) {
	            headerCellCC = headerRow.createCell((short)i);
	            headerCellCC.setCellValue(titlesCC[i]);
	            headerCellCC.setCellStyle(styles.get("header"));
	        }
	        //dados de movimenta��o de conta corrente
	        int rownum = 5;
	        if(listaMovCCorrente != null && listaMovCCorrente.size() > 0){
		        for (DetalheMovimentoCCVO conta : listaMovCCorrente) {
		            HSSFRow row = sheet.createRow(rownum++);
	            
	                HSSFCell cell0 = row.createCell((short)0);
	                cell0.setCellStyle(styles.get("cell"));
	                cell0.setCellValue(conta.getDtMovimentoFormatado());
	               
	                HSSFCell cell1 = row.createCell((short)1);
	                cell1.setCellStyle(styles.get("cell"));
	                cell1.setCellValue(nf.format( conta.getVrOperacao().doubleValue()) );
	               
	                HSSFCell cell2 = row.createCell((short)2);
	                cell2.setCellStyle(styles.get("cell"));
	                String tipo = conta.getTpDebitoCredito() == null ? "" : conta.getTpDebitoCredito();
					if(tipo.equalsIgnoreCase("D")){
						tipo = "D�BITO";
					}else if(tipo.equalsIgnoreCase("C")) {
						tipo = "CR�DITO";
					}
	                cell2.setCellValue(tipo); 
	               
	                HSSFCell cell3 = row.createCell((short)3);
	                cell3.setCellStyle(styles.get("cell"));
	                cell3.setCellValue(conta.getNuCpfCnpjCreditadoFormatado());
	               
	                HSSFCell cell4 = row.createCell((short)4);
	                cell4.setCellStyle(styles.get("cell"));
	                cell4.setCellValue(conta.getNuCpfCnpjDebitadoFormatado());
	               
	                HSSFCell cell5 = row.createCell((short)5);
	                cell5.setCellStyle(styles.get("cell"));
	                cell5.setCellValue(conta.getNuContaCorrente());
	               
		        }
	        }else{
	        	HSSFRow row = sheet.createRow(rownum++);		           
                HSSFCell cell0 = row.createCell((short)0);
                cell0.setCellStyle(styles.get("identifier"));
                cell0.setCellValue("Nenhum Registro encontrado!");
                sheet.addMergedRegion(new Region(rownum-1, (short)0, rownum-1, (short) 5));
                		
	        }
	        
	        //cabe�alho de movimenta��o de c�mbio
	        HSSFRow cambioRow = sheet.createRow(rownum++);
	        HSSFCell cambioCell = cambioRow.createCell((short)0);	        
	        cambioCell.setCellValue("Movimenta��o de C�mbio");
	        cambioCell.setCellStyle(styles.get("header"));	        	        
	        sheet.addMergedRegion(new Region(rownum-1, (short)0, rownum-1, (short) 2));
       
	        HSSFRow headerRowC = sheet.createRow(rownum++);
	        headerRowC.setHeightInPoints(40);
	        HSSFCell headerCellCambio;
	        for (int i = 0; i < titlesCambio.length; i++) {
	        	headerCellCambio = headerRowC.createCell((short)i);
	        	headerCellCambio.setCellValue(titlesCambio[i]);
	        	headerCellCambio.setCellStyle(styles.get("header"));
	        }
	        
	        //dados de movimenta��o de c�mbio	
	        if(listaMovCambio != null && listaMovCambio.size() > 0){
		        for (DetalheMovimentoCambioVO cambio : this.listaMovCambio) {
		            HSSFRow row = sheet.createRow(rownum++);
		           
		                HSSFCell cell0 = row.createCell((short)0);
		                cell0.setCellStyle(styles.get("cell"));	                
		                cell0.setCellValue(cambio.getDtMovimentoFormatado());
	
		                HSSFCell cell1 = row.createCell((short)1);
		                cell1.setCellStyle(styles.get("cell"));	                		                
		                cell1.setCellValue(nf.format(cambio.getVrOperacao().doubleValue()));
		                
		                HSSFCell cell2 = row.createCell((short)2);
		                cell2.setCellStyle(styles.get("cell"));
		                String tipo = cambio.getTpOperacao() == null ? "" : cambio.getTpOperacao();
						if(tipo.equalsIgnoreCase("C")){
							tipo="COMPRA";
						}else if(tipo.equalsIgnoreCase("V")) {
							tipo = "VENDA";
						}
		                cell2.setCellValue(tipo);
		        }
	        }else{
	        	HSSFRow row = sheet.createRow(rownum++);
		           
                HSSFCell cell0 = row.createCell((short)0);
                cell0.setCellStyle(styles.get("identifier"));
                cell0.setCellValue("Nenhum Registro encontrado!");
                sheet.addMergedRegion(new Region(rownum-1, (short)0, rownum-1, (short) 2));
	        }

	        //setando o tamanho das colunas     
	        for (int i = 0; i <= 6; i++) {
	            sheet.setColumnWidth((short)i, (short)(20*256));  //20 characters 
	        }	        

			try {
				
				String contentDisposition ="inline; filename=Detalhe_Movimentacao_Financeira_Cliente_"+detalhe.getCliente().getPk().getId()+".xls";

				response.setContentType("application/vnd.ms-excel"); 
				response.setHeader ("Content-Disposition", contentDisposition);

				OutputStream out = response.getOutputStream();		
				
				wb.write(out);				 
				out.close();
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    
	    /**
	     * M�todo de inicializa��o da tabela de estilos que ser�o usados na cria��o da planilha
	     * @author talent.ealmeida
	     * @param wb
	     * @return um Map de estilos
	     */
	    private Map<String, HSSFCellStyle> createStyles(HSSFWorkbook wb){
	        Map<String, HSSFCellStyle> styles = new HashMap<String, HSSFCellStyle>();
	        HSSFCellStyle style;
	        HSSFFont titleFont = wb.createFont();
	        titleFont.setFontHeightInPoints((short)18);
	        titleFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	        style = wb.createCellStyle();
	        style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
	        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
	        style.setFont(titleFont);
	        styles.put("title", style);

	        HSSFFont monthFont = wb.createFont();
	        monthFont.setFontHeightInPoints((short)11);
	        monthFont.setColor(HSSFColor.WHITE.index);	        
	        style = wb.createCellStyle();
	        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
	        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
	        style.setFillForegroundColor(HSSFColor.GREY_50_PERCENT.index);
	        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	        style.setFont(monthFont);
	        style.setWrapText(true);
	        styles.put("header", style);

	        HSSFFont identifierFont = wb.createFont();
	        identifierFont.setFontHeightInPoints((short)9);
	        identifierFont.setColor(HSSFColor.BLACK.index);
	        identifierFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	        style = wb.createCellStyle();
	        style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
	        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);	        
	        style.setFont(identifierFont);
	        style.setWrapText(true);
	        styles.put("identifier", style);
	        
	        style = wb.createCellStyle();
	        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
	        style.setWrapText(true);
	        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	        style.setRightBorderColor(HSSFColor.BLACK.index);
	        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
	        style.setLeftBorderColor(HSSFColor.BLACK.index);
	        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	        style.setTopBorderColor(HSSFColor.BLACK.index);
	        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	        style.setBottomBorderColor(HSSFColor.BLACK.index);
	        styles.put("cell", style);

	        return styles;
	    }    
	}
