package br.com.serasa.mail;

import org.junit.Test;

import junit.framework.Assert;

public class MailBeanTest {
	
	@Test
	public void testGetDestinatarios() {
		
		String [] destinatarios = {"admin@teste.com", "teste@teste.com"}; 
		
		MailBean mail = new MailBean();
		mail.setDestinatarios(destinatarios);
		
		Assert.assertEquals(mail.getDestinatarios()[0], destinatarios[0]);
		Assert.assertEquals(mail.getDestinatarios()[1], destinatarios[1]);
		
		mail.setDestinatarios(null);
		Assert.assertNotNull(mail.getDestinatarios());
	}

}
