package br.com.serasa.consultaprevia.bean.validator;

import junit.framework.Assert;

import org.junit.Test;

public class TradutorDeErrosTest {
	
	private String texto = "dados da senha";
	private String nomeErro ="DADOS_DA_SENHA";
	
	@Test
	public void testDefaultConstructor() {
		TradutorDeErros erros = new TradutorDeErros();
		Assert.assertNotNull(erros);
	}
	
	@Test
	public void testDescricaoErro() {
		String result = TradutorDeErros.descricaoErro(nomeErro);
		Assert.assertEquals(result,  "");
	}
	
	@Test
	public void testAddTraducao() {

		TradutorDeErros.addTraducao(nomeErro, texto);
		String result = TradutorDeErros.descricaoErro(nomeErro);
		Assert.assertEquals(result,  texto);
	}
}
