package br.com.serasa.util;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.junit.Assert;
import org.junit.Test;

public class StringCipherTest {
    @Test
    public void testcriptografia() throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException,
            InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {
        StringCipher stringCipher = new StringCipher();
        String original = "serasa";
        String criptografada = stringCipher.encrypt(original);
        String descriptografada = stringCipher.decrypt(criptografada);
        
        Assert.assertEquals(original, descriptografada);
    }
    
    @Test
    public void testDecriptografia() throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException,
            InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {
        StringCipher stringCipher = new StringCipher();
        Assert.assertEquals("serasa", stringCipher.decrypt("I1ZB_pycLYLfyjx7p4FoAi2lSoEec0U1JdHGxrSe6WxALKdY_h_PABbFRsf38bYEV3o9j8Uh1_Awv7pZrv1pMyXfZQ-ZpOceZiMxx8Fyv_4c0YlAA3wY2PdVuuLXURs9l8WpgPeIBLLIQSGsdNUnFYYoD4EylTtVJ1_d1bz2fSA"));
    }
}
