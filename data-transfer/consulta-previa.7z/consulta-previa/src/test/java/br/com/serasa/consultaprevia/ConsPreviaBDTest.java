package br.com.serasa.consultaprevia;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.net.ssl.SSLSocketFactory;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.com.serasa.bd.FunctionQuery;
import br.com.serasa.bd.ResultQuery;
import br.com.serasa.bd.StatementQuery;
import br.com.serasa.bean.bdconnection.BDConnectionBean;
import br.com.serasa.consultaprevia.bean.ConsPreviaBean;
import br.com.serasa.consultaprevia.bean.ProxyBean;
import br.com.serasa.consultaprevia.bean.ReceitaBean;
import br.com.serasa.exception.NaoConectouNaReceitaException;
import br.com.serasa.socket.SSLSerasaSocket;

/**
 * Testcase para assegurar a execu��o de {@link AddressFinder}
 * 
 * @see {@link AddressFinder}
 * 
 * @since Set 20, 2012.
 * 
 * @author <a href="mailto:valter.bomtempo@br.experian.com">snj2136</a>
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SSLSerasaSocket.class, ConsPreviaBD.class, StatementQuery.class, FunctionQuery.class })
public class ConsPreviaBDTest {

    @Test
    public void testExecutaConsultaPreviaSimples() throws Exception {
        SSLSerasaSocket sslSerasaSocket = mock(SSLSerasaSocket.class);
        when(sslSerasaSocket.executeConsultaHttps()).thenReturn(true);
        when(sslSerasaSocket.getConteudoRetorno()).thenReturn("13");

        SSLSocketFactory factory = mock(SSLSocketFactory.class);

        whenNew(SSLSerasaSocket.class).withArguments(any(ProxyBean.class), any(ReceitaBean.class), anyString(),
            anyString(), anyString(), any(SSLSocketFactory.class)).thenReturn(sslSerasaSocket);

        ResourceBundle msgProperties = mock(ResourceBundle.class);

        Map<String, String> param = new HashMap<String, String>();
        param.put("provConsSimples", "1");
        param.put("consprevia_timeout", "10");

        ConsPreviaBD cons = new ConsPreviaBD(getConsPreviaBean(1), getReceitaBean(), getProxyBean(), param, factory,
                msgProperties);
        Assert.assertTrue(cons.consultData());
    }

    @Test
    public void testConsultaPreviaSimplesIndisponivel() throws Exception {
        SSLSerasaSocket sslSerasaSocket = mock(SSLSerasaSocket.class);
        when(sslSerasaSocket.executeConsultaHttps()).thenReturn(true);
        when(sslSerasaSocket.getConteudoRetorno()).thenReturn("90");

        SSLSocketFactory factory = mock(SSLSocketFactory.class);

        whenNew(SSLSerasaSocket.class).withArguments(any(ProxyBean.class), any(ReceitaBean.class), anyString(),
            anyString(), anyString(), any(SSLSocketFactory.class)).thenReturn(sslSerasaSocket);

        Map<String, String> param = new HashMap<String, String>();
        param.put("provConsSimples", "1");
        param.put("consprevia_timeout", "10");

        ResourceBundle msgProperties = mock(ResourceBundle.class);

        ConsPreviaBD cons = new ConsPreviaBD(getConsPreviaBean(1), getReceitaBean(), getProxyBean(), param, factory,
                msgProperties);
        Assert.assertTrue(cons.consultData());
    }

    @Test(expected = NaoConectouNaReceitaException.class)
    public void testConsultaPreviaIndisponivelServidor() throws Exception {
        SSLSerasaSocket sslSerasaSocket = mock(SSLSerasaSocket.class);
        when(sslSerasaSocket.executeConsultaHttps()).thenReturn(true);
        when(sslSerasaSocket.getConteudoRetorno()).thenReturn("90");

        SSLSocketFactory factory = mock(SSLSocketFactory.class);

        whenNew(SSLSerasaSocket.class).withArguments(any(ProxyBean.class), any(ReceitaBean.class), anyString(),
            anyString(), anyString(), any(SSLSocketFactory.class)).thenReturn(sslSerasaSocket);

        BDConnectionBean connectionBean = mock(BDConnectionBean.class);

        Map<String, String> param = new HashMap<String, String>();
        param.put("provConsSimples", "2");
        param.put("consprevia_timeout", "10");

        FunctionQuery query = mock(FunctionQuery.class);

        mockStatic(FunctionQuery.class);
        when(FunctionQuery.getInstance(eq(connectionBean), anyString())).thenReturn(query);

        ResultQuery result = mock(ResultQuery.class);
        when(result.next()).thenReturn(true, false);
        when(result.getString("cn_part")).thenReturn("Nome/razao social sera validado posteriormente");

        mockStatic(StatementQuery.class);
        when(StatementQuery.executeConsultQuery(connectionBean, query)).thenReturn(result);

        ResourceBundle msgProperties = mock(ResourceBundle.class);

        ConsPreviaBD cons = new ConsPreviaBD(getConsPreviaBean(2), getReceitaBean(), getProxyBean(), param, factory,
                msgProperties);
        Assert.assertTrue(cons.consultData());
    }

    @Test(expected = NaoConectouNaReceitaException.class)
    public void testConsultaPreviaIndisponivelPessoaFisica() throws Exception {
        SSLSerasaSocket sslSerasaSocket = mock(SSLSerasaSocket.class);
        when(sslSerasaSocket.executeConsultaHttps()).thenReturn(true);
        when(sslSerasaSocket.getConteudoRetorno()).thenReturn("90");

        SSLSocketFactory factory = mock(SSLSocketFactory.class);

        whenNew(SSLSerasaSocket.class).withArguments(any(ProxyBean.class), any(ReceitaBean.class), anyString(),
            anyString(), anyString(), any(SSLSocketFactory.class)).thenReturn(sslSerasaSocket);

        BDConnectionBean connectionBean = mock(BDConnectionBean.class);

        Map<String, String> param = new HashMap<String, String>();
        param.put("provConsSimples", "2");
        param.put("consprevia_timeout", "10");

        FunctionQuery query = mock(FunctionQuery.class);

        mockStatic(FunctionQuery.class);
        when(FunctionQuery.getInstance(eq(connectionBean), anyString())).thenReturn(query);

        ResultQuery result = mock(ResultQuery.class);
        when(result.next()).thenReturn(true, false);
        when(result.getString("cn_part")).thenReturn("Nome/razao social sera validado posteriormente");

        mockStatic(StatementQuery.class);
        when(StatementQuery.executeConsultQuery(connectionBean, query)).thenReturn(result);

        ResourceBundle msgProperties = mock(ResourceBundle.class);

        ConsPreviaBD cons = new ConsPreviaBD(getConsPreviaBean(1), getReceitaBean(), getProxyBean(), param, factory,
                msgProperties);
        Assert.assertTrue(cons.consultData());
    }

    public ConsPreviaBean getConsPreviaBean(int tipoCert) {
        ConsPreviaBean cons = new ConsPreviaBean();
        if (tipoCert == 1) {
            cons.setTpCert("1");
        } else {
            cons.setTpCert("7");
        }
        cons.setCnpj("62952049000100");
        cons.setCodRetorno("13");
        cons.setCpf("12345678909");
        cons.setDtNasc("14081982");
        cons.setNome("Nome Homologa��o");

        return cons;
    }

    public ReceitaBean getReceitaBean() {
        Map<String, String> param = new HashMap<String, String>();
        param.put("HOST_RECEITA", "127.0.0.1");
        param.put("PORT_RECEITA", "8080");
        param.put("URL_RECEITA", "www.teste.com.br");

        ReceitaBean bean = new ReceitaBean(param);
        return bean;
    }

    public ProxyBean getProxyBean() {
        Map<String, String> param = new HashMap<String, String>();
        param.put("host_proxy", "127.0.0.1");
        param.put("password_proxy", "123456");
        param.put("port_proxy", "8080");
        param.put("user_proxy", "cwf3650");

        ProxyBean bean = new ProxyBean(param);
        return bean;
    }
}
