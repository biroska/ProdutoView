package br.com.serasa.util;

import org.junit.Assert;
import org.junit.Test;

public class DataUtilTest {
    
    @Test
    public void testFormatarTextoConsultaSimplesEmpty() {
        String texto = DataUtil.formatarTextoConsultaSimples("");
        Assert.assertEquals("", texto);
    }
    
    @Test
    public void testFormatarTextoConsultaSimplesNull() {
        String texto = DataUtil.formatarTextoConsultaSimples(null);
        Assert.assertEquals("", texto);
    }

    @Test
    public void testFormatarTextoConsultaSimples1() {
        String texto = DataUtil.formatarTextoConsultaSimples("VALDECIR DA LUZ                                     #CLINICA MEDICA MAUACLINIC LTDA EPP               #Porte da Empresa �: Micro-Empresa, Empresa de Pequeno Porte ou Empresa Optante pelo Simples Nacional.");
        Assert.assertEquals("CLINICA MEDICA MAUACLINIC LTDA EPP", texto);
    }
    
    @Test
    public void testFormatarTextoConsultaSimples2() {
        String texto = DataUtil.formatarTextoConsultaSimples("ERVINO SCHULTZ                                      #SCHULTZ EMPREITEIRA LTDA EPP         #Porte da Empresa �: Micro-Empresa, Empresa de Pequeno Porte ou Empresa Optante pelo Simples Nacional.");
        Assert.assertEquals("SCHULTZ EMPREITEIRA LTDA EPP", texto);
    }
    
    @Test
    public void testFormatarTextoConsultaSimplesRFForaDoAr() {
        String texto = DataUtil.formatarTextoConsultaSimples("Razao social sera validada posteriormente");
        Assert.assertEquals("Razao social sera validada posteriormente", texto);
    }
    
    @Test
    public void testInsertZeros() {
    	String result = DataUtil.insertZeros("456", 15);
    	Assert.assertEquals(result, "000000000000456");
    }
    
    @Test (expected = NullPointerException.class)
    public void testInsertZerosComStringNula() {
    	DataUtil.insertZeros(null, 15);
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void testInsertZerosComStringMaioQueTamanho() {
    	DataUtil.insertZeros("45456", 4);
    }
    
    @Test
    public void testRetiraAspas() {
    	String result = DataUtil.retiraAspas("'Teste'");
    	Assert.assertEquals(result, "Teste");
    }
    
    @Test
    public void testRetiraAspasComStringNula() {
    	String result = DataUtil.retiraAspas(null);
    	Assert.assertEquals(result, "");
    }
    
    @Test
    public void testRetiraAspasComStringVazia() {
    	String result = DataUtil.retiraAspas("");
    	Assert.assertEquals(result, "");
    }
    
    @Test
    public void testaAeitaSomenteLetrasNumeros() {
    	String str = "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ�";
    	String result = DataUtil.aceitaSomenteLetrasNumeros(str);
    	Assert.assertEquals(result, "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZC");
    }
}
