package br.com.serasa.servlets.bean;

import junit.framework.Assert;

import org.junit.Test;

public class ErrorBeanTest {
	
	private ErrorBean e;
	
	@Test
	public void testDefaultConstrutor() {
		e = new ErrorBean();
		Assert.assertTrue(e.getErrors().length == 0);
	}
	
	@Test
	public void testGetErrorsComParametro() {
		e = new ErrorBean("Erro 404");
		Assert.assertTrue(e.getErrors().length == 1);
	}
}
