package br.com.serasa.consultaprevia;

import static org.mockito.Mockito.mock;

import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;

import br.com.serasa.exception.NaoConectouNaReceitaException;

@Ignore
public class ConsPreviaConsultCommandTest {

    private static final String XML_PF = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>23415575896</cpf><cnpj /><dtnasc>25121966</dtnasc></consprev>";

    private static final String XML_PF_CNPJ = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>78370043887</cpf><cnpj>01859670000120</cnpj><dtnasc>28091952</dtnasc></consprev>";

    private static final String XML_PF_INVALID_CPF = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>783700438</cpf><cnpj /><dtnasc>28091952</dtnasc></consprev>";

    private static final String XML_PF_INVALID_DATE1 = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>78370043887</cpf><cnpj>01859670000120</cnpj><dtnasc>12131966</dtnasc></consprev>";

    private static final String XML_PF_INVALID_DATE2 = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>78370043887</cpf><cnpj>01859670000120</cnpj><dtnasc></dtnasc></consprev>";

    private static final String XML_PF_INVALID_DATE3 = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>78370043887</cpf><cnpj>01859670000120</cnpj><dtnasc>121219</dtnasc></consprev>";

    private static final String XML_PJ = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>2</tipo-cert><cpf>11122233396</cpf><cnpj>00958378000100</cnpj><dtnasc>01011900</dtnasc></consprev>";

    private static final String XML_PJ_INVALID_CNPJ = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>2</tipo-cert><cpf>11122233396</cpf><cnpj>00958378000101</cnpj><dtnasc>01011900</dtnasc></consprev>";

    private HttpServletRequest req;

    private SSLSocketFactory fact;

    private Map<String, String> paramMap = new HashMap<String, String>();

    @Before
    public void before() throws ServletException {
        req = Mockito.mock(HttpServletRequest.class);
        fact = Mockito.mock(SSLSocketFactory.class);

        paramMap.put("HOST_RECEITA", "161.148.231.104,161.148.231.100");
        paramMap.put("PORT_RECEITA", "443");
        paramMap.put(
            "URL_RECEITA",
            "https://www6.receita.fazenda.gov.br/consprev.asp?,https://www.receita.fazenda.gov.br/Receita222/SSL/CC/ATBHE/CA/ConsPrev.asp?");
        paramMap.put("host_proxy", "10.96.161.27");
        paramMap.put("port_proxy", "3128");
        paramMap.put("user_proxy", "youruser");
        paramMap.put("password_proxy", "yourpass");
        paramMap.put("keystore_receita", "/br/com/serasa/consultaprevia/keystore/certreqstore.jks");
        paramMap.put("keystore_password", "serasa");
        paramMap.put("data-source-owner-user", "prod");

        readKeystore();
    }

    private void readKeystore() {
        String keystorePass = paramMap.get("keystore_password").toString();
        String keystore = paramMap.get("keystore_receita").toString();

        try {
            URL keystorePath = getClass().getResource(keystore);
            System.setProperty("javax.net.ssl.trustStore", keystorePath.toString().replace("file:", ""));
            System.setProperty("javax.net.ssl.trustStorePassword", keystorePass);

            SSLSocketFactory factory = null;
            InputStream is = null;

            try {
                SSLContext ctx = SSLContext.getInstance("TLS");
                KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
                KeyStore ks = KeyStore.getInstance("JKS");
                char[] passphrase = keystorePass.toCharArray();

                is = getClass().getResourceAsStream(keystore);

                ks.load(is, passphrase);
                kmf.init(ks, passphrase);
                ctx.init(kmf.getKeyManagers(), null, null);
                factory = ctx.getSocketFactory();
                fact = factory;
            } catch (Exception e) {
                e.getMessage();
            } finally {
                if (is != null) {
                    is.close();
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }
    }

    @Test
    public void testConsultaPf() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("0");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "00");
    }

    @Test
    public void testConsultaPfComCnpj() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("0");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaPfComCnpjBom() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "60");
    }

    @Test
    public void testConsultaPfInvalidCpf() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_CPF);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaPfInvalidDate1() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_DATE1);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaPfInvalidDate2() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_DATE2);
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaPfInvalidDate3() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_DATE3);
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaPj() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ);
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "27");

    }

    @Test
    public void testConsultaPjInvalidCnpj() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ_INVALID_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("0");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaPjInvalidCnpjConSimp() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ_INVALID_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

    @Test
    public void testConsultaSimplesPf() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-3");
    }

    @Test
    public void testConsultaSimplesPfComCnpj() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "60");
    }

    @Test
    public void testConsultaSimplesPj() throws NaoConectouNaReceitaException {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ResourceBundle msgProperties = mock(ResourceBundle.class);
        ConsPreviaConsultCommand consulta = new ConsPreviaConsultCommand(req, paramMap, fact, msgProperties);
        Assert.assertEquals(consulta.getCodigo(), "-2");
    }

}
