package br.com.serasa.tools;

import org.junit.Test;

import junit.framework.Assert;

public class CleanerTest {
	
	@Test
	public void testDefaultConstructor() {
		Cleaner c = new Cleaner();
		Assert.assertNotNull(c);
	}
	
	@Test
	public void testSomenteLetrasNumeros() {
		String str = "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String result = Cleaner.somenteLetrasNumeros(str);
		Assert.assertEquals(result, str);
	}
	
	@Test
	public void testSomenteLetrasNumerosComCaracteresInvalidos() {
		String str = "1234@abcde$%";
		String result = Cleaner.somenteLetrasNumeros(str);
		Assert.assertEquals(result, "1234 ABCDE");
	}
	
	@Test
	public void testSomenteLetrasNumerosComStringVazia() {
		String str = "";
		String result = Cleaner.somenteLetrasNumeros(str);
		Assert.assertEquals(result, str);
	}
	
	@Test
	public void testRemoveEndLine() {
		Cleaner.removeEndLine("teste\r\n");
	}
	
	@Test
	public void testRemoveEndLineComStringVazia() {
		Cleaner.removeEndLine("");
	}

}
