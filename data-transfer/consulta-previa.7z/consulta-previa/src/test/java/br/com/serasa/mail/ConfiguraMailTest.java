package br.com.serasa.mail;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.util.Properties;
import javax.mail.MessagingException;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SmtpData.class, SendMail.class})
public class ConfiguraMailTest {
	
	@Test
	public void testDefaultConstructor() {
		ConfiguraMail mail = new ConfiguraMail();
		Assert.assertNotNull(mail);
	}
	
	@Test
	public void testConfiguraEmail() throws MessagingException {
		
		Properties properties = mock(Properties.class);
		when(properties.getProperty("mail.host")).thenReturn("local");
		when(properties.getProperty("mail.from")).thenReturn("teste@teste.com");
		when(properties.getProperty("mail.to")).thenReturn("admin@teste.com");
		when(properties.getProperty("mail.usuario")).thenReturn("user@teste.com");
		when(properties.getProperty("mail.senha")).thenReturn("abc123");
		
		SmtpData mailSenderBean = mock(SmtpData.class);
		 
		mockStatic(SmtpData.class);
		when(SmtpData.getInstance(anyString(), anyString(), anyString())).thenReturn(mailSenderBean);
		 
		SendMail smtpMailSender = mock(SendMail.class);
		mockStatic(SendMail.class);
		when(SendMail.getInstance(mailSenderBean)).thenReturn(smtpMailSender);
		
		ConfiguraMail mail = new ConfiguraMail(properties);
		mail.enviaMail("Renove agora", "Renove seu certificado com a Serasa");
	}

}
