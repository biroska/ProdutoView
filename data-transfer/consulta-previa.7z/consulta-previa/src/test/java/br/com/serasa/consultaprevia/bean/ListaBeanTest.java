package br.com.serasa.consultaprevia.bean;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

public class ListaBeanTest {
	
	private ListaBean bean;
	
	@Before
	public void setUp() {
		bean = new ListaBean();
	}
	
	@Test
	public void testGetLista() {
		
		List<Object> lista = new ArrayList<Object>();
		lista.add("Teste");
		bean.setLista(lista);
		
		Assert.assertEquals(bean.getLista().get(0), lista.get(0));
	}
	
	@Test
	public void testGetLinhasAfetadas() {
		String objeto = "Teste";
		bean.add(objeto);
		
		Assert.assertTrue(bean.getLinhasAfetadas() == 1);
	}
	

}
