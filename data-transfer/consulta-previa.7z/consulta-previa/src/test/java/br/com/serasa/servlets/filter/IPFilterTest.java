package br.com.serasa.servlets.filter;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import java.io.IOException;
import java.sql.Connection;
import java.util.Collections;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import br.com.serasa.helper.CachedParamXmlImpl;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ CachedParamXmlImpl.class, InitialContext.class })
@PowerMockIgnore({ "javax.management.*", "javax.xml.parsers.*", "com.sun.org.apache.xerces.internal.jaxp.*",
        "ch.qos.logback.*", "org.slf4j.*" })
public class IPFilterTest {

    public static final IPFilter IP_FILTER = new IPFilter();

    private FilterConfig config;

    private ServletRequest servletRequest;

    private HttpServletResponse servletResponse;

    private FilterChain chain;

    private CachedParamXmlImpl cache;

    @Before
    public void before() throws Exception {
        config = mock(FilterConfig.class);
        servletRequest = mock(ServletRequest.class);
        servletResponse = mock(HttpServletResponse.class);
        chain = mock(FilterChain.class);
        configureCache();
    }

    @Test
    public void doPostIP_allowed() throws ServletException, IOException {
        when(cache.getValueAsString("allowedIPs")).thenReturn("10.0.0.1");

        when(servletRequest.getRemoteAddr()).thenReturn("10.0.0.1");

        mockStatic(CachedParamXmlImpl.class);
        when(CachedParamXmlImpl.getInstance()).thenReturn(cache);

        IP_FILTER.init(config);
        IP_FILTER.doFilter(servletRequest, servletResponse, chain);

        verify(chain).doFilter(servletRequest, servletResponse);
    }

    @Test
    public void doPostIP_denied() throws ServletException, IOException {
        when(cache.getValueAsString("allowedIPs")).thenReturn("10.0.0.1");

        when(servletRequest.getRemoteAddr()).thenReturn("1.2.3.1");

        IP_FILTER.init(config);
        IP_FILTER.doFilter(servletRequest, servletResponse, chain);

        verify(((HttpServletResponse) servletResponse)).sendError(HttpServletResponse.SC_NOT_FOUND);
    }

    @Test
    public void doPostIP_wildcard() throws ServletException, IOException {
        when(cache.getValueAsString("allowedIPs")).thenReturn("10.0.0.1,10.52.107.*,10.52.108.*");

        when(servletRequest.getRemoteAddr()).thenReturn("10.52.107.16");

        IP_FILTER.init(config);
        IP_FILTER.doFilter(servletRequest, servletResponse, chain);

        verify(chain).doFilter(servletRequest, servletResponse);
    }

    @Test
    public void doPostIP_wildcard2() throws ServletException, IOException {
        when(cache.getValueAsString("allowedIPs")).thenReturn("10.0.0.1,10.52.107.*,10.52.108.*");

        when(servletRequest.getRemoteAddr()).thenReturn("10.52.108.33");

        IP_FILTER.init(config);
        IP_FILTER.doFilter(servletRequest, servletResponse, chain);

        verify(chain).doFilter(servletRequest, servletResponse);
    }

    @SuppressWarnings("unchecked")
    public void configureCache() throws Exception {
        Context envCtx = mock(Context.class);

        Connection conn = mock(Connection.class);

        DataSource dataSource = mock(DataSource.class);
        when(dataSource.getConnection()).thenReturn(conn);

        InitialContext initCtx = mock(InitialContext.class);
        when(initCtx.lookup("java:comp/env")).thenReturn(envCtx);
        when(envCtx.lookup("jdbc/datasource")).thenReturn(dataSource);
        when(envCtx.lookup("data-source-owner-user")).thenReturn("admin");
        when(envCtx.lookup("bd-param-context")).thenReturn("teste");

        whenNew(InitialContext.class).withNoArguments().thenReturn(initCtx);

        cache = mock(CachedParamXmlImpl.class);
        when(cache.cacheGetKeys()).thenReturn(Collections.EMPTY_LIST);

        mockStatic(CachedParamXmlImpl.class);
        when(CachedParamXmlImpl.getInstance()).thenReturn(cache);
    }
}
