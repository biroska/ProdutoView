package br.com.serasa.exception;

import junit.framework.Assert;

import org.junit.Test;

public class ErrosMapTest {
	
	private String sistemaIndisponivel = "Sistema temporariamente fora do ar. Tente mais tarde.";
	
	@Test
	public void testGetMsgErrorCpfInvalido() {
		String resultadoEsperado = "CPF informado inv&aacute;lido. Emiss&atilde;o do Certificado n&atilde;o permitida.";
		
		String result = ErrorsMap.getMsgError("01");
		Assert.assertEquals(result, resultadoEsperado);
		System.out.println(ErrorsMap.getMsgError("01"));
	}
	
	@Test
	public void testGetMsgErrorCpfInexistente() {
		String resultadoEsperado = "CPF informado inexistente nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.";
		String result = ErrorsMap.getMsgError("02");
		Assert.assertEquals(result, resultadoEsperado);
	}
	
	@Test
	public void testGetMsgErrorCpfCancelado() {
		String resultadoEsperado = "O CPF informado se encontra na situa&ccedil;&atilde;o cadastral de CANCELADO nas bases de dados da SRF. Emiss&atilde;o do certificado n&atilde;o permitida.";
		
		String result = ErrorsMap.getMsgError("03");
		Assert.assertEquals(result, resultadoEsperado);
		System.out.println(result);
	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro90() {

		String result = ErrorsMap.getMsgError("90");
		Assert.assertEquals(result, sistemaIndisponivel);
	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro91() {

		String result = ErrorsMap.getMsgError("91");
		Assert.assertEquals(result, sistemaIndisponivel);

	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro92() {
		
		String result = ErrorsMap.getMsgError("92");
		Assert.assertEquals(result, sistemaIndisponivel);

	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro93() {
		
		String result = ErrorsMap.getMsgError("93");
		Assert.assertEquals(result, sistemaIndisponivel);

	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro94() {
		
		String result = ErrorsMap.getMsgError("94");
		Assert.assertEquals(result, sistemaIndisponivel);

	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro95() {
		
		String result = ErrorsMap.getMsgError("95");
		Assert.assertEquals(result, sistemaIndisponivel);

	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro96() {
		
		String result = ErrorsMap.getMsgError("96");
		Assert.assertEquals(result, sistemaIndisponivel);

	}
	
	@Test
	public void testGetMsgErrorSistemaIndisponivelErro97() {
		
		String result = ErrorsMap.getMsgError("97");
		Assert.assertEquals(result, sistemaIndisponivel);

	}

}
