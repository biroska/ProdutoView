package br.com.serasa.consultaprevia;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import br.com.serasa.exception.TrataErros;

public class ConsPreviaValidateCommandTest {
    
    private static final String XML_PF = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>12345678909</cpf><cnpj /><dtnasc>12121966</dtnasc></consprev>";
    private static final String XML_PF_CNPJ = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>12345678909</cpf><cnpj>00958378000100</cnpj><dtnasc>12121966</dtnasc></consprev>";
    private static final String XML_PF_INVALID_CPF = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>12345678900</cpf><cnpj /><dtnasc>12121966</dtnasc></consprev>";
    private static final String XML_PF_INVALID_DATE1 = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>12345678900</cpf><cnpj /><dtnasc>12131966</dtnasc></consprev>";
    private static final String XML_PF_INVALID_DATE2 = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>12345678900</cpf><cnpj /><dtnasc></dtnasc></consprev>";
    private static final String XML_PF_INVALID_DATE3 = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>1</tipo-cert><cpf>12345678900</cpf><cnpj /><dtnasc>121219</dtnasc></consprev>";
    private static final String XML_PJ = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>2</tipo-cert><cpf>11122233396</cpf><cnpj>00958378000100</cnpj><dtnasc>01011900</dtnasc></consprev>";
    private static final String XML_PJ_INVALID_CNPJ = "<consprev><tipo-msg>REQ</tipo-msg><tipo-cert>2</tipo-cert><cpf>11122233396</cpf><cnpj>00958378000101</cnpj><dtnasc>01011900</dtnasc></consprev>";

    private HttpServletRequest req;
    
    @Before
    public void before() {
        req = Mockito.mock(HttpServletRequest.class);        
    }
    
    @Test 
    public void testConsultaPf() throws Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("0");
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertTrue(consulta.executeAction(req, null));      
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaPfComCnpj() throws Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("0");
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaPfInvalidCpf() throws Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_CPF);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");        
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));    
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaPfInvalidDate1() throws Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_DATE1);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");        
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaPfInvalidDate2() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_DATE2);
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaPfInvalidDate3() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_INVALID_DATE3);
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));
    }
    
    @Test
    public void testConsultaPj() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ);
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertTrue(consulta.executeAction(req, null));
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaPjInvalidCnpj() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ_INVALID_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");        
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));
    }
    
    @Test
    public void testConsultaSimplesPf() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertTrue(consulta.executeAction(req, null));
    }
    
    @Test (expected =  TrataErros.class)
    public void testConsultaSimplesPfComCnpj() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PF_CNPJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertFalse(consulta.executeAction(req, null));
    }
    
    @Test
    public void testConsultaSimplesPj() throws TrataErros, Exception {
        Mockito.when(req.getParameter("xml")).thenReturn(XML_PJ);
        Mockito.when(req.getParameter("provConsSimples")).thenReturn("1");
        ConsPreviaValidateCommand consulta = new ConsPreviaValidateCommand();
        Assert.assertTrue(consulta.executeAction(req, null));
    }

}
