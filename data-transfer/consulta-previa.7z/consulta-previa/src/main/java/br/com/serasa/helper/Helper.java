package br.com.serasa.helper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Um Helper cria um Command a partir de um par�metro action, e delega para este Command a execu��o da a��o. � uma ponte
 * entre o Servlet e os Command.
 * 
 * @author riko
 * @created 10 de outubro de 2003
 */
public interface Helper {

    /**
     * Valor da chave no Map para o objeto java.sql.Connection
     */
    public final static String PARAM_CONNECTION = "java.sql.connection";

    /**
     * A partir de action, cria um command para executar a a��o.
     * 
     * @param action Par�metro action do Request
     * @exception NoSuchActionException Se nenhum Command existir para tal action
     */
    public void setAction(String action) throws NoSuchActionException;

    /**
     * Retorna a p�gina de erro padr�o para este Helper
     * 
     * @return Nome da p�gina de erro. Dever� ser precedida de "/", retornando o caminho relativo ao contexto web e o
     *         nome da p�gina. Ex: "/erroGeral.jsp"
     */
    public String getErrorPage();

    /**
     * Delega ao Command a execu��o da a��o. Se ocorrer algum erro, recupera do Command a lista de erros, cria um
     * ErrorBean e insere no Request, retornando false para o Servlet.
     * 
     * @param request Request do Http
     * @param paramMap Map dos parametros iniciais do Servlet, contendo tamb�m parametros que o Servlet possa inserir
     *        durante a requisi��o, como a conex�o com o BD.
     * @return Retorna true se execu��o for ok, false c.c.
     */
    public boolean executeAction(HttpServletRequest request, Map<String, String> paramMap) throws Exception;
}
