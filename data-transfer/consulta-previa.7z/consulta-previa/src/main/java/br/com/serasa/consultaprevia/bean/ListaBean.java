/*
 * Created on 22/01/2004
 */
package br.com.serasa.consultaprevia.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dadario
 */
public class ListaBean {

    private List<Object> lista = new ArrayList<Object>();

    /**
     * @return Returns the lista.
     */
    public List<Object> getLista() {
        return lista;
    }

    /**
     * @param lista The lista to set.
     */
    public void setLista(List<Object> lista) {
        this.lista = lista;
    }

    /**
     * @param certificado
     */
    public void add(Object object) {
        lista.add(object);
    }

    /**
     * @return Returns the linhasAfetadas.
     */
    public int getLinhasAfetadas() {
        return lista.size();
    }
}
