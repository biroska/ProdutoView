/*
 * Created on 22/08/2003
 */
package br.com.serasa.helper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import br.com.serasa.servlets.bean.ErrorBean;

/**
 * Implementa alguns m�todos que possam ser comuns aos Helpers. No caso normal, Helpers dever�o apenas implementar o
 * m�todo setAction() e definir algumas constantes como por exemplo valores para o action. Cont�m um Command, que dever�
 * ser inicializado em setAction antes de ser invocado o m�todo executeAction().
 * 
 * @author riko
 * @created 10 de Outubro de 2003
 * 
 */
public abstract class HelperImpl implements Helper {

    /**
     * Interface command
     */
    protected Command command;

    /**
     * @return Nome da p�gina de erro
     * 
     */
    public String getErrorPage() {
        return "/erroGeral.jsp";
    }

    /**
     * Delega ao Command a execu��o da a��o. Se ocorrer erro, recupera do Command a lista de erros, insere-os em um
     * ErrorBean e retorna false.
     * 
     * @return true se executar ok, false c.c. Se Command for null (n�o inicializado) retorna false.
     */
    public boolean executeAction(HttpServletRequest request, Map<String, String> paramMap) throws Exception {
        if (command == null) {
            ErrorBean errorBean = new ErrorBean("Erro interno: Command n�o foi inicializado (null)");
            request.setAttribute("errorBean", errorBean);
            return false;
        }
        if (!command.executeAction(request, paramMap)) {
            final String[] errors = command.getErrors();
            ErrorBean errorBean = new ErrorBean(errors);
            request.setAttribute("errorBean", errorBean);
            return false;
        }
        return true;
    }
}
