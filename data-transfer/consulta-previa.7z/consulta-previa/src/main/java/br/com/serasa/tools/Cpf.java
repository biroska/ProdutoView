/*
 * Created on 20/02/2004
 */
package br.com.serasa.tools;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dadario
 * 
 */
public class Cpf {

    private static List<String> CPF_INVALIDOS = new ArrayList<String>();

    private static final int MAX_TAMANHO_CPF = 11;

    static {
        CPF_INVALIDOS.add("00000000000");
        CPF_INVALIDOS.add("11111111111");
        CPF_INVALIDOS.add("22222222222");
        CPF_INVALIDOS.add("33333333333");
        CPF_INVALIDOS.add("44444444444");
        CPF_INVALIDOS.add("55555555555");
        CPF_INVALIDOS.add("66666666666");
        CPF_INVALIDOS.add("77777777777");
        CPF_INVALIDOS.add("88888888888");
        CPF_INVALIDOS.add("99999999999");
    }

    /**
     * Gets the cpfValid attribute of the DataValidator class
     * 
     * @param cpf Description of the Parameter
     * @return The cpfValid value
     */
    public static boolean isCpfValid(String cpf) {

        if (!(cpf.length() == 11) || CPF_INVALIDOS.contains(cpf)) {
            return false;
        }

        int num[] = new int[11];

        // d�gitos verificadores
        int dv1;

        // d�gitos verificadores
        int dv2;

        // auxiliares no c�lculo
        int soma;

        // auxiliares no c�lculo
        int resto;

        // guarda os n�meros em um vetor de inteiros para c�lculos posteriores
        for (int i = 0; i < 11; i++) {
            num[i] = Integer.parseInt(cpf.substring(i, i + 1));
        }

        // calcula o primeiro d�gito verificador

        soma = 10 * num[0] + 9 * num[1] + 8 * num[2] + 7 * num[3] + 6 * num[4] + 5 * num[5] + 4 * num[6] + 3 * num[7]
               + 2 * num[8];

        resto = soma % 11;
        dv1 = 11 - resto;

        if (dv1 > 9) {
            dv1 = 0;
        }

        // verifica se o primeiro d�gito verificador est� correto
        if (dv1 == num[9]) {
            // calcula o segundo d�gito verificador

            soma = 11 * num[0] + 10 * num[1] + 9 * num[2] + 8 * num[3] + 7 * num[4] + 6 * num[5] + 5 * num[6] + 4
                   * num[7] + 3 * num[8] + 2 * num[9];

            resto = soma % 11;
            dv2 = 11 - resto;

            if (dv2 > 9) {
                dv2 = 0;
            }

            if (dv2 == num[10]) {
                return true;
            }

            return false;
        }

        return false;
    }

    /**
     * @param retorno
     * @return
     */
    public static String colocarZeros(String cpf) {
        return Formatter.adicioneZerosAFrente(cpf, MAX_TAMANHO_CPF);
    }

}
