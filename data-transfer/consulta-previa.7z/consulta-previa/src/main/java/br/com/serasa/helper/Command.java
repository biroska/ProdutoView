package br.com.serasa.helper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Um command executa uma a��o espec�fica (valida��o, inser��o etc). O Helper apenas delega a execu��o para o Command.
 * Este � respons�vel por:
 * <ul>
 * <li>manter a lista de erros que possoa ocorrer;
 * <li>Gerar e inicializar os beans (a partir de um HttpServletRequest ou do BD)
 * <li>Inserir valores (beans) se necess�rio no HttpServletRequest
 * 
 * @author riko
 * @created 10 de outubro de 2003
 */
public interface Command {

    /**
     * Lista de erros
     * 
     * @return Um array de string contendo as mensagens de erro, se n�o existir nenhum erro retorna null
     */
    public String[] getErrors();

    /**
     * Executa a��o correspondente ao Command. Id�ia: - pegar do request os dados e criar os beans desejados - pegar do
     * initMap dados que est�o no init do Servlet (web.xml) que forem desejados - executar a��o correspondente - inserir
     * os beans no request se necess�rio
     * 
     * @param request Request do HTTP
     * @param paramMap Dados de inicializa��o do servlet, conex�o com BD etc.
     * @return Retorna true se execu��o for ok, false c.c.. Neste caso, os erros estar�o em uma lista de erros
     *         (recuperadas pelo getErrors()).
     */
    //public boolean executeAction(HttpServletRequest request, Map paramMap);
    public boolean executeAction(HttpServletRequest request, Map<String, String> paramMap) throws Exception;
}
