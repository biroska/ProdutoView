package br.com.serasa.exception;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.consultaprevia.ErrorsMap;

public class TrataErros extends ConsultaPreviaException {

    /**
     * 
     */
    private static final long serialVersionUID = 448624650120383806L;

    private String mensagemErro;

    private String codigoErro;

    //mensagem Serpro
    private String conteudoRetorno;

    private ErrorsMap erros;

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    public TrataErros() {
        super();
        erros = new ErrorsMap();

    }

    //adicionada mensagem do Serpro (conteudoRetorno)
    public TrataErros(String codigoErro, String mensagemErro, String conteudoRetorno) {
        erros = new ErrorsMap();
        try {
            addErro(mensagemErro, codigoErro, conteudoRetorno);
        } catch (ConsultaPreviaException e) {
            log.info("Erro..: {}", e.getMessage());
        }
    }

    public TrataErros(String codigoErro, String mensagemErro) {
        erros = new ErrorsMap();
        try {
            addErro(mensagemErro, codigoErro);
        } catch (ConsultaPreviaException e) {
            log.info("Erro..: {}", e.getMessage());
        }
    }

    public void setErros(ErrorsMap erros) {
        this.erros = erros;
    }

    public ErrorsMap getErros() {
        return this.erros;
    }

    //adicionada mensagem do Serpro (conteudoRetorno)
    public void addErro(String mensagemErro, String codigoErro, String conteudoRetorno) throws ConsultaPreviaException {
        setCodigoErro(codigoErro);
        if (mensagemErro != null && !"".equals(mensagemErro.trim())){
        	setMensagemErro(mensagemErro);
        } else {
        	setMensagemErro(ErrorsMap.getMsgError(getCodigoErro()));
        }
        //setMensagemErro(mensagemErro);
        setConteudoRetorno(conteudoRetorno);
        throw new ConsultaPreviaException(getMensagemErro());
    }

    public void addErro(String mensagemErro, String codigoErro) throws ConsultaPreviaException {
        setCodigoErro(codigoErro);
        if (mensagemErro != null && !"".equals(mensagemErro.trim())){
        	setMensagemErro(mensagemErro);
        } else {
        	setMensagemErro(ErrorsMap.getMsgError(getCodigoErro()));
        }
        setMensagemErro(mensagemErro);
        setConteudoRetorno("");
        throw new ConsultaPreviaException(getMensagemErro());
    }

    public void setMensagemErro(String mensagemErro) {
        this.mensagemErro = mensagemErro;
        log.info(mensagemErro);
    }

    public String getMensagemErro() {
        return mensagemErro;
    }

    public void setCodigoErro(String codigoErro) {
        this.codigoErro = codigoErro;
    }

    public String getCodigoErro() {
        return codigoErro;
    }

    public String getConteudoRetorno() {
        return conteudoRetorno;
    }

    public void setConteudoRetorno(String conteudoRetorno) {
        this.conteudoRetorno = conteudoRetorno;
    }

    public CustomLogger getLog() {
        return log;
    }

    public void setLog(CustomLogger log) {
        this.log = log;
    }

}
