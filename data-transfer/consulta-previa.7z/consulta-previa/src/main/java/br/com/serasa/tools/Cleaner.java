/*
 * Created on 18/02/2004
 */
package br.com.serasa.tools;

/**
 * @author dadario
 * 
 */
public class Cleaner {

    public static String removeEndLine(String data) {

        if (Verify.isEmpty(data)) {
            return null;
        }
        String retorno = data.replaceAll("\r\n", "");
        return retorno.replaceAll("\n", "");
    }

    public static String removeAspas(String valor) {

        if (Verify.isEmpty(valor)) {
            return valor;
        }

        return valor.trim().replaceAll("[\'\"]", "");
    }

    public static String trocaCaracteresEspeciais(String valor) {

        if (Verify.isEmpty(valor)) {
            return valor;
        }

        String strRetorna = new String(valor);

        String informado = "�����������������������������������������������������@!?#$%<>{}_?\\[]|��,;=*+�������׿������������ߵ�ޯ�������������`^�~'\"";

        String convertido = "aeiouaeiouaeiouaeiouaocAEIOUAEIOUAEIOUAEIOUAOCaAnNyyY                                                                      ";

        char chInformado[] = informado.toCharArray();
        char chConvertido[] = convertido.toCharArray();

        for (int i = 0; i < informado.length() - 1; i++) {
            strRetorna = strRetorna.replace(chInformado[i], chConvertido[i]);
        }

        return strRetorna.trim().replaceAll("\\s+", " ");
    }

    public static String somenteLetrasNumeros(String str) {
    	
        String informado = trocaCaracteresEspeciais(str.toUpperCase());

        final String validos = "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        char chValidos[] = validos.toCharArray();
        char chInformado[] = informado.toCharArray();
        StringBuilder strRetorna = new StringBuilder();

        for (int i = 0; i < informado.length(); i++) {
            for (int j = 0; j < validos.length(); j++) {
                if (chInformado[i] != chValidos[j]) {
                    strRetorna.append("");
                } else {
                    strRetorna.append(chInformado[i]);
                }
            }
        }
        return strRetorna.toString().trim().toUpperCase();
    }

}
