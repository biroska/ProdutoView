package br.com.serasa.exception;

import br.com.serasa.consultaprevia.bean.ConsPreviaBean;

public class NaoConectouNaReceitaException extends Exception {

    private static final long serialVersionUID = -3405605845987972736L;

    private ConsPreviaBean consPreviaBean;

    public NaoConectouNaReceitaException(ConsPreviaBean consPreviaBean) {
        super();
        this.consPreviaBean = consPreviaBean;
    }

    public ConsPreviaBean getConsPreviaBean() {
        return consPreviaBean;
    }
}
