/*
 * Created on 20/02/2004
 */
package br.com.serasa.consultaprevia.bean.validator;

import br.com.serasa.consultaprevia.bean.validator.filtro.Filtro;
import br.com.serasa.consultaprevia.bean.validator.filtro.FiltroManager;
import br.com.serasa.tools.Verify;

/**
 * @author dadario
 */
public class Validador {

    /**
     * Valida um objeto BEAN com base no filtro fornecido. Pode ser encadeado varios filtros para fazer a validacao
     * 
     * @param bean
     * @param filtro
     * @return
     */
    public static ErroList validar(Object bean, FiltroManager filtroManager) {
        ErroList erros = new ErroList();
        validador(bean, filtroManager, erros);
        return erros;
    }

    /**
     * @param bean
     * @param filtroManager
     * @param erros
     */
    private static void validador(Object bean, FiltroManager filtroManager, ErroList erros) {
        if (Verify.isNull(bean)) {
            erros.add("Objeto bean &eacute; nulo para esta opera&ccedil;&atilde;o.");
            return;
        }

        while (filtroManager.hasNext()) {
            Filtro filtro = filtroManager.getFiltro();
            erros.setFiltroDaVez(filtro);
            filtro.setErros(erros);
            filtro.valida(bean);
        }
    }
}
