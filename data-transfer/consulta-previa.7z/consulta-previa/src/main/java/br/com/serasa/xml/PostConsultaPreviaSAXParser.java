package br.com.serasa.xml;

import java.io.IOException;
import java.io.StringReader;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import br.com.serasa.consultaprevia.bean.ConsPreviaBean;
import br.com.serasa.exception.TrataErros;
import br.com.serasa.tools.Cnpj;
import br.com.serasa.tools.Cpf;
import br.com.serasa.tools.Verify;

// import br.com.serasa.util.DataUtil;

/**
 * Classe que utilizada a biblioteca SAX para salvar os dados do xml POST_GESTAO_CICLO em um bean do tipo GestaoBean.
 * 
 * @author Emerson Tozette - 25/10/2005
 * 
 */
public class PostConsultaPreviaSAXParser extends DefaultHandler {

    private ConsPreviaBean consultaBean;

    private String qName;
    
    private static CustomLogger log = CustomLoggerFactory.getLogger(PostConsultaPreviaSAXParser.class);
    
    private final static String APACHE_DISALLOW_DOCTYPE = "http://apache.org/xml/features/disallow-doctype-decl";
    private final static String APACHE_LOAD_EXTERNAL_DTD  = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    private final static String SAX_EXTERNAL_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
    private final static String SAX_EXTERNAL_PARAMETER_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";

    public PostConsultaPreviaSAXParser() {
        consultaBean = new ConsPreviaBean();
        qName = "";
    }

    public ConsPreviaBean getConsPreviaBean() {
        return this.consultaBean;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.xml.sax.ContentHandler#startElement(java.lang.String,
     *      java.lang.String, java.lang.String, org.xml.sax.Attributes)
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attrs) {

        this.qName = qName;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.xml.sax.ContentHandler#endElement(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public void endElement(String uri, String localName, String qName) {

        this.qName = "";
    }

    /*
     * (non-Javadoc)
     *
     * @see org.xml.sax.ContentHandler#characters(char[], int, int)
     */
    @Override
    public void characters(char[] ch, int start, int length) {

        String conteudo = new String(ch, start, length);

        if (this.qName.equals("tipo-msg")) {
            consultaBean.setTpMsg(concatenarConteudo(consultaBean.getTpMsg(), conteudo));
        } else if (this.qName.equals("tipo-cert")) {
            consultaBean.setTpCert(concatenarConteudo(consultaBean.getTpCert(), conteudo));
        } else if (this.qName.equals("cpf")) {
            consultaBean.setCpf(concatenarConteudo(consultaBean.getCpf(), conteudo));

        } else if (this.qName.equals("cnpj")) {
            consultaBean.setCnpj(concatenarConteudo(consultaBean.getCnpj(), conteudo));

        } else if (this.qName.equals("dtnasc")) {
            consultaBean.setDtNasc(concatenarConteudo(consultaBean.getDtNasc(), conteudo));
        }
    }

    /**
     * Metodo auxiliar.
     * 
     * @param valorCampoBean
     * @param valorElementoXml
     * @return Devolve valorCampoBean concatenado com valorElementoXml, ou valorElementoXml caso valorCampoBean seja
     *         igual a null.
     */
    private String concatenarConteudo(String valorCampoBean, String valorElementoXml) {
        if (valorCampoBean == null)
            return valorElementoXml;
        return valorCampoBean + valorElementoXml;
    }

    /**
     * Salva o conteudo de um xml POST_GESTAO_CICLO em um bean ConsPreviaBean.
     * 
     * @param xml O xml em formato String
     * @return Um bean com os dados do xml
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws IOException
     */
    public static ConsPreviaBean processarXmlConsultaPrevia(HttpServletRequest req) throws TrataErros {
        PostConsultaPreviaSAXParser gestaoCicloParser = new PostConsultaPreviaSAXParser();

        String xml = PostConsultaPreviaSAXParser.obterXml(req);
        try {
            // 1) instancio a fabrica:
            // 2) com a fabrica instancio um parser:
            SAXParser saxParser = getSafeSaxParser();
            // 3) embrulho o xml (String) em um StringReader e em um
            // InputSource:
            InputSource source = new InputSource(new StringReader(xml));
            // 4) faco o parse:
            saxParser.parse(source, gestaoCicloParser);
        } catch (ParserConfigurationException pce) {
            //throw new TrataErros("-1", pce.getMessage());
            throw new TrataErros("-1", pce.getMessage(), "");
        } catch (SAXException se) {
            //throw new TrataErros("-1", se.getMessage());
            throw new TrataErros("-1", se.getMessage(), "");
        } catch (IOException ioe) {
            //throw new TrataErros("-1", ioe.getMessage());
            throw new TrataErros("-1", ioe.getMessage(), "");
        }

        return gestaoCicloParser.getConsPreviaBean();
    }

	private static SAXParser getSafeSaxParser() throws ParserConfigurationException, SAXException {
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		
		factory.setFeature( APACHE_DISALLOW_DOCTYPE, true);
		factory.setFeature( APACHE_LOAD_EXTERNAL_DTD, false);
		factory.setFeature( SAX_EXTERNAL_GENERAL_ENTITIES, false);
		factory.setFeature( SAX_EXTERNAL_PARAMETER_ENTITIES, false);
		
		factory.setXIncludeAware( false );
		factory.setValidating( true );
		
		SAXParser saxParser = factory.newSAXParser();
		
		return saxParser;
	}

    public static String obterXml(HttpServletRequest req) throws TrataErros {
        String xml = req.getParameter("xml");
        log.info(xml);
        if (xml == null || xml.trim().equals("")) {
            //throw new TrataErros("-1", "Foi recebido um XML vazio, ou o parametro XML nao foi enviado "
            //			       + "atraves do POST.");
            throw new TrataErros("-1", "<![CDATA[Foi recebido um XML vazio, ou o parametro XML nao foi enviado "
                                       + "atraves do POST.]]>", "");
        }

        return xml;
    }

    public void validarConsPreviaBean(ConsPreviaBean cons, boolean provConsSimples) throws TrataErros { 
    	
        verificaSeVazio(cons.getTpMsg(), "<tipo-msg>");
        if (!("REQ".equals(cons.getTpMsg())))
            //throw new TrataErros("-2", "O tipo da msg deve ser REQ");
            throw new TrataErros("-2", "<![CDATA[O tipo da msg deve ser REQ]]>", "");

        verificaSeVazio(cons.getTpCert(), "<tipo-cert>");
        // Se provier da Consulta Simples, tem que ser 1        
        if (provConsSimples && !(Verify.isPessoaFisica(cons.getTpCert()))) {
            //throw new TrataErros("-2", "O tipo da cert deve ser 1 = PF ou 2 = PJ ou 3 = Servidor");
            throw new TrataErros("-2", "<![CDATA[O tipo da cert deve ser 1 = PF]]>", "");
        } else if (!(Verify.isPessoaFisica(cons.getTpCert()) || Verify.isPessoaJuridica(cons.getTpCert()) || Verify
                .isServidor(cons.getTpCert()))) {
            //throw new TrataErros("-2", "O tipo da cert deve ser 1 = PF ou 2 = PJ ou 3 = Servidor");
            throw new TrataErros("-2", "<![CDATA[O tipo da cert deve ser 1 = PF ou 2 = PJ ou 3 = Servidor]]>", "");
        }
        
        verificaSeVazio(cons.getCpf(), "cpf");
        if (!(Cpf.isCpfValid(cons.getCpf())))
            //throw new TrataErros("-2", "O cpf � inv�lido");
            throw new TrataErros("-2", "<![CDATA[O cpf � inv�lido]]>", "");

        // Se provier da Consulta Simples, cnpj tem que ser populado.
        if (provConsSimples) {
        	verificaSeVazio(cons.getCnpj(), "cnpj");	
        }
        
        if (!(Verify.isEmpty(cons.getCnpj()))) {
            if (!(Cnpj.isValid(cons.getCnpj())))
                //throw new TrataErros("-2", "O Cnpj � inv�lido");
                throw new TrataErros("-2", "<![CDATA[O Cnpj � inv�lido]]>", "");
            // Se provier da Consulta Simples, essa verifica n�o tem que ser feita. 
            if (!(provConsSimples)) {
	            if ((Verify.isPessoaFisica(cons.getTpCert()))) {
	                //throw new TrataErros("-2", "O Cnpj s� � v�lido para pessoa juridica e para servidor");
	                throw new TrataErros("-2", "<![CDATA[O Cnpj s� � v�lido para pessoa juridica e para servidor]]>", "");
	            }
            }
        }

        verificaSeVazio(cons.getDtNasc(), "<dtnasc>");
        if (!(Verify.isValidDate(cons.getDtNasc()))) {
            //throw new TrataErros("-2", "A data � inv�lida");
            throw new TrataErros("-2", "<![CDATA[A data � inv�lida]]>", "");
        }

    }

    private void verificaSeVazio(String campo, String nomeCampo) throws TrataErros {
        if (campo == null || campo.trim().equals("")) {
            //throw new TrataErros("-3", "O campo " + nomeCampo + " nao pode conter um valor vazio");
            throw new TrataErros("-3", "<![CDATA[O campo " + nomeCampo + " nao pode conter um valor vazio]]>", "");
        }
    }

    public static void imprimir(ConsPreviaBean consultaBean) {
        log.info("<tipo-msg>..: {}", consultaBean.getTpMsg());
        log.info("<tipo-cert>.: {}", consultaBean.getTpCert());
        log.info("<cpf>.......: {}", consultaBean.getCpf());
        log.info("<cnpj>......: {}", consultaBean.getCnpj());
        log.info("<dtnasc>....: {}", consultaBean.getDtNasc());
        log.info("<tipo-msg>..: {}", consultaBean.getTpMsg());
        log.info("<codigo>....: {}", consultaBean.getCodRetorno());
        log.info("<texto>.....: {}", consultaBean.getNome());
    }
}
