package br.com.serasa.helper;

/**
 * Lan�ada se o valor do par�metro helper do HttpRequest n�o existir para um Helper a ser instanciado.
 * 
 * @author riko
 * @created 10 de Outubro de 2003
 */
public class NoSuchHelperException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = -5709986969291541632L;

    /**
     * Constructor for the NoSuchHelperException object
     * 
     * @param msg Description of the Parameter
     */
    public NoSuchHelperException(String msg) {
        super(msg);
    }
}
