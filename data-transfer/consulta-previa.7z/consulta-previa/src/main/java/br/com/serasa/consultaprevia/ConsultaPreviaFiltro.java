/*
 * Created on 03/03/2004
 */
package br.com.serasa.consultaprevia;

import java.text.ParseException;
import java.util.Date;

import br.com.serasa.consultaprevia.bean.ConsPreviaBean;
import br.com.serasa.consultaprevia.bean.validator.filtro.Filtro;
import br.com.serasa.tools.Cnpj;
import br.com.serasa.tools.Cpf;
import br.com.serasa.tools.Data;
import br.com.serasa.tools.Verify;

/**
 * @author dadario
 * 
 */
public class ConsultaPreviaFiltro extends Filtro {

    private ConsPreviaBean consPreviaBean;

    @Override
    public void valida(Object bean) {
        this.consPreviaBean = (ConsPreviaBean) bean;
        validateCPF();
        validateDtNasc();

        if (!ConsPreviaBean.TIPO_CERT_PF.equalsIgnoreCase(consPreviaBean.getTpCert())) {
        	validateCNPJ();
        }
    }

    /**
     * Valida��o da data de nascimento: somente datas ap�s 01/01/1900 e hoje,
     */
    private void validateDtNasc() {
        final String valor = limparCampo(consPreviaBean.getDtNasc());

        if (Verify.isEmpty(valor)) {
            addErro("Por favor, informe a data de nascimento do Respons�vel pelo Certificado no formato DDMMAAAA.");
            return;
        }
        if (valor.length() != 8) {
            addErro("Data de nascimento inv�lida: " + valor
                    + ". Por favor, informe a data de nascimento do Respons�vel pelo Certificado no formato DDMMAAAA.");
            return;
        }

        try {
            Date dataNascimento = Data.parse(Data.DATA_SEM_SEPARADOR, valor);
            Date dataLimite = Data.parse(Data.DATA_SEM_SEPARADOR, "01011900");

            if (Data.depoisDe(dataNascimento, new Date()) || Data.antesDe(dataNascimento, dataLimite)) {
                addErro("Data de nascimento inv�lida: " + valor
                        + ". Por favor, informe a data de nascimento do Respons�vel "
                        + "pelo Certificado no formado DDMMAAAA.");
            }
        } catch (ParseException e) {
            addErro("Data de nascimento inv�lida: " + valor
                    + ". Por favor, informe a data de nascimento do Respons�vel pelo Certificado no formado DDMMAAAA.");
        }

        consPreviaBean.setDtNasc(valor);
    }

    /**
     * Validacao de CPF. Se este tiver menos que 11 digitos, inserir zeros na frente. Neste caso, atualizar o valor do
     * cpf no JavaBean. Se tiver mais que 11 digitos, erro.
     */
    private void validateCPF() {
        String valor = limparCampo(consPreviaBean.getCpf());
        if (Verify.isEmpty(valor)) {
            addErro("Por favor, informe o CPF do Respons�vel pelo Certificado "
                    + "no formato 99999999999. N�o utilize pontos ou barras.");
        } else if (!Verify.isNumber(valor)) {
            addErro("Por favor, informe o CPF do Respons�vel pelo Certificado "
                    + "no formato 99999999999. N�o utilize pontos ou barras.");
        } else {
            valor = Cpf.colocarZeros(valor);

            if (!Cpf.isCpfValid(valor)) {
                addErro("D�gito do CPF incorreto. Por favor, informe o CPF do Respons�vel pelo"
                        + " Certificado no formato 99999999999. N�o utilize pontos ou barras.");
            }
        }
        consPreviaBean.setCpf(valor);

    }

    /*
     private void validateTituloEleitor() {
     String valor = limparCampo(consPreviaBean.getNumTitulo());
     if (Verify.isEmpty(valor)) {
     addErro("Por favor, informe o T�tulo de Eleitor do Respons�vel pelo Certificado no formato 999999999999." +
     " N�o utilize pontos ou barras.");
     } else if (!Verify.isNumber(valor)) {
     addErro("Por favor, informe o T�tulo de Eleitor do Respons�vel pelo Certificado no formato 999999999999. " +
     "N�o utilize pontos ou barras.");
     } else {

     valor = Formatter.adicioneZerosAFrente(valor, 12);
     if ("000000000000".equalsIgnoreCase(valor)) {
     addErro("Por favor, informe o T�tulo de Eleitor do Respons�vel pelo Certificado no formato 999999999999. " +
     "N�o utilize pontos ou barras.");
     }
     }
     consPreviaBean.setNumTitulo(valor);
     }
     */
    private void validateCNPJ() {
        String valor = consPreviaBean.getCnpj();
        if (Verify.isEmpty(valor)) {
            addErro("Por favor, informe o CNPJ da empresa requerente.");
        } else if (!Verify.isNumber(valor)) {
            addErro("Por favor, informe o CNPJ no formato 99999999999999. N�o utilize pontos ou barras.");
        } else {
            if (!Cnpj.isValid(valor)) {
                addErro("D�gito do CNPJ incorreto. Por favor, informe o CNPJ no formato 99999999999999."
                        + " N�o utilize pontos ou barras.");
            }
        }

        consPreviaBean.setCnpj(valor);
    }
}
