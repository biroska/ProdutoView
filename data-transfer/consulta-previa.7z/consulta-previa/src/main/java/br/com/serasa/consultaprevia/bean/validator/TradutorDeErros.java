/*
 * Created on 27/02/2004
 */

package br.com.serasa.consultaprevia.bean.validator;

import java.util.HashMap;
import java.util.Map;

// import br.com.serasa.consultaprevia.bean.validator.filtro.*;

/**
 * @author riko
 * 
 */
public class TradutorDeErros {
    public static final String DADOS_DA_FATURA = "-> Dados da Fatura";

    public static final String DADOS_DO_1_REPRESENTANTE_LEGAL = "-> Dados do 1&ordm; Representante Legal";

    public static final String DADOS_DO_REPRESENTANTE_LEGAL = "-> Dados do 2&ordm; Representante Legal";

    public static final String DADOS_DA_EMPRESA_DO_REQUERENTE = "-> Dados do Requerente";

    public static final String DADOS_DO_REQUERENTE = "-> Dados do Requerente";

    public static final String DADOS_DO_EXCLUSIVOS = "-> Dados do Exclusivos";

    public static final String DADOS_DO_CERTIFICADO = "-> Dados do Certificado";

    public static final String DADOS_DO_RESPONSAVEL = "-> Dados do Respons&aacute;vel pelo Uso do Certificado";

    public static final Object DADOS_DA_SENHA = "->Senha de Revoga&ccedil;&atilde;o";

    public static final String DADOS_DO_OU_AMCHAM = "-> Dados exclusivos da AMCHAM";

    public static final String DADOS_FATURA = "-> Dados de Cobran&ccedil;a";

    private static final Map<String, String> NOME_ERROS = new HashMap<String, String>();

    static {
        // Area dos filtros utilizados com Cliente Fisico
        //NOME_ERROS.put(UserBeanComSenhaFiltro.class.getName(), DADOS_DA_SENHA);
        //NOME_ERROS.put(SimplesUserBeanFiltro.class.getName(), DADOS_DO_RESPONSAVEL);
        //NOME_ERROS.put(CertificadoBeanComPkcs10Filtro.class.getName(), DADOS_DO_CERTIFICADO);
        //NOME_ERROS.put(SimplesCertificadoBeanFiltro.class.getName(), DADOS_DO_CERTIFICADO);

        // Filtros para os campos de OU
        //NOME_ERROS.put(AmchamOUFiltro.class.getName(), DADOS_DO_EXCLUSIVOS);
        //NOME_ERROS.put(BryOUFiltro.class.getName(), DADOS_DO_EXCLUSIVOS);
        //NOME_ERROS.put(ServidorOuFiltro.class.getName(), DADOS_DO_EXCLUSIVOS);
        //NOME_ERROS.put(SpbOuFiltro.class.getName(), DADOS_DO_EXCLUSIVOS);

        // Filtros para os cliente de pessoa Jurica
        //NOME_ERROS.put(SimplesPjBeanFiltro.class.getName(), DADOS_DO_REQUERENTE);
        //NOME_ERROS.put(SimplesEmpresaBeanFiltro.class.getName(), DADOS_DA_EMPRESA_DO_REQUERENTE);
        //NOME_ERROS.put(SimplesRepresentanteBeanFiltro.class.getName(), DADOS_DO_REPRESENTANTE_LEGAL);
        //NOME_ERROS.put(SimplesServerCertificadoBeanFiltro.class.getName(), DADOS_DO_CERTIFICADO);

        // Filtros para o Servidor
        //NOME_ERROS.put(SimplesServerBeanFiltro.class.getName(), DADOS_DO_REQUERENTE);
        //NOME_ERROS.put(SimplesFaturaBeanFiltro.class.getName(), DADOS_DA_FATURA);
        //NOME_ERROS.put(SimplesServerCertificadoBeanFiltro.class.getName(), DADOS_DO_CERTIFICADO);
        //NOME_ERROS.put(CertificadoBeanSemPkcs10Filtro.class.getName(), DADOS_DO_CERTIFICADO);

        // Filtro para o Representante Principal
        //NOME_ERROS.put(RepresentantePrincipalBeanFiltro.class.getName(), DADOS_DO_1_REPRESENTANTE_LEGAL);

        // Filtro para AMCHAM OU
        //NOME_ERROS.put(AmchamOUFiltro.class.getName(), DADOS_DO_OU_AMCHAM);

        // Filtro para FATURA
        //NOME_ERROS.put(FaturaFiltro.class.getName(), DADOS_FATURA);
    }

    public static String descricaoErro(String chave) {
        if (NOME_ERROS.containsKey(chave)) {
            return NOME_ERROS.get(chave);
        }
        return "";
    }

    public static void addTraducao(String nomeErro, String texto) {
        NOME_ERROS.put(nomeErro, texto);
    }

}
