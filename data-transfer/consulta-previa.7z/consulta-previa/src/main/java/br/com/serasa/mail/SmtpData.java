/*
 * Created on 10/12/2003
 */
package br.com.serasa.mail;

/**
 * @author riko
 * 
 */
public class SmtpData {

    private String host;

    private String username;

    private String password;

    private SmtpData(String host) {
        this(host, null, null);
    }

    private SmtpData(String host, String userName, String password) {
        this.host = host;
        this.username = userName;
        this.password = password;
    }

    public static SmtpData getInstance(String host) {
        return new SmtpData(host);
    }

    public static SmtpData getInstance(String host, String userName, String password) {
        return new SmtpData(host, userName, password);
    }

    /**
     * Se username e password forem null, nao autentica.
     * 
     * @return Returns the authenticated.
     */
    public boolean isAuthenticated() {
        return !isEmptyString(username) || !isEmptyString(password);
    }

    private boolean isEmptyString(String toCheck) {
        return toCheck == null || "".equals(toCheck.trim());
    }

    /**
     * @return Returns the host.
     */
    public String getHost() {
        return host;
    }

    /**
     * @return Returns the password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * @return Returns the username.
     */
    public String getUsername() {
        return username;
    }

}
