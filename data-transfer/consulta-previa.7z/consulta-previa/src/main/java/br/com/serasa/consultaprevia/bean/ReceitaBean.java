/**
 * 
 */
package br.com.serasa.consultaprevia.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Tiziano
 * 
 */
public class ReceitaBean {
    private List<String> ipsReceita = new ArrayList<String>();

    private int portReceita;

    private List<String> urlsReceita = new ArrayList<String>();

    private int currentIndex = 0;

    public ReceitaBean() {}

    public ReceitaBean(Map<String, String> paramMap) {
        setIpsReceita(paramMap);
        setPortReceita(paramMap);
        setUrlsReceita(paramMap);
    }

    private void setIpsReceita(Map<String, String> paramMap) {
        StringTokenizer tok = new StringTokenizer((String) paramMap.get("HOST_RECEITA"), ",");
        while (tok.hasMoreTokens()) {
            String ip = tok.nextToken();
            //logger.info("Adicionando ip " + ip);
            ipsReceita.add(ip);
        }
    }

    public String getCurrentIpReceita() {
        return ipsReceita.get(currentIndex);
    }

    private void setPortReceita(Map<String, String> paramMap) {
        this.portReceita = Integer.parseInt((String) paramMap.get("PORT_RECEITA"));
    }

    public int getPortReceita() {
        return this.portReceita;
    }

    private void setUrlsReceita(Map<String, String> paramMap) {
        StringTokenizer tok = new StringTokenizer((String) paramMap.get("URL_RECEITA"), ",");
        while (tok.hasMoreTokens()) {
            String url = tok.nextToken();
            //logger.info("Adicionando url " + url);
            urlsReceita.add(url);
        }
    }

    public String getCurrentUrlReceita() {
        return this.urlsReceita.get(currentIndex);
    }

    public void setCurrentIndex(int currentIndex) {
        this.currentIndex = currentIndex;
    }

    public int urlsQty() {
        return urlsReceita.size();
    }
}
