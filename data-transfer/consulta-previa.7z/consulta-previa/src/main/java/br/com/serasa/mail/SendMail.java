package br.com.serasa.mail;

import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

public class SendMail {

    private SmtpData smtpData;

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());
    
    SendMail(SmtpData smtpData) {
        this.smtpData = smtpData;
    }

    public static SendMail getInstance(SmtpData smtpData) {
        return new SendMail(smtpData);
    }

    public void sendMail(MailBean mailBean) throws MessagingException {
        boolean emailSent;

        Session session = smtpData.isAuthenticated() ? createAuthenticatedSession(mailBean) : createSession(mailBean);

        // create a message
        MimeMessage msg = new MimeMessage(session);

        // set the from and to address
        InternetAddress addressFrom = new InternetAddress(mailBean.getRemetente());
        msg.setFrom(addressFrom);
        log.info("++ mail from: {}", mailBean.getRemetente());

        String destinatarios[] = mailBean.getDestinatarios();
        InternetAddress[] addressTo = new InternetAddress[destinatarios.length];
        log.info("++ mail to:");
        for (int i = 0; i < destinatarios.length; i++) {
            addressTo[i] = new InternetAddress(destinatarios[i]);
            log.info("++++ {}", destinatarios[i]);
        }

        msg.setRecipients(Message.RecipientType.TO, addressTo);
        msg.setSentDate(new Date());

        msg.setSubject(mailBean.getAssunto(), "ISO-8859-1");
        log.info("++ mail subject: {}", mailBean.getAssunto());

        //Altera��o para enviar em formato HTML para ajustar os acentos.
        BodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setDataHandler(new DataHandler(mailBean.getConteudo(), "text/html; charset=ISO-8859-1"));
        MimeMultipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);

        //msg.setContent(mailBean.getConteudo(), "text/plain");
        msg.setContent(multipart);
        msg.setHeader("X-Mailer", "JavaMailer");
        log.info("++ mail: {}", mailBean.getConteudo());

        // riko 20/12/2004: utilizando Transport da Session criada anteriormente para autentica��o
        if (smtpData.isAuthenticated()) {
            try {
                log.info("Authenticating smtp and sending...");
                Transport transport = session.getTransport();
                msg.saveChanges();
                transport.connect();
                transport.sendMessage(msg, addressTo);
                transport.close();
                emailSent = true;
            } catch (Exception e) {
                emailSent = false;
            }

        } else {
            try {
                log.info("Sending without authentication...");
                Transport.send(msg);
                emailSent = true;
            } catch (Exception e) {
                emailSent = false;
            }

        }
        log.info("");
        if (emailSent == true) {
            log.info("***** OK: Mail Sent *****");
        } else if (emailSent == false) {
            log.info("***** FAILED: Mail Not Sent *****");
        }

    }

    private Session createSession(MailBean mailBean) {
        log.info(">createSession()");
        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", smtpData.getHost());
        props.put("mail.smtp.auth", "false");

        return Session.getDefaultInstance(props);
    }

    /**
     * @param smtp_host_name2
     * @param smtp_auth_user2
     * @param smtp_auth_pwd2
     * @return
     */
    private Session createAuthenticatedSession(MailBean mailBean) {
        log.info(">createAuthenticatedSession()");
        //Set the host smtp address
        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", smtpData.getHost());
        props.put("mail.smtp.auth", "true");

        Authenticator auth = new SMTPAuthenticator(smtpData.getUsername(), smtpData.getPassword());
        return Session.getDefaultInstance(props, auth);
    }

    /**
     * SimpleAuthenticator is used to do simple authentication when the SMTP server requires it.
     */
    private class SMTPAuthenticator extends javax.mail.Authenticator {

        private String username;

        private String password;

        SMTPAuthenticator(String username, String password) {
            this.username = username;
            this.password = password;
        }

        @Override
        public PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
        }
    }
}
