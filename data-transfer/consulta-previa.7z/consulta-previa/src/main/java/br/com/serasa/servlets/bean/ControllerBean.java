package br.com.serasa.servlets.bean;

/**
 * Description of the Class
 * 
 * @author Tiziano
 * @created 26 de Janeiro de 2006
 */
public class ControllerBean {

    private String xml;

    /**
     * Sets the nivel attribute of the ControllerBean object
     * 
     * @param nivel The new nivel value
     */
    public void setXml(String xml) {
        this.xml = xml;
    }

    public String getXml() {
        return this.xml;
    }
}
