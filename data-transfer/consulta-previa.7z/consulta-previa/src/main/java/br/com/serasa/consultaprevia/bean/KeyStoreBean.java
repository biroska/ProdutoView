package br.com.serasa.consultaprevia.bean;

import java.security.KeyStore;


public class KeyStoreBean {
    private String password;
    private KeyStore keystore;
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public KeyStore getKeystore() {
        return keystore;
    }

    public void setKeystore(KeyStore keystore) {
        this.keystore = keystore;
    }
}
