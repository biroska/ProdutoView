package br.com.serasa.helper;

/**
 * Lan�ada se n�o existir a��o correspondente.
 * 
 * @author riko
 * @created 10 de Outubro de 2003
 */
public class NoSuchActionException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = -4931513529515230871L;

    /**
     * Constructor for the NoSuchActionException object
     * 
     * @param msg Description of the Parameter
     */
    public NoSuchActionException(String msg) {
        super(msg);
    }
}
