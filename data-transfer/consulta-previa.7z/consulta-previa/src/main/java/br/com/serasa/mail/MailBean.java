/*
 * Created on 08/12/2003
 */
package br.com.serasa.mail;

import java.util.Arrays;
import java.util.StringTokenizer;

/**
 * Cont�m os atributos de um e-mail
 * 
 * @author riko
 * 
 */
public class MailBean {

    private String destinatarios[];

    private String remetente;

    private String assunto;

    private String conteudo;

    private String tipoEnvio; // externo/interno

    //private static final String TIPO_ENVIO_INTERNO = "1";

    private static final String TIPO_ENVIO_EXTERNO = "2";

    /**
     * @return Returns the assunto.
     */
    public String getAssunto() {
        return assunto;
    }

    /**
     * @param assunto The assunto to set.
     */
    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    /**
     * @return Returns the conteudo.
     */
    public String getConteudo() {
        return conteudo;
    }

    /**
     * @param conteudo The conteudo to set.
     */
    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    /**
     * @return Returns the remetente.
     */
    public String getRemetente() {
        return remetente;
    }

    /**
     * @param remetente The remetente to set.
     */
    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }

    /**
     * @return Returns the destinatarios.
     */
    public String[] getDestinatarios() {
        return destinatarios;
    }

    /**
     * @param destinatarios The destinatarios to set.
     */
    public void setDestinatarios(String[] destinatarios) {
    	if (destinatarios != null) {
    		this.destinatarios = Arrays.copyOf(destinatarios, destinatarios.length);
    	} 
    }

    public void setDestinatario(String destinatario) {
        if (destinatario == null) {
            this.destinatarios = null;
        } else {
            this.destinatarios = new String[1];
            this.destinatarios[0] = destinatario;
        }
    }

    /**
     * A partir de uma string contendo os e-mails separados por virgulas, quebra em varias strings, cria um array disso
     * e atribui o valor a destinatarios.
     * 
     * @param destinatariosEntreVirgulas String contendo e-mails separados por virgulas. Se possuir somente um, nao
     *        precisa ter virgulas. Se for null, seta o destinatarios como null.
     */
    public void splitAndAddDestinatarios(String destinatariosEntreVirgulas) {
        if (destinatariosEntreVirgulas == null) {
            setDestinatarios(null);
        } else {
            StringTokenizer tokenizer = new StringTokenizer(destinatariosEntreVirgulas, ", ");

            String resultado[] = new String[tokenizer.countTokens()];

            for (int i = 0; i < resultado.length && tokenizer.hasMoreTokens(); i++) {
                resultado[i] = tokenizer.nextToken();
            }
            setDestinatarios(resultado);
        }
    }

    /**
     * @return Returns the tipoEnvio.
     */
    public String getTipoEnvio() {
        return tipoEnvio;
    }

    /**
     * @param tipoEnvio The tipoEnvio to set.
     */
    public void setTipoEnvio(String tipoEnvio) {
        this.tipoEnvio = tipoEnvio;
    }

    public boolean isTipoEnvioExterno() {
        return TIPO_ENVIO_EXTERNO.equals(tipoEnvio);
    }

}
