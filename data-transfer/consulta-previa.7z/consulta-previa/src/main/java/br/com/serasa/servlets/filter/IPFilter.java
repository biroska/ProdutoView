package br.com.serasa.servlets.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.owasp.esapi.CustomLogger;
import org.owasp.esapi.CustomLoggerFactory;

import br.com.serasa.helper.CachedParamXmlImpl;

/**
 * Filtro de IP, que impede que se acesse o contexto de IPs nao permitidos Este filtro permite acesso apenas aos IPs
 * internos (172.*) e IPs que estao listados no web.xml
 * 
 * Criado em 27/03/2007
 * 
 * @author Hugo
 */
public class IPFilter implements Filter {

    private CustomLogger log = CustomLoggerFactory.getLogger(this.getClass().getName());

    // lista de IPs externos permitidos (lido do web.xml)
    private List<String> allowedExternalIPs;

    public void init(FilterConfig config) throws ServletException {
        try {
            // le a lista de IPs externos permitidos
            String ipList = CachedParamXmlImpl.getInstance().getValueAsString("allowedIPs");
            StringTokenizer tok = new StringTokenizer(ipList, ",");

            allowedExternalIPs = new ArrayList<String>();
            while (tok.hasMoreTokens()) {
                allowedExternalIPs.add(tok.nextToken());
            }

            log.info("IPs externos permitidos: {}", allowedExternalIPs);
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        String clientIP = request.getRemoteAddr();
        // se o IP esta na lista de permitidos, ou esta na rede interna, deixa acessar
        if (clientIP.startsWith("10.96.") || clientIP.startsWith("172.") || clientIP.startsWith("192.168.")
            || allowedExternalIPs.contains(clientIP)) {
            log.info("IP {} permitido", clientIP);
            chain.doFilter(request, response);
        } else {
            // verificar wildcard
            String[] ipSplit = clientIP.split("\\.");
            if (ipSplit.length == 4) {
                if (allowedExternalIPs.contains(ipSplit[0] + ".*")) {
                    log.info("IP RANGE[2] ALLOWED:" + clientIP);
                    log.info("IP {} permitido", clientIP);
                    chain.doFilter(request, response);
                } else if (allowedExternalIPs.contains(ipSplit[0] + "." + ipSplit[1] + ".*")) {
                    log.info("IP RANGE[3] ALLOWED:" + clientIP);
                    log.info("IP {} permitido", clientIP);
                    chain.doFilter(request, response);
                } else if (allowedExternalIPs.contains(ipSplit[0] + "." + ipSplit[1] + "." + ipSplit[2] + ".*")) {
                    log.info("IP RANGE[4] ALLOWED:" + clientIP);
                    log.info("IP {} permitido", clientIP);
                    chain.doFilter(request, response);
                } else {
                    log.info("IP {} nao permitido", clientIP);
                    // IP nao permitido, envia um erro de pagina nao encontrada (HTTP 404)
                    ((HttpServletResponse) response).sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            }
        }
    }

    public void destroy() {
        allowedExternalIPs = null;
    }
}
