/*
 * Created on 29/09/2003
 * 
 * To change the template for this generated file go to Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and
 * Comments
 */
package br.com.serasa.socket;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/**
 * @author riko
 * 
 *         To change the template for this generated type comment go to Window&gt;Preferences&gt;Java&gt;Code
 *         Generation&gt;Code and Comments
 */
public class ProxyAuthenticator extends Authenticator {

    private PasswordAuthentication authentication;

    public ProxyAuthenticator(String username, String password) {
        char passwordChars[] = password == null ? null : password.toCharArray();
        authentication = new PasswordAuthentication(username, passwordChars);
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return authentication;
    }
}
