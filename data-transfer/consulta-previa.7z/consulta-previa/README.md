# Consulta Prévia

Serviço responsável por buscar os dados de pessoas físicas e jurídicas na RFB.

## Getting Started

### Prerequisites

*	Java – JDK 8;
*	Tomcat 9 – Com configurações de SSL duplo;
*	Maven 3.5.4 – Deve utilizar o Java 6 durante a compilação;
*	Acesso ao bitbucket do time de E-ID;
*	Registrar os certificados para utilizar a aplicação;
*	Criar diretórios de log e properties;

### Installing

1.	Instalar o Java e configurar a sua variável de ambiente;<br/>

2.	Configurar o Tomcat conforme as orientações descritas em [Configuração do Tomcat com SSL duplo](https://confluenceglobal.experian.local/confluence/pages/viewpage.action?pageId=525864933).<br/>

3.	Configurar o Maven 3.5.4;<br/>
3.1.	Realizar o download do Maven;
3.2.	Utilizar o arquivo "_settings.xml_" disponível em: [settings.xml](https://confluenceglobal.experian.local/confluence/download/attachments/443524321/settings.xml?version=2&modificationDate=1565372443053&api=v2).<br/>

4.	Fazer o checkout da branch de trabalho criada no repositório: [Bitbucket Consulta Prévia](https://bitbucketglobal.experian.local/projects/SEEID/repos/consulta-previa/browse).<br/>

5.	Registrar os certificados para utilizar a aplicação;<br/>
5.1.		Realizar o download dos certificados em: [Confluence Certificados de Acessos ao Sistema AR](https://confluenceglobal.experian.local/confluence/display/SEEXEI/Certificados+de+Acessos+ao+Sistema+AR);<br/>
5.2.		Instalar os certificados, informando a senha: “**serasa**” e adicionando-os ao repositório: “**Pessoal**”.<br/>

6.	Criar diretórios de log;<br/>
6.1.		Criar os seguintes diretórios: “_\opt\IBM\WebSphere\app\logs_” e “_\opt\IBM\WebSphere\app\properties_”;<br/>
6.2.		Copiar o arquivo “_logback-consultaprevia.xml_” do diretório "_conf_" do projeto "_requisicao_" para a pasta: “_\opt\IBM\WebSphere\app\properties_”;<br/>

7.	Testar o acesso a aplicação: https://localhost:8443/consulta-previa/ .<br/>

### Database

| Ambiente  | datasource | database  | username  | password |
| :------------ |:---------------|:---------------|:---------------|:---------------|
| **Desenvolvimento** | jdbc/CicloReq| 10.96.165.72:1521:dbciclod |  prod | serasa |
| **Homologação** | jdbc/CicloConsultaPrevia | 10.96.166.123:1521:dbcicloh |  cofre de senhas |
| **Produção** | jdbc/CicloReq | spobrdbciclo02:1521:dbciclo |  | |
| **Produção** | jdbc/CicloReq | spobrdbciclo01:1521:dbciclo |  | |


### Application Server

**Websphere 8.5**

| Ambiente  | Servidor  | Clusters |
| :------------ |:---------------|:---------------|
| Desenvolvimento  | spobrwaseiddev1 |  spobrwaseiddev1Cell,node=spobrwaseiddev1Node,server=requisicao.cddesenv.intranet, cluster=cluster-requisicaoWS, cluster=cluster-requisicao |
| Homologação      | spobreidwashi01 |  cluster=cluster-requisicao, node=spobreidihshe01Node,server=requisicao-uat.certificadodigital.com.br, node=spobreidihshi01Node,server=requisicao.cdhomologa.intranet |
| Homologação      | spobreidwashi02 |  cluster=cluster-requisicao, node=spobreidihshi02Node,server=requisicao.cdhomologa.intranet, node=spobreidihshe02Node,server=requisicao-uat.certificadodigital.com.br |
| Produção	       | spobreidwas01   | |
| Produção	       | spobreidwas02   | |     
| Produção	       | spobreidwas03   | |
| Produção	       | spobreidwas04   | |
| Console Produção | spobreiddmgr    | |
